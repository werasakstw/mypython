var express = require('express')
var app = express()

app.get('/', 
	function(req, res) {
		res.send('Hello')
	}
)
app.get('/hi',
	(req, res) => {
		res.send('Hi')
	}
)
app.listen(8080)
console.log('Server running at http://127.0.0.1:8080');

// curl 127.0.0.1:8080
// curl 127.0.0.1:8080/hi
