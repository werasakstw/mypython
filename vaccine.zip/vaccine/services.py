from flask import Flask, render_template, request
from flask_admin import Admin, BaseView, expose
from flask_bootstrap import Bootstrap
from admins import StudentForm, stu_json, connect
from time import localtime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'hello123'
app.config['FLASK_ADMIN_SWATCH'] = 'cerulean'
bootstrap = Bootstrap(app)
admin = Admin(app, name='Services', template_mode='bootstrap3')

@app.route('/')
def index():
    return render_template('index.html')

class StudentView(BaseView):
    @expose('/')
    def index(self):
        return self.render('student_view.html')

    @expose('/add', methods=['GET', 'POST'])
    def add(self):
        now = '%4d-%02d-%02d' % localtime()[:3]
        form = StudentForm(sid='3-0000-00000-00-0', prefix_='นาย', name='John Rambo', \
            dept='วิทยาการคอมพิวเตอร์', status='ปี 1', phone='081-000-0000', \
            email='john@rambo.com', birth=now)
        if form.validate_on_submit():
            sid = form.sid.data
            prefix_ = form.prefix_.data
            name = form.name.data    
            dept = form.dept.data
            status = form.status.data
            phone = form.phone.data
            email = form.email.data
            birth = form.birth.data       
            db = connect().mydb
            tb = db['student']
            tb.insert_one(stu_json(sid, prefix_, name, dept, status, phone, email, birth))
            return 'Register ' + name + ' success.'
        return self.render('student_add.html', form=form)

    @expose('/find')
    def find(self):
        return self.render('student_find.html')
admin.add_view(StudentView(name='Student'))

@app.route('/student/find_by_name', methods=['POST'])
def student_find_by_name():
    if request.method == 'POST':
        name = request.form.get('name')
        db = connect().mydb
        tb = db['student']
        for s in tb.find({'name': name }, {'_id': False, 'sid': True, 'dept': True}):
            return str(s)
    return 'No found'

@app.route('/student/find_by_sid', methods=['POST'])
def student_find_by_sid():
    if request.method == 'POST':
        sid = request.form.get('sid')
        db = connect().mydb
        tb = db['student']
        for s in tb.find({'sid': sid }, {'_id': False, 'name': True, 'dept': True}):
            return str(s)
    return 'No found'
    
@app.route('/student/insert', methods=['POST'])
def student_insert():
    sid = request.form.get('sid')
    prefix_ = request.form.get('prefix_')
    name = request.form.get('name')
    dept = request.form.get('dept')
    status = request.form.get('status')
    phone = request.form.get('phone')
    email = request.form.get('email')
    birth = request.form.get('birth')
    db = connect().mydb
    tb = db['student']
    tb.insert_one(stu_json(sid, prefix_, name, dept, status, phone, email, birth))
    return 'Insert' + name + ' success.'

#------------------------------------------------------------------

if __name__ == '__main__':
    app.run(port=8080, debug=True)
