import pandas as pd
from admins import stu_json, fac_json
from requests import post

def send_post(path, data):
    return post(path, data=data).content.decode()
             
def student_insert():
    df = pd.read_csv('students.csv', encoding='ISO-8859-11' )
    for s in df.values:
        sj = stu_json(s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7])
        print(send_post('http://127.0.0.1:8080/student/insert', data=sj))
##student_insert()

def faculty_insert():
    df = pd.read_csv('faculty.csv', encoding='ISO-8859-11' )
    for s in df.values:
        sj = fac_json(s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7])
        print(send_post('http://127.0.0.1:8080/faculty/insert', data=sj))
faculty_insert()
