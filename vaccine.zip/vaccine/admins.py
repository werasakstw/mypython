﻿# pip install flask_pymongo
# pip install flask_wtf

from flask import Flask
from flask_admin import Admin

app = Flask(__name__)
app.config['SECRET_KEY'] = 'hello123'
app.config['FLASK_ADMIN_SWATCH'] = 'cerulean'
admin = Admin(app, name='Vaccine App', template_mode='bootstrap3')

from flask_wtf import FlaskForm as Form
from wtforms.fields import StringField, SubmitField, IntegerField
from wtforms import validators
from wtforms.validators import DataRequired, Length, NumberRange, Email
from wtforms.fields.html5 import DateField
import json
class StudentForm(Form):
    sid = StringField('Student Id', validators=[DataRequired(), Length(max=17)])
    prefix_ = StringField('Prefix', validators=[DataRequired(), Length(max=10)])
    name = StringField('Name', validators=[DataRequired(), Length(max=60)])
    dept = StringField('Department', validators=[DataRequired(), Length(max=30)])
    status = StringField('Status', validators=[DataRequired(), Length(max=30)])
    phone = StringField('Phone Number', validators=[DataRequired(), Length(max=12)])
    email = StringField('Email', validators=[DataRequired(), Length(max=30)])
    birth = StringField('Birth Date', validators=[DataRequired(), Length(max=10)])
    submit = SubmitField('Submit')

def stu_json(sid, prefix_, name, dept, status, phone, email, birth):
    return {"sid": sid, "prefix_": prefix_, "name": name, \
            "dept": dept, "status": status, \
            "phone": phone, "email": email, "birth": birth }

from flask_admin.contrib.pymongo import ModelView
class StudentView(ModelView):
    column_list = ('sid', 'prefix_', 'name', 'dept', 'status', 'birth')
    form = StudentForm

#-------------------------------------------------------------------

class FacultyForm(Form):
    fid = StringField('Faculty Id', validators=[DataRequired(), Length(max=17)])
    rank = StringField('Rank', validators=[DataRequired(), Length(max=20)])
    prefix_ = StringField('Prefix', validators=[DataRequired(), Length(max=10)])
    name = StringField('Name', validators=[DataRequired(), Length(max=60)])
    dept = StringField('Department', validators=[DataRequired(), Length(max=50)])
    phone = StringField('Phone Number', validators=[DataRequired(), Length(max=12)])
    email = StringField('Email', validators=[DataRequired(), Length(max=30)])
    birth = StringField('Birth Date', validators=[DataRequired(), Length(max=10)])
    submit = SubmitField('Submit')
    
def fac_json(fid, rank, prefix_, name, dept, phone, email, birth):
    return {"fid": fid, "rank": rank, "prefix_": prefix_, "name": name, \
            "dept": dept, "phone": phone, "email": email, "birth": birth }

class FacultyView(ModelView):
    column_list = ('fid', 'rank', 'prefix_', 'name', 'dept', 'birth')
    form = FacultyForm

#-------------------------------------------------------------------
    
class InjectionForm(Form):
    iid = StringField('Injection Id', validators=[DataRequired(), Length(max=10)])
    name = StringField('Name', validators=[DataRequired(), Length(max=60)])
    vaccine = StringField('Phone Number', validators=[DataRequired(), Length(max=12)])
    dose = IntegerField('Dose', validators=[DataRequired(), NumberRange(min=1, max=10)])
    date = StringField('Date', validators=[DataRequired(), Length(max=10)])
    location = StringField('Location', validators=[DataRequired(), Length(max=50)])
    athority = StringField('Athority', validators=[Length(max=60)])
    
def inj_json(iid, name, vaccine, dose, date, location, athority):
    return {"iid": iid, "name": name, "vaccine": vaccine, "dose": dose, \
            "date": date, "location": location, "athority": athority }

class InjectionView(ModelView):
    column_list = ('iid', 'name', 'vaccine', 'dose', 'date', 'location')
    form = InjectionForm


#-------------------------------------------------------------------

class ExaminationForm(Form):
    eid = StringField('Examination Id', validators=[DataRequired(), Length(max=10)])
    name = StringField('Name', validators=[DataRequired(), Length(max=60)])
    date = StringField('Date', validators=[DataRequired(), Length(max=10)])
    location = StringField('Location', validators=[DataRequired(), Length(max=50)])
    athority = StringField('Athority', validators=[Length(max=60)])
    result = StringField('Result', validators=[Length(max=50)])
    
def exa_json(eid, name, date, location, athority, result):
    return {"eid": eid, "name": name, "date": date, "location": location, \
            "athority": athority, "result": result }

class ExaminationView(ModelView):
    column_list = ('eid', 'name', 'date', 'location', 'result')
    form = ExaminationForm


#-------------------------------------------------------------------

class QueueForm(Form):
    qid = StringField('Queue Id', validators=[DataRequired(), Length(max=10)])
    name = StringField('Name', validators=[DataRequired(), Length(max=60)])
    todo = StringField('Todo', validators=[DataRequired(), Length(max=50)])
    date = StringField('Enqueue Date', validators=[DataRequired(), Length(max=10)])
  
def que_json(qid, name, todo, date):
    return {"qid": qid, "name": name, "todo": todo, "date": date }

class QueueView(ModelView):
    column_list = ('qid', 'name', 'todo', 'date')
    form = QueueForm


#-------------------------------------------------------------------

class AppointmentForm(Form):
    aid = StringField('Appointment Id', validators=[DataRequired(), Length(max=10)])
    name = StringField('Name', validators=[DataRequired(), Length(max=50)])
    todo = StringField('Todo', validators=[DataRequired(), Length(max=30)])
    location = StringField('Location', validators=[Length(max=30)])
    date = StringField('Appointment Date', validators=[Length(max=10)])
    qnum = IntegerField('Queue Number', validators=[NumberRange(min=0, max=100000)])
      
def app_json(aid, name, todo, location, date, qnum):
    return {"aid": aid, "name": name, "todo": todo, \
        "location": location, "date": date, "qnum": qnum }

class AppointmentView(ModelView):
    column_list = ('aid', 'name', 'todo', 'location', 'date', 'qnum')
    form = AppointmentForm

#-------------------------------------------------------------------
   
import pymongo as pm
def connect():
    try:
         return  pm.MongoClient() # 'mongodb://127.0.0.1:27017'
    except:
        print('Connect fails.')
    return None

db = connect().mydb
if db:
    db['student'].drop()
    tb = db['student']
    john = stu_json('1', 'นาย', 'John Rambo', 'comp sic', 'freshy', '081-111-1234', 'john@rambo.com', '1/2/2021')
    jack = stu_json('2', 'นาง', 'Jack Ripper', 'comp end', 'senior', '081-111-1234', 'jack@ripper.com', '1/2/2021')
    tb.insert_many([john, jack])
    admin.add_view(StudentView(db['student']))

    db['faculty'].drop()
    tb = db['faculty']
    jame = fac_json('3', 'ผ.ศ.', 'นาย', 'Jame Bond', 'วิทยาการคอมพิวเตอร์', '081-000-0000', 'jame@bond.com', '1/2/2021')
    tb.insert_one(jame)
    admin.add_view(FacultyView(db['faculty']))

    db['injection'].drop()
    tb = db['injection']
    jim1 = inj_json('5', 'Jim Morrison', 'sinovac', 1, '1/2/2021', 'โรงพยาบาลเพชรบูรณ์', 'สุดหล่อ นิยมไทย')
    jim2 = inj_json('6', 'Jim Morrison', 'sinovac', 2, '1/2/2021', 'โรงพยาบาลเพชรบูรณ์', 'สุดหล่อ นิยมไทย')
    tb.insert_many([jim1, jim2])
    admin.add_view(InjectionView(db['injection']))

    db['examination'].drop()
    tb = db['examination']
    jim = exa_json('7', 'Jim Morrison', '1/2/2021', 'โรงพยาบาลเพชรบูรณ์', 'สุดหล่อ นิยมไทย', 'pending')
    tb.insert_one(jim)
    admin.add_view(ExaminationView(db['examination']))

    db['queue'].drop()
    tb = db['queue']
    john = que_json('1', 'John Rambo', 'vaccine injection', '1/2/2021')
    jack = que_json('2', 'Jack Ripper', 'vaccine injection', '1/2/2021')
    tb.insert_many([john, jack])
    admin.add_view(QueueView(db['queue']))

    db['appointment'].drop()
    tb = db['appointment']
    john = app_json('1', 'John Rambo', 'vaccine injection', 'โรงพยาบาลเพชรบูรณ์', '1/2/2021', 1)
    tb.insert_one(john)
    admin.add_view(AppointmentView(db['appointment']))

if __name__ == '__main__':
    app.run(port=8081, debug=True)

