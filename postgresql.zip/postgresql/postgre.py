'''
https://www.guru99.com/download-install-postgresql.html
1. Download
        https://www.postgresql.org/download

2.  Install and set pwd.
3. Start Service
net start postgresql-x64-14
net stop postgresql-x64-14
4. Command line test.
psql -U postgres
    pwd when install.
\l          Listing Databases               '''

''' pip install psycopg2 '''
import psycopg2
def getConnection():
    return psycopg2.connect(database="postgres",
        user = "postgres", password = "hello123",
        host = "127.0.0.1", port = "5432")

def create():
    con = getConnection()
    cur = con.cursor()
    cur.execute("""CREATE TABLE students (id INT, name TEXT, gpa REAL)""")
    cur.execute("""INSERT INTO students VALUES(1, 'John Rambo', 1.2)""")
    cur.execute("""INSERT INTO students VALUES(2, 'Jack Ripper', 4.0)""")
    cur.execute("""INSERT INTO students VALUES(3, 'Joe Green', 2.8)""")
    con.commit()
    con.close()
# create()

def list_all():
    con = getConnection()
    cur = con.cursor()
    cur.execute('SELECT * FROM students')
    for r in cur.fetchall():
        print(r)
    con.close()
# list_all()

def find_byname(name):
    con = getConnection()
    cur = con.cursor()
    cur.execute("SELECT * FROM students WHERE name = '" + name + "';")
    print(cur.fetchall())
# find_byname('John Rambo')

def drop():
    con = getConnection()
    cur = con.cursor()
    cur.execute("DROP TABLE students;")
    con.commit()
# drop()
