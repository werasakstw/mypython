﻿# pip install flask_pymongo
# pip install flask_wtf

from flask import Flask
from flask_admin import Admin

app = Flask(__name__)
app.config['SECRET_KEY'] = 'hello123'
app.config['FLASK_ADMIN_SWATCH'] = 'cerulean'
admin = Admin(app, name='Vaccine App', template_mode='bootstrap3')

from flask_wtf import FlaskForm as Form
from wtforms.fields import StringField, SubmitField, IntegerField, \
         BooleanField, SelectField
from wtforms import validators
from wtforms.validators import DataRequired, Length, NumberRange, Email
import json
dept_choice = (('ครุศาสตร์','ครุศาสตร์'), \
               ('เทคโนโลยีการเกษตรและเทคโนโลยีอุตสาหกรรม','เทคโนโลยีการเกษตรและเทคโนโลยีอุตสาหกรรม'), \
               ('มนุษยศาสตร์และสังคมศาสตร์','มนุษยศาสตร์และสังคมศาสตร์'), \
               ('วิทยาการจัดการ','วิทยาการจัดการ'), \
               ('วิทยาศาสตร์และเทคโนโลยี','วิทยาศาสตร์และเทคโนโลยี'))
status_choice = (('ปกติ','ปกติ'), ('พ้นสภาพ','พ้นสภาพ'), \
                 ('รักษาสภาพ','รักษาสภาพ'), ('พักสภาพ','พักสภาพ'))
                 
class StudentForm(Form):
    cid = StringField(' Id', validators=[DataRequired(), Length(max=13)])
    sid = StringField('Student Id', validators=[DataRequired(), Length(max=12)])
    prefix_ = SelectField('Prefix', choices=(('นาย','นาย'), ('นาง','นาง'), ('นางสาว','นางสาว')))
    name = StringField('First Name', validators=[DataRequired(), Length(max=60)])
    dept = SelectField('Department', choices=dept_choice)
    major = StringField('Major', validators=[DataRequired(), Length(max=50)])
    status = SelectField('Status', choices=status_choice)
    phone = StringField('Phone Number', validators=[DataRequired(), Length(max=12)])
    email = StringField('Email', validators=[DataRequired(), Length(max=30)])
    birth = StringField('Birth Date', validators=[DataRequired(), Length(max=10)])
    submit = SubmitField('Submit')

def stu_json(cid, sid, prefix_, name, dept, major, status, phone, email, birth):
    return {"cid": cid, "sid": sid, "prefix_": prefix_, \
            "name": name, "dept": dept, "major": major, "status": status,\
            "phone": phone, "email": email, "birth": birth }

from flask_admin.contrib.pymongo import ModelView
class StudentView(ModelView):
    column_list = ('cid', 'sid', 'prefix_', 'name', 'dept', 'phone', 'email', 'birth')
    column_searchable_list = ('name', 'phone', 'email', 'dept')
    can_delete = False
    can_create = False
    form = StudentForm

#-------------------------------------------------------------------

class FacultyForm(Form):
    fid = StringField('Id', validators=[DataRequired(), Length(max=6)])
    prefix_ = SelectField('Prefix', choices=(('นาย','นาย'), ('นาง','นาง'), ('นางสาว','นางสาว')))
    name = StringField('Name', validators=[DataRequired(), Length(max=60)])
    dept = SelectField('Department', choices=dept_choice)
    position = StringField('Position', validators=[DataRequired(), Length(max=30)])
    submit = SubmitField('Submit')  
    
def fac_json(fid, prefix_, name, dept, position):
    return {"fid": fid, "prefix_": prefix_, "name": name, \
            "dept": dept, "position": position }

class FacultyView(ModelView):
    column_list = ('fid', 'prefix_', 'name', 'dept', 'position')
    column_searchable_list = ('fid', 'name', 'dept')
    can_delete = False
    can_create = False
    form = FacultyForm

#-------------------------------------------------------------------

vaccine_choice = (('sinovac','sinovac'), \
          ('astra zeneca','astra zeneca'), ('sinopharm','sinopharm'), \
          ('pfizer','pfizer'), ('moderna','moderna'))
location_choice = (('โรงพยาบาลเพชรบูรณ์','โรงพยาบาลเพชรบูรณ์'), \
                   ('โรงพยาบาลเพชรรัตน์','โรงพยาบาลเพชรรัตน์'), \
                   ('ศูนย์ฉีดวัคซีน อบจ.เพชรบูรณ์','ศูนย์ฉีดวัคซีน อบจ.เพชรบูรณ์'), \
                   )
class InjectionForm(Form):
    iid = StringField('Id', validators=[DataRequired(), Length(max=17)])
    name = StringField('First Name', validators=[DataRequired(), Length(max=60)])
    vaccine = SelectField('Vaccine', choices = vaccine_choice)
    dose = IntegerField('Dose', validators=[DataRequired(), Length(min=1, max=3)])
    date = StringField('Date')
    location = SelectField('Location', choices = location_choice)
    submit = SubmitField('Submit')
    
def inj_json(iid, name, vaccine, dose, date, location):
    return {"iid": iid, "name": name, "vaccine": vaccine, "dose": dose, \
            "date": date, "location": location }

class InjectionView(ModelView):
    column_list = ('iid', 'name', 'vaccine', 'dose', 'date', 'location')
    column_searchable_list = ('name', 'vaccine', 'location')
    can_delete = False
    can_create = False
    form = InjectionForm

#-------------------------------------------------------------------
   
import pymongo as pm
def connect():
    try:
         return  pm.MongoClient() # 'mongodb://127.0.0.1:27017'
    except:
        print('Connect fails.')
    return None

import datetime
today = datetime.date.isoformat(datetime.date.today())

db = connect().mydb
if db:
    db['student'].drop()
    tb = db['student']
    john = stu_json('1470000000000', '581103000000', 'นาย', 'John Rambo', \
                    'ครุศาสตร์', 'คณิตศาสตร์', 'ปกติ', \
                    '081-1111234', 'john@rambo.com', today)
    jack = stu_json('1470000000000', '581103000000', 'นางสาว', 'Jack Ripper', \
                    'วิทยาศาสตร์และเทคโนโลยี','ฟิสิกส์', 'ปกติ', \
                    '081-1111234', 'jack@ripper.com', today)
    tb.insert_many([john, jack])
    admin.add_view(StudentView(db['student']))

    db['faculty'].drop()
    tb = db['faculty']
    jame = fac_json('123456', 'นาย', 'Jame Bond', 'ครุศาสตร์', 'ผ.ศ')
    tb.insert_one(jame)
    admin.add_view(FacultyView(db['faculty']))

    db['injection'].drop()
    tb = db['injection']
    jim1 = inj_json(1, 'Jim Morrison', 'sinovac', 1, today, 'โรงพยาบาลเพชรบูรณ์')
    jim2 = inj_json(2, 'Jim Morrison', 'sinovac', 2, today, 'โรงพยาบาลเพชรบูรณ์')
    tb.insert_many([jim1, jim2])
    admin.add_view(InjectionView(db['injection']))

if __name__ == '__main__':
    app.run(port=8081, debug=True)

