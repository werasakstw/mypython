from myutil import *

# Infura is not a wallet.
def infura_info():
    print(w3i.clientVersion) # Geth ....
    print(w3i.eth.chainId)   # 4
    print(w3i.eth.mining)    # False
    print(w3i.eth.get_block('latest').number)
    print(w3i.eth.accounts)  # []
# infura_info()

# Off wallet Account(owa) and In Wallet Account(iwa):
# An account contains private key and address.
# Infura allows creating owa but not iwa.
from eth_utils.curried import to_hex
def create_owa():
    owa = w3i.eth.account.create('This is a seed, not a pwd.')
    print(to_hex(owa._private_key))
    print(owa._address)
# create_owa()  # Try: list accounts again.

# Alternatively an owa can be created using 'Account',
# no providers needed.
from eth_account import Account
def alt_create_owa():
    a = Account.create('seed')
    print(to_hex(a.privateKey))   # Or a.key
    print(a.address)
# alt_create_owa()

# Infura allows balance checking of any valid _address.
def get_me_balance():  # 'me' account from metamask.
    me_addr = '0x16c25A4cb42906a367Cce89043f3e39F9f892eb0'
    print(w3i.eth.get_balance(me_addr))
# get_me_balance()

#----------------------------------------------------

# Openethereum may perform as a wallet.
def oeth_info():
    print(w3o.clientVersion) # OpenEthereum
    print(w3o.eth.chainId)   # 4
    print(w3o.eth.mining)    # True
    print(w3o.eth.get_block('latest').number)
    print(w3o.eth.accounts)
# oeth_info()

# Wallets allow creating iwa with password.
# print(w3o.geth.personal.new_account('john')) # 'john' is the account pwd.
# Try: list accounts again.
# The address is returned, the private key is stored in the wallet.
# OpenEthereum stores a account in a 'key' file at:
# ....\AppData\Roaming\OpenEthereum\keys\rinkeby

# The private key of an iwa can be retrieve from the 'key' file,
#  but the pwd is needed.
def retrieve_privatekey():
    key_dir = 'C:/Users/THAIMART/AppData/Roaming/OpenEthereum/keys/rinkeby'
    key_file = '/UTC--2022-04-08T07-33-30Z--74824171-10e1-c9b8-d9f9-7fa19761618f'
    with open(key_dir+key_file) as f:
#        prikey = w3i.eth.account.decrypt(f.read(), 'john')
        prikey = Account.decrypt(f.read(), 'john')
        print(to_hex(prikey))
# retrieve_privatekey()
# For accounts created in Metamask, their private keys can be exported.

# OpenEthereum will provide account balance service when its
#  blockchain syncing is done.
