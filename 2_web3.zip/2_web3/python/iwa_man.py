from myutil import *

# Web3py parity is deprecated and not all available on Openethereum.
# But Openethereum support JSONRPC-parity.
#       https://openethereum.github.io/JSONRPC
# https://openethereum.github.io/JSONRPC-parity_accounts-module
# https://web3py.readthedocs.io/en/stable/web3.parity.html

URL = 'http://127.0.0.1:8545'
HEADERS = {'Content-type': 'application/json', 'Accept': 'text/plain'}
import requests
def rpc(method, param):
   DATA = '{"jsonrpc":"2.0", "method": "%s","params": %s, "id": 1}' % (method, param)
   return requests.post(URL, data=DATA, headers=HEADERS).text

#----------------------------------------------------------------

# List accounts:
##print(w3.eth.accounts)

# List accounts with info.
##print_json_str(rpc('parity_allAccountsInfo', []))
# Try: w3.parity.personal.list_accounts()

# Create 'john' account.
##print_json_str(rpc('parity_newAccountFromPhrase', quote2('recovery phrase','joe')))
# Try: w3.geth.personal.new_account('john')
john_addr = '0x6710A4a84f6d99f141DAD80b91fab2a4a4B12e54'            

# Verify address with password.
print_result(rpc('parity_testPassword', quote2(john_addr, 'John')))

# Change password.
old_pwd = 'john'
new_pwd = 'John'
##print_result(rpc('parity_changePassword', quote3(john_addr, old_pwd, new_pwd)))
# Try: Verify 'john' address with 'John'.

# Kill account.
##print_json_str(rpc('parity_killAccount', quote2(john_addr, new_pwd)))
# Try: list account.

# Set account name:
# Create a new 'jack' account.
##print(w3.geth.personal.new_account('jack'))
jack_addr = '0xf041259945B8dE56Cc38bCdcD892479A19037A8E'
##print_json_str(rpc('parity_setAccountName', quote2(john_addr, 'Jack Ripper')))
# Try: list account with info. 

# Set meta data of an account:
def set_meta():
    params = '''[\"0xf041259945B8dE56Cc38bCdcD892479A19037A8E\",
\"{\\"aliases\\":\\"The Ripper\\"}\" ]'''
    print_json(rpc('parity_setAccountMeta', params))
##set_meta()
# Try: list account with inf
