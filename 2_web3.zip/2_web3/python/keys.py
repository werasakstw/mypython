# pip install eth_account
# pip install eth_utils
from eth_account import Account
from eth_utils.curried import to_hex

# Creating Off Wallet Account (without provider).
def account_create():
    acc = Account.create()
    print(to_hex(acc._private_key))
    print(acc._address)     # checksum address
# account_create()

# pip install eth-keys
from eth_keys import keys
from eth_utils import decode_hex

# To compute public key and address:
def pri_pub_addr():
    pri_key_hex_bytes = Account.create()._private_key   # hex bytes
    pri_key = to_hex(pri_key_hex_bytes)     # hex str
    print(pri_key)

    # Private key -> Public key:
    pri_key_bytes = decode_hex(pri_key)
    pri_key_obj = keys.PrivateKey(pri_key_bytes) # private key object
    pub_key = pri_key_obj.public_key
    print(pub_key)

    # Public key -> Address:
    print(pub_key.to_address())
    print(pub_key.to_checksum_address())
# pri_pub_addr()
