from myutil import *
from eth_utils.curried import to_hex

me_addr = "0x16c25A4cb42906a367Cce89043f3e39F9f892eb0"
me_prikey = "27ec6c0cbbd712214163bf859a67f38d290ba69650b1355066d5064d5d9522aa"
john_addr = "0x8D36440Ea00E281622C697c02446Fef65df6B39c"
# print(w3i.eth.get_balance(me_addr))
# print(w3i.eth.get_balance(john_addr))

def get_info():
    nonce = w3i.eth.getTransactionCount(me_addr)
    block = w3i.eth.getBlock("latest")
    currGas = '0x' + str(block.gasLimit)[:16]
    return nonce, currGas

# 'nonce' is used for prevent sending a tx more than once,
#    mostly it is the number of tx sent by the address.
# 'chainId' is used for prevent sending tx acorss chains.
# 'gas' is the max gas allowed to execute this tx,
#    the minimum is 0x21000.
# 'gasPrice' is the price offered by the sender, mostly
#    obtained from the last block, but may not enough in bussy hours.
# 'form' is the sender address that already included in the tx sig.

# Send from 'me' to 'john' using raw tx.
def send_raw_tx():
    nonce, currGas = get_info();
    tx = {   # a dict
        'to': john_addr,    # receiver address
        'value': "0x1",     # in wei
        'nonce': nonce,
        'chainId': "0x4",   # EIP-155 requires chainId.
        'gas': "0x21000",
        'gasPrice': "0x40000000",    # currGas,
    }
    # print(tx)

    # Sign transaction with sender private key.
    signed_tx = w3i.eth.account.sign_transaction(tx, me_prikey)

    # Send the transaction
    tx_hash = w3i.eth.sendRawTransaction(signed_tx.rawTransaction)
    print(to_hex(tx_hash))
# send_raw_tx()
tx_hash = '0xb968ad07055f4511dace1343d5673226591c31c064a6e568be4117ef285b1bc0'

# The tx is sent but may not success.
# Check the tx sent by this address in Etherscan.
# Wait while pending until transfer.

# Check tx:  Try: w3.eth.get_transaction_receipt(tx_hash)
# print_json(w3i.eth.get_transaction(tx_hash))
# The success tx "transactionIndex" should not be null.
# Try: 'john' balance again.
block_number = 10467834

# Print all tx_hashs in the Block.
# [print(to_hex(th)) for th in w3i.eth.get_block(block_number)['transactions']]
