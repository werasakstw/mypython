''' A namespace is a collection of named objects.
A scope is an area(in source code) where a namespace is defined.
A scopes is defined by a block (of control, function, class) or file.
Scopes can be nested.
'Scope Rules' are rules that define how to determine which name refers
 to which objects. '''
def scope_rules():
    ## 1. A name must be defined before it can be referred.
    # print(x)      # error
    x = 0
    print(x)        # 0

    ## 2. A name can be shadowed(redfined) in the same scope.
    x = 1
    print(x)        # 1

    def greet():
        print('Hello')
    def greet():
        print('Hi')
    greet()         # Hi

    ## 3. An inner scope may refer to names in outer scopes.
    def f():
        print(x)
    f()             # 1

    ## 4. An inner scope may shadow names in outer scopes.
    def f():
        x = 2
        print(x)    # 2
    f()
    print(x)        # 1

    ''' 5. In an inner scope, after the name is referred to it cannot be
      shadowed that name in the outer scope. '''
    def f():
        print(x)
        x = 2       # error
    # f()

    ## 6. An inner scope cannot modify the outer scope variables.
    def f():
        x += 1      # error
    # f()

    ''' Python applies static(lexical) scope rules which means names
     are bound by lexically scope, not by calling stack scope. '''
    def f():
        print(x)    # 1
        ## x bound to x in the outer scope, not to scope where calling from.
    def ff():
        x = 2
        f()
    ff()
# scope_rules()

x = 1
def global_test():
    ## 'global' binds local name to global name and allows modification.
    global x
    x += 1
    print(x)                # 2
# global_test()
# print(x)   # 2

## 'nonlocal' binda local name the outer scope names, that is noy blobal.
y = 1
def nonlocal_test():
    y = 2
    def f():
        # global y
        nonlocal y
        print(y)            # 2
    f()
# nonlocal_test()
