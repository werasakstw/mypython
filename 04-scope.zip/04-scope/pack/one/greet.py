
def hello():
	print("Hello (pack.one).")

def hi():
	print("Hi (pack.one).")
