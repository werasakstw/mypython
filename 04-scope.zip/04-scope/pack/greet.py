
def hello():
	print('Hello I am in mypack\greet.py')

