''' When an 'import <module>' is executed:
    1. The module is loaded.
    2. The module's namespace is created as a dict and can be referred by __dict__.
    3. The module code is executed.
    4. Objects defined in the module are created and added to the dict.
So two modules may contain the same names, since in different namespaces. '''
def np_dict():
    import mod  ## The namespace 'mod' is created and added to current namespace.
    print(dir())            # ['mod']

    print(mod.__name__)     # mod

    ## A namespace is created as a __dict__ for storing names in the namespace.
    print(mod.__dict__.keys())
    print(dir(mod))
# np_dict()

''' The module namespace is created once at the first import.
Reimporting an imported module does not create a new namespace. '''
def reimport():
    import mod
    print(mod.x)        #  1
    mod.x = 3

    import mod      ##  Reimport the same module.
    print(mod.x)        #  3

    #  importlib.reload() allows reimporting to recreate new namespace.
    import importlib
    importlib.reload(mod)
    print(mod.x)
# reimport()

''' sys.path is a list of search paths for searching imported modules.
By default the sys.path is initialized as:
      - Working directory.
      - PYTHONPATH environment variable.
      - The installation dependent default.  '''
import sys
def search_path():
    for p in sys.path:
        print(p)
# search_path()

''' sys.path is a mutable list.
That allows importing modules from specified directories.
Suppose we want to import \mypack\greet.  '''
def mod_path():     #  / is the path separator.
    p = 'C:/mypython/src/04-scope/pack/one'
    sys.path.append(p)
    import greet
    greet.hello()
# mod_path()

''' Normally the sys.path should not be modified since the
 search path will be vary from program to program and
 longer search path would make module searching slow.
If the 'pack.one' is visible in the search path, we can use. '''
def imp_mypack():
    from pack.one import greet
    greet.hello()
# imp_mypack()
