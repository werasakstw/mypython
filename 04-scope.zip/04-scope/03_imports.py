''' A Python module is a file.
The file name is the name of the module and its namespace.
A module is a collection of objects, functions and classes.

'import' statements allow using objects defined in modules.
The imported modules must be in the 'search path' which
  by default includes the working directory.
Python has several import options.
Some 'import' options are allowed locally. '''

## 1.  import <module>
def import1():
    ## mod.py is in working directory.
    import mod      ## Locally  import
    ## The module name must be used to quantify the objects.
    print(mod.x, mod.names)
    mod.hello()
    mod._hi()
    mod.A()
# import1()

## 2.  import <module> as <other>
def import2():
    import mod as m
    ## The module name is redefined as <other>.
    print(m.x, m.names)
    m.hello()
    m._hi()
    m.A()
# import2()

## 3.  from <module> import <objects>
def import3():
    ''' 'static import' allows no quantified name.
    One or more names can be imported using , as seperater. '''
    from mod import x, hello, _hi
    print(x)
    hello()
    _hi()
# import3()

## 4.  from <module> import <object> as <other>
def import4():
    from mod import hello as greet
    greet()
# import4()

''' 5. from <module> import *
Static import all objects, allowed only at the module level.
Names that begins with an underscore cannot be referred to.  '''
from mod import *
def import5():
    print(x, names)
    hello()
    # _hi()       # error
    A()
# import5()
''' A name that begins with an _ is not local(or private to
  the module) since it can be imported normally (as in import3()). '''

'''With static import all, a module may define a tuple __all__
  to specify only the names that can be referred to. e.g. mod_all.py '''
from mod_all import *
def mod_all_test():
    print(john)
    # print(jack)     # error
    hello()
    # hi()            # error

    # But __all__ does not make the names un-importable.
    import mod_all
    print(mod_all.jack)
    mod_all.hi()
# mod_all_test()

#-----------------------------------------------------------

''' A Python 'package' is a directory, which is a collection of modules.
Packages allow organizing a lot of modules as directory.

Importing a module in a package needs the path to the module
  starting from the search path.
Before Python 3.3, a package directory must have a file '__init__.py'
  to mark that it is a package. '''
def pack_import():
    ## 1.  import <module path>
    import pack.one.greet
    pack.one.greet.hello()
    pack.one.greet.hi()

    ## 2. from <module path> import <name>
    from pack.one.greet import hello
    hello()

    ## 3.  from <module path> import <name> as <other>
    from pack.one.greet import hi as h
    h()

    ##  4. from <package path> import <module>
    from pack.one import greet
    greet.hello()
    greet.hi()
# pack_import()

''' 5.  from <module path> import *
Allowed only at the module level.  '''
from pack.one.greet import *
def import_pack_star():
    hello()
    hi()
# import_pack_star()
