# pip install openpyxl
import pandas as pd

# Clean illegal characters students.xlsx -> students1.xlsx

# Change header and save as s1.csv
def xlsx_csv():
    df = pd.read_excel(pd.ExcelFile('students1.xlsx'))
    df.to_csv('s1.csv', index=False, encoding='ISO-8859-11')
##xlsx_csv()

# Print 'fname' column.
def print_col():
    df = pd.read_csv('s1.csv', encoding='ISO-8859-11' )
    print(df['fname'])
##print_col()

# Remove 'gender' column.
def rm_col():
    df = pd.read_csv('s1.csv', encoding='ISO-8859-11' )
    df = df.drop('gender', axis=1)
    df.to_csv('s2.csv', index=False, encoding='ISO-8859-11')
##rm_col()

def fix_dash():   
    df = pd.read_csv('s2.csv', encoding='ISO-8859-11' )
    df.hphone = df.hphone.fillna('-')
    df.mphone = df.mphone.fillna('-')
    df.email = df.email.fillna('-')
    df.vnumber = df.vnumber.fillna('-')
    df.lane = df.lane.fillna('-')
    df.rode = df.rode.fillna('-')
    df.to_csv('s3.csv', index=False, encoding='ISO-8859-11')
##fix_dash()

def fix_phone():
    def fix(n):
        n = str(n)
        if (len(n) == 10 or len(n) == 9) and '-' not in n:
            return n[:3]+'-'+n[3:]
        return n
    df = pd.read_csv('s3.csv', encoding='ISO-8859-11' )
    df.hphone = df.hphone.map(fix)
    df.mphone = df.mphone.map(fix)
    df.to_csv('s4.csv', index=False, encoding='ISO-8859-11')
##fix_phone()

def strip():
    df = pd.read_csv('s4.csv', encoding='ISO-8859-11' )
    
    def strip_discipline(n):
        return n[9:]        # ตัด 'สาขาวิชา ' ออก
    df.discipline = df.discipline.map(strip_discipline)
    
    def strip_district(n):
        return n[5:]        # ตัด 'อำเภอ' ออก
    df.district = df.district.map(strip_district)
    df.to_csv('s5.csv', index=False, encoding='ISO-8859-11')
strip()
