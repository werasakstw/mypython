const fs = require('fs');
const src = fs.readFileSync("./Storage.sol", "utf8");
// console.log(src);

const solc = require('solc');
var res = solc.compile(src, 1);
console.log(res);