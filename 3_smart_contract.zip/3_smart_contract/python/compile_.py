## pip install py-solc-x

# from solcx import install_solc
# print(install_solc(version='latest'))
# Check C:\Users\<User>\.solcx

from solcx import compile_source
from myutil import *
def compile(fn):
    code = read_file('contracts/' + fn + '.sol')
    compiled = compile_source(code,
          output_values=['abi', 'bin'],
          solc_version='0.8.13')    # Storage, Faucet, Erc20Token
    res = compiled['<stdin>:'+fn]
    abi = res['abi']
    bin = res['bin']
    write_file('contracts/' + fn + '.abi', w3.toJSON(abi))
    write_file('contracts/' + fn + '.bin', bin)
    return abi, bin
# abi, bin = compile('Storage')
# abi, bin = compile('Faucet')
# abi, bin = compile('Erc20Token')
# print(abi); print(bin)

def test_contract_obj(fn):
    abi = read_file('contracts/' + fn + '.abi')
    bin = read_file('contracts/' + fn + '.bin')
    # print(abi); print(bin)

    # Create contract object: (does not deployed yet)
    c = w3.eth.contract(abi=abi, bytecode=bin)

    # List all functions in the contract.
    for f in c.all_functions():
        print(f.fn_name)
# test_contract_obj('Storage')
# test_contract_obj('Faucet')
# test_contract_obj('Erc20Token')
