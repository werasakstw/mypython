from myutil import *

e20_addr = '0x2bB9Dce961204f5Bed8E286Ad9361Cb3FafcE479'
e20_abi = read_file('contracts/Erc20Token.abi')
e20_con = w3.eth.contract(address=e20_addr, abi=e20_abi)

def con_info():
    print(e20_con.functions.name().call())
    print(e20_con.functions.symbol().call())
    print(e20_con.functions.decimals().call())
    print(e20_con.functions.totalSupply().call())
    for f in e20_con.all_functions():
        print(f.fn_name)
# con_info()

def create_account():
    from eth_account import Account
    a = Account.create('seed.')
    print(a._address)
    print(to_hex(a._private_key))
# create_account()

me_addr = "0x16c25A4cb42906a367Cce89043f3e39F9f892eb0"
me_prikey = "27ec6c0cbbd712214163bf859a67f38d290ba69650b1355066d5064d5d9522aa"
# Create account for john, jack and joe.
john_addr = '0xDCD4a8EcB2b686DAc053d827b5236acaf982e01B'
john_prikey = '0xe791f03db3d504366c98ee1fe8e251137659228396edb5beef7ed3ff005405f9'
jack_addr = '0x9c7a37c959142770A06E1b9b733644A4b394bA67'
jack_prikey = '0xd7c4054aabac9f8d25d5508a43a8f7ff0a0d24ef69dc7847d853df9db6547731'
joe_addr = '0xA4835cF82b19925E02f9Bd2bf8D359f724D7700A'
joe_prikey = '0x468d9965f6f956a874bf4f3c3b1fb7ca79aee6dd59f9199283dbce551d100eac'

# Transfer eth from sender to receiver.
def send_eth(sender_prikey, receiver_addr, value):
    _, sender_addr = from_prikey(sender_prikey)
    nonce, currGas = get_nonce_gas(sender_addr)
    tx = { 'chainId': "0x4", 'nonce': nonce,
        'to': receiver_addr, 'value': value, # in wei
        'gas': "0x21000", 'gasPrice': "0x80000000" # currGas #
    }
    # print(tx)
    signed_tx = w3.eth.account.sign_transaction(tx, sender_prikey)
    tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
    print(to_hex(tx_hash))
# send_eth(me_prikey, john_addr, 10000000000000000)
tx_hash = '0x7fc17b0746d435a552421688867d81df66df584dda7c216262ecb7a0d1a2c1d4'
# show_tx(tx_hash)

def eth_balances():
    print('me:\t', w3.eth.getBalance(me_addr))
    print('john:\t', w3.eth.getBalance(john_addr))
    print('jack:\t', w3.eth.getBalance(jack_addr))
    print('joe:\t', w3.eth.getBalance(joe_addr))
# eth_balances()

# Transfer etc from sender to receiver.
def send_etc(sender_prikey, receiver_addr, value):
    _, sender_addr = from_prikey(sender_prikey)
    nonce, currGas = get_nonce_gas(sender_addr)
    tx = e20_con.functions.transfer(receiver_addr, value) \
         .buildTransaction({
            'chainId': 4, 'nonce': nonce,
            'gas': "0x21000", 'gasPrice': "0x70000000"
        })
    print(sign_send(tx, sender_prikey))
# send_etc(me_prikey, john_addr, 10)
# tx_hash = '0x277d149745dba166021f33e12d4e8f050e654f68dbb8925f1d5be8feed42e38c'
# show_tx(tx_hash)

def etc_balances():
    # The account that deploys the contract earns the total supply.
    print('me:\t', e20_con.functions.balanceOf(me_addr).call())
    print('john:\t', e20_con.functions.balanceOf(john_addr).call())
    print('jack:\t', e20_con.functions.balanceOf(jack_addr).call())
    print('joe:\t', e20_con.functions.balanceOf(joe_addr).call())
# etc_balances()


################################################################

# In cases that the sender is not the 'asset owner', the sender must approve
#   the 'asset owner' to spend some of his token.
# And the 'asset owner' must be the one who send the transfer tx.

# To set the amount that the sender approves the owner to spend.
# The amount is not accumulated with repeated set and not reduced with repeated spends.
def set_approve(owner_prikey, spender_addr, amount):
    _, owner_addr = from_prikey(owner_prikey)
    nonce, currGas = get_nonce_gas(owner_addr)
    tx = e20_con.functions.approve(spender_addr, amount) \
             .buildTransaction({
                'chainId': 4, 'nonce': nonce, \
                'gas': "0x21000", 'gasPrice': "0x50000000"
            })
    print(sign_send(tx, owner_prikey))
# set_approve(john_prikey, jack_addr, 7)
tx_hash = '0x7ea6e180c0c1bb82ce76102a29d2b2c6aabbe0e6ade1b62e29426f4abf14d1ac'
show_tx(tx_hash)

# Shows how much a sender approve the 'asset owner' to spend.
def show_allowance(owner_addr, spender_addr):
    print(e20_con.functions.allowance(owner_addr, spender_addr).call())
# show_allowance(john_addr, jack_addr)

def tranfer_from(con, sender_prikey, receiver_addr, value):
    _, sender_addr = from_prikey(sender_prikey)
    nonce, currGas = get_nonce_gas(sender_addr)
    tx = con.functions.transferFrom(sender_addr, receiver_addr, value) \
            .buildTransaction({
                'chainId': 4, 'nonce': nonce,
                # 'gas': "0x21000", 'gasPrice': "0x40000000"
            })
    print(sign_send(tx, sender_prikey))
# tranfer_from(e20_con, john_prikey, jack_addr, 1)
# tranfer_from(fst_con, john_prikey, jack_addr, 1)
# check_balances(fst_con)
