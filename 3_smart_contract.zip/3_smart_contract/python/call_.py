# To call a function of smart contract, we need
#   the smart contract address and its abi.

# The smart contract address can be found by checking
#  the 'to' of the tx that deploy the contract, using
#  Remix or Etherscan.

from myutil import *

# Storage:
st_addr = '0xBb84b3351cC164866c5FAC56992485a0e99B9231'
st_abi = read_file('contracts/Storage.abi')
st_ct = w3.eth.contract(address=st_addr, abi=st_abi)
def st_getter():  # No tx creating and no gas.
    print(st_ct.functions.retrieve().call())

    # Using 'ConciseContract' is more efficient for repeated calls.
    # from web3.contract import ConciseContract
    # cc = ConciseContract(st_ct)
    # for _ in range(3):
    #     print(cc.retrieve())
# st_getter()

me_addr = "0x16c25A4cb42906a367Cce89043f3e39F9f892eb0"
me_prikey = "27ec6c0cbbd712214163bf859a67f38d290ba69650b1355066d5064d5d9522aa"

def st_setter(value): # Needs a tx creating.
    nonce, currGas = get_nonce_gas(me_addr)
    tx = st_ct.functions.store(value).buildTransaction({
        'nonce': nonce, 'chainId': 4,
        'gas': "0x70000", 'gasPrice': "0x40000000"  # currGas
    })
    print(sign_send(tx, me_prikey))
# st_setter(1)
# tx_hash = '0x47b9d41c5d252f892356d8af0e4a9ce86daf7dfeb112b2ed0f1841732cf9244f'
# show_tx(tx_hash)

# st_getter()

#----------------------------------------------------------

# Faucet:
fc_addr = '0xFb4e24C16ef0dbd7F53cBd7e7617aD18B959f191'
fc_abi = read_file('contracts/Faucet.abi')
fc_ct = w3.eth.contract(address=fc_addr, abi=fc_abi)

# A smart contract has a balance and can perform as a wallet or faucet.
# print(w3.eth.get_balance(fc_addr))
# print(w3.eth.get_balance(me_addr))

# Deposit some eth to the faucet by excuting the fallback function of the contract.
# The 'value' of tx is the amount to deposit.
# If the 'data' is empty, the 'value' will be added to the contract balance.
def deposit(value):
    nonce, currGas = get_nonce_gas(me_addr)
    # Using raw tx, no contract reference needed.
    tx = {
        'from': me_addr, 'to': fc_addr,
        'value': value, 'data': '',
        'chainId': 4, 'nonce': nonce,
        'gas': "0x70000", 'gasPrice': currGas,
    }
    print(sign_send(tx, me_prikey))
# deposit(10)
tx_hash = '0x3ace4c70eb486935abaec843f35ce62d8b29edd347861a2b05fb77febf01cd43'
# show_tx(tx_hash)

# print(w3.eth.get_balance(fc_addr))

def withdraw(value):
    nonce, currGas = get_nonce_gas(me_addr)
    # 'value' will be transfered from the contract balance to the tx sender balance.
    tx = fc_ct.functions.withdraw(value).buildTransaction({
        'chainId': 4, 'nonce': nonce,
        'gas': "0x70000", 'gasPrice': "0x40000000"  # currGas,
    })
    print(sign_send(tx, me_prikey))
# withdraw(2)
tx_hash = '0x6d1268a43c71a2a56b59074d517dea52bfc25f481a13ae815cf25530c89dd75d'
# show_tx(tx_hash)

# print(w3.eth.get_balance(fc_addr))
# print(w3.eth.get_balance(me_addr))
