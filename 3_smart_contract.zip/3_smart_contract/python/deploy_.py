from myutil import *
from eth_utils.curried import to_hex

me_addr = "0x16c25A4cb42906a367Cce89043f3e39F9f892eb0"
me_prikey = "27ec6c0cbbd712214163bf859a67f38d290ba69650b1355066d5064d5d9522aa"
##print(w3.eth.get_balance(me_addr))

# There are two alternative to programmatically deploy smart contracts.
# 1. Using contract constructor, using both abi and bin.
def deploy_con(fn):
    abi = read_file('contracts/' + fn + '.abi')
    bin = read_file('contracts/' + fn + '.bin')

    # Create contract object (not deployed jet).
    con = w3.eth.contract(abi=abi, bytecode=bin)
    nonce = w3.eth.getTransactionCount(me_addr)
    tx = con.constructor().buildTransaction({
        'nonce': nonce, 'chainId': "0x4",
        'gas': 1000000, 'gasPrice': "0x40000000",  # currGas
    })

    # Sign and sender tx.
    signed_tx = w3.eth.account.sign_transaction(tx, me_prikey)
    tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
    print(to_hex(tx_hash))
# deploy_con('Storage')
# deploy_con('Faucet')
# deploy_con('Erc20Token')
st_tx_hash = '0x7154d7a36b94e1fba1d02ff063adf9d973b71f94f6491f283a61ca54ca23065b'
fc_tx_hash = '0xd28d9c0267b79eb8156bf9090cb1ecd078ac11c124a7284978110158a67e1099'
et_tx_hash = '0x911088ed910e0b05ea891ad064ad51cd23de87a6d96f781b46293eab511f95af'

# Once a contract is deployed it get an address.
# print(w3.eth.get_transaction_receipt(st_tx_hash).contractAddress)
st_addr = '0xBb84b3351cC164866c5FAC56992485a0e99B9231'
# print(w3.eth.get_transaction_receipt(fc_tx_hash).contractAddress)
fc_addr = '0xFb4e24C16ef0dbd7F53cBd7e7617aD18B959f191'
# print(w3.eth.get_transaction_receipt(et_tx_hash).contractAddress)
et_addr = '0x2bB9Dce961204f5Bed8E286Ad9361Cb3FafcE479'

# 2. Deploy contract by sending tx to address 0, using only bin.
def deploy_bin(fn):
    bin = read_file('contracts/' + fn + '.bin')
    nonce = w3.eth.getTransactionCount(me_addr)
    # The 'bin' is passed as 'data' of the tx.
    tx = { 'from': me_addr, # 'to': 0,
           'value': 0, 'data': bin,
           'nonce': nonce, 'chainId': "0x4",
           'gas': 1000000, 'gasPrice': "0x40000000"
    }
    return sign_send(tx, me_prikey)

#---------------------------------------------------------------

def test_contract(addr, abi):
    c = w3.eth.contract(address=addr, abi=abi)
    for f in c.all_functions():
        print(f.fn_name)
# test_contract(st_addr, read_file('contracts/Storage.abi'))
# test_contract(fc_addr, read_file('contracts/Faucet.abi'))
# test_contract(et_addr, read_file('contracts/Erc20Token.abi'))
