from web3 import Web3
URL = "https://rinkeby.infura.io/v3/1c33caf701824d43882200b69d5e0849"
w3 = Web3(Web3.HTTPProvider(URL))

from web3.middleware import geth_poa_middleware
w3.middleware_onion.inject(geth_poa_middleware, layer=0)

#------------------------------------------------------

def read_file(name):
    with open(name, 'r') as f:
        return f.read()

def write_file(name, data):
    with open(name, 'w') as f:
        f.write(data)

#-------------------------------------------------------

import json
def print_json(ad): # AttributeDict
   st = w3.toJSON(ad)   # str
   js = json.loads(st)
   print(json.dumps(js, indent=4, sort_keys=True))

#------------------------------------------------------

def get_nonce_gas(sender_addr):
    nonce = w3.eth.getTransactionCount(sender_addr)
    block = w3.eth.getBlock("latest")
    gl = block.gasLimit + 10000000 # extra offer
    currGas = "0x" + str(gl)[:8]
    return nonce, currGas

from eth_utils.curried import to_hex
def sign_send(tx, prikey):
    signed_tx = w3.eth.account.sign_transaction(tx, prikey)
    return to_hex(w3.eth.sendRawTransaction(signed_tx.rawTransaction))

def show_tx(tx_hash):
    print_json(w3.eth.get_transaction_receipt(tx_hash))

#-----------------------------------------------------------

from eth_keys import keys
from eth_utils import decode_hex
# Return a tuple of (public_key, address)
def from_prikey(prikey):
    pri_key = keys.PrivateKey(decode_hex(prikey))
    return pri_key.public_key, pri_key.public_key.to_checksum_address()
