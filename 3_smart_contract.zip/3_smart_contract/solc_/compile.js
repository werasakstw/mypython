const fs = require('fs');
const code = fs.readFileSync("Storage.sol", "utf8");
// console.log(code);

const solc = require('solc');
let res = solc.compile(code);
console.log(res);
