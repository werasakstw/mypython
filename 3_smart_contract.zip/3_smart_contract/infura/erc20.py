from myutil import *

e20_addr = '0xb65712C2735eb99e67c117d7060EeFb31744006B'
e20_abi = read_file('contracts/MyErc20.abi')
e20_con = w3.eth.contract(address=e20_addr, abi=e20_abi)
def e20_con_info():
    print(e20_con.functions.name().call())
    print(e20_con.functions.symbol().call())
    print(e20_con.functions.totalSupply().call())
    print([ f.fn_name for f in e20_con.all_functions()])
##e20_con_info()

# Addresses in Metamask have different format.
def create_account():
    a1 = w3.eth.account.create('This is a seed.')
    print(to_hex(a1._private_key))
    print(a1._address)
##create_account()
    
me_addr = "0x16c25A4cb42906a367Cce89043f3e39F9f892eb0"
me_prikey = "27ec6c0cbbd712214163bf859a67f38d290ba69650b1355066d5064d5d9522aa"
john_addr = '0x1Bf9A3F3bD94BA7Ef6081Fc9e96ccA7A28189aF2'
john_prikey = '0xf152561ecbd99ee97089b2afea9aee5f7f37ac40fb82c4bba7bb0a8cb97ade48'
jack_addr = '0x9c7a37c959142770A06E1b9b733644A4b394bA67'
jack_prikey = '0xd7c4054aabac9f8d25d5508a43a8f7ff0a0d24ef69dc7847d853df9db6547731'
def check_balances():
    # The account that deploys the contract earns the total supply.
    print(e20_con.functions.balanceOf(me_addr).call())
    print(e20_con.functions.balanceOf(john_addr).call())
    print(e20_con.functions.balanceOf(jack_addr).call())
##check_balances()

# Transfer 'value' from sender to receiver. 'sender' is the tx sender.
def transfer(receiver, value, sender_addr, sender_prikey):
    nonce, currGas = get_nonce_gas(sender_addr)
    tx = e20_con.functions.transfer(receiver, value) \
             .buildTransaction({
                'chainId': 4, 'nonce': nonce, \
                'gas': "0x21000", 'gasPrice': currGas })
    return sign_send(tx, sender_prikey)
# Transfer from 'me' to 'john'.
##print(transfer(john_addr, 10**20, me_addr, me_prikey))
##check_balances()

##print(transfer(jack_addr, 1, me_addr, me_prikey))
##tx_hash = '0xb51406136af1dc7067fe61c022d1a7f8800e0af90b38a25b913244eff8695f41'
##print(w3.eth.get_transaction_receipt(tx_hash))
##check_balances()

#-----------------------------------------------------------

# Shows how much a sender approve a spender to spend.
def show_allowance(owner_addr, spender_addr):
    print(e20_con.functions.allowance(owner_addr, spender_addr).call())
##show_allowance(me_addr, john_addr)
##show_allowance(john_addr, me_addr)

# To set the amount that a sender approve a spender to spend.
# The amount is not accumulated with repeated set
#  and not reduced with repeated spends.
def set_approve(spender_addr, owner_prikey, owner_addr, amount):
    nonce, currGas = get_nonce_gas(owner_addr)
    tx = e20_con.functions.approve(spender_addr, amount) \
             .buildTransaction({
                'chainId': 4, 'nonce': nonce, \
                'gas': "0x21000", 'gasPrice': currGas })
    return sign_send(tx, owner_prikey)
##print(set_approve(john_addr, me_prikey, me_addr, 10**20))

# 'john' approve 'me' to spend 100.
print(set_approve(me_addr, john_prikey, john_addr, 10))
##show_allowance(john_addr, me_addr)
