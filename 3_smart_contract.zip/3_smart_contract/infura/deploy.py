from myutil import *
from eth_utils.curried import to_hex

me_addr = "0x16c25A4cb42906a367Cce89043f3e39F9f892eb0"
me_prikey = "27ec6c0cbbd712214163bf859a67f38d290ba69650b1355066d5064d5d9522aa"
##print(w3i.eth.get_balance(me_addr))

# There are two alternative to programmatically deploy smart contracts.
# 1. Using contract constructor, using both abi and bin.
def deploy_con(fn):  
    abi = read_file('contracts/' + fn + '.abi')
    bin = read_file('contracts/' + fn + '.bin')
    
    # Create contract object (not deployed jet).
    con = w3.eth.contract(abi=abi, bytecode=bin)

    nonce = w3.eth.getTransactionCount(me_addr)
    tx = con.constructor().buildTransaction({
        'nonce': nonce, 'chainId': "0x4",
        'gas': 1000000, 'gasPrice': "0x40000000",  # currGas
    })
    
    # Sign and sender tx.
    signed_tx = w3.eth.account.sign_transaction(tx, me_prikey)
    tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
    print(to_hex(tx_hash))
##deploy_con('Storage')
##deploy_bin('Faucet')

# Once a contract is deployed it get an address.
##print(w3.eth.get_transaction_receipt(tx_hash).contractAddress)
##con_addr = '0xbE1b12Ea579EbC104E016210D402Ce9d7B1252dd'

# 2. Deploy contract by sending tx to address 0, using only bin.
def deploy_bin(fn):
    bin = read_file('contracts/' + fn + '.bin')
    nonce = w3.eth.getTransactionCount(me_addr)
    # The 'bin' is passed as 'data' of the tx.
    tx = { 'from': me_addr, # 'to': 0,
           'value': 0, 'data': bin,
           'nonce': nonce, 'chainId': "0x4",
           'gas': 1000000, 'gasPrice': "0x40000000"
    }
    return sign_send(tx, me_prikey)
##print(deploy_bin('MyErc20'))
##tx_hash = '0xbd37e573e6200011728257f94886bf05c60dc49b01b01b548ea7bd70eadba356'
##print(w3.eth.get_transaction_receipt(tx_hash).contractAddress)
##e20_addr = '0xb65712C2735eb99e67c117d7060EeFb31744006B'
