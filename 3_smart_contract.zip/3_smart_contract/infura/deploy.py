from myutil import *
from eth_utils.curried import to_hex

me_addr = "0x16c25A4cb42906a367Cce89043f3e39F9f892eb0"
me_prikey = "27ec6c0cbbd712214163bf859a67f38d290ba69650b1355066d5064d5d9522aa"
##print(w3i.eth.get_balance(me_addr))

# There are two alternative to programmatically deploy smart contracts.
# 1. Using contract constructor.
def con_deploy():
    abi = read_file('contracts/1_Storage.abi')
    bin = read_file('contracts/1_Storage.bin')
    
    # Create contract object (not deployed jet).
    con = w3.eth.contract(abi=abi, bytecode=bin)

    nonce = w3.eth.getTransactionCount(me_addr)
    tx = con.constructor().buildTransaction({
        'nonce': nonce, 'chainId': "0x4",
        'gas': "0x21000", 'gasPrice': "0x40000000",  # currGas
    })
    
    # Sign transaction with sender private key.
    signed_tx = w3.eth.account.sign_transaction(tx, me_prikey)
    tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
    print(to_hex(tx_hash))
##con_deploy()
tx_hash = '0x442b55fe9d0d115934294f147966dca052fb210c2cc923df7d8fb186f07b535a'

# Test the deployed 1_Storage contract.
def test_call():
    # Once a contract is deployed its geet an address.
    # Get Contract Address.
    addr = w3.eth.get_transaction_receipt(tx_hash).contractAddress
    abi = read_file('contracts/1_Storage.abi')
    c = w3.eth.contract(address=addr, abi=abi)
    print(c.functions.retrieve().call())
test_call()


# 2. Deploy contract by sending tx to address 0.
def deploy():
    nonce = w3.eth.getTransactionCount(me_addr)
    bin = read_file('contracts/1_Storage.bin')
    tx = { 'from': me_addr, # 'to': 0,
           'value': 0, 'data': bin,
           'nonce': nonce, 'chainId': "0x4",
           'gas': "0x21000", 'gasPrice': "0x40000000",  # currGas
    }
    signed_tx = w3.eth.account.sign_transaction(tx, me_prikey)
    tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
    print(to_hex(tx_hash))
##deploy()
##tx_hash = '0xa4d05562e3e05b6bb4ea7d5b09c4b5e846e127627a5d26b0819ae16ac759a81b'
# Try: test_call() with this tx_hash.
