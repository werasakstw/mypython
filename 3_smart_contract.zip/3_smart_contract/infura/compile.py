# pip install py-solc-x

from myutil import *
from eth_utils.curried import to_hex

##code = read_file('contracts/1_Storage.sol')
##print(code)

from solcx import install_solc
##print(install_solc(version='latest')) # as the pragma specify

# Compiled:
from solcx import compile_source
def compile(fn):
    code = read_file('contracts/' + fn+'.sol')
    compiled = compile_source(code, output_values=['abi', 'bin'])
    cid, cintf = compiled.popitem()
    abi = cintf['abi']
    bin = cintf['bin']
    write_file('contracts/' + fn+'.abi', w3.toJSON(cintf['abi']))
    write_file('contracts/' + fn+'.bin', cintf['bin'])
    return abi, bin
##abi, bin = compile('1_Storage')
##abi, bin = compile('Faucet')
##print(abi); print(bin)

# Test contract object:
def test_contract_obj(fn):
    abi = read_file('contracts/' + fn+'.abi')
    bin = read_file('contracts/' + fn+'.bin')
##    print(abi); print(bin)
    
    # Create contract object:
    c = w3.eth.contract(abi=abi, bytecode=bin)
    
    # List all functions in the contract.
    for f in c.all_functions():
        print(f.fn_name)
##test_contract_obj('1_Storage')
##test_contract_obj('Faucet')

