from myutil import *
from eth_utils.curried import to_hex

# To deploy a new contract a transaction must be created and signed.
# Here we will try calling an ready deployed contract.

# Find the 1_Storage contract address in Remix.
# Or in etherscan, stored as 'to'.
# Suppose 1_Storage contract is already deployed at:
addr = '0x3d06dc82f48668e0B652E79b8dA50e23A25BeED2'

# Read 1_Storage.abi from 'pysolc'.
# Or find 1_Storage abi in remix:compilation.
abi = read_file('contracts/1_Storage.abi')
##print(abi)

# Get call.
def retrieve_call():
    # Retrieve 1_Storage contract from address and abi.
    c = w3.eth.contract(address=addr, abi=abi)
    print(c.functions.retrieve().call())
##retrieve_call()
# Note: Normally to call a contract function we need
#  the contract address and its abi.

# Alternative 'ConciseContract' more efficient get calls.
def cc_call():
    c = w3.eth.contract(address=addr, abi=abi)
    from web3.contract import ConciseContract
    cc = ConciseContract(c)
    for _ in range(3):
        print(cc.retrieve())
##cc_call()

# Setting value needs creating a signed transaction.
me_addr = "0x16c25A4cb42906a367Cce89043f3e39F9f892eb0"
me_prikey = "27ec6c0cbbd712214163bf859a67f38d290ba69650b1355066d5064d5d9522aa"
def store_call():
    nonce = w3.eth.getTransactionCount(me_addr)
    c = w3.eth.contract(address=addr, abi=abi)
    tx = c.functions.store(123).buildTransaction({
        'nonce': nonce, 'chainId': 4,
        'gas': "0x21000", 'gasPrice': "0x40000000",  # currGas
    })

    # Sign transaction with sender private key.
    signed_tx = w3.eth.account.sign_transaction(tx, me_prikey)

    # Send transaction
    tx_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
    print(to_hex(tx_hash))
##store_call()
tx_hash = '0x9f24667e2e8798453412c17a6c8ed562782063a51166d850ae35bde9999b71a8'

# Get transaction Receipt.
##print_json(w3.eth.get_transaction_receipt(tx_hash))

# Try: retrieve_call() again.
##retrieve_call()
