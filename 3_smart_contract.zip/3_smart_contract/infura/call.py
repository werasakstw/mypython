from myutil import *

# To call a function of a deployed smart contract, we need
#   the smart contract address and its abi.

# The smart contract address can be found:
#  - Using Remix or Etherscan.
#  - Checking the 'to' of the tx that deploy the contract.

# Storage Smart Contract:
st_addr = '0x3d06dc82f48668e0B652E79b8dA50e23A25BeED2'
st_abi = read_file('contracts/Storage.abi')

# Getter call: No needs to create a tx and no gas.
def st_retrieve():
    c = w3.eth.contract(address=st_addr, abi=st_abi)
    print(c.functions.retrieve().call())
##st_retrieve()

# Alternatively, using 'ConciseContract' is more efficient for getter calls.
from web3.contract import ConciseContract
def st_cc():
    c = w3.eth.contract(address=st_addr, abi=st_abi)
    cc = ConciseContract(c)
    for _ in range(3):
        print(cc.retrieve())
##st_cc()

# Setter call: Needs a tx and gas.
me_addr = "0x16c25A4cb42906a367Cce89043f3e39F9f892eb0"
me_prikey = "27ec6c0cbbd712214163bf859a67f38d290ba69650b1355066d5064d5d9522aa"

def st_store(v):
    nonce, currGas = get_nonce_gas(me_addr)
    c = w3.eth.contract(address=st_addr, abi=st_abi)
    tx = c.functions.store(v).buildTransaction({
        'nonce': nonce, 'chainId': 4,
        'gas': "0x21000", 'gasPrice': currGas
    })
    return sign_send(tx, me_prikey)
##print(st_store(2))
tx_hash = '0x59729f104ec33de6141e28879d63a867ae58241a4fb125064e1851fe2f6abba5'
##print(w3.eth.get_transaction_receipt(tx_hash).contractAddress)
##st_retrieve()

#----------------------------------------------------------

# Faucet Smart Contract:
fc_addr = '0xEe6b30bdcEB23d6151F14bC0f474F2c401E7eABB'
fc_abi = read_file('contracts/Faucet.abi')

# A smart contract has address and balance
#  that can perform as a wallet or faucet.
print(w3.eth.get_balance(fc_addr))
print(w3.eth.get_balance(me_addr))

# Deposit some values to the faucet by excuting
#   the fallback function of the contract.
# The 'value' of tx is the amount to deposit.
# If the 'data' is empty, the 'value' will be added to the contract balance.
def deposit(v):  
    nonce, currGas = get_nonce_gas(me_addr)
    tx = {
        'from': me_addr, 'to': fc_addr,
        'value': v, 'data': '',
        'chainId': 4, 'nonce': nonce,
        'gas': 1000000, 'gasPrice': currGas,
    }
    return sign_send(tx, me_prikey)
##print(deposit(100))

def withdraw(v):
    con = w3.eth.contract(address=fc_addr, abi=fc_abi)
    nonce, currGas = get_nonce_gas(me_addr)
    # The 'v' will be transfered from the contract balance
    #   to the tx caller balance.
    tx = con.functions.withdraw(v).buildTransaction({
        'chainId': 4, 'nonce': nonce,
        'gas': 1000000, 'gasPrice': "0x40000000",
    })
    return sign_send(tx, me_prikey)
##print(withdraw(2))
