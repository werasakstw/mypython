import pandas as pd
from admins import connect, stu_json, fac_json, inj_json
from requests import post

def list(table):
    with connect() as con:
        tb = con['mydb'][table]
        for r in tb.find({}, { '_id': False }):
            print(r)
##list('student')

#---------------------------------------------------------

def send_post(path, data):
    return post(path, data=data).content.decode()
             
def student_insert():
    df = pd.read_csv('student.csv', encoding='ISO-8859-11' )
    for s in df.values:
        sj = stu_json(s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7], s[8], s[9], s[10])
        print(send_post('http://127.0.0.1:8080/student/insert', data=sj))
#student_insert()

def faculty_insert():
    df = pd.read_csv('faculty.csv', encoding='ISO-8859-11' )
    for s in df.values:
        sj = fac_json(s[0], s[1], s[2], s[3], s[4])
        #print(sj, end='\n\n')
        print(send_post('http://127.0.0.1:8080/faculty/insert', data=sj))
faculty_insert()

def injection_insert():
    df = pd.read_csv('inj.csv', encoding='ISO-8859-11' )
    for s in df.values:
        sj = inj_json(s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7])
        #print(sj, end='\n\n')
        print(send_post('http://127.0.0.1:8080/injection/insert', data=sj))
#injection_insert()










def faculty_insert():
    df = pd.read_csv('faculty.csv', encoding='ISO-8859-11' )
    for s in df.values:
        sj = fac_json(s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7])
        print(send_post('http://127.0.0.1:8080/faculty/insert', data=sj))
##faculty_insert()
