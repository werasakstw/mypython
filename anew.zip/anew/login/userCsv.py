from flask import Flask
import pandas as pd

app = Flask(__name__)
app.config['SECRET_KEY'] = 'hello123'

udf = None
def load_udf():
    print('Load users.csv')
    global udf
    udf = pd.read_csv('users.csv', encoding='ISO-8859-11' )

@app.route('/list')
def list():
    res = [(uid, name, pwd) for uid, name, pwd in zip(
                udf.uid.values, udf.name.values, udf.pwd.values)]
    return str(res)

@app.route('/get/<uid>')
def get(uid):
    res = udf.query('uid == @uid').values
    print(uid, res)
    if res.size > 0:
        return str(res[0])
    return 'Not found'

@app.route('/find/<name>')
def find(name):
    res = udf.query('name == @name').values
    print(name, res)
    if res.size > 0:
        return str(res[0])
    return 'Not found'
# curl 127.0.0.1:8080/find/John%20Rambo

@app.route('/update/<name>/<pwd>')
def update(name, pwd):
    udf.loc[udf.name == name, 'pwd'] = pwd
    udf.to_csv('users.csv', encoding='ISO-8859-11', index=False)
    return 'Success'

@app.route('/insert/<uid>/<name>/<pwd>')
def insert(uid, name, pwd):
    try:
        with open('users.csv', 'a') as f:
            f.write('%s,%s,%s\n' % (uid, name, pwd))
        load_udf()
        return 'Success'
    except:
        return 'Fail'
# curl 127.0.0.1:8080/insert/3/Jame%20Bond/whatup

if __name__ == '__main__':
    load_udf()
    app.run(port=8080, debug=True)
