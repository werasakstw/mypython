from flask import Flask, render_template, redirect, request, session, url_for, flash
from flask_pymongo import PyMongo

app = Flask(__name__)
app.config['SECRET_KEY'] = 'hello123'
app.config['USE_SESSION_FOR_NEXT'] = True
app.config['MONGO_URI'] = 'mongodb://localhost:27017/mydb'
db = PyMongo(app).db.mydb

from werkzeug.security import generate_password_hash, check_password_hash
@app.route('/adduser')
def adduser():
    db.user.insert_many([
        {'citizen_id': '0000000000001', 'name': 'john', 'pwd': generate_password_hash('john')},
        {'citizen_id': '0000000000002', 'name': 'jack', 'pwd': generate_password_hash('jack')} ])
    return 'Success'

@app.route('/list')
def list():
    res = db.user.find({}, {'_id': False, 'citizen_id': True, 'name': True, 'pwd': True})
    return render_template('list.html', users=[s for s in res])

@app.route('/find/<name>')
def find(name):
    return db.user.find_one({'name': name}, {'_id' : False})

@app.route('/update/<name>/<pwd>')
def update(name, pwd):
    res = db.user.update_one({'name': name}, {'$set': {'pwd': pwd}})
    return res.raw_result

@app.route('/delete/<name>')
def delete(name):
    res = db.user.delete_one({'name': name})
    return res.raw_result

@app.route('/drop')
def drop():
    db.user.drop()
    return 'Success'

@app.before_first_request
def init_db():
    print('Init Db')
    db.user.drop()
    adduser()

#-------------------------------------------------------------------
from flask_login import LoginManager, login_required, \
	login_user, current_user, logout_user
from flask_login.mixins import UserMixin

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

class User(UserMixin):
    def __init__(self, citizen_id, name, pwd):
        self.citizen_id = citizen_id
        self.name = name
        self.pwd = pwd

    def get_id(self):
        return self.name

@login_manager.user_loader
def load_user(name):
    u = db.user.find_one({'name': name})
    if not u:
        return None
    return User(citizen_id=u['citizen_id'], name=u['name'], pwd=u['pwd'])
     
#--------------------------------------------------

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/curuser')
def curuser():
    try:
        return current_user.name
    except:
        return 'None'

@app.route('/hello')
@login_required
def hello():
    return 'Hello ' + current_user.name

#--------------------------------------------------

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    
    name = request.form.get('name').strip()
    pwd = request.form.get('pwd').strip()
    if name == '' or pwd == '':
        flash('Name and password are required.')
        return redirect(url_for('login'))

    u = db.user.find_one({'name': name})
    if not u or not check_password_hash(u['pwd'], pwd):
        flash('Invalid user or password.')
        return redirect(url_for('login'))
    
    login_user(User(citizen_id=u['citizen_id'], name=u['name'], pwd=u['pwd']), remember=True)
    if 'next' in session:
        return redirect(session['next'])
    return current_user.name + ' successfully login.'

@app.route('/logout')
@login_required
def logout():
    cuname = current_user.name
    logout_user()
    return cuname + ' logout.'

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')

    cid = request.form.get('cid').strip()
    name = request.form.get('name').strip()
    pwd = request.form.get('pwd').strip()
    cpwd = request.form.get('cpwd').strip()
    if cid == '' or name == '' or pwd == '' or cpwd == '':
        flash('Please fill in all values.')
        return redirect(url_for('register'))
    if len(cid) != 13:
        flash('Citizen id must be 13 digits.')
        return redirect(url_for('register'))        
    if pwd != cpwd:
        flash('Confirm password invalid.')
        return redirect(url_for('register'))

    u = db.user.find_one({'name': name})
    if u:
        flash('The user is already registered.')
        return redirect(url_for('register'))

    db.user.insert_one({"citizen_id": cid, "name": name, "pwd": generate_password_hash(pwd)})
    flash('Register success.')
    return render_template('index.html')

@app.route('/changepwd', methods=['GET', 'POST'])
def changepwd():
    if request.method == 'GET':
        return render_template('changepwd.html')
    name = request.form.get('name').strip()
    opwd = request.form.get('opwd').strip()
    npwd = request.form.get('npwd').strip()
    cpwd = request.form.get('cpwd').strip()
    if name == '' or opwd == '' or npwd == '' or cpwd == '':
        flash('Please fill in all values.')
        return redirect(url_for('changepwd'))
    if npwd != cpwd:
        flash('New and Confirm password invalid.')
        return redirect(url_for('changepwd'))
 
    u = db.user.find_one({'name': name})
    if not u:
        flash('The name is not registered.')
        return redirect(url_for('changepwd'))
    if not check_password_hash(u['pwd'], opwd):
        flash('Invalid old password.')
        return redirect(url_for('changepwd'))

    hpwd = generate_password_hash(npwd)
    db.user.update_one({'name': name}, {'$set': {'pwd': hpwd}})
    flash('Change password success.')
    return render_template('index.html')

if __name__ == "__main__":
    app.run(port=8080, debug=True)
