import requests

def send_get(path):
   return requests.get(path).content.decode()

p = 'http://127.0.0.1:8080/admin/myfileadmin/download/'
##fname = 'hello.txt'
fname = 'students.csv'
print(send_get(p+fname))


