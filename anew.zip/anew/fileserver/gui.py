from tkinter import *
from tkinter import ttk
import requests, os
MYFONT = 'Helvetica 13 normal'

root = Tk()
root.title('Statistic')
root.minsize(width=650, height=150)
root.geometry('700x300+150+120')

loadframe = LabelFrame(root, text='Input File', font=MYFONT)
loadframe.pack(side=TOP, anchor=W, padx=100, pady=30)

ttk.Label(loadframe, text='File Name') \
    .grid(column=0, row=1, padx=8, pady=4)
name = StringVar()
ttk.Entry(loadframe, width=40, textvariable=name) \
    .grid(column=1, row=1, sticky='w', padx=10, pady=10)

output = Label(loadframe, text='', font=MYFONT)
output.grid(column=1, row=2, sticky='w', padx= 10, pady=10)

dpath = 'http://127.0.0.1:8080/admin/myfileadmin/download/'
fname = 'students.csv'
def doLoad():
    global fname
    fname = name.get().strip()
    if fname == '':
        output.config(fg='red', text='Please input a file name.')
    elif os.path.exists(fname):
        output.config(fg='red', text=fname + ' already loaded.')
    else:
        res = requests.get(dpath+fname)
        if res.status_code == 200:
            with open(fname, 'wb') as f:
                f.write(res.content)
                output.config(fg='green', text='Load ' + fname + ' success.')
        else:
            output.config(fg='red', text='Error loading the file.')

ttk.Button(loadframe, text="Load", command=doLoad) \
    .grid(column=3, row=1, padx=10, pady=10)

#-----------------------------------------------------------

opframe = LabelFrame(root, text='Operations', font=MYFONT)
opframe.pack(side=BOTTOM, padx=100, pady=30)

import pandas as pd
import matplotlib.pyplot as pp

def doStatistics():
    df = pd.read_csv(fname)
    t = df.total

    frame = Tk()
    frame.title('Statistic')
    frame.geometry('500x250+300+220')
    frame.config(padx= 20, pady=20)
    Label(frame, text='Max-Min', fg='red', font=MYFONT) \
       .grid(column=0, row=0, padx= 10, pady=10)
    Label(frame, text=('%.2f,   %.2f' % (t.max(), t.min())), font=MYFONT) \
       .grid(column=1, row=0, padx= 10, pady=10)

    Label(frame, text='Mean-Median', fg='red', font=MYFONT) \
       .grid(column=0, row=1, padx= 10, pady=10)
    Label(frame, text=('%.2f,   %.2f' % (t.mean(), t.median())), font=MYFONT) \
       .grid(column=1, row=1, padx= 10, pady=10)

    Label(frame, text='SD', fg='red', font=MYFONT) \
       .grid(column=0, row=2, padx= 10, pady=10)
    Label(frame, text=('%.2f' % t.std()), font=MYFONT) \
       .grid(column=1, row=2, padx= 10, pady=10)
    
    gc = df.grade.value_counts()
    gc = [(k,v) for k, v in sorted(gc.items(), key=lambda item: item[0])]
    Label(frame, text='Frequency count', fg='red', font=MYFONT) \
       .grid(column=0, row=3, padx= 10, pady=10)
    Label(frame, text=str(gc), font=MYFONT) \
       .grid(column=1, row=3, padx= 10, pady=10)   
    
ttk.Button(opframe, text="Statistics", command=doStatistics) \
    .grid(column=0, row=0, padx=10, pady=10)

def doHistogram():
    df = pd.read_csv(fname)
    pp.title('Total Histogram')
    pp.hist(df.total)
    pp.show()

ttk.Button(opframe, text="Histogram", command=doHistogram) \
    .grid(column=1, row=0, padx=10, pady=10)

def doPie():
    df = pd.read_csv(fname)
    pp.title('Pie')
    gc = df.grade.value_counts()
    pp.pie(gc, autopct='%.1f%%', labels=('C', 'D', 'B', 'A', 'F'))
    pp.show()
    
ttk.Button(opframe, text="Pie", command=doPie) \
    .grid(column=2, row=0, padx=10, pady=10)








