from flask import Flask
from flask_admin import Admin
from flask_admin.contrib.fileadmin import FileAdmin

app = Flask(__name__)
app.config['SECRET_KEY'] = 'hello123'
admin = Admin(app, name='Data Service', template_mode='bootstrap3')

class MyFileAdmin(FileAdmin):
    can_edit = False 
    can_delete = False
    can_mkdir = False
    can_upload = True
    allowed_extensions = ('csv')	# For upload files.
##    can_rename = False

import os.path as op
path = op.join(op.dirname(__file__), 'data')
admin.add_view(MyFileAdmin(path, None, name='Data'))
 
# curl 127.0.0.1:8080/admin/myfileadmin/download/hello.txt
# curl 127.0.0.1:8080/admin/myfileadmin/download/students.csv
# The downloaded file is saved in the default Download directory.

#----------------------------------------------------------------

import pandas as pd

sdf = None
if not sdf:
    print('Load student.csv')
    sdf = pd.read_csv('data/students.csv', encoding='ISO-8859-11' )

@app.route('/name_grade')
def name_grade():
    res = [(n,g) for n,g in zip( \
        sdf.name.values, sdf.grade.values) ]
    return str(res)

@app.route('/total_avg')
def total_avg():
    return '%.2f' % sdf.total.mean()

@app.route('/grade/<name>')
def grade(name):
    res = sdf.loc[sdf.name == name, 'grade'].values
    if res:
        return res[0]
    return 'Name not found'

@app.route('/fail')
def fail():
    res = [n for n in sdf.loc[sdf.grade == 'F', 'name'].values]
    if res:
        return str(res)
    return 'None'

if __name__ == '__main__':
    app.run(port=8080, debug=True)
