from werkzeug.security import generate_password_hash, \
     check_password_hash

name = 'john'
pw = 'hello123'

d = {}
d[name] = generate_password_hash(pw)
print(d, len(d[name]))
print(check_password_hash(d[name], 'hello123'))



'''
# pip install Flask-Bcrypt
# from flask_bcrypt import Bcrypt

from flask import Flask
app = Flask(__name__)
bcrypt = Bcrypt(app)

class Pwd():
    def __init__(self):
        if not os.path.exists('pwd.bin'):
            with open('pwd.bin', 'wb') as f:
                pickle.dump({'rambo': 'First Blood'}, f)

    def _print(self):
        with open('pwd.bin', 'rb') as f:
            d = pickle.load(f)
        for (k, v) in d.items():
            print(k, v)

    def save(self, name, pwd):
        with open('pwd.bin', 'rb') as f:
            p = pickle.load(f)
        p[name] = bcrypt.generate_password_hash(pwd)
        with open('pwd.bin', 'wb') as f:
            pickle.dump(p, f)

    def is_valid(self, name, pwd):
        with open('pwd.bin', 'rb') as f:
            p = pickle.load(f)
        return bcrypt.check_password_hash(p[name], pwd)
        
pwd = Pwd()
pwd.save('admin', 'hello123')
pwd._print()
print(pwd.is_valid('admin', 'hello123'))

def reg_pwd(name, pwd):
	pw_hash = bcrypt.generate_password_hash(pwd)
	savePwd(name, pw_hash)
#reg_pwd('jack', 'hello123')
'''

