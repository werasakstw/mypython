from flask import Flask, jsonify
from flask_pymongo import PyMongo
app = Flask(__name__)
app.config['SECRET_KEY'] = 'hello123'
app.config['MONGO_URI'] = 'mongodb://localhost:27017/mydb'
db = PyMongo(app).db.mydb

@app.route('/add')
def add():
    db.user.insert_one({'name': 'john', 'pwd': 'john'})
    db.user.insert_many([{'name': 'jack', 'pwd': 'jack'},
                         {'name': 'joe', 'pwd': 'joe'}] )
    return 'success'

import json
@app.route('/list')
def list():
##    res = db.mydb.user.find()
    res = db.user.find({}, {'_id' : False})
    us = [u for u in res]
    return jsonify(us)
##    return json.dumps(us)
##    return str(us)

@app.route('/find/<name>')
def find(name):
    res = db.user.find_one({'name': name}, {'_id' : False})
    return json.dumps(res)

@app.route('/update/<name>/<pwd>')
def update(name, pwd):
    res = db.user.update_one({'name': name}, {'$set': {'pwd': pwd}})
    return res.raw_result

@app.route('/replace/<name>/<pwd>')
def replace(name, pwd):
    res = db.user.replace_one({'name': name}, \
                                   {'name': name, 'pwd': pwd})
    return res.raw_result

@app.route('/delete/<name>')
def delete(name):
    res = db.user.delete_one({'name': name})
    return res.raw_result

@app.route('/drop')
def drop():
    db.user.drop()
    return 'success'

if __name__ == '__main__':
    app.run(port=8080, debug=True)
