﻿# pip install email-validator

from flask import Flask
from flask_admin import Admin

app = Flask(__name__)
app.config['SECRET_KEY'] = 'hello123'
app.config['FLASK_ADMIN_SWATCH'] = 'cerulean'
admin = Admin(app, name='Test', template_mode='bootstrap3')

from flask_wtf import FlaskForm as Form
from wtforms.fields import PasswordField, TextField, SelectField, StringField, SubmitField, IntegerField, BooleanField, SelectField
from wtforms import validators
from wtforms.validators import DataRequired, Length, NumberRange, Email, AnyOf
#from wtforms.fields.html5 import DateField
import json
class StudentForm(Form):
    prefix_ = SelectField('Prefix', choices=(('นาย','นาย'), ('นาง','นาง'), ('นางสาว','นางสาว')))
    rank = StringField('Rank', validators=[DataRequired(), AnyOf(('อ', 'ผศ', 'รศ', 'ศ'))])
    name = StringField('Name', validators=[DataRequired(), Length(max=60)])
    pro = BooleanField('Pro')
    phone = StringField('Phone Number', validators=[DataRequired(), Length(max=12)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    birth = StringField('Birth Date')
    pwd = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Submit')

def stu_json( prefix_, rank, name, pro, phone, email, birth, pwd):
    return {"prefix_": prefix_, "rank": rank, "name": name, "pro": pro, \
            "phone": phone, "email": email, "birth": birth, \
            "pwd": pwd }

from flask_admin.contrib.pymongo import ModelView
class StudentView(ModelView):
    column_list = ('prefix_', 'rank', 'name', 'pro', 'phone', \
                  'email', 'birth', 'pwd')
    form_edit_rules = ('prefix_', 'rank', 'name', 'pro', 'phone', \
                  'email', 'birth', 'pwd')
    column_searchable_list = ('name', 'phone', 'email')
    column_sortable_list = ('name', 'phone')
    can_delete = False
    form = StudentForm

#-------------------------------------------------------------------
   
import pymongo as pm
def connect():
    try:
         return  pm.MongoClient() # 'mongodb://127.0.0.1:27017'
    except:
        print('Connect fails.')
    return None

import datetime
today = datetime.date.today()		# date object
ts = datetime.date.isoformat(today)	# str

db = connect().mydb
if db:
    db['student'].drop()
    tb = db['student']
    john = stu_json('นาย', 'ผศ', 'John Rambo', True, '081-1111234', \
        'john@rambo.com', ts, 'hello')
    jack = stu_json('นาย', 'ศ', 'Jack Ripper', False, '081-1111000', \
        'jack@ripper.com', ts, 'hi')
    tb.insert_many([john, jack])
    admin.add_view(StudentView(db['student']))

if __name__ == '__main__':
    app.run(port=8081, debug=True)

