import pandas as pd

code = [ c for c in range(10)]
status = [ 'ปกติ', 'ย้ายสาขาวิชา', 'ขอพักการเรียน', 'ขอรักษาสถานภาพนักศึกษา', \
    'ขอคืนสถานภาพนักศึกษา', 'ย้ายไปเรียน ภาคกศ.ปช.', 'พ้นสภาพวัดผลทางทะเบียน', \
    'พ้นสภาพทางการเงิน', 'พ้นสภาพการเป็นนักศึกษา', 'ลาออก']
st = {}
for s, c in zip(status, code):
    st[s] = c
def get_status(s):
    return st[s]
##print(get_status('ลาออก'))

def student_csv():
    df = pd.read_csv('s5.csv', encoding='ISO-8859-11' )
    df['status_code'] = df.status.map(get_status)
    sdf = df.drop('zcode', axis=1)  \
            .drop('province', axis=1) \
            .drop('district', axis=1) \
            .drop('subdistrict', axis=1) \
            .drop('rode', axis=1) \
            .drop('lane', axis=1) \
            .drop('village', axis=1) \
            .drop('home_number', axis=1) \
            .drop('email', axis=1) \
            .drop('mobile_phone', axis=1) \
            .drop('home_phone', axis=1) \
            .drop('status', axis=1) \
            .drop('discipline', axis=1) \
            .drop('category', axis=1) \
            .drop('department', axis=1)
    sdf.to_csv('student.csv', index=False, encoding='ISO-8859-11')
##student_csv()

def address_csv():
    df = pd.read_csv('s5.csv', encoding='ISO-8859-11' )
    df['status_code'] = df.status.map(get_status)
    adf = df.drop('studen_id', axis=1)  \
            .drop('prefix', axis=1) \
            .drop('first_name', axis=1) \
            .drop('last_name', axis=1) \
            .drop('birth__date', axis=1) \
            .drop('discipline_code', axis=1) \
            .drop('discipline', axis=1) \
            .drop('department_code', axis=1) \
            .drop('department', axis=1) \
            .drop('category_code', axis=1) \
            .drop('category', axis=1) \
            .drop('status_code', axis=1) \
            .drop('status', axis=1)
    adf.to_csv('address.csv', index=False, encoding='ISO-8859-11')
##address_csv()            
