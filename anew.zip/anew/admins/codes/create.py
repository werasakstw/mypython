import pandas as pd

def find_status():
    s = set()
    def add(st):
        if st not in s:
            s.add(st)
    df = pd.read_csv('s5.csv', encoding='ISO-8859-11' )
    df.status.map(add)
    print(s)
##find_status()

def status_csv():
    code = [ c for c in range(10)]
    status = [ 'ปกติ', 'ย้ายสาขาวิชา', 'พักการเรียน', 'รักษาสถานภาพนักศึกษา', \
    'คืนสถานภาพนักศึกษา', 'ย้ายไปเรียน ภาคกศ.ปช.', 'พ้นสภาพวัดผลทางทะเบียน', \
    'พ้นสภาพทางการเงิน', 'พ้นสภาพการเป็นนักศึกษา', 'ลาออก']
    st = { 'code': code,
           'status': status }
    df = pd.DataFrame(st, columns=['code', 'status'])
    df.to_csv('status.csv', index=False, encoding='ISO-8859-11' )
##status_csv()

def discipline_csv():
    s = set()
    def add(cd):
        if cd not in s:
            s.add(cd)
    df = pd.read_csv('s5.csv', encoding='ISO-8859-11' )
    cf = df.discode.values
    df = df.discipline.values
    for c, d in zip(cf, df):
        add((c, d))
    code = []
    discipline = []
    for (c,d) in s:
        code.append(c)
        discipline.append(d)
    dt = { 'code': code,
           'discipline': discipline }
    df = pd.DataFrame(dt, columns=['code', 'discipline'])
    df = df.sort_values(by='code',  ascending=True)
    df.to_csv('discipline.csv', index=False, encoding='ISO-8859-11' )
##discipline_csv()

def department_csv():
    s = set()
    def add(cd):
        if cd not in s:
            s.add(cd)
    df = pd.read_csv('s5.csv', encoding='ISO-8859-11' )
    cf = df.depcode.values
    df = df.department.values
    for c, d in zip(cf, df):
        add((c, d))    
    code = []
    department = []
    for (c,d) in s:
        code.append(c)
        department.append(d)
    dt = { 'code': code,
           'department': department }
    df = pd.DataFrame(dt, columns=['code', 'department'])
    df = df.sort_values(by='code',  ascending=True)
    df.to_csv('department.csv', index=False, encoding='ISO-8859-11' )
##department_csv()

def category_csv():
    s = set()
    def add(cd):
        if cd not in s:
            s.add(cd)
    df = pd.read_csv('s5.csv', encoding='ISO-8859-11' )
    cf = df.catcode.values
    df = df.category.values
    for c, d in zip(cf, df):
        add((c, d))    
    code = []
    category = []
    for (c,d) in s:
        code.append(c)
        category.append(d)
    dt = { 'code': code,
           'category': category }
    df = pd.DataFrame(dt, columns=['code', 'category'])
    df = df.sort_values(by='code',  ascending=True)
    df.to_csv('category.csv', index=False, encoding='ISO-8859-11' )
##category_csv()

