import csv

prefix_choice = ((0, 'นาย'), (1, 'นาง'), (2, 'นางสาว'))
prefix_dict = dict(prefix_choice)
def prefix_value(c):
    return prefix_dict.get(c)

#---------------------------------------------------------

def create_discipline_choice():
    with open('codes/discipline.csv') as f: 
        data = csv.reader(f)
        header = next(data)
        a = []
        for row in data:
            a.append((int(row[0]), row[1]))
        return tuple(a)
discipline_choice = create_discipline_choice()
discipline_dict = dict(discipline_choice)
def discipline_value(c):
    return discipline_dict.get(c)

#---------------------------------------------------------

department_choice = ((1, 'ครุศาสตร์'), (2, 'มนุษยศาสตร์และสังคมศาสตร์'), \
               (3, 'วิทยาศาสตร์และเทคโนโลยี'), (4, 'วิทยาการจัดการ'), \
               (5, 'เทคโนโลยีการเกษตรและเทคโนโลยีอุตสาหกรรม'))
department_dict = dict(department_choice)
def department_value(c):
    return department_dict.get(c)

#---------------------------------------------------------

category_choice =((1, 'ปกติ'), (2, 'กศ.ปช'), (3, 'พิเศษ(ป.โท)'), (6, 'ปกติ(ป.โท)'))
category_dict = dict(category_choice)
def category_value(c):
    return category_dict.get(c)

#---------------------------------------------------------

status_choice = ((0, 'ปกติ'), (1, 'ย้ายสาขาวิชา'), (2, 'พักการเรียน'), \
                 (3, 'รักษาสถานภาพนักศึกษา'), (4, 'คืนสถานภาพนักศึกษา'), \
                 (5, 'ย้ายไปเรียน ภาคกศ.ปช.'), (6, 'พ้นสภาพวัดผลทางทะเบียน'), \
                 (7, 'พ้นสภาพทางการเงิน'), (8, 'พ้นสภาพการเป็นนักศึกษา'),   (9, 'ลาออก'))
status_dict = dict(status_choice)
def status_value(c):
    return status_dict.get(c)
