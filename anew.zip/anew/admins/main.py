﻿# pip install flask_pymongo
# pip install flask_wtf

from flask import Flask, render_template, request
from flask_admin import Admin
from flask_admin.menu import MenuLink
from flask_pymongo import PyMongo

app = Flask(__name__)
app.config['SECRET_KEY'] = 'hello123'
app.config['FLASK_ADMIN_SWATCH'] = 'cerulean'
app.config['MONGO_URI'] = 'mongodb://localhost:27017/mydb'
admin = Admin(app, name='Admin App', template_mode='bootstrap3')
db = PyMongo(app).db.mydb

from flask_wtf import FlaskForm as Form
from wtforms.fields import StringField, SelectField
from wtforms import validators
from wtforms.validators import DataRequired, Length
from codes.code import *

class StudentForm(Form):
    citizen_id = StringField('Citizen Id', validators=[DataRequired(), Length(max=13)])
    student_id = StringField('Student Id', validators=[DataRequired(), Length(max=12)])
    prefix_ = SelectField('Prefix', choices=prefix_choice)
    first_name = StringField('First Name', validators=[DataRequired(), Length(max=60)])
    last_name = StringField('First Name', validators=[DataRequired(), Length(max=60)])
    birth_date = StringField('Birth Date', validators=[DataRequired(), Length(max=10)])
    discipline_code = SelectField('Discipline', choices=discipline_choice)
    department_code = SelectField('Department', choices=department_choice)
    category_code = SelectField('Category', choices=category_choice)
    status_code = SelectField('Status', choices=status_choice)

def stu_json(citizen_id, student_id, prefix_, first_name, last_name, birth_date, \
             discipline_code, department_code, category_code, status_code):
    return {"citizen_id": citizen_id, "student_id": student_id, "prefix_": prefix_, \
            "first_name": first_name, "last_name": last_name, "birth_date": birth_date, \
            "discipline_code": discipline_code, "department_code": department_code, \
            "category_code": category_code, "status_code": status_code}

from flask_admin.contrib.pymongo import ModelView
class StudentView(ModelView):
    column_list = ('citizen_id', 'student_id', 'prefix_', 'first_name', 'last_name',
      'birth_date', 'discipline_code', 'department_code', 'category_code', 'status_code' )
    column_searchable_list = ('first_name', 'last_name')
    can_delete = False
    can_create = False
    form = StudentForm

@app.route('/student/list')
def student_list():
    res = db.student.find({}, {'_id': False, 'citizen_id': True, 'prefix_': True, \
       'first_name': True, 'last_name': True, 'birth_date': True, \
       'discipline_code': True, 'department_code': True, \
       'category_code': True, 'status_code': True })
    return str([s for s in res])
   
#------------------------------------------------------------------

import datetime
@app.before_first_request
def init_db():
    print('Init Db')
    db.student.drop()
    today = datetime.date.isoformat(datetime.date.today())
    john = stu_json('1470000000000', '581103000000', 0, 'John', 'Rambo', today, 5, 2, 1, 0)
    jack = stu_json('1470000000001', '581103000001', 1, 'Jack', 'Ripper', today, 24,1, 2, 1)
    db.student.insert_many([john, jack])


#------------------------------------------------------------------

admin.add_view(StudentView(db['student'], name='Student Admin', category='Student'))
admin.add_link(MenuLink(name='Student Info', url='/student_index', category='Student'))
    
@app.route('/student_index')
def student_index():
    return render_template('student_index.html')

def date_decode(d):
    date = datetime.datetime.strptime(d, "%Y-%m-%d")
    return datetime.datetime.strftime(date, "%d %B %Y")

def student_decode(s):
    sd = dict(s)
    sd['prefix_'] = prefix_value(sd['prefix_'])
    sd['birth_date'] = date_decode(sd['birth_date'])
    sd['discipline'] = discipline_value(sd['discipline_code'])
    sd['department'] = department_value(sd['department_code'])
    sd['category'] = category_value(sd['category_code'])
    sd['status'] = status_value(sd['status_code'])
    return sd
                        
@app.route('/student/find_by_cid')
def student_find_by_cid():
    cid = request.args.get('cid')
    s = db.student.find_one({'citizen_id': cid})
    if not s:
        return 'Not Found'
    return render_template('student_info.html', student=student_decode(s))

if __name__ == '__main__':
    app.run(port=8081, debug=True)

