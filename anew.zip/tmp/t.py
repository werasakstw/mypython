from flask import Flask
import pandas as pd

udf = pd.read_csv('users.csv', encoding='ISO-8859-11' )
print(udf)

uid = 2
res = udf.query('uid == @uid').values
print(uid, res)

name = 'John Rambo'
res = udf.query('name == @name').values
print(uid, res)
