from flask import Flask, render_template, redirect, request, session, url_for, flash
from flask_admin import Admin
from flask_pymongo import PyMongo

from flask_wtf import FlaskForm
from wtforms.fields import IntegerField, StringField
from wtforms.validators import DataRequired, Length

from flask_login import LoginManager, login_required, \
	login_user, current_user, logout_user
from flask_login.mixins import UserMixin

from werkzeug.security import generate_password_hash, \
     check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'hello123'
app.config['FLASK_ADMIN_SWATCH'] = 'cerulean'
app.config['USE_SESSION_FOR_NEXT'] = True
app.config['MONGO_URI'] = 'mongodb://localhost:27017/mydb'
admin = Admin(app, name='Test', template_mode='bootstrap3')
db = PyMongo(app).db.mydb

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'


   
class UserForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired(), Length(max=60)])
    pwd = StringField('Password', validators=[DataRequired(), Length(max=100)])
    
def user_json(name, pwd):
    return { "name": name, "pwd": generate_password_hash(pwd) }

from flask_admin.contrib.pymongo import ModelView
class UserView(ModelView):
    column_list = ('name', 'pwd')
    form = UserForm
admin.add_view(UserView(db['user']))
               
@app.before_first_request
def init_db():
    print('Init Db')
    db.user.drop()
    john = user_json('john', 'john')
    jack = user_json('jack', 'jack')
    db.user.insert_many([john, jack])

#--------------------------------------------------

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

class User(UserMixin):
  def __init__(self, name, pwd):
    self.name = name
    self.pwd = pwd

  def get_id(self):
    return self.name

@login_manager.user_loader
def load_user(name):
    u = db.user.find_one({'name': name})
    if not u:
        return None
    return User(name=u['name'], pwd=u['pwd'])
     
#--------------------------------------------------

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/list')
def list():
    res = db.user.find({}, {'_id': False, 'name': True, 'pwd': True})
    return str([s for s in res])

@app.route('/find/<name>')
def find(name):
    return db.user.find_one({'name': name}, {'_id' : False})

@app.route('/curuser')
def curuser():
    try:
        return current_user.name
    except:
        return 'None'

@app.route('/hello')
@login_required
def hello():
    return 'Hello ' + current_user.name

@app.route('/logout')
@login_required
def logout():
    uname = current_user.name
    logout_user()
    return uname + ' logout.'


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    
    name = request.form.get('name').strip()
    pwd = request.form.get('pwd').strip()
    if name == '' or pwd == '':
        flash('Name and password are required.')
        return redirect(url_for('login'))

    u = db.user.find_one({'name': name})
    if not u or not check_password_hash(u['pwd'], pwd):
        flash('Invalid user or password.')
        return redirect(url_for('login'))
    
    login_user(User(name=u['name'], pwd=u['pwd']), remember=True)
    if 'next' in session:
        return redirect(session['next'])
    return user.name + ' successfully login.'

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')

    name = request.form.get('name').strip()
    pwd = request.form.get('pwd').strip()
    cpwd = request.form.get('cpwd').strip()
    if name == '' or pwd == '' or cpwd == '':
        flash('Name, password and comfirm password are required.')
        return redirect(url_for('register'))
    if pwd != cpwd:
        flash('Confirm password in valid.')
        return redirect(url_for('register'))

    u = db.user.find_one({'name': name})
    if u:
        flash('The user is already registered.')
        return redirect(url_for('register'))

    db.user.insert_one(user_json(name, pwd))
    flash('Register success.')
    return render_template('index.html')


if __name__ == "__main__":
    app.run(port=8080, debug=True)
