﻿''' An object is 'hashable' if it is immutable (its value never changes during
  lifetime) and must be capable of comparing itself to the other.
        __hash__() returns an integer that is the hash value of the object.
        __eq__() for comparing its value to the other object value.
The choices of computing hash is depended on implementations.
Two objects are equal if they have the same hash value but the reverse may not be true. '''
def hash_test():
    ## Most classes use the object's state as the hash value e.g. int.
    i = 1
    print(hash(i), hash(i))     # 1 1

    ## <class 'object'> has __hash__() that returns a random integers.
    a, b = object(), object()
    print(hash(a), hash(b))     # -2147019034 464388
# hash_test()

## A class is hashable if it has __hash__() and __eq__().
class A:
    def __init__(self, x):
        self.x = x
    def __hash__(self):
        return self.x
    def __eq__(self, other):
        return self.x == other.x
# print(hash(A(0)), hash(A(1)), hash(A(1)))    # 0 1 1

## To test if an object is hashable.
from collections.abc import Hashable
# print(isinstance(A(0), Hashable))

## Dict's keys must be hashable.
def hash_key():
    d = dict()
    a, b = A(1), A(2)
    d[a] = 'hello'
    d[b] = 'hi'
    print(d[a])         # hello
    print(d[b])         # hi
    ## Try: comment  __hash__() or __eq__() in class 'A'.
# hash_key()

''' All immutable built-in types are hashable.
Mutable types such as list, dict, and set are not hashable. '''
def is_hashable(obj):
    return isinstance(obj, Hashable)

def hashable_test():
    ## Immutable types(e.g. bool, int, float, str, and tuple) are hashable.
    print(is_hashable(False), is_hashable(1), is_hashable(1.0), \
          is_hashable('Hello'), is_hashable((1,2)))
        # True True True True True

    ## Mutable types(e.g. list, set, and dict) are not hashable.
    print(is_hashable([]), is_hashable({1}), is_hashable({'x': 1}))
        # False False False
# hashable_test()

## Set members must be hashable, so set cannot be member of a set.
## 'frozenset' is immutable and hashable.
