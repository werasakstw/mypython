## sorted(<seq>) is a built-in function for sorting with no-side effect.
def sorted_test():
    ## Ordered oriented sequences e.g. str, list tuple can be sorted().
    ## The result is always a list.
    print(sorted('hello'))      # ['e', 'h', 'l', 'l', 'o']
    print(sorted((2, 1, 3)))    # [1, 2, 3]

    ## Reverese order sorted().
    print(sorted([2, 1, 3], reverse=True))  # [3, 2, 1]

    ## There is reversed(<seq>) that returns the reverse order of <seg>.
    print(list(reversed('hello')))      # ['o', 'l', 'l', 'e', 'h']
    print(list(reversed((2, 1, 3))))    # [3, 1, 2]

    ## A list of lists/tuples can be sorted by the first element is the key.
    a = [(3, 'john'), (1, 'jim'), (2, 'jack')]
    print(sorted(a))    # [(1, 'jim'), (2, 'jack'), (3, 'john')]

    ''' There is a 'key' argument for indicating the key to be in comparison.
           key=<function|lambda>
    <key> accepts a list/tuple and returns the field to be the key. '''
    def get_key(item):
        return item[1]
    print(sorted(a, key=get_key))   # [(2, 'jack'), (1, 'jim'), (3, 'john')]
    print(sorted(a, key= lambda item: item[0]))
                                    # [(1, 'jim'), (2, 'jack'), (3, 'john')]
# sorted_test()

''' Class 'list' has method sort() for sorting with side effect.
str and tuple have no sort(). '''
def sort_test():
    a = [2, 1, 3]
    a.sort()
    print(a)            # [1, 2, 3]

    ## sort() also has 'reverse' argument.
    a.sort(reverse=True)
    print(a)            # [3, 2, 1]

    ## There is also reverse() method to reverse the order.
    a.reverse()
    print(a)            # [1, 2, 3]

    ## A list of lists/tuples can also be sort().
    a = [(3, 'john'), (1, 'jim'), (2, 'jack')]
    a.sort()
    print(a)            # [(1, 'jim'), (2, 'jack'), (3, 'john')]

    ## There is also the 'key' argument for indicating the key.
    a.sort(key = lambda item: item[1])
    print(a)            # [(2, 'jack'), (1, 'jim'), (3, 'john')]
# sort_test()

def dict_sort():
    ## By default, dicts are sorted by key and the result is a list of keys.
    print(sorted({'john': 2, 'jack': 1, 'joe': 3}))  # ['jack', 'joe', 'john']

    ## To sort a list of dicts, a key is needed to specify the item to be key.
    students = [{'name': 'John', 'gpa': 1.8},
                { 'name': 'Jack', 'gpa': 4.0},
                { 'name': 'Joe', 'gpa': 2.5}]
    print(sorted(students, key=lambda s: s['gpa']))
    # [{'name': 'John', 'gpa': 1.8}, {'name': 'Joe', 'gpa': 2.5}, {'name': 'Jack', 'gpa': 4.0}]
# dict_sort()
