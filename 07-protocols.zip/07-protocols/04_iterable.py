''' An iterator is an object that has:
    __iter__(self) returns an iterator (which may be self or other).
    __next__(self) returns the next element and raises StopIteration if no more.

An object is 'iterable' if it has:
    __iter__(self) returns an iterator.

An iterator is an object that knows how to iterate the object.
Iterators allows sequential access to <obj> with:
        next(<obj>)   -->  __next__(<obj>)
  that was required by mechanism of for loop and comprehension.
So an 'iterator' can be nexted but not for 'iterable'.

An iterator is also iterable, but the reverse may not be true.
Ex. Lists and ranges are iterable but they are not iterator,
    We cannot perform next() on list and range.

Collections and string are iterable but have built-in internal iterators. '''
def iteration():
    a = [0, 1, 2, 3]
    ## iter(<col>) returns the iterator of <col>.
    i = iter(a)
    while True:
        try:
            print(next(i), end=',')  # 0,1,2,3,
        except StopIteration:
            del i
            break
    print()

    ''' Python hides the complexity under 'for' loop and comprehension.
    Mostly we should never use the internal iterator since there may be
    optimizations for some kinds of collections. '''
    for x in a:
        print(x, end=', ')           # 0, 1, 2, 3,
    print([x for x in a])            # [0, 1, 2, 3]
# iteration()

''' Iterator Protocol:
When an object is to be iterated:
 - If it has __iter__(), the iterator is obtained and used for iteration.
 - If no __iter__() but there is __getitem__(), an iterator is created
     and used for getting elements one at a time.
 - Else a TypeError is raised.
That is why an indexable object is also iterable.  '''

## Ex. iterator that has both __iter__ and __next__ by itself.
def iterator_test():
    class A:
        def __init__(self, a):
            self.a = a
            self.index = 0
        def __iter__(self):
            return self
        def __next__(self):
            try:
                i = self.a[self.index]
            except IndexError:
                raise StopIteration()
            self.index += 1
            return i

    a = A([1, 2, 3])
    print([x for x in a])       # [1, 2, 3]

    ## Once the instance is iterated, it run out its elements.
    print([x for x in a])       # []

    ## Multiple iterations on the same object would have wrong result.
    a = A([1, 2, 3])
    print([(x,y) for x in a for y in a])    # [(1, 2), (1, 3)]
# iterator_test()

''' To prevent the problem, an iterable object may delegate
  the iterator task to other object.  '''
def iterable_test():
    ## Class 'A' is iterable, it does not have __next__.
    class A:
        def __init__(self, a):
            self.a = a
        ## Delegates iteration to 'AIterator'.
        def __iter__(self):
            return AIterator(self.a)

    ## An iterator object knows how to next.
    class AIterator:
        def __init__(self, a):
            self.a = a
            self.index = 0
        def __next__(self):
            try:
                i = self.a[self.index]
            except IndexError:
                raise StopIteration()
            self.index += 1
            return i
        def __iter__(self):
            return  self   ## To conform the 'iterable' protocol.

    a = A([1, 2, 3])
    ## Each 'for' loop has it own iterator.
    print([(x, y) for x in a for y in a])
    # [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)]
# iterable_test()

''' Alternatively If not serious, an indexable is enough for multiple
iterations but it is inefficent. '''
def indexable_test():
    class A:
        def __init__(self, a):
            self.a = a
        def __getitem__(self, index):
            # print('__getitem__')   ## Try: uncomment this line.
            return self.a[index]

    a = A([1, 2, 3])
    print([(x, y) for x in a for y in a])
    # [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)]
# indexable_test()

''' Alternatively instead of delegate iterator to other object(ex. AIterator)
__iter__() function can itself be a function generator.
Since next() can also be applied to a generator and gets result from 'yield'. '''
def iterable_generator():
    class A:
        def __init__(self, a):
            self.a = a
        def __iter__(self):
            for i in self.a:
                yield i

    a = A([1, 2, 3])
    print([i for i in a ])

    '''  But each next() cause resume and suppend the execution of __iter__()
     just to get a value, that is a lot of wastes. '''
# iterable_generator()

''' Alternatively __iter__() may return a generator expression (a comprehension
  enclosed with ()) which results a generator object.
The __iter__() is called only once and returns the generator object.
Then each next() causes the generator object to fetch element from the
 list to be iterated(that is 'a').   '''
def eager_generator():
    class A:
        def __init__(self, a):
            self.a = a
        def __iter__(self):
            return (i for i in self.a)

    a = A([1, 2, 3])
    print([i for i in a ])
# eager_generator()

''' Examples of iterable objects:
zip() returns a zip object which is iterable.
Zip objects allows iterating over multiple sequences in parallel. '''
# print([x for x in zip([1, 2, 3], ['John', 'Jack', 'Joe'])])

## open() returns an iterable generator.
# for line in open('04_iterable.py'): print(line, end='')

## map() returns an iterable generator.
# print([x for x in map(lambda n : n*n, [1, 2, 3])])
