''' To handle attributes, a class may implement the following special methods:
      __setattr__()   to create and set attributes.
      __getattr__()   to get attributes.
      __delattr__()   to delete an attribute.
      __dir__()       returns a list of attributes.   '''
def attribute_protocol():
   class A:
      def __init__(self, x):
         print('__init__')
         self.x = x      ## calls  __setattr__

      def __setattr__(self, name, value):
         self.__dict__[name] = value
         print('__setattr__', name, value)

      def __getattr__(self, name):
         print('__getattr__', name)
         return self.__dict__[name]    ## Try:   return self.x

      def __delattr__(self, name):
         print('__delattr__', name)
         del(self.__dict__[name])

      def __dir__(self):
         return list(self.__dict__)

   a = A(1)         ## __init__
                    ## __setattr__ x 1
   print(dir(a))    ## ['x']
   print(a.x)       ## 1

   a.x = 2          ## __setattr__ x 2

   del a.x          ## __delattr__ x
   print(dir(a))    ## []
# attribute_protocol()

''' <class 'object'> has the default implementation for the methods.
So all objects have default 'access control' for attributes. '''
def access_control():
   class A:
      pass
   a = A()

   ## 1. Create a new attribute by setting its value.
   a.x = 1

   ## 2. Set the value of an existing attribute.
   a.x = 2

   ## 3. Get the value of an attribute.
   print(a.x)        ## 2

   ## 4. Delete an attribute.
   del(a.x)
# access_control()

''' We may override __getattr__() that return value of non exist attribute
which is called 'Ghost Attributes'.  '''
def ghost_attribute():
   class A:
      def __getattr__(self, name):
         if name == 'x':
            return 1
   a = A()
   print(a.x)           ## 1
   print(a.__dict__)    ## {}
# ghost_attribute()

''' Immutability does not allows modify/add attributes after creation.
__setattr__() can block the actions. '''
def immutable_object():
    class A:
        def __init__(self, x):
            super().__setattr__('x', x)   ## don't use it own __settattr__

        def __setattr__(self, name, value):
            raise AttributeError('Immutable object')

    a = A(1)
    print(a.__dict__)
    # a.x = 2           # error
    # a.y = 1           # error
# immutable_object()

#####################################################################

''' Name Binding Protocol:
Name binding is the process of mapping from name to object.
Python performs 'name binding' dynamically(at runtime).

When a name is referred via object or class:
1. If the name/operator has its corresponding special method
 in the object/class, it is bound accordingly.

2. If the class has __getattribute__(self, <name>) then it is
  invoked with parameter <name>. '''
def getattribute():
    class A:
        def __getattribute__(self, name):
            if name == 'x':
               return 1

    a = A()
    print(a.x, a.y)     # 1 None
# getattribute()

''' 3. The name is searched in the object's __dict__.
  If not found continues in the class's __dict__. '''
def dict_search():
   class A:
      x = 0
      def __init__(self, x):
         self.x = x

   a = A(1)
   print(A.x, a.x)     # 0 1

   del a.x
   print(a.x)          # 0
# dict_search()

''' 4. The name is searched in the superclass dicts,
 up to the <class 'object'>. '''
def superclass_dict():
   class A:
      x = 1
      def __init__(self, y):
          self.y = y
   class B(A):
      def __init__(self, y):
          super().__init__(y)

   b = B(2)
   print(b.x, b.y)           # 1 2
# superclass_dict()

''' 5. If the class has __getattr__(self, <name>) then it is invoked.
That means no __getattribute__ for the <name> and no <name> in
object/class dicts.  '''
def getattr():
    class A:
        def __getattr__(self, n):
            if n == 'x':
                return 1
    a = A()
    print(a.x)       ## 1
# getattr()
