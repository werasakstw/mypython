''' An object is 'indexable' if it has
    __getitem__(self, <position>) returns the element at <position>.

An indexable object can be:
1. Indexed:  <obj>[<index>]   -->   __getitem__(<obj>, <index>)
2. Sliced:   <obj>[<start>:<stop>:<step>]
3. Iterated by 'for' loop and comprehension.
4. Member testing with 'in'.
5. Sort:    sorted()            '''
class Names:
    n = ['John', 'Jack', 'Joe', 'Jame', 'Jim']
    def __getitem__(self, pos):
        return Names.n[pos]

def indexable():
    names = Names()
    print(names[0])       # John
    print(names[1::2])    # ['Jack', 'Jame']
    for n in names:
        print(n, end=', ')      # John, Jack, Joe, Jame, Jim,
    print()
    print([n for n in names])   # ['John', 'Jack', 'Joe', 'Jame', 'Jim']

    ''' To perform member test 'in', __contains__() is executed.
    If no __contains__(), it is performed by iterate checking with index. '''
    print('Jack' in names)      # True

    ## sorted() does not have side-effect, but returns a newly created object.
    print(sorted(names))        # ['Jack', 'Jame', 'Jim', 'Joe', 'John']
# indexable()

#--------------------------------------------------------------------

''' A 'mutable indexable' must have:
     __setitem__(self, <position>, <value>)  for set <value> at <position>. '''
def mutable_indexable():
    class MutableNames(Names):
        def __setitem__(self, pos, value):
            Names.n[pos] = value

    names = MutableNames()
    print(list(names))   # ['John', 'Jack', 'Joe', 'Jame', 'Jim']
    names[2] = 'Jody'
    print(list(names))   # ['John', 'Jack', 'Jody', 'Jame', 'Jim']
# mutable_indexable()

''' An 'indexable sequence' must have:
       __len__(self)  return the number of elements in the object.
An indexable sequence can be
   - reversed()  A method of class 'list'.
   - choice() A function in package 'random'.   '''
import random
def indexable_sequence():
    class NamesSequence(Names):
        def __len__(self):
            return len(Names.n)

    names_seq = NamesSequence()
    print(list(reversed(names_seq))) # ['Jim', 'Jame', 'Joe', 'Jack', 'John']
    print(random.choice(names_seq))  # Jack
# indexable_sequence()
