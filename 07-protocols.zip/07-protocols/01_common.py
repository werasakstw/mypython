'''Math Protocol:
To allows prefix and infix syntax for mathematic operations
  Python provides the following special methods.

unary:              -  __neg__      +  __pos__      abs()  __abs__

compartison:        >  __lt__       <= __le__       ==  __eq__
                    != __ne__       >  __gt__       >=  __ge__

arithmetic:         +  __add__          -  __sub__          *  __mul__
                    /  __truediv__      // __floordiv__     %  __mod__
                    divmod()  __divmod__        round()  __round__
                    ** or pow()  __pow__

reversed arithmetic:  __radd__      __rsub__       __rmul__      __rmod__
                      __rtruediv__  __rfloordiv__  __rdivmod__   __rpow__

in place arithmetic:  +=  __iadd__       -=  __isub__       *=  __imul__
                      /=  __itruediv__   //= __ifloordiv__  %=  __imod__
                      **=  __ipow__

bitwise:              ~  __invert__     &  __and__      |  __or__
                      ^  __xor__        << __lshift__   >> __rshift__

reversed bitwise:   __rlshift__    __rrshift__   __rand__   __rxor__   __ror__

in place bitwise:   &=  __iand__        |=   __ior__        ^=  __ixor__
                    <<= __ilshift__     >>=  __irshift__
'''
def math_ex():
    class A:
        def __init__(self, x):
            self.x = x
        def __add__(self, b):
            return self.x + b             # arithmetic
        def __radd__(self, b):
           return self.x + b              # reversed arithmetic
        def __iadd__(self, b):
            self.x += b;
            return self.x                 # inplace arithmetic
        def __neg__(self):
            return -self.x                # unary
        def __lshift__(self, n):
            return self.x << n            # bitwise

    a = A(0)
    print(a + 1)            # 1          __add__(a, 1)
    print(1 + a)            # 1          __radd__(a, 1)
    a += 1;                 #            __iadd__(a, 1)
    print(-a)               # -1         __neg__(a)
    print(a << 1)           # 2          __lshift__(a, 1)

    class B:
        def __init__(self, x):
            self.x = x
        def __lt__(self, d):
            return self.x < d.x

    print(B(1) < B(2))      # True
# math_ex()

## If __iadd__() is not implemented, += falls back to __add__ if available.
def inplace():
    class A:
        def __init__(self, x):
            self.x = x
        '''
        def __iadd__(self, other):        # in-place add
            self.x += other.x
            return self
        '''
        def __add__(self, other):          # un-mutate add
            return A(self.x + other.x)

    a1, a2 = A(1), A(2)
    print(id(a1))
    a1 += a2
    print(a1.x)         # 3
# inplace()

#----------------------------------------------------------------------

''' Coercion Protocol:
When Python compiler need to determine the Boolean value of an object
  it call the __bool__() of the object.  '''
def coercion():
    class A:
        def __init__(self, x):
            self.x = x
        def __bool__(self):
            if self.x == 0:
                return False
            return True
    print(bool(A(0)), bool(A(1)))   # False True

    ## Objects of classes that support coercion protocol can be used as consitions.
    if A(123):
        print('Hello')              # Hello
# coercion()

#-----------------------------------------------------------------

''' String Protocol:
Python has str() and repr() to convert an object into a str. '''
def str_pro():
    ''' The class 'object' has default implementation of __repr__
    and __str__ that just return the class name and address. '''
    class A:
        def __init__(self, x):
            self.x = x
    a = A(1)
    print(str(a))   # <__main__.str_pro.<locals>.A object at 0x031FA2C8>
    print(repr(a))  # <__main__.str_pro.<locals>.A object at 0x031FA2C8>

    ## 'str' class's implemenmtation.
    print(str('Hello'))      # Hello    (that should bw viewed by programers).
    print(repr('Hello'))     # 'Hello'  (that should bw viewed by users).

    class A:
        def __str__(self):
            return '__str__()'

        def __repr__(self):
            return '__repr__()'
    a = A()
    print(str(a))       # __str__()
    print(repr(a))      # __repr__()

    ''' Formatted with format():
         {!s}    -->  str()
         {!r}    -->  repr()        '''
    print('{!s}, {!r}'.format(a, a))    # __str__(), __repr__()

    ''' Formatted with %
         %s    -->  str()
         %r    -->  repr()      '''
    print('%s, %r' % (a, a))            # __str__(), __repr__()
# str_pro()
