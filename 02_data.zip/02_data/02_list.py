''' List: is an sequence of elements.
A list has memory to store elements, order-oriented, mutable,
  generic, and nestable.
Lists can be indexed, sliced and iterated.
Check with: supplement\sequences.py   '''
def list_mutable():
    a = ['a', 'b', 'c']

    ## Modify element.
    a[1] = 'x'
    print(a)                # ['a', 'x', 'c']

    ## Modify the whole.
    a = ['a', 'b']
    print(a)                # ['a', 'b']

    ## + operor is overloaded for list soncatenation.
    a += ['c']
    print(a)                # ['a', 'b', 'c']

    ## Delete an element at position.
    del a[1]
    print(a)                # ['a', 'c']

    ## Clear all elements.
    a.clear()
    print(a)                # []

    ## Delete the whole.
    del a;
    # print(a)              # error
# list_mutable()

## Pyton 3.8 introduces a new syntax of 'for'.
# for i in 2, 1, 3:
#     print(i, end=',')   # 2,1,3
