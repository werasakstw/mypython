''' Set: is a mutable value oriented sequence of elements.
 Set is a simple tool to eliminate dupicated values. '''
# print(set('Hello'))             # {'H', 'o', 'e', 'l'}

''' Set elements have no position nor order, therefore cannot be indexed.
Elements can be member checked with 'in'. '''
# print(1 in {'a', 1, True} )   # True

def set_mutable():
    s = set()

    ## Adding duplicated elements have no effect nor error.
    s.add(1); s.add(2); s.add(3); s.add(2)
    print(s)                # {1, 2, 3}

    s.remove(2); print(s)   # {1, 3}

    ## Remove a non-member is an error.
    # s.remove(0)           # Error
    s.discard(0)            # No error

    ## pop() Remove and return an arbitrary element.
    print(s.pop())          # 3
    print(s)                # {1}

    ## update() union itself with the other.
    s.update({'a', 'b'})
    print(s)                # {'b', 1, 'a'}

    ''' Mutable sequences(e.g. list, set and dict) are non-hashable.
    str, number, immutable sequences(e.g. tuple) are hashable.
    Set members must be hashable, since elements are accessed by value hashing. '''
    # s.add({0})              # Error
    # s.add([6])
    s.add((4, 5))
    print(s)   # {'a', (4, 5), 1, 'b'}
# set_mutable()

''' frozenset: is immutable and hashable.
A frozenset can be used mostly as set, except mutable operations
 (e.g. add and remove) are not allowed. '''
def frozen_set():
    ## Sets cannot be keys of dict, since set is non-hashable.
    d = {}
    # d[ {1, 2} ] = 'hello'         # error

    ## Frozensets should be created with initial value.
    fs = frozenset({1, 2})
    # fs.add(3)         # Error

    ## A frozenset can be a key of a dict.
    d[ fs ] = 'hello'
    print(d[fs])        # hello

    ## A frozenset can be member of a set
    print( {0, fs} )    # {0, frozenset({1, 2})}
# frozen_set()

#-------------------------------------------------------------------------

''' collections.Counter: Multiset is a set that allows elements to have
more than one occurrence.
It is implemented as a dict with item of <value>:<number of occurrence>. '''
import collections
def counter_test():
    ## A counter is very useful for frequency count.
    c = collections.Counter()
    c.update({'A': 1, 'B': 3, 'C': 5})
    print(c)        # Counter({'C': 5, 'B': 3, 'A': 1})
    c.update({'B': 1, 'C': 2, 'F': 2})
    print(c)        # Counter({'C': 7, 'B': 4, 'F': 2, 'A': 1})

    ## Unique elements,  Total number of elements
    print(len(c), sum(c.values()))  # 4 14

    ## Counter is applicable to str, list, tuple, and set.
    for k,v in collections.Counter('Hello').items():
        print('%s(%d)' % (k, v), end=' ') ## H(1) e(1) l(2) o(1)
    print()

    ## Anagrams are strings that contain the same set of characters.
    print(collections.Counter('night') == collections.Counter('thing')) ## True
# counter_test()
