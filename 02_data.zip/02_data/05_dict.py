''' 'dict' is a set of elements in the form <key>:<value>.
Dicts are unordered(value-oriented) and mutable.
Keys must be hashable (e.g. number, str and immutable types),
Values can be of any types.
O(1) time complexity for lookup, insert, update, and delete. '''
def dict_create():
    ## Dicts are normaly created as literals.
    d = { 'id': 1, 'name': 'john'}
    print(type(d), d)       # <class 'dict'> {'id': 1, 'name': 'john'}

    ## Dicts can be created from json str.
    import json
    js = '{ "id": 2, "name": "jack"}'
    print(type(js))         # <class 'str'>
    d = json.loads(js)
    print(type(d), d)       # <class 'dict'> {'id': 2, 'name': 'jack'}

    ## A dict can be dumped into a json str.
    s = json.dumps(d)
    print(type(s), s)       # <class 'str'> {"id": 2, "name": "jack"}

    ## Dict can be created from list or tuple (but not a set) of elements.
    print( dict([ ['id', 2],
                  ('name', 'Joe Green'),
                  ('gpa', 2.0) ]) )
        # {'id': 2, 'name': 'Joe Green', 'gpa': 2.0}

    ## Dict can be created from two lists with zip()
    k = ['a', 'b', 'c']
    v = [1, 2, 3]
    print(dict(zip(k, v)))      # {'a': 1, 'b': 2, 'c': 3}

    ## Dict can be created with comprehension.
    print( {x: x * x for x in range(5)} )  # {0: 0, 1: 1, 2: 4, 3: 9, 4: 16}
# dict_create()

def dict_mutable():
    d = {'x': 1}

    ## Add new element
    d['y'] = 2
    print(d)                    # {'x': 1, 'y': 2}

    ## Replace an element
    d['x'] = 0
    print(d)                    # {'x': 0, 'y': 2}

    ## Delete an element
    del d['y']
    print(d)                    # {'x': 0}

    ## Update element value
    d['x'] += 1.0
    print(d)	                # {'x': 1.0}

    # Update a dict with another dict.
    a = { 'x': 1, 'y': 2 }
    b = { 'y': 3, 'z': 4 }
    a.update(b)
    print(a, b)     # {'x': 1, 'y': 3, 'z': 4} {'y': 3, 'z': 4}

    # Dict can be cleared.
    a.clear()
    print(a)        # {}

    # Dict can be deleted as a whole.
    del(a)
    # print(a)      # error
# dict_mutable()

def dict_access():
    d = { 'x': 1, 'y': 2 }

    ## Dict elements are accessedd by indexed with the element's key.
    print(d['x'])            # 1

    ## Indexing with non-exist key is an error.
    # print(d['z'])          # error

    ## get() does not cause error and allows returning default value.
    print(d.get('z'), d.get('z', 0))   # None 0

    ## 'in' may be used for existing key.
    print('x' in d, 'z' in d)       # True False

    ## Immutable objects can be keys of dicts.
    t = { (1, 'john'): 1.5, (2, 'jack'): 3.8 }
    print(t[ (2, 'jack') ])             # 3.8

    ## Since Python 3.0, keys(), values(), and items() do not return a list.
    print(d.keys())       # dict_keys(['x', 'y'])
    print(d.values())     # dict_values([1, 2])
    print(d.items())      # dict_items([('x', 1), ('y', 2)])
# dict_access()

def dict_iteration():
    d = {'a':0, 'b':1, 'c':2}

    ## If a dict is iterated, only the keys are obtained.
    for k in d:
        print(k, end=",")       #  a,b,c,
    print()

    ## keys() returns a dict_keys which is an iterable view of the keys.
    for k in d.keys():
        print(k, end=",")       #  a,b,c,
    print()

    ## values() returns iterable view of values.
    for v in d.values():
        print(v, end=",")       #  0,1,2,
    print()

    ## items() returns iterable view of items represented as tuple.
    for i in d.items():
        print(i, end=",")       #  ('a', 0),('b', 1),('c', 2),
# dict_iteration()
