# Python string literals may be enclosed with:
# 	'           single quotes
# 	"           double quotes
# 	'''  """    triple single/double quotes
def quotes():
    print('Hello')
    print("Hello")
    print('''Hello''')
    print("""Hello""")

    ## Single quotes and double quotes may be nested.
    print('John said "Hello".')
    print("Jack said 'Hi'.")

    ''' Single/double quotes cannot contain <newline> nor <return>.
    Triple quotes are useful for multiple line strings which may contain ' or ". '''
    print('''
When I saw John yesterday.
He said "Hello". I said, 'Hi'.
''')

    ''' Escape characters inside quoted strings:
    Special characters begins with \ e.g.  \',  \",  \\,
       \r (return),  \n (newline),  \s (space), and \t (tab)   '''
    print('Joe said \'Hello\'.')
# quotes()

''' Python implements string type using class 'str' which contains
 an immutable array of Unicode characters.
Python does not support 'char' type.
A character is a str of one character. '''
s = 'abc'
# print(type(s), type(s[0]))      # <class 'str'> <class 'str'>

def raw_string():
    ## str may contains special characters.
    print('Hello\tJohn.')            # Hello<new line>John.

    ''' Raw String: prefixed with r
    When displayed, special characters are not interpreted. '''
    print(r'Hello\tJack.')           # Hello\tJack.
# raw_string()

''' Python 2: has 'str' and 'unicode' types.
    Python 3: has 'str' and 'bytes' types.
'bytes' is a bytes array. Its literal is prefixed with 'b'. '''
# print(type('Hello'))             # <class 'str'>
# print(type(b'Hello'))            # <class 'bytes'>

''' encode(<encoding>='utf-8')  str -> bytes
    decode(<encoding>='utf-8') bytes -> str     '''
def encode_decode():
    b = 'Hello'.encode()
    print(b)          # b'Hello'
    print(type(b))    # <class 'bytes'>

    s = b.decode()
    print(s)          # Hello
    print(type(s))    # <class 'str'>

    print('ก'.encode())                     # b'\xe0\xb8\x81'
    print('ก'.encode('utf-16'))             # b'\xff\xfe\x01\x0e'
    print(b'\xe0\xb8\x81'.decode())                 # ก
    print(b'\xff\xfe\x01\x0e'.decode('utf-16'))     # ก
# encode_decode()

def str_iterate():
    s = 'กขค'
    ## str is iterated by character.
    for c in s:
        print(c, end=',')       # �,�,�,
    print()

    ## 'bytes' allows iterating by byte.
    for c in s.encode():
        print(c, end=',')       # 224,184,129,224,184,130,224,184,132
# str_iterate()

''' chr(<int>) returns unicode character of the int value.
    ord(<character>) return unicode of <character>.  '''
# print(chr(65), ord('A'))        ## A 65
def ord_test():
    ## Accessing each character in a string as unicode.
    for c in 'ABC':
        print('%s (%d)' % (c, ord(c)), end=',')  ## A (65),B (66),C (67),
    print()

    for c in 'กขค':
        print('%s(%d)' % (c, ord(c)), end=', ')  ## ก(3585), ข(3586), ค(3588),
# ord_test()

## A string that created by +(append) has more overhead than creating at once.
# print('Hello' + ' ' + 'how' + ' ' + 'are' + ' ' + 'you?')  # bad
# print(' '.join(['Hello', 'how', 'are', 'you?']))           # good

#-------------------------------------------------------------
''' String Formats:
1. Old Style String Format: Similar to C's printf().
          <str with format characters> % values
If values have more than one values, they must enclosed in ().
Values are substituted in order of format characters.

Format Characters:
    b binary
    c character - convert to unicode character
    d decimal (default)
    n decimal with locale specific separators
    o octal
    x hex (lower-case)
    X hex (upper-case)
    e/E Exponent. Lower/upper-case e
    f Fixed point
    g/G General. Fixed with exponent for large, and small numbers ( g default)
    n g with locale specific separators
    % Percentage (multiplies by 100)
'''
def old_style():
    print('Hello! %s.' % 'John')            # Hello! John.
    print('Hello! %s.' % ['John', 'Jack'])  # Hello! ['John', 'Jack'].
    print('Hello! %s  and %s.' % ('John', 'Jack')) # values are wrapped as a tuple
                                            # Hello! John  and Jack.
    ## Format with number bases.    %b is not supported.
    print('%o, %d, %x' % (10, 10, 10))      # 12, 10, a

    ## Float format
    print('%.2f' % 123.456)                 # 123.46

    ## Sequences can be formatted to str.
    print('%s, %s' % ([1, 2, 3], {1, 2, 3})) # [1, 2, 3], {1, 2, 3}
# old_style()

'''
2. New Style String Formatting: (Python 3.0)
Create a str from a template by substitute values in place holders.
          <str with place holders>.format(<values>)
Here format() is a method of class 'str'.
A place holder is specified with {} (no %).
The place holders can be specified by order, position or name.
Values may be formatted by default, according to the types.
'''
def new_style():
    ## {} are place holder for formatted values.
    print('Hello {} and {}.'.format('John', 'Jack'))  # Hello John and Jack.

    ## The place holder may specify value position.
    print('Please bring me {1} {0}.'.format('books', 10))
                                                    # Please bring me 10 books.
    ## Place holder with names.
    print('Hello {n1} and {n2}.'.format(n2 = "John", n1 = "Jack"))
                                                    # Hello! Jack and John.
    ## name/position with format characters
    print('Hello {n1:s} and {n2:s}.'.format(n2 = 'John', n1 = 'Jack'))
                                                    # Hello! Jack and John.
    print('{0:s}, {1:.2f}, {2:3d}'.format('books', 1.2, 12)) # books, 1.20,  12

    ## Format with number bases
    print('{:b}, {:d}, {:o}, {:x}'.format(10, 10, 10, 10))  # 1010, 10, 12, a

    ## Float format
    print('{:.2f}'.format(123.456))                 # 123.46

    ## Default list/set format.
    print('{}, {}'.format([1, 2, 3], {1, 2, 3}))    # [1, 2, 3], {1, 2, 3}
# new_style()

''' format() is a built-in function:
             format(<value>, <pattern>)
It can be used to format <value> of any types.
  <pattern> is  [sign][width][.precision][type]
'''
def format_function():
    ## 'd' is for displayed as decimal.
    print(format(12, '+4d'))    #  +12

    x = 12.3456
    ## f    Fixed point with default precision 6.
    ## F    Same as f , except nan is converted to NAN and inf to INF.
    print(format(x, 'f'))       # 12.345600
    print(format(x, '+4.2f'))   # +12.35

    ## e, E Exponential format, with e/E to mark the exponent. Default precision is 6.
    print(format(x, 'e'))       # 1.234560e+01
    print(format(x, '.2E'))     # 1.23E+01

    ## g, G, n General format, where the number is rounded to the given precision.
    print(format(x, 'G'))       # 12.3456

    ## %   multiplied by 100, displayed in f format with a percentage sign.
    print(format(0.25, '.1%'))  # 25.0%

    ## Convert int to str, with number bases:
    print(format(10, 'b'))      # 1010
    print(format(10, 'o'))      # 12
    print(format(10, 'd'))      # 10
    print(format(10, 'x'))      # a
    print(format(10, 'X'))      # A
# format_function()

''' 3. f-string (Function String, Interpolation) Python 3.6: allows evaluating
 expressions that embedded inside string literal.
A function string is prefixed with f e.g.  f'hello'.
An expression is surrounded by { }.
Expressions are evaluated at runtime and results are inserted at the positions. '''
def interpolation():
    name = 'John'
    print(f'Hello {name}')      # Hello John

    a, b = 1, 2
    print(f'a + b = {a + b}')   # a + b = 3
# interpolation()

''' 4. Template String: is less powerful but simple and more suitable in some cases.
All values are automatically formatted according to the type.
It allows creating a str from a template which default format.
Template strings are not a core language feature but supplied by standard library. '''
from string import Template     # 'string' is a standard lib.
def temp_str():
    t = Template('Hello $name please send me $value buck.')
    print(t.substitute(name='John', value='10')) # Hello John please send me 10 buck.
# temp_str()

# Zen of Python: There should be one obvious way to do something.
# Rich languages provide many ways to do the samething.

# Srings can be indexed, sliced and iterated. Check: supplement\sequences.py
