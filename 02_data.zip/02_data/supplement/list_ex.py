def list_literal():
    # List literals are enclosed in [ ].
    print([1, 2, 3])                # 1, 2, 3]

    # List may contain duplicate elements
    print( [1, 2, 1] )              # [1, 2, 1]

    # Lists are generic and nestable.
    print([1, 2.0, '3', True])      # [1, 2.0, '3', True]
    print([1, [2, 3]])              # [1, [2, 3]]

    # Empty list may be created using list() factory.
    print( [], list() )             # [] []

    # A comma after the last element is optional.
    print([1, 2, 3])
    print([1, 2, 3,])

    # That allows listing each elements in separated line with the last
    #  element may or may not has a comma.
    print([ 'John',
            'Jack',
            'Joe',  # Always end with , for consistency.
         ])
# list_literal()

def list_create():
    # list() can create list from other types.
    print(list('Hello'))            # ['H', 'e', 'l', 'l', 'o']
    print(list(range(3)))           # [0, 1, 2]
    print(list( (1, 2, 1) ))        # [1, 2, 1]
    print(list( {1, 2, 1} ))        # [1, 2]

    # List can be created with comprehension.
    print( [i for i in range(10) if i % 2 == 0] )   # [0, 1, 2]

    # List can be created with initialized value using * (repeat opertor).
    print([True]*3)             # [True, True, True]
    print([0]*5)                # [0, 0, 0, 0, 0]
# list_create()

def list_op():
    a = ['a', 'b']

    # <list>.append(<item|list>) add <item|list> to the end
    a.append(1); print(a)         # ['a', 'b', 1]
    a.append([2, 3]); print(a)    # ['a', 'b', 1, [2, 3]]

    # <list>.extend(<list>) or += combines two lists
    a = ['x', 'y']
    a.extend([1, 2]); print(a)       # ['x', 'y', 1, 2]

    # <list>.insert(<pos>,<item>) insert <item> before the <pos>.
    a = ['a', 'b']
    a.insert(1, 'x')
    print(a)                    # ['a', 'x', 'b']

    # <list>.remove(<item>) remove the first occurrence of <item>.
    a = ['a', 'x', 'b', 'x']
    a.remove('x')
    print(a)                    # ['a', 'b', 'x']

    # <list>.pop(<pos>) pop element at <pos> and returns the element.
    #   default <pos>: is -1 (the end).
    print(a.pop(), a)               # x ['a', 'b']
    print(a.pop(0), a)              # a ['b']
##list_op()

######################################################################

## Examples of list usage:
# Lists can be used as mapping (instead of function) but only from integer to object.
# Day Mapping:
#   sat = 0, sun = 1, mon = 2, tue = 3, wed = 4, thu = 5, fri = 6
dm = ['sat', 'sun', 'mon', 'tue', 'wed', 'thu', 'fri' ]
## print(dm[6])        # fri


#-----------------------------------------------------------

# List allows storing results for using later instead of recompute.
# Factorial:
#      n! = fac(n) = n * (n-1) * (n-2) .... * 1
def fac(n):
    r = 1;
    for i in range(1, n+1):
        r *= i
    return r
##print(fac(5))

# Find a 3 digits integer 'abc' such that:
#              abc = a! + b! + c!
#    hint:     145 = 1! + 4! + 5!
def abc():
    for a in range(1, 10):
        for b in range(0, 10):
            for c in range(0, 10):
                if 100*a+10*b+c == fac(a) + fac(b) + fac(c):
                    print(a, b, c)
##abc()

# List allows accessing elements by position.
# Trading memory for speed.
def abcx():
    fac = [1, 1]
    for i in range(2, 10):
        fac.append(fac[i-1]*i)
    for a in range(1, 10):
        for b in range(0, 10):
            for c in range(0, 10):
                if 100*a+10*b+c == fac[a] + fac[b] + fac[c]:
                    print(a, b, c)
##abcx()

#-------------------------------------------------------------

# Lists allows passing a lot of values to/from a function.
# Create a list of n booleans, filled with True except the first two.
def gen_list(n):
    a = [False, False]  # position 0 and 1 are False.
    for i in range(2, n+1):
        a.append(True)
    return a
##print(gen_list(5))      # [False, False, True, True, True, True]

# Sieve of Eratosthenes: efficiently create a lot of primes.
def sieve(n):
    a = gen_list(n)
    # From 2 to the half of n.
    for i in range(2, n // 2):
        # Start for a prime position
        if a[i]:
            # Jump by i
            for j in range(i*2, n+1, i):
                # Mark the j position is not prime.
                a[j] = False
    # Return a list of prime positions
    return [i for i in range(n+1) if a[i]]
##print(sieve(100))

#--------------------------------------------------------------

# Random Password Generator:
#   - length between 8 to 10 characters.
#   - begins with an upper case letter then follow by digits, lower case or upper case letters.
import string, random
def gen_pwd():
    DIGITS = list(string.digits)
    UPPER = list(string.ascii_uppercase)
    LOWER = list(string.ascii_lowercase)
    SYM = [DIGITS, LOWER, UPPER]
    def gen():
        p = random.choice(string.ascii_uppercase)  # The first character.
        for i in range(random.randint(7, 9)):
            s = random.choice(SYM)
            p += random.choice(s)
        return p

    for i in range(10):
        print(gen())
##gen_pwd()

#----------------------------------------------------------------

# List allows representing order oriented data.
#  ex.  Polynomial:  1 + 2*x + 3*x**2 + 4*x**3
#     represented as a list of coefficient  [1, 2, 3, 4]
def eval_poly(p, x):
    r = 0
    for i, c in enumerate(p):
        r += c*x**i
    print(r)
##eval_poly([1, 2, 3, 4], 1.5)
