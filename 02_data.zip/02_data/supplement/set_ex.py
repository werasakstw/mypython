def set_literal():
     ## Set literals are enclosed in { }.
     print( {1, 2, 3} )

     ''' There is no empty set literal, since {} is an empty dict.
     An empty set is denoted by its factory. '''
     print( set() )              # set()

     ## Set cannot contain duplicate elements.
     print( {1, 2, 1} )              # {1, 2}

     ''' Sets are generic but not nestable.
     Set elements must be hashable, e.g. number, str and tuple.'''
     print({1, 2.0, '3', True, (1,)})

     # A comma after the last element is optional.
    print( {1, 2, 3,} )
# set_literal()

def set_create():
    ## Sets can be created by set() factory.
    print(set('Hello'))         # {'H', 'l', 'o', 'e'}
    print(set(range(3)))        # {0, 1, 2}
    print(set( [1, 2, 1] ))     # {1, 2}
    print(set( (1, 2, 1) ))     # {1, 2}

    ## Set can be created from comprehension.
    print( {i for i in range(3)} )   # {0, 1, 2}

    ## Set does not support *.
    # print({True}*3)           # error
# set_create()

''' Python supports both set methods and operations.
O(1) for membership tests.
O(n) for union, intersection, difference, and
 subset operations. '''
def set_op():
    a = {1, 2, 3}
    b = {3, 4}
    print(a & b)    # intersection() {3}
    print(a | b)    # uion()         {1, 2, 3, 4}
    print(a - b)    # difference()   {1, 2}
    print(a ^ b)    # exclusive      {1, 2, 4}

    ## Set comparision.
    b = { 3, 1 }
    print(b <= a)    # issubset()        True
    print(a >= b)    # issuperset()      True
    print(a < a)     # is proper subset     False
    print(b < a)     #                   True
    print(a > b)     # is proper superset   True
# set_op()
