# Stack:
# Lists are implemented as dynamic arrays which need to resize occasionally.
# Lists over-allocate storage so that not every push or pop requires resizing.
# List provide terrible performance when add/remove at the front or in the
#   middle since the remain elements must be shifted.
# List provides efficient random access and append()/pop() at the end.
# Therefore list is a decent stack.
def stack_test():
    s = list()
    s.append(1); s.append(2); s.append(3);
    print(s.pop(), s.pop(), s.pop())    # 3 2 1
# stack_test()

# collections.deque: Stacks and Queues
# Deque supports fast add/remove elements from either ends,
#  that serve well for both stack and queue.
# But deque is implemented as doubly-linked lists which consumes a lot of
#  memory for points. Poor performance for random access but decent
#  add/remove elements in the middle since no shifting required.
import collections
def deque_test():
    dq = collections.deque()

    # add/remove at the end (right end)
    dq.append(1); dq.append(2); dq.append(3);
    print(dq.pop(), dq.pop(), dq.pop())  # 3 2 1

    # add/remove at the front (left end)
    dq.appendleft(1); dq.appendleft(2); dq.appendleft(3);
    print(dq.popleft(), dq.popleft(), dq.popleft())  # 3 2 1

    # add at the end, remove at the front
    dq.append(1); dq.append(2); dq.append(3);
    print(dq.popleft(), dq.popleft(), dq.popleft())  # 1 2 3
# deque_test()

#------------------------------------------------------------------

# heapq: List-Based Binary Heaps (priority queue)

import heapq
def heapq_test():
    a = []
    heapq.heappush(a, (3, 'john'))
    heapq.heappush(a, (1, 'jim'))
    heapq.heappush(a, (2, 'jack'))
    print(a)    # [(1, 'jim'), (3, 'john'), (2, 'jack')]

    while a:
        print(heapq.heappop(a), end=', ')
# heapq_test()    # (1, 'jim'), (2, 'jack'), (3, 'john'),

# queue.PriorityQueue: synchronized to support concurrent users.
import queue
def pq_test():
    pq = queue.PriorityQueue()
    pq.put((3, 'john'))
    pq.put((1, 'jim'))
    pq.put((2, 'jack'))

    while not pq.empty():
        print(pq.get(), end=', ') # (1, 'jim'), (2, 'jack'), (3, 'john'),
# pq_test()
