'''
Lists are sequences of objects which have memory overhead.
Arrays store homogeneous sequence of int or float as binary, so that
  can be as lean as C array.
Python arrays need a 'typecode' for determining the type of elements.
   Type code       Underline Type    Minimum size in bytes
     'b'         signed integer              1
     'B'         unsigned integer            1
     'u'         Unicode character           2
     'h'         signed integer              2
     'H'         unsigned integer            2
     'i'         signed integer              2
     'I'         unsigned integer            2
     'l'         signed integer              4
     'L'         unsigned integer            4
     'q'         signed integer              8
     'Q'         unsigned integer            8
     'f'         floating point              4
     'd'         double-precision float      8

Python provides 'array' as a standard lib.
'''
import array
def array_test():
    ## Array of 'b' (signed integer) with initialized values in range(10)
    a = array.array('b', range(10))
    print(a)            # array('b', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    print(len(a))       # 10

    ## Arrays can be indexed.
    print(a[0])         # 0

    ## Arrays can be iterated.
    for x in a:
        print(x, end=",")   # 0,1,2,3,4,5,6,7,8,9,
    print()

    ## Arrays are mutable.
    a.append(10)
    print(a)            # array('b', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    a[1] = 11
    print(a)            # array('b', [0, 11, 2, 3, 4, 5, 6, 7, 8, 9, 10])

    ## Arrays are type safe.
    # a[1] = 'a'        # Compile time error

    ## Arrays can be convered to lists.
    print(a.tolist())   # [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
# array_test()

## Array has methods for fast data transfer to/from a file.
def file_test():
    size = 10
    a = array.array('H', range(size)) # two bytes unsigned int

    with open('test.bin', 'wb') as fp:
        a.tofile(fp)

    with open('test.bin', 'rb') as fp:
        b = array.array('H')          # two byte signed int
        ##b = array.array('b')        # one byte signed int
        b.fromfile(fp, size)
    print(b)
# file_test()

''' Memory View: A 'memorview' is a shared-memory sequence type.
memoryview.cast() allows change the way the array bytes are read or written,
  without copying or moving data. It returns another memory view object
  that shares the same memory. '''
def mv_test():
    ## 1 byte signed int
    a = array.array('b', [-2, -1, 0, 1, 2, 3])
    print(a.tolist())               #  [-2, -1, 0, 1, 2, 3]

    mv = memoryview(a)
    ## 1 byte unsigned int
    print(mv.cast('B').tolist())    # [254, 255, 0, 1, 2, 3]

    ## 2 byte unsigned int
    print(mv.cast('H').tolist())    # [65534, 256, 770]
# mv_test()

#---------------------------------------------------------------------

# bytes: Immutable array of bytes
# A byte is an integer in range [0, 256).
# 'bytes' literal is a str prefixed with 'b'.
b = b'123'
print(len(b), b[0])     # 3 49       '1' is 49 in ascii
# b[0] = 0              # Error

# 'bytes' can be created with factory. (input must be a tuple)
print( bytes((0, 1, 2, 3)) )    # b'\x00\x01\x02\x03'

#---------------------------------------------------
# bytearray:  Mutable arrays of bytes
def byte_array():
    b = bytearray((0, 1, 2, 3))
    print(b)           # bytearray(b'\x00\x01\x02\x03')

    # Bytearrays are mutable.
    b.append(4)
    print(b)           # bytearray(b'\x00\x01\x02\x03\x04')

    b[1] = 0
    print(b)           # bytearray(b'\x00\x00\x02\x03\x04')

    # Bytearrays can shrink.
    del b[1]
    print(b)           # bytearray(b'\x00\x02\x03\x04')
# byte_array()

## bytes and bytearray can be converted to and from.
# print(bytes(bytearray((0, 1, 2))))  # b'\x00\x01\x02'
# print(bytearray(bytes((0, 1, 2))))  # bytearray(b'\x00\x01\x02')
