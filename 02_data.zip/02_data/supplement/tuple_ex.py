def tuple_literal():
    # Tuple literals are enclosed in ( ).
    print( (1, 2, 3) )

    # Empty tuple.
    print( (), tuple() )

    # Single element tuple listeral.
    print( (1) )            # integer 1 in parenthesis.
    print( (1,) )           # tuple with 1 element.

    # Tuples are generic and nestable.
    print((1, 2.0, '3', True))
    print((1, (2, 3)))

    # Tuple may contain duplicate elements
    print( (1, 2, 1) )
# tuple_literal()

def tuple_create():
    ## Tuple may be created by tuple() factory.
    print(tuple('Hello'))
    print(tuple(range(3)))
    print(tuple( [1, 2, 3] ))
    print(tuple( {1, 2, 1} ))

    ## Tuple cannot be created with comprehension.
    ## ( <comprehension> ) results a generator.
    print( type( (i for i in range(3))  )) # <class 'generator'>

    ## + is overloaded for merging tuples.
    print((1, 2) + (2, 'b'))  # (1, 2, 2, 'b')

    ## Tuple can be created with initialized value using *
    print((True,)*3)        # (True, True, True)
# tuple_create()
