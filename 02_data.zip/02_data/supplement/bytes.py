
##  Bytes Strings:
def bytes_string():
    print('Hello\tJohn.')       ## string           Hello	John.
    print(r'Hello\tJack.')      ## raw string       Hello\tJack.
    print(b'Hello\tJoe.')       ## bytes string     b'Hello\tJoe.'

    for c in 'Hello\tJack.':
        print(c, end=',')       ## H,e,l,l,o,	,J,a,c,k,.,
    print()
    for c in r'Hello\tJack.':
        print(c, end=',')       ## H,e,l,l,o,\,t,J,a,c,k,.,
    print()
    for c in b'Hello\tJack.':   ## A bytes string must be iterated to get bytes data.
        print(c, end=',')       ## 72,101,108,108,111,9,74,97,99,107,46,
# bytes_string()

## Python 3 represents strings as unicode.
## A string can be encoded with an encoding into a bytes string, and may be decoded back.
def encode_decode():
    print('ก'.encode())      ## encode()  using 'utf-8' as the default.
    print('ก'.encode('utf-16'))
    print(b'\xe0\xb8\x81'.decode())
    print(b'\xff\xfe\x01\x0e'.decode('utf-16'))
# encode_decode()

## The Unicode Standard explicitly separates the character identity from byte representations.
## Character identity is called 'code point' which represented as:
##       A prefix 'U' and 4 to 6 hexadecimal digits.
## ex. U0041 is letter A
def code_point():
    print('A'.encode())                     ## b'A'
    [print(hex(c)) for c in 'A'.encode()]   ## 0x41
    print('\u0041')                         ## A
# code_point()


## chr(<int>) returns unicode character of the int value.
## ord(<character>) return unicode
# print(chr(65), ord('A'))
# [print(ord(c)) for c in 'ABC']

