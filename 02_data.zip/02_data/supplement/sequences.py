''' Range: is a generator of values in a sequence defined with:
            range(<start>=0, <stop>=-1, <step>=1)
    <stop> is required, <start> and <step> are options.
A list has memory to store its elements.
A range does not, it generates value one at a time.
list() factory generates a list from a range.
 '''
def range_ex():
    print(list(range(3)))           # [0, 1, 2]
    print(list(range(1, 3)))        # [1, 2]
    print(list(range(1, 10, 3)))    # [1, 4, 7]
# range_ex()

#---------------------------------------------------

st = 'abc'                  # str
l = [0, 1, 2]               # list
t = (0, 1, 2)               # tuple
s = {0, 1, 2}               # set
d = {'a':0, 'b':1, 'c':2}   # dict

''' Python has builtin functions for sequence types.
'in' returns True if the first operand occurs in the second operand,
  applicable to all sequence types. '''
# print('b' in st, 1 in l, 1 in t, 1 in s, 'b' in d)

## max() and min() applicable to all sequence types.
# print(max(st), max(l), max(t), max(s), max(d))
# print(min(st), min(l), min(t), min(s), min(d))

## len() returns number of elemenmts, applicable to all sequence types.
# print(len(st), len(l), len(t), len(s), len(d))

''' '+' is append operator.
    '*' is repeate operator.
Applicable to str, list and tuple, but not set nor dict. '''
# print(st+st, l+l, t+t)
# print(st*3, l*3, t*3)

''' <seq>.count(<item>) is a method of str, list, and tuple
  which returns the number of occurrence of the <item> in <seq>. '''
# print(st.count('b'), l.count(1), t.count(1))

''' del(<var>) deletes both name and value of the <var>.
 Referring a deleted name is an error.   '''
def del_test():
    ## Deleting a variable.
    x = 1
    del(x)
    # print(x)      # error

    ## clear() removes elements of the collection,
    ##  it is only applicable to mutable collections.
    a = [1, 2]
    a.clear()
    print(a)        # []
# del_test()

#---------------------------------------------------------

''' <seq>.index(<item>) is a method of str, list, and tuple
   which returns the position of the <item> in <seq>.  '''
# print(st.index('a'), l.index(1), t.index(1))

## index() raises ValueError when the <item> is not found.
# print(st.index('ac'), l.index(3), t.index(3))     # error

''' Indexing:
Elements of ordered oriented sequences can accessed by 'index' operator:
             <seq>[<position>]
The first position is 0.
Negative index counts from the last, which is -1.
An exception is throwed when index out of bound(checked at runtime). '''
def indexing():
    print(st[-1], st[1], l[-1], t[-1], l[0], t[0])  # c b 2 2 0 0

    # List and tuple can be indexed with position.
    a = [0, (1, 2)]
    print(a[1], a[1][0])        # (1, 2) 1


    # Dict can be indexed with key. Sets cannot be indexed.
    d = {'a':1, 'b':{'x':2, 'y':3} }
    print(d['b'], d['b']['x'])  # {'x': 2, 'y': 3} 2
# indexing()

# Indexing allows modification the value if the sequence is mutable.
def mutable_index():
    ## Strings are immutable.
##    s[0] = '0'        # error

    ## Lists are mutable.
    a = [1, 2]
    a[0] = 0
    print(a)            # [0, 2]
    # del() allows deleteing element at the index.
    del(a[0])
    print(a)             # [2]

    ## Tuples are immutable.
    # t[0] = 3          # error

    ## Sets do not allow indexing.
    ## Dicts are mutable
    d = {'a':1, 'b':2}
    d['a'] = 0
    print(d)            # {'a': 0, 'b': 2}
    del(d['a'])
    print(d)            # {'b': 2}
# mutable_index()

#---------------------------------------------------------

# Slicing:
#   <seq>[<start>:<end>:<step>] is 'sclice' operator which extracts elements in the <seq>.
# Applicable to order-oriented types str, list, and tuple, not set and dict.
def slicing():
    a = list(range(10))

    ## The first and the last.
    print(a[0], a[-1])      # 0 9

    ## Skip the first.     Try: skip the first two (2).
    print(a[1:])       # [1, 2, 3, 4, 5, 6, 7, 8, 9]

    ## Exclude the last.   Try: exclude the last two (-2).
    print(a[:-1])      # [0, 1, 2, 3, 4, 5, 6, 7, 8]

    ## First two.
    print(a[:2])       # [0, 1]

    ## Last two.
    print(a[-2:])      # [8, 9]

    ## Skip the first two and exclude the last three.
    print(a[2:-3]) 	    # [2, 3, 4, 5, 6]

    ## The whole
    print(a[::])        # 0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    ## Even positions
    print(a[::2])       # [0, 2, 4, 6, 8]
    ## Odd positions
    print(a[1::2])      # [1, 3, 5, 7, 9]

    ## reversed
    print(a[::-1])      # [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

    ## Try this:
    ## s[:], s[0:], s[2:2], s[-2:-2], s[2::], s[:2:]
# slicing()

def iterate():
    s = 'abcd'
    # Sequences can be iterated with indexing. (Bad)
    for i in range(len(s)):
        print(s[i], end=',')  # a,b,c,d,
    print()

    # Iteration without index is more efficient.
    for i in s:
        print(i, end=',')     # a,b,c,d,
    print()

    # Reverse Iteration
    for i in reversed(s):
        print(i, end=',')     # d,c,b,a,
    print()

    # Iteration by comprehension.
    print([x for x in s])      # ['a', 'b', 'c', 'd']

    # Iteratation with index using enumerate().
    for i, x in enumerate(s):
        print(f'({i}, {x})', end=', ')
                # (0, a), (1, b), (2, c), (3, d),
# iterate()

## Zipping allows parallel iteration.
def zipping():
    a = ['john', 'jack', 'joe']
    b = ['rambo', 'ripper', 'green']
    for x in zip(a, b):
        print(x, end=', ')
        # ('john', 'rambo'), ('jack', 'ripper'), ('joe', 'green')

    #  zip() stops when the shortest sequence is done.
    for i in zip([1, 2, 3], [4, 5]):
        print(i, end=',')   # (1, 4),(2, 5),

    #  zip() can be nested
    for i in zip(zip([1, 2, 3], [4, 5, 6]), [7, 8, 9]):
        print(i, end=',')   # (1, 4),(2, 5),((1, 4), 7),((2, 5), 8),((3, 6), 9),
# zipping()

#---------------------------------------------------------s

# Randomly Selection:
import random
def select():
    # The sequences may be range, list or tuple.
    seq = range(10)
    # seq = [1, 2, 3, 4]
    # seq = (1, 2, 3, 4)

    # choice(<seq>) returns a randomly selected element from the <seq> independently.
    print(random.choice(seq))

    # sample(<seq>, n)) returns randomly selected n elements from the <seq> independently.
    print(random.sample(seq, 4))

    # shuffle(<seq>) in place randomly shuffles.
    # The sequence must be a list.
    a = [1, 2, 3, 4, 5]
    random.shuffle(a)
    print(a)
# select()

# Permutation: is a complete Shuffling.
# Brute Force Permute: requires a lot of 'if' for a long sequence.
def permuteBF(a):
    [ print(x, y, z)
        for x in a
        for y in a if y != x
        for z in a if z not in [x, y] ]
# permuteBF([1, 2, 3])
# permuteBF(range(3))

# Recursive Permutation: is a complicate function.
def permuteR(a):
    def _permuteR(a, i):
        def swap(i, j):
            a[i], a[j] = a[j], a[i]     # tmp = a[i]; a[i] = a[j]; a[j] = tmp

        if i == len(a):
            print(a)
        else:
            j = i
            while j < len(a):
                swap(i, j)
                _permuteR(a, i+1)
                swap(i, j)
                j += 1

    _permuteR(a, 0)
# permuteR([1, 2, 3, 4])

# 'itertools' lib provides a lot of tools to handle sequences.
import itertools
def itertools_test():
    ## permutations(<seq>) returns a generator.
    ## <seq> may str, list, tuple, set or dict.
    a = '123'

    for p in itertools.permutations(a):
        print(p)            # Resulting a tuple.

    ## Permutation with limit positions.
    print([p for p in itertools.permutations([1, 2, 3], 2)])
        ## [(1, 2), (1, 3), (2, 1), (2, 3), (3, 1), (3, 2)]

    # combinations(<seq>, n) returns a generator of tuples of n elements
    #  selected from <seq>.
    print(list(itertools.combinations([1, 2, 3, 4], 2)))
        # (1, 2),(1, 3),(1, 4),(2, 3),(2, 4),(3, 4),

    print([p for p in itertools.combinations_with_replacement([1, 2, 3], 2)])
        # [(1, 1), (1, 2), (1, 3), (2, 2), (2, 3), (3, 3)]

    print([p for p in itertools.product([1, 2, 3], repeat=2)])   ## to itself
        # [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)]
# itertools_test()

## Infinite Iterators:
def inf_iter():
    ## count(<start> [,<step>])   default <step> = 1
    for i in itertools.count(5, 2):
        print(i, end=',')        # 5,7,9,11,
        if i > 10:
            break
    print()

    ## cycle(<str>)
    c = 0
    for i in itertools.cycle('abcd'):
        print(i, end=',')       ## a,b,c,d,a,b,c,d,a,b,c,
        c += 1
        if c > 10:
            break
    print()

    # Repeat an Item with limit:
    ## repeat(<item> [,n])  upto n times.
    print([i for i in itertools.repeat(1, 5)])
        # [1, 1, 1, 1, 1]
    print([1]*5)
        # [1, 1, 1, 1, 1]
# inf_iter()

from itertools import *  # So that no need to qualified package name.
def iter_tool():
    # Chain: create a list from lists, str or range().
    print([i for i in chain([1,2,3], ['x', 'y'])]) # [1, 2, 3, 'x', 'y']
    print([i for i in chain([1,2,3], 'xy')]) # [1, 2, 3, 'x', 'y']
    print([i for i in chain('abc', 'xy')])   # ['a', 'b', 'c', 'x', 'y']
    print([i for i in chain(range(3), [4, 5])])   # [0, 1, 2, 4, 5]

    #---------------------------------------------------------------------

    # Filter:
    print([i for i in compress([1, 2, 3], [True, False, True])])  # [1, 3]
    print([i for i in compress([1, 2, 3], [0, 1, 1])])  # [2, 3]
    print([i for i in compress('abc', [1, 0, 1])])  # ['a', 'c']

    # Accept if <lambda> is False.
    print([i for i in filterfalse(lambda x: x%2 == 0, range(5)) ]) # [1, 3]

    # Start when <lambda> is False.
    print([i for i in dropwhile(lambda x: x < 4, [1,3,4,1,5]) ])   # [4, 1, 5]

    # Accept until <lambda> is False.
    print([i for i in takewhile(lambda x: x < 4, [1,3,4,1,5]) ])  # [1, 3]

    #---------------------------------------------------------------------

    # Accumulate: default operator is + which may be add or append().
    print([i for i in accumulate(range(5))])    # [0, 1, 3, 6, 10]
    print([i for i in accumulate('abcd')])       # ['a', 'ab', 'abc', 'abcd']
    print([i for i in accumulate(range(5), lambda x, y: x + y)])  # [0, 1, 3, 6, 10]
    import operator as op
    print([i for i in accumulate(range(6)[1:], op.mul)])     # [1, 2, 6, 24, 120]
# iter_tool()

#----------------------------------------------------------

# Magic Squares:
# Fill numbers 1 to 9 in a 3x3 square such that the sum in
# rows, columns, and diagonals are equal.
def magic_square():
    def test(a):
        if sum(a[0:3]) == sum(a[3:6]) == sum(a[6:10]) == \
           sum(a[0:10:3]) == sum(a[1:10:3]) == sum(a[2:10:3]) == \
           sum(a[0:10:4]) == sum(a[2:8:2]):
               return True
        return False

    def print_sq(a):
        print(a[0], a[1], a[2])
        print(a[3], a[4], a[5])
        print(a[6], a[7], a[8])
        print()

    for a in itertools.permutations(range(1, 10)):
        if test(a):
            print_sq(a)
# magic_square()
