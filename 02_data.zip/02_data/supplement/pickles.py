
# The state of an object may be persisted beyond the program lifetime
#  by write and read from a file.
import pickle
class A:
    def __init__(self, x):
        self.x = x

def pickle_test():
    with open('tmp', 'wb') as f:
        pickle.dump(123, f)
        pickle.dump('Hello', f)
        pickle.dump([1, 2, 3], f)
       
        a = A(1)
        pickle.dump(a, f)  

    with open('tmp', 'rb') as f:
        print(pickle.load(f))
        print(pickle.load(f))
        print(pickle.load(f))

        b = pickle.load(f)
        print(b.x)
##pickle_test()

# Object Serialization to bytes.
import struct
def struct_test():
     Student = struct.Struct('i4sf?') # int, (4)bytes, float, bool
     
     # Pack
     john = Student.pack(1, 'John'.encode(), 3.0, False)
     print(john)
     
     # UnPack
     sid, name, gpam, pro = Student.unpack(john)
     print(sid, name.decode(), gpam, pro)
##struct_test()
