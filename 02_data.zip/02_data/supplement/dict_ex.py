def dict_literal():
    ## Dict literals are enclosed in { } using ',' as separator.
    print( { 'id': 1,
             'name': 'John Rambo',
             'gpa': 1.8 } )

    ## Empty Dict
    print( {}, dict() )

    ## Value can be any type.
    print( { 'id': 2,
             'name': 'Jack Ripper',
             'email': ('jack@ripper.com', ),
             'info': { 'age': 25, 'weight': 80 },
             'take_courses': [ 'oop', 'alg']  } )
# dict_literal()

#-------------------------------------------------------------

import collections
def ordered_dict():
    # Since Python 3.6, dict instances preserve insertion order of keys.
    d = { 'john':1, 'jack': 2 }
    d['joe'] = 3
    print(d)   # {'john': 1, 'jack': 2, 'joe': 3}

    od = collections.OrderedDict(john=1, jack=2)
    od['three'] = 3
    print(od) # OrderedDict([('john', 1), ('jack', 2), ('three', 3)])

def default_dict():
    # Accessing non-exist key of a dict results an error.
    d = { 'john':1 }
#    print(d['jack'])  # error

    dd = collections.defaultdict(list)
    dd['cs'].append('john')
    print(dd['ce'])     # []
    print(dd['cs'])     # ['john']
    # Here a list is used to store values of the same key.
    dd['cs'].append('jaxk')
    print(dd)   # defaultdict(<class 'list'>, {'cs': ['john', 'jaxk'], 'ce': []})
# default_dict()

def chain_map():
    d1 = { 'john': 1, 'jack': 2 }
    d2 = { 'jack': 3, 'joe': 4 }

    # Chain two or more dict to be searched at once.
    cd = collections.ChainMap(d1, d2)
    print(cd)    # The first occurence value is returned.
    print(cd['jack'], cd['joe']) # 2 4
# chain_map()

import types
def read_only_dict():
    d = { 'john': 1, 'jack': 2 }

    # A wrapper for read only view.
    rod = types.MappingProxyType(d)
    print(rod['jack'])          # 2

    # Item modification is not allowed.
##    rod['jack'] = 3           # error

    # Adding more item is not allowed.
##    rod['joe'] = 3           # error

    # The original is still mutable.
    d['joe'] = 3
    print(rod)          # {'john': 1, 'jack': 2, 'joe': 3}
# read_only_dict()
