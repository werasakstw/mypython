
## pip install numpy
import numpy as np

## Numpy provides homogeneous array.
##              np.arange(<size>)
##              np.array(<range>)
def np_array():
    a = np.arange(10)         ## int32 is the default dtype.
    # a = np.array(range(10))
    print(a)                  ## [0 1 2 3 4 5 6 7 8 9]
    print(a.dtype, type(a))   ## int32  <class 'numpy.ndarray'>

    ## Data Types:   
    ## bool, inti, int8, int16, int32, int64, uint8, uint16, uint32, uint64
    ##  float16, float32, float64, complex64, complex128
    print(np.array(range(3), dtype=np.float16))    ## [0. 1. 2.]
# np_array()

def aggreagate_op():
    a = np.array(range(10))
    ## Aggregate Operations: +, -, *, /, %, **
    print(a+1)      ## [ 1  2  3  4  5  6  7  8  9 10]
    print(a*2)      ## [ 0  2  4  6  8 10 12 14 16 18]
    print(a**2)     ## [ 0  1  4  9 16 25 36 49 64 81]

    ## Aggreagate Selection:
    print(a>7)      ## [False False False False False False False False  True  True]
    print(a[a>7])   ## [8 9]

    ## clip(min, max): clips all values into a range.
    print(a.clip(3, 6))  ## [3 3 3 3 4 5 6 6 6 6]

    ## Built-in functions:
    print(a.sum(), a.min(), a.max(), a.mean())  ## 45 0 9 4.5
    ## Alternatively:
    print(np.sum(a), np.min(a), np.max(a), np.mean(a), np.average(a))

    ## Slice asignment:
    a[2:] = [1] * 8
    print(a)                    ## [0 1 1 1 1 1 1 1 1 1]

    a[1:8:2] = 2                ## [0 2 1 2 1 2 1 2 1 1]
    print(a)

    a[a>1] = 3                  ## [0 3 1 3 1 3 1 3 1 1]
    print(a)
# aggreagate_op()

## Create and Copy:
def create_copy():
    print(np.zeros(10, dtype=int))   ## [0 0 0 0 0 0 0 0 0 0]
    print(np.ones(3, dtype=complex)) ## [1.+0.j 1.+0.j 1.+0.j]
    print(np.array([1] * 4))    ## [1 1 1 1]
    print(np.array([1, 2] * 3)) ## [1 2 1 2 1 2]

    ## Copy 
    a = np.array(range(5))
    b = a.copy()
    # b = np.array(a)
    b[0] = 1
    print(a, b, a is b)     ## [0 1 2 3 4] [1 1 2 3 4] False

    ## Shallow Copy:
    c = a.view()
    # c = a
    c[0] = 1
    print(a, c, a is c)     ## [1 1 2 3 4] [1 1 2 3 4] False
# create_copy()

## Multidimensional Array:
##          array([dim1, dim2, dim3, ...])
def multi_dim():
    m = np.array([np.array(range(2)), np.array(range(2))])
    print(m.shape)  ## (2, 2)   tuple of each dimension size
    print(m)        ## [[0 1]
                    ##  [0 1]]

    ## Indexing
    a = np.array([[1,2],[3,4]])
    print(a)        ## [[1 2]
                    ##  [3 4]]
    
    print(a[0], a[0][0])     ## [1 2] 0

    ## Vectorized Operations: , -, *, /, %, **
    b = np.array([[1,2],[3,4]])
    print(a + b)

    ## Comparison OPerations:
    print(a == 2)           ## [[False  True]
                            ##  [False False]]

    ## Boolean index as a filter.
    b = np.array([[False, True],[True, False]])
    print(a[b])         ## [2 3]
# multi_dim()                 

###########################################################

## Matrix:
##          mat(<value>)
def matrix_test():
    print(np.mat(np.array(range(9)).reshape(3, 3)))
                                                ## [[0 1 2]
                                                ##  [3 4 5]
                                                ##  [6 7 8]]
     
    print(np.mat('0, 0, 0; 1, 1, 1; 2, 2, 2'))  ## [[0 0 0]
                                                ##  [1 1 1]
                                                ##  [2 2 2]]
    ## Identity matrix (of float)
    i = np.eye(3)
    print(i)    ## [[1. 0. 0.]
                ##  [0. 1. 0.]
                ##  [0. 0. 1.]]

    ## save a matrix as text file
    np.savetxt('m.txt', i)

    ## load a matrix from file
    j = np.loadtxt('m.txt')
    print(j)
# matrix_test()

## Array VS Matrix:
def arr_mat():
    a = np.array(4).reshape(2, 2); print(a)
                                     ## [[0 1]
                                     ##  [2 3]]
    
    m = np.mat('0 1; 2 3'); print(m) ## [[0 1]
                                     ##  [2 3]] 
    print(a*a)      ## [[0 1]
                    ##  [4 9]]
    
    print(m*m)      ## [[ 2  3]
                    ##  [ 6 11]]

    ## Matrix Inverse
    print(m.I)      ## [[-1.5  0.5]
                    ##  [ 1.   0. ]]

    ## Identity matrix
    print(m * m.I)  ## [[1. 0.]
                    ##  [0. 1.]]
# arr_mat()

## Linear Algebra:  numpy.linalg
## Solving Linear Equations
## ex.      2x + 3y = 8
##          4x + 5y = 10
def solv_eq():
    m = np.mat("2 3; 4 5")
    a = np.array([8, 10])
    print(np.linalg.solve(m, a))    ## [-5.  6.]
# solv_eq()

##########################################################

## Performance Test:

import time
## time.clock() returns current system clock, may be affected by system processes.
## time.perf_counter() returns highest precision possible system clock in nano seconds.
## time.process_time() returnsclocks the processor spends on the specific process.
def sum_sq():
    n = 1000
    a = list(range(n))
    b = np.arange(n)
    
    print('For Loop:')
    start = time.perf_counter()
    s = 0
    for x in a:
        s += x*x
    stop = time.perf_counter()
    print('a: %d, %.6f' % (s, stop - start))

    start = time.perf_counter()
    s = 0
    for x in b:
        s += x*x
    stop = time.perf_counter()
    print('b: %d, %.6f' % (s, stop - start))
    
    #---------------------------------------------#
    
    print('\nComprehension:')
    ## sum() is a built-in Python function.
    start = time.perf_counter()
    s = sum([x*x for x in a])
    stop = time.perf_counter()
    print('a: %d, %.6f' % (s, stop - start))

    start = time.perf_counter()
    s = sum([x*x for x in b])
    stop = time.perf_counter()
    print('b: %d, %.6f' % (s, stop - start))

    #---------------------------------------------#
    
    print('\nAggreagate:')
    start = time.perf_counter()
    s = sum(b*b)
    stop = time.perf_counter()
    print('b: %d, %.6f' % (s, stop - start))
    
    print('\nDot:')
    start = time.perf_counter()
    s = b.dot(b)
    stop = time.perf_counter()
    print('b: %d, %.6f' % (s, stop - start))
# sum_sq()   
    
import timeit
def ptest():
    print('%.4f' % timeit.timeit('sum([x*x for x in range(1000)])',
                        number=10000))
        
    print('%.4f' % timeit.timeit('sum(a*a)',
                        setup='import numpy as np;a=np.arange(1000)',
                        number=10000))
    print('%.4f' % timeit.timeit('a.dot(a)',
                        setup='import numpy as np;a=np.arange(1000)',
                        number=10000))
# ptest()


