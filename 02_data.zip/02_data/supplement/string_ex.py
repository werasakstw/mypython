def str_create():
    # Mostly strings are created as literals.
    s = '123'
    print(s)

    # String with value or form other types can be created with 'str' factory.
    print(str())          ## empty str
    print(str(False))     ## 'False'
    print(str(True))      ## 'True'
    print(str(1))         ## '1'
    print(str(1.23))      ## '1.23'
# str_create()

# String Operations:
def str_op():
    # Conditional String
    print('Hello' if True else 'Hi') # Hello

    s = 'Hello'
    # Built-in functions
    print(len(s), min(s), max(s))    # 5 H o

    # in
    print('el' in s)                # True

    # Find
    print(s.find('el'))             # 1

    # Startswith, Endswith
    print(s.startswith('Hell'), s.endswith('lo')) # True True

    # Occurance count
    print(s.count('l'))             # 2

    # Slice
    print(s[1:3], s[1:], s[:3])     # el ello Hel

    # Reverse
    print(s[::-1])                  # olleH

    # Step
    print(s[::2])                   # Hlo

    # Str to int
    print(int('123'), int('10', 2), int('F', 16))  # 123  2  15

    # Int to str
    print(bin(5), oct(8),hex(15) )      # 0b101  0o10  0xf

    # <str>.strip(<chars>) removes characters from both ends of a string.
    print(' Hello '.strip())            # Hello
    print('...Hello.how.are.you?.......'.strip('.'))    # Hello.how.are.you?

    # <str>.replace(<str1>,<str2>) replaces str1 with str2.
    print('john jack joe'.replace('j', 'J'))    # John Jack Joe

    # list -> str
    # <separator>.join(<str list>) creates a string from <str list>.
    a = ['a', 'b', 'c']
    print(', '.join(a))         # a, b, c

    # join() only works with str.
    a = [1, 2, 3]
    # print(', '.join(a))       #  error
    print(', '.join(str(x) for x in a))   # 1, 2, 3

    # str -> list
    # <str>.split(<separator>) splits the <str> into a list of str.
    # The default separator is a blank.
    print('a,b,c'.split(','))           # ['a', 'b', 'c']

    # Split with separator
    x = '  a  b    c '
    print(x.split())        # ['a', 'b', 'c']
    print(x.split(' '))     # ['', '', 'a', '', 'b', '', '', '', 'c', '']

    # str -> str
    # <str>.partition(<separator>) partitions the <str> into head, sep, and tail.
    head, separator, tail = 'John Jack Joe'.partition(' ')
    print([head], [separator], [tail])  # ['John'] [' '] ['Jack Joe']
# str_op()

def cases():
    s = 'john jack joe'

    # <str>.capitalize() capitalizes only the first word.
    print(s.capitalize())  # John jack joe

    # <str>.title() capitalize all the words.
    print(s.title())       # John Jack Joe

    # <str>.upper() converts all characters to uppercase.
    print(s.upper())       # JOHN JACK JOE

    # <str>.lower() converts all characters to lowercase.
    print('John Jack Joe'.lower())    # john jack joe

    # <str>.swapcase()
    print('John Jack Joe'.swapcase())   # jOHN jACK jOE
# cases()

# String Close Match:
from difflib import get_close_matches
def close_match():
    x = 'abc'
    y = ['aaa', 'bac', 'aac', 'xbc', 'bdca', 'abb']
    print(get_close_matches(x, y))
    print(get_close_matches(x, y, n=1))
    print(get_close_matches(x, y, cutoff=0.4))
    print(get_close_matches(x, y, cutoff=0.7))
# close_match()

# 'string' lib: provides ready to use characters, digits and symbols.
import string
def str_const():
    print(string.ascii_lowercase)
    print(string.ascii_uppercase)
    print(string.ascii_letters)
    print(string.digits)
    print(string.punctuation)
    print(string.whitespace)
    print(string.printable)
# str_const()

# Python dose not allow integers with leading 0.
# Sometime it is safer to work with str.
def car(n: str):  # Type Annotation
   return(n[0], n[1:])
##print(car('123'))       # ('1', '23')
##print(car('1023'))      # ('1', '023')
