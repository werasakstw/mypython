''' Tuple: is immutable order-oriented sequence.
Tuples are more efficient than lists.
Tuples can be indexed, sliced and iterated.
Tuples have no methods that modifies their state e.g.
 append(), extends(), insert(), remove(), pop() reverse() and sort().  '''
def tuple_immutable():
    t = ('a', 'b', 'c')

    ## Elements cannot be modified.
    # t[0] = 0          # error

    ## Tuple cannot be appended.
    # t.append('d')       # error

    ## Tuple Element cannot be deleted.
    # del(t[2])         # error

    ## Tuple can be replaced as a whole.
    t = ('x', 'y')
    print(t)            # ('x', 'y')

    ## Tuple can be deleted as a whole. clear() is not supported.
    del(t)
    # print(t)          # error

    ## If a tuple element is mutable, the element may be modified.
    b = (1, [2, 3])
    b[1].append(4)      ## Lists are mutable.
    print(b)            # (1, [2, 3, 4])
# tuple_immutable()

## Tuples allow a function to return more than one values.
def div10(n):
    return n//10, n%10      ## Automatic tuple packing.
# print(div10(12))          # (1, 2)

## Passing lists as parameters may have side effect, but not for tuples.
def tuple_param():
    def f(a, t):
        a += 'x'
        # t += 'x'     # error

    a = ['a','b']
    t = ('a','b')
    f(a, t)
    print(a)        # ['a', 'b', 'x']
# tuple_param()

#####################################################

## Tuple Unpacking: is an assignment of a tuple to several variables.
def tuple_unpacking():
    a, b, c = ('John', 'Jack', 'Joe')
    print(a, b, c)      # John Jack Joe

    ## Multiple Tuples Unpacking:
    (a, b), (c, d, e) = (1, 2), (3, 4, 5)
    print(a, b, c, d, e)    # 1 2 3 4 5

    ## Nested Tuples Unpacking:
    (a, (b, c)) = (1, (2, 3))
    print(a, b, c)      # 1 2 3

    ## The left and right sides of tuple unpacking must have the same size.
    # (a, b) = (1, 2, 3)    # error
    # (a, b, c) = (1, 2)    # error

    ## Wildcards *
    (a, b, *c) = (1, 2, 3, 4, 5)    ## c is a list, not a tuple.
    print(a, b, c)        # 1 2 [3, 4, 5]

    ## * may not be the last.
    (a, *b, c) = (1, 2, 3, 4, 5)
    print(a, b, c)        # 1 [2, 3, 4] 5

    ## * may accept empty.
    (a, b, *c) = (1, 2)
    print(a, b, c)        # 1 2 []

    ''' Automatic tuple packing.
     On a value context e.g. right side of =, () is optional.  '''
    t = 1, 2, 3
    print(t)              # (1, 2, 3)

    ## Multiple Assignment is a tuple unpacking in disguise.
    x, y, z = 1, 2, 3
    print(x, y, z)        # 1 2 3

    ## Automatic tuple pack/unpack.
    a, b, *c = 1, 2, 3, 4, 5
    print(a, b, c)        # 1 2 [3, 4, 5]

    ''' Tuple unpacking can exchange values in one statement
     without using a temporary holder. '''
    x, y = 1, 2
    y, x = x, y
    print(x, y)            # 2 1
# tuple_unpacking()
