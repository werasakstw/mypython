from requests import get

## Get a json file.
def getfile(path):
    print(get(path).content.decode())
getfile('https://gateway.pinata.cloud/ipfs/QmY3j1iLesaSnvDTxMaSbJw7nA1zfZDrCJ2xGsh2QVUTEt')

#------------------------------------------------

API_KEY = ''
API_SECRET = ''
ACESS_TOKEN = ''

## pip install pinata
from pinata import Pinata

p = Pinata(API_KEY, API_SECRET, ACESS_TOKEN)
# print(p)

## Pin a file.
# print(p.pin_file('hello.txt'))
## 'IpfsHash': 'QmbpXkpq189TQRV75yohiD3EvikXt8jUnNucCAzHYExDAX',
# getfile('https://gateway.pinata.cloud/ipfs/QmbpXkpq189TQRV75yohiD3EvikXt8jUnNucCAzHYExDAX')

## Get all pins
def get_pins():
    ps = p.get_pins()
    print(ps['data']['count'])
    for r in ps['data']['results']:
        rp = r['pin']
        print(rp['name'], '\t', rp['cid'])
# get_pins()

## Unpin a file.
ipfshash = 'QmbpXkpq189TQRV75yohiD3EvikXt8jUnNucCAzHYExDAX'
# print(p.unpin_file(ipfshash))
# get_pins()
