

from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def index():
    return 'I am index.'

@app.route("/hello")
def hello():
    return render_template('hello.html')

@app.route("/hi")
def hi():
    return render_template('hi.html')