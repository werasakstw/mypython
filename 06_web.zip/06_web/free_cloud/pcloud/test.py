## pip install pcloud
from pcloud import PyCloud
email = ''
pwd = ''
pc = PyCloud(email, '', endpoint='eapi')

def list_dir():
    a = pc.listfolder(folderid=0)   ## 0 is the root folder.
    for f in a['metadata']['contents']:
        # print(f)
        print(f['name'], '\t', f.get('fileid'))
list_dir()

## Upload File
def upload(file_list):
    print(pc.uploadfile(files=file_list, folderid=0))
# upload(['hello.txt', 'bird.png'])

## Upload Data
import io
from PIL import Image
def upload_image():
    im = Image.open('bird.png', 'r')
    bi = io.BytesIO()
    im.save(bi, format='png')
    print(pc.uploadfile(data=bi.getvalue(), filename='bird.png', folderid=0))
# upload_image()

## Download File:
fileid = '19877551985'
def download():
        ## File open needs flagsgs: 0(create), 1(read), 2(write)
        ## File may be specified with path or fileid.
    a = pc.file_open(path='/hello.txt', flags=1)
    # print(pc.file_open(fileid=fileid, flags=1))
        ## {'result': 0, 'fd': 1, 'fileid': 19877551985}
        ## The file is identified by 'fd'.
    # print(pc.file_size(fd=1))
        ## {'result': 0, 'size': 20, 'offset': 0}
        ## File read needs the file size.
    data = pc.file_read(fd=1, count=20)
    print(data.decode())
# download()

## Delete File
def delete():
    print(pc.deletefile(path='/hello.txt'))
    # print(pc.deletefile(fileid=fileid))
# delete()
