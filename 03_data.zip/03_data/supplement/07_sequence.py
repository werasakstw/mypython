''' 'range' is a generator (result one value at a time) for
  sequence of consecutive integers.
            range(<start>=0, <stop>=-1, <step>=1)
    <stop> is required, <start> and <step> are options. '''
def range_ex():
    ''' A list has memory to store its elements, a range does not.
    list() factory can generates a list from a range.  '''
    print(list(range(3)))           ## [0, 1, 2]
    print(list(range(1, 3)))        ## [1, 2]
    print(list(range(1, 10, 3)))    ## [1, 4, 7]

    ''' Ranges are iterable. '''
    for i in range(10):	            ## (0, 10]
    # for i in range(1, 10):	    ## (1, 10]
    # for i in range(1, 10, 2):	    ## step = 2
        print(i, end=',')
    print()
# range_ex()

#-----------------------------------------------------------------

''' 'Sequences' are collections of elements, ordered or unordered. '''
st = 'abc'                  ## str
l = [0, 1, 2]               ## list
t = (0, 1, 2)               ## tuple
s = {0, 1, 2}               ## set
d = {'a':0, 'b':1, 'c':2}   ## dict
r = range(3)                ## range

''' len() returns number of elemenmts, applicable to all sequence types. '''
# print(len(st), len(l), len(t), len(s), len(d), len(r))  ##  3 3 3 3 3 3

''' max() and min() applicable to all sequence types.  '''
# print(max(st), max(l), max(t), max(s), max(d), max(r))  ## c 2 2 2 c 2
# print(min(st), min(l), min(t), min(s), min(d), min(r))  ## a 0 0 0 a 0

''' 'in' is a membership operator, applicable to all sequence types. '''
# print('b' in st, 1 in l, 1 in t, 1 in s, 'b' in d, 1 in r)
            ## True True True True True True

''' sum(<seq>) returns the summation of values in a sequence.
 Unapplicable to str and dict if elements are not numbers. '''
# print(sum(l), sum(t), sum(s), sum(r))   ## 3 3 3 3

''' Ex. Summation from 1 to n.
        sum_(n) = 1 + 2 + 3 + ... + n  =  n*(n+1)/2     '''
def sum_(n):
    # return sum(range(1, n+1))
    return n*(n+1)//2
# print(sum_(100))              # 5050

''' '+' is append operator.
    '*' is repeate operator.
Applicable to ordered types: str, list and tuple,
  but not to range and unordered types: set and dict. '''
# print(st+st, l+l, t+t)  ## abcabc [0, 1, 2, 0, 1, 2] (0, 1, 2, 0, 1, 2)
# print(st*3, l*3, t*3)
    ## abcabcabc [0, 1, 2, 0, 1, 2, 0, 1, 2] (0, 1, 2, 0, 1, 2, 0, 1, 2)

def delete():
    ''' del(<var>) deletes both name and value. '''
    x = 1
    del(x)
    ''' Referring to a deleted name is an error. '''
    # print(x)              ## error

    ''' del([<element>,]) deletes element of indexable mutable sequences
     e.g. list and dict, but str, tuple, set and range are not allowed. '''
    del(l[1], d['b'])
    print(l, d)             ## [0, 2] {'a': 0, 'c': 2}

    ''' <seq>.clear() removes all elements of mutable sequences,
       st, tuple and range are not allowed.
    clear() is a method of the type not a builtin.
    The object elements are cleared but the object still alive. '''
    lx = [1]; sx = {1}; dx = {'a':0}
    lx.clear(); sx.clear(); dx.clear()
    print(lx, sx, dx)          ## [] set() {}

    ''' del(<seq>) deletes the whole, str and tuple are not allowed.  '''
    del(lx); del(sx); del(dx)
# delete()

''' <seq>.count(<item>) returns the number of occurrence of
  <item> in <seq> which is a method of ordered sequences,
  set and dict are not allowed.  '''
# print(st.count('b'), l.count(1), t.count(1), r.count(1))  ## 1 1 1 1

#-------------------------------------------------------------------
''' Iterating
'for' and comprehension can iterate all sequences. '''
def iterate_seq():
    for x in st:
    # for x in l:
    # for x in t:
    # for x in s:
    # for x in d:
    # for x in r:
        print(x, end=',')
    print()

    print([x for x in st])
    print([x for x in l])
    print([x for x in t])
    print([x for x in s])
    print([x for x in d])
    print([x for x in r])

    ''' Reverse iteration applicable to all sequences, except set. '''
    print([x for x in reversed(st)])
    print([x for x in reversed(l)])
    print([x for x in reversed(t)])
    # print([x for x in reversed(s)])     ## error
    print([x for x in reversed(d)])
    print([x for x in reversed(r)])
# iterate_seq()

def special_iteration():
    ''' Pyton 3.8 introduces a new syntax of 'for' to iterate a sequence. '''
    for i in 2, 1, 3:
        print(i, end=',')   ## 2,1,3
    print()

    ''' Iteration with index and value. '''
    for i,v in enumerate(['john', 'jack', 'joe']):
        print(i, v, end='   ')  ## 0 john   1 jack   2 joe
    print()

    ''' Parallel iteration more than one lists. '''
    a = ['john', 'jack', 'joe']
    b = ['rambo', 'ripper', 'green']
    for t in zip(a, b):     ## Result is a tuple.
        print(t, end=', ')
        ## ('john', 'rambo'), ('jack', 'ripper'), ('joe', 'green'),
    print()

    ''' zip() stops when the shortest sequence is done. '''
    for i in zip([1, 2, 3], [4, 5]):
        print(i, end=',')   ## (1, 4),(2, 5),
    print()

    ''' zip() can be nested. '''
    for i in zip(zip([1, 2, 3], [4, 5, 6]), [7, 8, 9]):
        print(i, end=',')
        ## (1, 4),(2, 5),((1, 4), 7),((2, 5), 8),((3, 6), 9),
# special_iteration()

#-------------------------------------------------------------------
'''  Indexing
<seq>.index(<item>) returns the position of <item> in <seq>,
  which is a method of ordered sequences, set and dict are not allowed.
  ValueError is raised if the <item> is not found. '''
# print(st.index('b'), l.index(1), t.index(1), r.index(1))   ## 1 1 1 1

''' Elements of ordered sequences can accessed by 'index' operator:
                <seq>[<position>]
Index position is zero based.
Negative index starts from the last, which is -1.
An exception is raised when index out of bound(checked at runtime). '''
def indexing():
    print(st[-1], st[1], l[-1], t[-1], l[0], t[0], r[0])  ## c b 2 2 0 0 0

    ''' Indexing can be nested for list and tuple. '''
    a = [0, (1, 2)]
    print(a[1], a[1][0])        ## (1, 2) 1

    ''' Dict can be indexed with key, so keys must be unique.  '''
    d = {'a':1, 'b':{'x':2, 'y':3} }
    print(d['b'], d['b']['x'])  # {'x': 2, 'y': 3} 2
    ''' Sets are implemented as dicts using element values as keys but not allow indexing. '''

    ''' Indexing allows modification for mutable sequence. '''
    # st[0] = '0'           ## error        str is immutable

    l[0] = -1
    print(l)                ## [-1, 1, 2]

    # t[0] =-1              ## error        tupleis immutable

    d['x'] = 0
    print(d)                ## {'a': 1, 'b': {'x': 2, 'y': 3}, 'x': 0}
                ## Set and range are not indexable.
# indexing()

''' Slicing is expression for extracting elements in sequences, which
 applicable to only order-oriented types str, list, and tuple, not set and dict.
Slice expression issimilar to indexing:
                    <seq>[<start>:<end>:<step>]        '''
def slicing():
    a = list(range(10))

    ''' The first and the last. '''
    print(a[0], a[-1])      ## 0 9

    ''' Skip the first.     Try: skip the first two (2). '''
    print(a[1:])            ## [1, 2, 3, 4, 5, 6, 7, 8, 9]

    ''' Exclude the last.   Try: exclude the last two (-2).  '''
    print(a[:-1])           ## [0, 1, 2, 3, 4, 5, 6, 7, 8]

    ''' First two '''
    print(a[:2])            ## [0, 1]

    ''' Last two.  '''
    print(a[-2:])           ## [8, 9]

    ''' Skip the first two and exclude the last three. '''
    print(a[2:-3]) 	        ## [2, 3, 4, 5, 6]

    ''' The whole  '''
    print(a[::])            ## 0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    ''' Even positions  '''
    print(a[::2])           ## [0, 2, 4, 6, 8]
    ''' Odd positions  '''
    print(a[1::2])          ## [1, 3, 5, 7, 9]

    ''' Reversed  '''
    print(a[::-1])          ## [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

    ''' Try this: s[:], s[0:], s[2:2], s[-2:-2], s[2::], s[:2:]   '''

    ''' Slicing can be used in the left-hand side of assignments. '''
    a[:2] = [12, 345]
    print(a)                ## [12, 345, 2, 3, 4, 5, 6, 7, 8, 9]
# slicing()

########################################################################

''' Ex. Magic Squares: Fill numbers 1 to 9 in a 3x3 square such that
  the sum in rows, columns, and diagonals are equal. '''
import itertools
def magic_square():
    def test(a):
        if sum(a[0:3]) == sum(a[3:6]) == sum(a[6:10]) == \
           sum(a[0:10:3]) == sum(a[1:10:3]) == sum(a[2:10:3]) == \
           sum(a[0:10:4]) == sum(a[2:8:2]):
               return True
        return False

    def print_square(a):
        print(a[0:3]); print(a[3:6]); print(a[6:9], end='\n\n')

    for a in itertools.permutations(range(1, 10)):
        if test(a):
            print_square(a)
# magic_square()

''' Homework:
The magic_square() produces similar squares which are the results
of flipping or rotating. Write a program that eliminates such the cases.

Exercises: Find digit for each letter to fill a 3x3 square so that:
          a b c               x d a
        + d e f             + y e b
          x y z               z f c
The second square is the result of rotating the first square 90 degree.  '''

#--------------------------------------------------------------

''' 'itertools' lib provides a lot of tools to handle sequences. '''
import itertools
def itertools_test():
    ''' permutations(<seq>) returns a generator of tuples.
      <seq> may str, list, tuple, set or dict. '''
    a = '123'

    print( [x for x in itertools.permutations('123')])
        ## [('1', '2', '3'), ('1', '3', '2'), ('2', '1', '3'), ('2', '3', '1'), ('3', '1', '2'), ('3', '2', '1')]
    ''' Permutation with limit positions. '''
    print([p for p in itertools.permutations([1, 2, 3], 2)])
        ## [(1, 2), (1, 3), (2, 1), (2, 3), (3, 1), (3, 2)]

    ''' combinations(<seq>, n) returns a generator of tuples of n elements
      selected from <seq>. '''
    print(list(itertools.combinations([1, 2, 3, 4], 2)))
        ## (1, 2),(1, 3),(1, 4),(2, 3),(2, 4),(3, 4),

    print([p for p in itertools.combinations_with_replacement([1, 2, 3], 2)])
        ## [(1, 1), (1, 2), (1, 3), (2, 2), (2, 3), (3, 3)]

    print([p for p in itertools.product([1, 2, 3], repeat=2)])   ## to itself
        ## [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)]
# itertools_test()

''' Infinite counter
itertools.count(<start> [,<step> = 1]) returns a generator of increasing
  numbers from <start> with <step>. '''
def inf_counter():
    for i in itertools.count(5, 2):
        print(i, end=',')        # 5,7,9,11,
        if i > 10:
            break
# inf_counter()

''' Infinite cycle '''
def inf_cycle():
    c = 0
    seq = 'abc'
    # seq = [1,2,3]
    # seq = (1,2,3)
    # seq = {1,2,3}
    # seq = {'one': 1, 'two': 2}
    # seq =range(3)
    ''' itertools.cycle(<seq>) returns a generator of elements in <seq> repleatedly. '''
    for i in itertools.cycle(seq):
        print(i, end=',')
        c += 1
        if c > 10:
            break
# inf_cycle()

''' Generate repeat value indefinitely
itertools.repeat(<item> [,n]) returns a generator of <item> indefinitely
  or upto n times. '''
def inf_repeat():
    print([i for i in itertools.repeat(1, 3)])  ## [1, 1, 1 ]
    ''' But samecan be done with repeat operator. '''
    print([1]*3)                               ## [1, 1, 1]
# inf_repeat()

''' chain() creates a list from chain of list, tuple, set, str or range(). '''
def iter_chain():
    print([i for i in itertools.chain([1,2,3], ['x', 'y'])]) ## [1, 2, 3, 'x', 'y']
    print([i for i in itertools.chain({1,2,3}, ('x', 'y'))]) ## [1, 2, 3, 'x', 'y']
    print([i for i in itertools.chain('abc', 'xy')])   ## ['a', 'b', 'c', 'x', 'y']
    print([i for i in itertools.chain(range(3), [4, 5])])   ## [0, 1, 2, 4, 5]
# iter_chain()

''' Filter '''
def filter():
    ''' compress(<seq>,<cond>) filters elements with boolean, int, float or emptyness.   '''
    print([i for i in itertools.compress([1, 2, 3], [True, False, True])])  ## [1, 3]
    print([i for i in itertools.compress([1, 2, 3], [0, 1, 1])])  ## [2, 3]
    print([i for i in itertools.compress('abc', [1.0, 0.0, 1])])  ## ['a', 'c']
    print([i for i in itertools.compress('abc', [[1], set(), ()])]) ## ['a']

    ''' filterfalse(<lambda>, <seq>) accept if the <lambda> is False. '''
    print([i for i in itertools.filterfalse(lambda x: x%2 == 0, range(5)) ]) ## [1, 3]

    ''' dropwhile(<lambda>, <seq>) start accept when the <lambda> is False. '''
    print([i for i in itertools.dropwhile(lambda x: x < 4, [1,3,4,1,5]) ])   ## [4, 1, 5]

    ''' takewhile(<lambda>, <seq>) accept until <lambda> is False. '''
    print([i for i in itertools.takewhile(lambda x: x < 4, [1,3,4,1,5]) ])  ## [1, 3]
# filter()

import operator as op
def accumulate():
    ''' accumulate(<seq> [,<lambda>]) generates a result from the previous result by accumulate with the
      default operator + (which may be add or append()) or using the specified <lambda>. '''
    print([i for i in itertools.accumulate(range(5))])    ## [0, 1, 3, 6, 10]
    print([i for i in itertools.accumulate('abcd')])      ## ['a', 'ab', 'abc', 'abcd']
    print([i for i in itertools.accumulate(range(5), lambda x, y: x + y)])  ## [0, 1, 3, 6, 10]
    print([i for i in itertools.accumulate(range(6)[1:], op.mul)])     ## [1, 2, 6, 24, 120]
# accumulate()
