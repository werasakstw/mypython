''' Python is a pure 'object-oriented' language.
That means variables, functions and classes are implemented as objects.

But Python tries very hard not to looked like an 'oo' language.
Most Python libraries are built so that users can use without the concepts of 'oo'.
Instead of calling 'object' or 'instance', Python prefers 'variable',
  and avoid calling 'class' by using 'type'.

The following terminologies are vary among textbooks:
  'Class' is a mechanism for defining 'type' of objects.
  'Type' defines how to access value of object.
  'Object' is an instance of a class which may be variable, function or class.
  'Class/Object members' are members that belong to a class/object,
      which may be attributes, methods, or classes.
  'Attributes' are data. 'Method' are functions.

Class definition:
         class <name> [(<parents>, <meta class>)]:
            [<doc string>]
            <body>
Default <parents> and <meta class> is 'object' class.
By convention, class names begin with capital letters and
  variable names begin with lower case letters.

A class definition with empty <body>and no <doc string> must has 'pass' as the body. '''
class E:
    pass

''' <doc string> is optional, it is a string telling the class information.
An empty class with <doc string> may not have 'pass'. '''
class D:
   '''D doc string'''

''' Built-in and library classes are created statically, when imported.
User defined classes are created at runtime when the class definition is encountered. '''
def class_def():
    ''' A newly created class as empty namespace. '''
    print(dir())             ## []

    ''' Classes can be defined locally and accessible within the scope. '''
    class A:
        def greet():
            print('Hello')
    print(dir())            ## ['A']

    ''' All classes have their own namespace to store class members,
          which is created as a dict  named __dict__.  '''
    print(A.__dict__['greet']) ## <function classes.<locals>.A.greet at 0x034B33D0>
    A.greet()                  ## Hello
    # print(dir(A))            ## list of members in 'A' namespace.

    ''' Class definition can be shadowed within the same namespace. '''
    class A:
      def hi():
            print('Hi')
    print(dir())             ## ['A']
    A.hi()                   ## Hi

    ''' All classes are created as object of class 'type'. '''
    print(type(A))           ## <class 'type'>
# class_def()

''' After a class is defined, an object of the class may be created by:
                <class name>(<arguments>)               '''
def objects():
    class A:
        def hello(self):
            print('Hello')
    ''' To create an object 'a' of class 'A'.
     It is ok to say that 'a' is an object/instance/variable of type or class 'A'. '''
    a = A()
    print(type(a))      ## <class '__main__.objects.<locals>.A'>

    ''' Class definition creates a 'class object' for storing information of the class.
    All objects of class 'A' has a reference to the 'class object' of class 'A'.
    Objects of the same class have the same members. '''
    a.hello()                        ## Hello
    A().hello()                      ## Hello
    print(type(a) is type(A()))      ## True
# objects()
