''' 'Protocol' is specification which defines a set of operations.
If a class is 'conform to' a protocol that means objects of the class
  can preform operations(has methods) definded by the protocol.
We can say that a protocol defines what a set of classes can do.

An executable function/method must has:
    - A header which is specification defines what to do.
    - A body which is implementation defines how to do.
A header is required to define a references to the function/method.
Functions/methods are allowed to be defined with only header and
  no body that called 'abstract' function/method.
They are not executable(cannot be invoked), but can be used to define
  'abstract' classes which are classes that contain 'abstract' methods.

'Abstract' classes are not usable because some of their methods do not
  have implementation, but they can be used to define references to
  objects of the class.

'Abstract' class allow creating a protocol which means specifying what
   the class can do with a set of 'abstract' methods.

We can create a usable class that conform to an 'abstract' class by
  creating a subclass and implements its 'abstract' methods.

Python does not support creating 'abstract' method directly.
But 'abc' lib provides class 'ABCMeta' for creating abstract classes.
An abstract class must have the 'ABCMeta' as it metaclass.
An abstract method must be annotated with @abstractmethod,
  and has empty body or raises an error.   '''
from abc import ABCMeta, abstractmethod
class A(metaclass=ABCMeta):
    @abstractmethod
    def hello(self, name):
        pass
        # raise NotImplementedError()

''' This abstract class 'A' specifies that any classes that conform to
      the specification must have hello().
Creating an abstract class is not allowed. '''
# A()                             ## error

''' To make a usable class by subclassing class 'A'. '''
class MyA(A):
    def hello(self, name):
        print('Hello', name)
# MyA().hello('John')             ## Hello John

''' An 'abstract' class may have usable methods and have any number of
     'abstract' methods which some may even have body.  '''
class A(metaclass=ABCMeta):
    @abstractmethod
    def hello(self, name):
        pass
    @abstractmethod
    def hi(self, name):
        print('hi ' + name)
    def bye(self, name):
        print('Bye ' + name)

''' Partially implementation is not allowed. '''
class BadA(A):
    def hello(self, name):
        print('Hello ' + name)
# BadA()                         ## error

''' All 'abstract' methods must be implemented. '''
class MyA(A):
    def hello(self, name):
        print('Hello', name)
    def hi(self, name):
        print('Hi', name)
a = MyA()
# a.hello('John')         ## Hello John
# a.hi('Jack')            ## Hi Jack
# a.bye('Joe')            ## Bye Joe

#------------------------------------------------------------------
''' Math Protocol:
To allows prefix and infix syntax for mathematic operations,
  Python provides the following special methods.

unary:              -  __neg__      +  __pos__      abs()  __abs__

compartison:        <  __lt__       <= __le__       ==  __eq__
                    != __ne__       >  __gt__       >=  __ge__

arithmetic:         +  __add__          -  __sub__          *  __mul__
                    /  __truediv__      // __floordiv__     %  __mod__
                    divmod()  __divmod__        round()  __round__
                    ** or pow()  __pow__

reversed arithmetic:  __radd__      __rsub__       __rmul__      __rmod__
                      __rtruediv__  __rfloordiv__  __rdivmod__   __rpow__

in place arithmetic:  +=  __iadd__       -=  __isub__       *=  __imul__
                      /=  __itruediv__   //= __ifloordiv__  %=  __imod__
                      **=  __ipow__

bitwise:              ~  __invert__     &  __and__      |  __or__
                      ^  __xor__        << __lshift__   >> __rshift__

reversed bitwise:   __rlshift__    __rrshift__   __rand__   __rxor__   __ror__

in place bitwise:   &=  __iand__        |=   __ior__        ^=  __ixor__
                    <<= __ilshift__     >>=  __irshift__                    '''
class A:
    def __init__(self, x):
        self.x = x
    def __add__(self, b):
        return self.x + b             ## arithmetic
    def __radd__(self, b):
       return self.x + b              ## reversed arithmetic
    def __iadd__(self, b):
        self.x += b;
        return self.x                 ## inplace arithmetic
    def __neg__(self):
        return -self.x                ## unary
    def __lshift__(self, n):
        return self.x << n            ## bitwise
    def __lt__(self, d):              ## compare
        return self.x < d.x

a = A(0)
# print(a + 1)            ## 1          __add__(a, 1)
# print(1 + a)            ## 1          __radd__(a, 1)
# a += 1;                 ##            __iadd__(a, 1)
# print(-a)               ## -1         __neg__(a)
# print(a << 1)           ## 2          __lshift__(a, 1)
# print(A(1) < A(2))      ## True       __lt__(A(1), A(2))

''' If __iadd__() is not implemented, += falls back to __add__ if available. '''

class A:
    def __init__(self, x):
        self.x = x
    '''
    def __iadd__(self, other):        ## in-place add
        self.x += other.x
        return self
    '''
    def __add__(self, other):
        return A(self.x + other.x)

a1, a2 = A(1), A(2)
a1 += a2
# print(a1.x)         ## 3

#----------------------------------------------------------------------

''' Coercion Protocol:
When a boolean value is needed from an object, its __bool__() is executed. '''
class A:
    def __init__(self, x):
        self.x = x
    def __bool__(self):
        return False if self.x == 0 else True

# print(bool(A(0)), bool(A(1)))       ## False True
# if A(123):
#     print('Hello')                  ## Hello

#-----------------------------------------------------------------

''' String Protocol:
Python has str() and repr() to convert an object into a str.
The class 'object' has default implementation of __repr__() and __str__()
  that return the class name and address as str. '''
class A:
    def __init__(self, x):
        self.x = x

a = A(1)
# print(str(a))   ## <__main__.A object at 0x0000019DCAABC110>
# print(repr(a))  ## <__main__.A object at 0x0000019DCAABC110>

''' Class 'str' also has implemenmtation of __repr__() and __str__(). '''
# print(str('Hello'))      ## Hello
# print(repr('Hello'))     ## 'Hello'

''' str VS repr
__str__()   returns a str that should bw viewed by programmers.
__repr__()  returns a str that should bw viewed by users.       '''
class A:
    def __str__(self):
        return '__str__()'

    def __repr__(self):
        return '__repr__()'

a = A()
# print(str(a))               ## __str__()
# print(repr(a))              ## __repr__()

''' Formatted with format():
     {!s}    -->  str()
     {!r}    -->  repr()        '''
# print('{!s}, {!r}'.format(a, a))    ## __str__(), __repr__()

''' Formatted with %
     %s    -->  str()
     %r    -->  repr()      '''
# print('%s, %r' % (a, a))            ## __str__(), __repr__()

#-------------------------------------------------------------------------

''' Hashable Protocol
A class is 'hashable' if its objects has hash() that return a 'hash' value (int).
Class 'object' has hash() returns a random integers. '''
a, b = object(), object()
# print(hash(a), hash(b))         ## -2147019034 464388

''' Immutable Primitive Types have hash() that returns the object's state.
        e.g. int.      '''
i = 1
# print(hash(i), hash(i))         ## 1 1

''' Class 'str' has hash() returns the hash (int value) of its state.
s = 'Hello'
print(hash(s), hash(s))

## A class is 'hashable' if it is immutable and implements the following:
    __hash__() returns an integer that is the hash value of the object.
    __eq__() for comparing its value to the other object value.
The choices of computing hash is depended on implementations.
Two objects are equal if they have the same hash value but the reverse may not be true. '''
class A:
    def __init__(self, x):
        self.x = x
    def __hash__(self):
        return self.x
    def __eq__(self, other):
        return self.x == other.x
# print(hash(A(0)), hash(A(1)), hash(A(1)))    ## 0 1 1

''' To test if an object is hashable. '''
from collections.abc import Hashable
# print(isinstance(A(0), Hashable))       ## True

def is_hashable(obj):
    return isinstance(obj, Hashable)

''' Immutable types(e.g. bool, int, float, str, and tuple) are hashable. '''
# print(is_hashable(False), is_hashable(1), is_hashable(1.0), \
#       is_hashable('Hello'), is_hashable((1,2)))     ## True True True True True

''' Mutable types(e.g. list, set, and dict) are not hashable. '''
# print(is_hashable([]), is_hashable({1}), is_hashable({'x': 1}))  ## False False False

''' Dict's keys must be hashable. '''
def hash_key():
    d = dict()
    d[A(1)] = 'Hello'
    print(d[A(1)])         ## Hello
    ## Try: comment  __hash__() or __eq__() in class 'A'.
# hash_key()

''' Set members must be hashable, so set cannot be member of a set.
'frozenset' is immutable and hashable.  '''

#------------------------------------------------------------------------------

''' Indexable Protocol
A class is 'immutable indexable' if it has
    __getitem__(self, <position>) returns the element at <position>.

An indexable object can be:
    1. Indexed:  <obj>[<index>]   -->   __getitem__(<obj>, <index>)
    2. Sliced:   <obj>[<start>:<stop>:<step>]
    3. Iterated by 'for', comprehension and factory.
    4. Member testing with 'in'.
    5. Sort:    sorted()

Ex. Class 'Names' is immutable indexable.            '''
class Names:
    _n = ['John', 'Jack', 'Joe', 'Jame', 'Jim']
    def __getitem__(self, pos):
        return Names._n[pos]

''' Indexing and Slicing '''
n = Names()
# print(n[0])       ## John
# print(n[1::2])    ## ['Jack', 'Jame']

''' An indexable can be iterated by 'for' and comprehension. '''
# for x in n:
#     print(x, end=', ')      ## John, Jack, Joe, Jame, Jim,
# print()
# print([x for x in n])   ## ['John', 'Jack', 'Joe', 'Jame', 'Jim']

''' An indexable can be converted to list, tupel or set by the class factory. '''
# print(list(n))          ## ['John', 'Jack', 'Joe', 'Jame', 'Jim']
# print(tuple(n))         ## ('John', 'Jack', 'Joe', 'Jame', 'Jim')
# print(set(n))           ## {'Jim', 'Joe', 'John', 'Jame', 'Jack'}

''' The operator 'in' causes __contains__() to be executed.
But if the class has no __contains__(), it is performed by iterate checking.
So an indexable can be applied with 'in'.    '''
# print('Jack' in n)      ## True

''' An indexable can be sorted(). '''
# print(sorted(n))        ## ['Jack', 'Jame', 'Jim', 'Joe', 'John']

#--------------------------------------------------------------------

''' A class is 'mutable indexable' if it has __getitem__() and
     __setitem__(self, <position>, <value>)  for set <value> at <position>.
They are mutable which can be used in the left side of assignment. '''
class MutableNames(Names):
    def __setitem__(self, pos, value):
        Names._n[pos] = value

mn = MutableNames()
mn[2] = 'Jody'
# print(list(mn))   ## ['John', 'Jack', 'Jody', 'Jame', 'Jim']

''' An 'indexable sequence' may be immutable or mutable indexable but have:
       __len__(self)  return the number of elements in the object.
An indexable sequence can be
   - reversed()  A method of class 'list'.
   - choice() A function in package 'random'.   '''

class NamesSequence(Names):
    def __len__(self):
        return len(Names._n)

ns = NamesSequence()
# print(list(reversed(ns))) # ['Jim', 'Jame', 'Joe', 'Jack', 'John']
import random
# print(random.choice(ns))  # Jack

#----------------------------------------------------------------------

''' Iterable Protocol
A class is 'iterable' if it has:
        __iter__()   returns an iterator.
            iter(<iterable>)  ->  __iter__().

Ex. 'str' is iterable. It has a built-in iterator which is handled
  internally by 'for' loop and comprehension. '''
# print([c for c in 'Hello'])     ## ['H', 'e', 'l', 'l', 'o']

''' Ex. 'list' and 'range' are also iterable. '''
# print([c for c in  ['a', 'b', 'c']])    ## ['a', 'b', 'c']
# print([i for i in  range(4)])           ## [0, 1, 2, 3]

''' An 'iterator' is an object that has __iter__() and also:
    __next__() returns a next element and raises StopIteration if no more.
            next(<obj>)   -->  __next__(<obj>)
      that was required for iterations.
So an iterator knows how to iterate its self or other.
Ex. We can manually iterate a str with its iterator. '''
def man_next():
    i = iter('Hello')   ## returns internal iterator of the str.
    while True:
        try:
            print(next(i), end=', ')  ## H, e, l, l, o,
        except StopIteration:
            break
    print()
# man_next()
''' An iterator is also iterable, but the reverse may not be true.
An 'iterator' can be next() but 'iterable' cannot.
Ex. str, lists and ranges are iterable but not iterator. '''
# next('Hello')                 ## error
# next([1, 2, 3])               ## error
# next(range(3))                ## error

''' We should never manually iterate an iterable since there may be
      optimizations for each kinds of iterable. '''

#--------------------------------------------------------------

''' Iterator Protocol
When an object is to be iterated:
 - If it has __iter__(), the iterator is obtained and used for iteration.
 - If no __iter__() but there is __getitem__(), an iterator is created
     and used for getting elements one at a time with __getitem__().
 - Else a TypeError is raised.
Therefore an indexable object is also iterable.

Ex. Create an iterator class that has __iter__() and __next__ ().  '''
class A:
    def __init__(self, a):
        self.a = a
        self.index = 0
    def __iter__(self):
        return self
    def __next__(self):
        try:
            i = self.a[self.index]
        except IndexError:
            raise StopIteration()
        self.index += 1
        return i

a = A([1, 2, 3])
# print([x for x in a])       ## [1, 2, 3]

''' Once the instance is iterated, it run out its elements. '''
# print([x for x in a])       ## []

''' Nest iterations on the same object would have unexpected result. '''
a = A([1, 2, 3])
# print([(x,y) for x in a for y in a])    # [(1, 2), (1, 3)]

''' To prevent the problem, an iterable object may delegate
      the iterator task to other object.

Ex. Class 'A' does not have __next__() so it is iterable and delegates
       its iterator task to AIterator. '''
class A:
    def __init__(self, a):
        self.a = a
    def __iter__(self):
        return AIterator(self.a)

''' AIterator knows how to iterate(with next()) objects of class 'A'. '''
class AIterator:
    def __init__(self, a):
        self.a = a
        self.index = 0
    def __next__(self):
        try:
            i = self.a[self.index]
        except IndexError:
            raise StopIteration()
        self.index += 1
        return i
    def __iter__(self):
        return  self   ## To conform the 'iterable' protocol.

a = A([1, 2, 3])
# print([(x, y) for x in a for y in a]) ## Each loop has it own iterator.
    ## [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)]

''' If not serious we can alternatively use indexable as iterable.
That is good enough even for nest iterations but inefficent. '''
class A:
    def __init__(self, a):
        self.a = a
    def __getitem__(self, index):
        # print('__getitem__')   ## Try: uncomment this line.
        return self.a[index]

a = A([1, 2, 3])
# print([(x, y) for x in a for y in a])
    ## [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)]

''' Alternatively instead of delegate iterator to other object(ex. AIterator)
__iter__() can returns a generator.
Since next() can also be applied to a generator and gets result from 'yield'. '''
class A:
    def __init__(self, a):
        self.a = a
    def __iter__(self):
        for i in self.a:
            yield i

a = A([1, 2, 3])
# print([(x, y) for x in a for y in a])
    ## [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)]

'''  But each next() cause resume and suppend the execution of __iter__()
       just to get a value, that is a lot of wastes.
So so alternatively __iter__() may return a generator expression (a comprehension
  enclosed with ()) which results a generator object.
The __iter__() is called only once and returns the generator object.
Then each next() causes the generator object to fetch element from the list to be
   iterated(that is 'a').   '''
class A:
    def __init__(self, a):
        self.a = a
    def __iter__(self):
        return (i for i in self.a)

a = A([1, 2, 3])
print([(x, y) for x in a for y in a])
    ## [(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)]

''' Examples of iterable objects:
zip() returns a zip object which is iterable.
Zip objects allows iterating over multiple sequences in parallel. '''
# print([x for x in zip([1, 2, 3], ['John', 'Jack', 'Joe'])])

''' open() returns an iterable generator. '''
# for line in open(__file__): print(line, end='')

''' map() returns an iterable generator. '''
# print([x for x in map(lambda n : n*n, [1, 2, 3])])
