''' Methods are members of class/object that can be invoked as <obj>.<method>().
Methods are similar to functions but not the same.
'self' is the predefined reference to the object.

There are three kinds of methods:
1. 'Class Methods' are belong to a class (created in the class namespace).
    - Calling via the class name.
    - No 'self' as a parameter.             '''
class A:
    def hello(n):
        print('Hello', n )

    ''' Alternatively, a class method is annotated with @classmethod.
    'cls' musbet  the first parameter.
    'cls' is the predefined reference to the 'class object' of the class.  '''
    @classmethod
    def hi(cls, name):
        print('Hi', name)

# A.hello('John')                 ## Hello John
# A.hi('Jack')                    ## Hi Jack

''' All methods are implemented as functions.
Compilers convert 'class method' calls by passing the class as the first argument.
    <class>.<method>(<arguments>) -> <method>(<class>, <argument>)
  e.g.
     A.hello('John')   -> hello(A, 'John')

2. 'Object Methods' are belong to an object (created in the object namespace).
    - Calling via the object.
    - Must have 'self' as the first parameter.   '''
class B:
    def hello(self, n):
        print('Hello', n)

b = B()
# b.hello('John')         ## Hello John

''' 3. 'Static Methods' do not belong to a class nor an object.
    - Calling via the class name.
    - no 'self' nor 'cls' as the first parameter.
    - annotated with @staticmethod.
Static methods are not considered members but go with the class.

Ex. A boundary class is used for grouping relelated members,
      not representing an object.       '''
class MyMath:
    @staticmethod
    def sq(x):
        return x * x

# print(MyMath.sq(2))         ## 4
''' Python allows accessing static methods via object. '''
# print(MyMath().sq(3))       ## 9

''' Python does not support 'method overloading' which is defining methods
  with the same name but different parameters in the same scope.  '''
def met_shadow():
   class A:
      def f(self):
         print('f(self)')

      ''' Redefining method with the same name is shadowing which overrides
        the existing one and only the newest one is valid.'''
      def f(self, x):
         print('f(self, x)')
   a = A()
   # print(dir(a))      ## There is only one 'f'.
   # a.f()              ## error
   a.f(1)               ## f(self, x)
# met_shadow()

#-----------------------------------------------------------------

''' 'Attributes' are data members of class/object.
Like methods, attributes are accessed via dot syntax.
Methods and attributes are kept in the class/object namespace, so their
  names should be different.
There are two kinds of attributes.

1. 'Class Attributes' are belong to class.
    - Defined in the class scope and created in the class namespace.
    - Accessed via the class.  '''
class A:
    x = 1
    def f():
        print(A.x)  ## The namespace must be explicit.
# print(A.x)      ## 1

''' 2. 'Object Attributes' are belong to an object.
    - Defined with 'self' in the object method.
    - Accessed via the object reference or 'self'.
That is why 'self' must be passed to 'object methods'. '''
class A:
    # self.x = 0     ## error: no 'self' in the class scope.
    def set_x(self, x):
        self.x = x
    def get_x(self):
        return self.x
a = A()
a.set_x(1)
# print(a.get_x())            ## 1

#---------------------------------------------------------------

''' Members Modification
Class/Object members are stored in the class/object dict which is mutable.
So they can be changed at runtime.          '''
def member_mod():
    class A:
        pass
    class B:
        def hello(self):
            print('Hello')

    def hi():
        print('Hi')

    ''' Create an empty object 'a'. '''
    a = A()

    ''' Add data member'x' to object 'a'. '''
    a.x = 1
    print(a.x)        ## 1

    ''' Add an object method to be member of object 'a'. '''
    a.greet = B().hello     ## A method must be assigned with a method.
    a.greet()         ## Hello

    ''' Add class method to be member of class 'A'. '''
    A.hi = hi   ## A class method is a function must be assigned with a function.
    A.hi()            ## Hi
# member_mod()

''' Advices:
1. Objects of the same class may be different and cannot be used in the same way.
2. Classes should be modified by creating a new class with subclassing, not by
     modifying the existing class.
3. Object states should be initialized when the object is created.

Python classes provide initialization method:
               __init__(self, <args>)
<args> are values passed to be initial state of the created object.
__init__() cannot be overloaded and should never be called explicitly,
  it will be called implicitly when the object is created with <class name>(<arg>). '''
class A:
    def __init__(self, x, y):
        self.x = x
        self.y = y
a = A(1, 2)
# print(a.x, a.y)         ## 1 2
