''' Class extensions define relationship between child and parent classes.
           class <name>(<parent classes>, <meta class>):
               <body>
If no <parent  classes>, it is given <class 'object'> by default.
<class 'object'> is the top most class of all classes.
<parent classes> may be more than one. Python allows multiple inheritance.
<meta class> defines how to create an object of the class, it is optional
  if not defined the <class 'object'> is used by default. '''
class A:
    pass
class B(A):
    pass
''' All classes have an attribute __base__ which is the parent class object. '''
# print(A.__base__.__name__)       ## object
# print(B.__base__.__name__)       ## A

''' isintance(<obj>, <class>) returns True if <obj> is an object of or
      descendant of the <class>.  '''
class C(B):
    pass
a, b, c = A(), B(), C()
# print(isinstance(a, A), isinstance(b, A), isinstance(c, A))
               ## True True True

''' Child classes 'inherite' members from its parent class. '''
class A:
    '''A Doc String'''
    a = 'class attribute'
    def __init__(self):
        print('A.__init__()')
        self.x = 'object attribute'

    @property
    def p(self):
        print('property')
        return 0

    @classmethod
    def cls_method(cls):
        print('class method')

    def obj_method(self):
        print('object method')

    @staticmethod
    def sq(n):
        print('static method', n*n)

def inherit():
   class B(A):
      pass

   print(B.__doc__)      ## None           !! Doc string is not inherited.
   print(B.a)            ## class attribute
   B.cls_method()        ## class method
   B.sq(2)               ## static method 4

   b = B()               ## A.__init__()   !! chained
   b.obj_method()        ## object method
   print(b.x)            ## object attribute
   print(b.p)            ## property  0
# inherit()

''' 'Overriding' allows creating a child class that modifies inherited members. '''
def override():
   class C(A):
       '''C Doc String'''
       a = 'C class attribute'
       def __init__(self):
           print('C.__init__ ')
           self.x = 'C object attribute'
       @property
       def p(self):
           print('C property')
           return 10
       @classmethod
       def cls_method(cls):
           print('C class method')
       def obj_method(self):
           print('C object method')
       @staticmethod
       def sq(n):
           print('C static method', n*n)

   print(C.__doc__)      ## C Doc String
   print(C.a)            ## C class attribute
   C.cls_method()        ## C class method
   C.sq(2)               ## C static method 4

   c = C()               ## C.__init__
   print(c.x)            ## C object attribute
   c.obj_method()        ## C object method
   print(c.p)            ## C Properties 10
# override()

#--------------------------------------------------------------------
''' Java 'super' is a predefined reference for accessing overriden members,
      but Python 'super' is a class which an object of class 'type'. '''
# print(type(super))     ## <class 'type'>

''' The class 'super' is callable, it can be called like a function.
super() returns an object to access the superclass of the 'self' object.
But super() is allowed be called only in scopes that contain 'self'. '''
class A:
    def f(self, name):
        print('Hello', name)
class B(A):
    def f(self, name):
        super().f(name)
    def g(name):
        super().f(name)     ## error: no 'self' here.

# B().f('John')             ## Hello John
# B.g('John')               ## error

''' Valid uses of super():
1. Method Extending.
Overriding modifies the whole method with a new one.
Extending extends the inherited method with extra actions.  '''
class A:
    def f(self):
        print('A.f')
class B(A):
    def f(self):        ## overriding
        print('B.f')
class C(A):
    def f(self):        ## extending
        super().f()
        print('C.f')

# B().f()             ## B.f
# C().f()             ## A.f
                      ## C.f

''' 2. Passing parameters to superclass's __init__().
In C++ and Java, when an object is created there is a machanism to pass parameters
  to superclass constructors for initialization chain.
C++ and Java support automatic initialization chain, but Python does not.

'Initialization Chain' is a mechanism to guarantee that when a descendant class
  is created all the ancestor class constructors are activated from top down.

Initialization chain is not mandatory in Python.
Descendant classes may explicitly pass parameters to superclass if needed and
  super() need not to be the first statement in __init__().
Initialization chain is a good practice, so most Python Descendant classes
  call super().__init__() explicitly.  '''
class A:
    def __init__(self, msg):
        print(msg, end=', ')
class B(A):
    def __init__(self):
        super().__init__('Hello')   ## Try: comment this line
        print('Bye')
# B()                    ## Hello, Bye

''' A subclass should take care of attribute initialization in its own,
      and use super() to pass initial values to its superclass. '''
class Student:
    def __init__(self, _id, name):
        self.id = _id
        self.name = name
class GradStudent(Student):
    def __init__(self, _id, name, thesis):
        super().__init__(_id, name)
        self.thesis = thesis

g = GradStudent(2, 'Jack', 'oop')
# print(g.id, g.name, g.thesis)       ## 2 Jack oop

''' 'Multiple Inheritance' is class extension that allows a class
  to have more than one parent classes.
That simplies class designing but may cause a lot of problems.
Java and many others do not allows multiple inheritance, but Python allows.  '''
class A:
    def f(self):
        print('A.f')
class B:
    def f(self):
        print('B.f')
    def g(self):
        print('B.g')
class C(A, B):
    pass
c = C()
# print(isinstance(c, A), isinstance(c, B))   ## True True
# c.f()                                       ## A.f  ????
# c.g()                                       ## B.g

''' Java would have problems resolving which f() is in c.f().
Python performs searching for inherited names in the 'method resolution order'
  (mro) which is defined as the built-in __mro__.
The order may be simplified as 'top-down' and 'left-right'.  '''
class A:
    def f(self):
        print('A.f')
class B(A):
    def f(self):
        print('B.f')
class C(A):
    def f(self):
        print('C.f')
class D(B, C):          ## Try: D(C, B):
    pass
# D().f()               ## B.f
# print([x.__name__ for x in D.__mro__])
                        ## ['D', 'B', 'C', 'A', 'object']
''' Advices:
Extension is good for 'is-a' relationship.
Composition is better for 'has-a' relationship but less expensive.
Both can be used for 'code reuse' but composition is safer. '''
class A:
    def f(self):
        print('A.f')
class B:
    def g(self):
        print('B.g')
class C:                    ## composition
    def __init__(self):
        self.a = A()
        self.b = B()
    def f(self):
        self.a.f()
    def g(self):
        self.b.g()
class E(A, B):              ## extension
    pass

# c = C(); c.f(); c.g()
# e = E(); e.f(); e.g()

''' Python may create a class from other class members, called 'sharing'. '''
class A:
    def f(self):
        print('a.f()')
class B:
    x = 1
    def g():
        print('B.g()')
''' Without extension nor composition '''
class C:
  f = A.f
  x = B.x
  g = B.g

# C.g()             ## B.g()
# print(C.x)        ## 1
c = C()
# c.f()             ## a.f()
#-------------------------------------------------------------------

''' 'Protocol' is an aspect of 'type'.
Java has 'interfaces' for to define protocols(or types).
Interface allows creating:
   - Specification of classes.
   - Multiple types classes.

Python does not have interfaces and not support polymorphism (in the oop sense).
Since a Python identifier can be bound to values of any types.

Duck Types: "Anything that quacks as a duck can be used as a duck".
If an object can perform in a certain context that is good enough
  without having to conform to a certain protocol.  '''
class A:
    def f(self):
        print('A')
class B:
    def f(self):
        print('B')

def test(x):     ## x can be an instance of any class that has f().
    x.f()

# test(A())   ## A
# test(B())   ## B
