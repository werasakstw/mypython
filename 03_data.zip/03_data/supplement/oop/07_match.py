''' Python 3.10 introduces 'match' for decision.
            match <expression>:
                case <pattern_1>:
                    <action_1>
                case <pattern_2>:
                    <action_2>
                case _:
                    <default action>
The <expression> is evaluated, then the result is matched with <pattern>,
  if match the <action> is executed,
  if no matchs the <default action> is executed.
Unlike 'switch' in C and Java, 'match' offers more capabilities.

1. Match with literals:
'match' is an expression that returns a value.
<action> of the matched case returns the result of the 'match' expression. '''
def match_literal():
    def switch(x):
        match x:
            case x if x < 0:           ## guard if
                return 'negative'
            case 0:
                return 'zero'
            case 1:
                return 'one'
            case 2 | 3:                 ## OR
                return 'few'
            # case _:                   ## wildcard is optional.
            #     return 'many'

    print(switch(-1))   ## negative
    print(switch(1))    ## one
    print(switch(3))    ## few
# match_literal()

''' 2. Match with tuple
'match' may be used as statement if no returned value.    '''
def tuple_match():
    def point_match(point): ## 'point' is a (x,y) tuple.
        match point:
            case (0, 0):
                print('Origin')
            case (0, y):
                print('Y =', y)
            case (x, 0):
                print('X =', x)
            case (x, y):
                print(f'X = {x}, Y = {y}')
            case _:
                print('Not a point')

    point_match((0,0))       ## Origin
    point_match((0,1))       ## Y = 1
    point_match((2,0))       ## X = 2
    point_match((3,4))       ## X = 3, Y = 4
# tuple_match()

''' 3. Match with object '''
def obj_match():
    class Point:
        def __init__(self, x, y):
            self.x = x
            self.y = y

    def point_match(point):  # 'point' is object of class Point.
        match point:
            case Point(x=0, y=0):
                print('Origin')
            case Point(x=0, y=y):
                print(f'Y={y}')
            case Point(x=x, y=0):
                print(f'X={x}')
            case Point():
                print('Any point')
            case _:
                print('Not a point')
    point_match(Point(x=0, y=0))    # Origin.
    point_match(Point(x=0, y=1))    # Y=1
    point_match(Point(x=2, y=0))    # X=2
    point_match(Point(x=3, y=4))    # Any point
    point_match('Point')            # Not a point
# obj_match()

''' 4. Match to collections '''
def collections_match():
    def col_match(c):
        match c:
            case []:
                print('Empty list')
            case [a]:
                print(f'One elements list: {a}')
            case [a, b]:
                print(f'Two elements list: {a}, {b}')
            case (x,y,z):
                print(f'tuple: {x}, {y}, {z}')
            case {'name': n}:
                print(f'name: {n}')
            ## Set patterns are not allowed.
            ## List and tuple patterns must have different number of elements.
    col_match([])                   ## Empty list
    col_match([1])                  ## One elements list: 1
    col_match([1, 2])               ## Two elements list: 1, 2
    col_match((1,2,3))              ## tuple: 1, 2, 3
    col_match({'name': 'john'})     # name: john
# collections_match()

''' 5. Match to enum '''
def enum_match():
    from enum import Enum
    class Color(Enum):
        RED = 0
        GREEN = 1
        BLUE = 2
    def e_match(e):
        match e:
            case Color.RED:
                print('red')
            case Color.GREEN:
                print('green')
            case Color.BLUE:
                print('blue')

    e_match(Color.RED)      # red
# enum_match()
