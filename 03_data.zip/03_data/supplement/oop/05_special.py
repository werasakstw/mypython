''' Names that begin and end with double underscores, e.g. __x__
     is called under-under-x, dunder-x, magic-x or special-x.
Special names have special meaning and supposed to be used by knowledgeable
 programmers with really good reasons only.
Mere mortals should never mangle with special names.
Ex.  __eq__()       '''
class A:
    def __init__(self, x):
        self.x = x
    def is_equal(self, obj):
        print('is_equal()')
        return self.x == obj.x
    def __eq__(self, obj):     ## special method
        print('__eq__()')
        return self.x == obj.x

a1, a2 = A(1), A(1)
# print(a1.is_equal(a2))        ## is_equal()    True
# print(a1 == a2)               ## __eq__()      True
'''  == is the infix syntax for activate __eq__(). '''

''' Expressions have 3 syntax:
      1. Postfix      <class|object>.method(<argument>)
      2. Prefix       function(argument)
      3. Infix        operand <operator> operand
They are equally expressive. Preference is ่just the choices of aesthetics.
Python makes decision that:
  Postfix should be hidden and used exclusively by high-end programmers.
  Prefix and Infix are for non-professional programmers.

Python is a big and complicated language but be carefully designed to hide
  complex features under 'surface syntax'.
Special name is one of the mechanism.
    ex. the following objects have special methods.
string                __repr__  __str__  __format__
numbers               __abs__  __bool__  __complex__  __int__  __float__  __hash__   __index__
collections           __len__  __getitem__  __setitem__  __delitem__  __contains__
iteration             __iter__  __reversed__  __next__
callables             __call__
context management    __enter__  __exit__
creation destruction  __new__  __init__  __del__
attribute management  __getattr__  __getattribute__  __setattr__  __delattr__  __dir__
attribute descriptors __get__  __set__  __delete__
class services        __prepare__  __instancecheck__  __subclasscheck__

Special Name Benefit:
1. Provides infix/postfix and consistency usages for popular features.
Mapping from infix/postfix operations to special methods are done at compile
  time, no extra overheads at runtime.

2. Allows optimization
Ex. len(<obj>) returns the length of <obj>.
It is a built-in function that normally converted to calling __len__(<obj>).
But Python compiler may decise what to do according to the type of <obj>. e.g. if
 the type has its length stored in the object, the value is just returned without
 calling to __len__().
Calling len() instead of __len__() is more readable and sometime more efficient. '''
class A:
    def __len__(self):
        return 100

# print(len(A()))              # 100

''' 3. Standardized action name for predictable and consistent usage.
That make the language simple and uses less learning time.

4. Establish protocols. To make a class conforms to a protocol, just implements
  special methods of the protocol.

Ex. 'in' is an operator for member testing.
        <obj1> in <obj2>  is mapped to    __contains__(<obj1>, <obj2>)
Any classes that implements __contains__() can be used with 'in'.  '''
class A:
    def __contains__(self, x):
        return 0 < x < 10

# print(1 in A())                 ## True

''' 5. Hides complicated mechanism of the language.
Ex. Creating an object with <class>() cusing activation of __init__().
There are extra steps before __init__(). e.g. __call__ and __new___.  '''
class A:
    def __init__(self, x, y):
        print('__init__()')
        self.x, self.y = x, y

# a = A(1, 2)           ## __init__()
# print(a.x, a.y)       ## 1 2

''' 6. Hides attributes of classes/objects that users do not need to know.
Ex. All objects has a __dict__ to hold its namespace.
dir(<obj>) returns a list of names in __dict__ that are inherited names to the class. '''
class A:
    x = 1
    def f():
        pass

# print(A.__dict__)   ## a dict
# print(dir(A))       ## a list


''' 7. Defining methods for infix expressions.
Ex.      x + y -->  x.__ add__(y)    '''
class A:
    def __init__(self, x):
        self.x = x
    def __add__(self, b):
        return self.x + b.x

a1, a2 = A(1), A(2)
# print(a1 + a2)          ## 3

''' It is the developer responsibility to spend extra hard efforts
 just to make the users a little bit happier. '''
