''' Python does not support 'information hiding' (in oop sense).
Class/object members are public and cannot be private.
    "Pushing more work done is better than spending effort hiding somethings".

In the old time, there is a convention that names begin with _ are supposed to be
  used locally. Python does not enforce this convention.
But Python provides 'name mangling', that means names begin with __ are not normally
  accessible via object or class.  '''
class A:
     __x = 0
     def __init__(self, y, z):
         self._y = y
         self.__z = z
     def __f(self):
         print('Hello')
# print(A.__x)            ## error
a = A(1,2)
# print(a._y)             ## 1
# print(a.__z)            ## error
# a.__f()                 ## error

''' That does not make the __<name> private.
Since they are created with _<class name> prefixed and can be accessed normally. '''
# print(A._A__x)           ## 0
# print(a._A__z)           ## 2
# a._A__f()                ## Hello

''' Another 'name mangling' is a global name that defined as:
          _<class>__<name>
Would be accessible in the <class> scope with __<name>.
The name is intended to be used in the <class> exclusively. '''
_A__x = 123
def _A__hello():
    print('Hello')
class A:
    def test():
        print(__x)     ## 123
        # __hello()      ## Hello
# A.test()

#-----------------------------------------------------------------
''' Getter/Setter
Most OO languages encapsulate data with getter/setter methods which
  allow decoupling data representation and access control.
'getter/setter' can be implemented in Python classes as normal methods. '''
class A:
    def __init__(self, x):
        self.x = x
    def set_x(self, x):
        self.x = x
    def get_x(self):
        return self.x

a = A(0)
a.set_x(1)
# print(a.get_x())     ## 1

''' 'getter/setter' does not prevent accessing attributes directly. '''
a.x = 2
# print(a.x)           ## 2
#-------------------------------------------------------------------

''' 'Property' are methods that can be used with dot syntax, not method calling.
Property is not for encapsulation, but to:
    - hide the postfix syntax.
    - add action injection.
Action injection means performing something when an attribute is accessed.
That allows implementing access policy and access event handling.

Properties can defined with:
1. Using property():  the old style.
    <property> = property(<fget>=None, <fset>=None, <fdel>=None, <doc>=None)
<fget> and <fset> are getter/setter of the <property>.
<fdel> is executed when the <property> is deleted.
<doc> is the <property> string doc.
Instead of set() and get(), naming on_read() and on_write() would be more meaningful. '''
class A:
 ''' Property names must be different from class and object attributes.
 So the object attribute e.g. '_x' is usual be prefixed. '''
 def on_read(self):
     print('on_read()')
     return self._x

 def on_write(self, x):
     print('on_write()')
     self._x = x

 def on_del(self):           ## optional.
     print('on_del()')
     del self._x

 x = property(fget=on_read, fset=on_write, fdel=on_del)

'''' Now the property 'x' can be accessed as an attributes, not a method.
And can be on the left side of assignment. '''
a = A()
# a.x = 1            ## on_write()
# print(a.x)         ## on_read()  1

''' But 'property' does not encapsulate, since _x is still accessible. '''
a._x = 2
# print(a._x)       ## 2

''' Property does not prevent postfix syntax, a.on_write() and a.on_read() are still usable. '''
# a.on_write(3)               ## on_write()
# print(a.on_read())          ## on_read()

''' on_del() is activated when the object is deleted. '''
# del(a.x)                    ## on_del()

''' 2. Using Decorators:
        @property       to annotate getter
        @<name>.setter  to annotate setter
        @<name>.deleter to annotate deleter          '''
class A:
 @property
 def x(self): 	          ## x become the getter
     print('on_read()')
     return self._x

 @x.setter
 def x(self, x):           ## x become the setter
     print('on_write()')
     self._x = x

 @x.deleter
 def x(self):              ## x become the deleter
     print('on_del()')
     del self._x

a = A()
# a.x = 1                     ## on_write()
# print(a.x)                  ## on_read()     1
''' But a.x(1) and a.x() are not allowed. '''
# del a.x                     ## on_del()

''' Property allows using attribute that does not directly exist.
A 'backup property' has attribute that stores the state.
A 'computed property' is computed from other values.
Mostly computed properties are read-only. '''

#-------------------------------------------------------------

''' Memory Concern:
Objects store attributes in a dict, which have memory overhead
  for the mutability and underlying hash table.
Python allows objects to use tuple for storing attributes.
If __slots__ is assigned with a tuple of attribute names, the class
  will used a tuple to store attributes instead of a dict.
A class with slots must be defined at top-level scope. '''
class A:
   __slots__ = ('x', 'y')
   def __init__(self, x, y):
      self.x, self.y  = x, y

a = A(1, 2)
# print(a.x, a.y)      # 1 2

####################################################################

''' Ex. Class 'Circle' does not have attribute 'area' but computes from 'radius'.
The property 'area' is read-only because there is only the getter. '''
import math
class Circle():
   def __init__(self, radius):
      self.radius = radius

   @property
   def area(self):
      return math.pi * (self.radius ** 2)
# print(Circle(10).area)      ## 314.1592653589793
