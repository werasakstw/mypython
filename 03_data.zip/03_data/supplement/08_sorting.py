''' Sorting
1. No side effect sorting with sorted() which is a built-in function that
     always returns a list.
Ordered sequences e.g. str, list tuple can be sorted(). '''
# print(sorted('hello'))      ## ['e', 'h', 'l', 'l', 'o']
# print(sorted((2, 1, 3)))    ## [1, 2, 3]

''' A list of lists or tuples is sorted with the first element as key. '''
a = [(3, 'john'), (1, 'jim'), (2, 'jack')]
# print(sorted(a))    ## [(1, 'jim'), (2, 'jack'), (3, 'john')]

''' 'key' argument specifies the function to be used for comparison.
                key=<function>
<function> accepts a list/tuple and returns the element to be the key. '''
def get_key(item):
    return item[1]
# print(sorted(a, key=get_key))   ## [(2, 'jack'), (1, 'jim'), (3, 'john')]

''' Alternatively the key is given as a lambda. '''
# print(sorted(a, key= lambda item: item[0]))
                                ## [(1, 'jim'), (2, 'jack'), (3, 'john')]

''' sorted() has an argument 'reverese' to specify order. '''
# print(sorted([2, 1, 3], reverse=True))  ## [3, 2, 1]

''' But there is a built-in function reversed(<seq>) that returns
      a list of reversed order of <seg>. '''
# print(list(reversed('hello')))      # ['o', 'l', 'l', 'e', 'h']
# print(list(reversed((2, 1, 3))))    # [3, 1, 2]

#----------------------------------------------------------------

''' 2. Mutable ordered class e.g. 'list' has sort() for in-place sorting.
'str' and 'tuple' are immutable, 'set' and 'dict' are un-ordered. '''
a = [2, 1, 3]
a.sort()
# print(a)            ## [1, 2, 3]

''' The 'reverse' argument is supported. '''
a.sort(reverse=True)
# print(a)            ## [3, 2, 1]

''' But there is also reverse() in the class. '''
a.reverse()
# print(a)            ## [1, 2, 3]

''' A list of lists/tuples can be sort() with the first element as key. '''
a = [(3, 'john'), (1, 'jim'), (2, 'jack')]
a.sort()
# print(a)            ## [(1, 'jim'), (2, 'jack'), (3, 'john')]

''' 'key' argument specifies the function/lambda to select key. '''
a.sort(key = lambda item: item[1])
# print(a)            ## [(2, 'jack'), (1, 'jim'), (3, 'john')]

''' Dict Sorting
By default, dicts are sorted by key and results a list of keys. '''
print(sorted({'john': 2, 'jack': 1, 'joe': 3}))  ## ['jack', 'joe', 'john']

''' A list of dicts sorting needs 'key' argument to specify function/lambda
     to select key. '''
students = [{'name': 'John', 'gpa': 1.8},
            { 'name': 'Jack', 'gpa': 4.0},
            { 'name': 'Joe', 'gpa': 2.5}]
# print(sorted(students, key=lambda s: s['gpa']))
    ## [{'name': 'John', 'gpa': 1.8}, {'name': 'Joe', 'gpa': 2.5}, {'name': 'Jack', 'gpa': 4.0}]
