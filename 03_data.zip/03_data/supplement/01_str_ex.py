# Python string literals may be enclosed with:
# 	'           single quotes
# 	"           double quotes
# 	'''  """    triple single/double quotes
def quotes():
    print('Hello')
    print("Hello")
    print('''Hello''')
    print("""Hello""")

    ''' Single quotes and double quotes may be nested.  '''
    print('John said "Hello".')
    print("Jack said 'Hi'.")

    ''' Single/double quotes cannot contain <newline> nor <return>.
    Triple quotes may contain ' or ". '''
    print('''When I saw John yesterday.
He said "Hello". I said, 'Hi'.''')
# quotes()

''' 'str' factory creats a string with value form other types. '''
def str_factory():
    print(str())          ## empty str
    print(str(False))     ## 'False'
    print(str(True))      ## 'True'
    print(str(1))         ## '1'
    print(str(1.23))      ## '1.23'
# str_create()

''' String Operations '''
def str_op():
    ''' Conditional String '''
    print('Hello' if True else 'Hi')    ## Hello

    s = 'Hello'

    ''' Built-in functions'''
    print(len(s), min(s), max(s))    ## 5 H o

    ''' in  '''
    print('el' in s)                ## True

    ''' Find  '''
    print(s.find('el'))             ## 1

    ''' Startswith, Endswith  '''
    print(s.startswith('Hell'), s.endswith('lo')) ## True True

    ''' Occurance count  '''
    print(s.count('l'))             ## 2

    ''' Slice  '''
    print(s[1:3], s[1:], s[:3])     ## el ello Hel

    ''' Str to int  '''
    print(int('123'), int('10', 2), int('F', 16))  ## 123  2  15

    ''' Int to str '''
    print(bin(5), oct(8),hex(15) )      ## 0b101  0o10  0xf

    ''' <str>.strip(<chars>) removes characters from both ends of a string.  '''
    print(' Hello '.strip())            ## Hello
    print('...Hello.how.are.you?.......'.strip('.'))    ## Hello.how.are.you?

    ''' <str>.replace(<str1>,<str2>) replaces str1 with str2.  '''
    print('john jack joe'.replace('j', 'J'))    ## John Jack Joe

    ''' list -> str
    <separator>.join(<str list>) creates a string from <str list>.  '''
    a = ['a', 'b', 'c']
    print(', '.join(a))         ## a, b, c

    ''' join() only works with str.  '''
    a = [1, 2, 3]
    # print(', '.join(a))       ##  error
    print(', '.join(str(x) for x in a))   ## 1, 2, 3

    ''' str -> list
    <str>.split(<separator>) splits the <str> into a list of str.
    The default separator is a blank.  '''
    print('a,b,c'.split(','))           ## ['a', 'b', 'c']

    ''' Split with separator  '''
    x = '  a  b    c '
    print(x.split())        ## ['a', 'b', 'c']
    print(x.split(' '))     ## ['', '', 'a', '', 'b', '', '', '', 'c', '']

    ''' str -> str
    <str>.partition(<separator>) partitions the <str> into head, sep, and tail. '''
    head, separator, tail = 'John Jack Joe'.partition(' ')
    print([head], [separator], [tail])  ## ['John'] [' '] ['Jack Joe']
# str_op()

''' Strings may contain special characters, \<symbol>.
       e.g.  \',  \",  \\, \r (return),  \n (newline),
            \s (space), and \t (tab)
The special characters will be interpreted as is when displayed.  '''
# print('Hello\tJohn.')            ## Hello     John.

''' Raw String: is prefixed with r and the special characters are not interpreted. '''
# print(r'Hello\tJack.')           ## Hello\tJack.

''' 'string' lib: provides ready to use characters, digits and symbols.  '''
import string
def str_const():
    print(string.ascii_lowercase)
    print(string.ascii_uppercase)
    print(string.ascii_letters)
    print(string.digits)
    print(string.punctuation)
    print(string.whitespace)
    print(string.printable)
# str_const()

''' Handling Character Cases  '''
def cases():
    s = 'john jack joe'

    ''' <str>.capitalize() capitalizes only the first word. '''
    print(s.capitalize())  # John jack joe

    ''' <str>.title() capitalize all the words.  '''
    print(s.title())       ## John Jack Joe

    ''' <str>.upper() converts all characters to uppercase.  '''
    print(s.upper())       ## JOHN JACK JOE

    ''' <str>.lower() converts all characters to lowercase.  '''
    print('John Jack Joe'.lower())      ## john jack joe

    '''  <str>.swapcase() '''
    print('John Jack Joe'.swapcase())   ## jOHN jACK jOE
# cases()

''' Close Matching String  '''
from difflib import get_close_matches
def close_match():
    x = 'abc'
    y = ['aaa', 'bac', 'aac', 'xbc', 'bdca', 'abb']
    print(get_close_matches(x, y))
    print(get_close_matches(x, y, n=1))
    print(get_close_matches(x, y, cutoff=0.4))
    print(get_close_matches(x, y, cutoff=0.7))
# close_match()

########################################################################

''' Ex. Printing Multiplication Table. '''
def mul_table(n):
    for i in range(2, 13):
        print('%2d x %d = %4d' % (i, n, i*n))
# mul_table(2)
''' Exercises: Print all multiplication tables for n from 2 to 99.  '''

''' Ex. Table of Left Over Bread Prices:
Suppose the price of left over breads is 60% of the previous day
  and will throw away after the third day.
For breads that cost 50, 100, 200, and 300 on the first day,
 print the prices on each left over days.  '''
def left_over():
    for i in [50, 100, 200, 300]:
        print(i, end='\t')
        for j in range(3):
            i *= 0.6
            print('%.2f' % i, end='\t')
        print()
# left_over()

''' Ex. Pig Latin: A children's encryption.
         https://www.wikihow.com/Speak-Pig-Latin
  If a word begins with a vowel(a, e, i, o, u) add 'way' to the end.
  Else move the first character to the end then add 'ay'.  '''
def pig_latin(s):
    def encrypt(w):
        if w[0] in 'aeiou':
            return f'{w}way'
        return f'{w[1:]}{w[0]}ay'

    ''' str -> list '''
    en= [encrypt(w) for w in s.split(' ')]
    print(' '.join(en))                 ## list -> str
# pig_latin('Your kiss is sweet.')

''' Try: Handle capital letters at the beginning of statement.  '''

''' Exercises:
The United State banknotes in have images of famous presidents:
        George Washington  (gw)	 $1
        Thomas Jefferson   (tj)	 $2
        Abraham Lincoln    (al)	 $5
        Alexander Hamilton (ah)  $10
        Andrew Jackson	   (aj)  $20
        Ulysses S. Grant   (ug)  $50
        Benjamin Franklin  (bf)  $100

That allows encoding an integer value into a string by the rules:
        - 2 characters (of a president) represent an integer.
        - The result is summation of each values.
    There can be many ways to represent a value.
    e.g.   gwgwgw = 1 + 1 + 1 = tjgw = 2 + 1 = 3
               ah = gwgwgwgwgwal = altjgwtj = 5
    Write functions for:
            decode(<string>) -> <integer>
            encode(<integer>) -> <string>   for the shortest string
'''
