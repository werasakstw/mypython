''' Sets can be created directly with literal or set() factory. '''
# print(set('Hello'))               ## {'H', 'l', 'o', 'e'}
# print(set(range(3)))              ## {0, 1, 2}
# print(set( [1, 2, 1] ))           ## {1, 2}
# print(set( (1, 2, 1) ))           ## {1, 2}

''' Set can be a result of comprehension. '''
# print( {i for i in range(3)} )    ## {0, 1, 2}

''' Set does not support the repeat operation(*). '''
# print({True}*3)                   ## error

''' A comma after the last element is optional.
That allows listing each elements in a line with no , on the last.  '''
# print( {1, 2, 3,} )               ## {1, 2, 3}

''' Python supports both set methods and set operators.
      O(1) for membership tests.
      O(n) for union, intersection, difference, and subset operations. '''
a = {1, 2, 3}
b = {3, 4}
# print(a & b)    ## {3}              intersection()
# print(a | b)    ## {1, 2, 3, 4}     uion()
# print(a - b)    ## {1, 2}           difference()
# print(a ^ b)    ## {1, 2, 4}        exclusive()

''' Set comparision. '''
b = { 3, 1 }
# print(b <= a)    ## True            issubset()
# print(a >= b)    ## True            issuperset()
# print(a < a)     ## False           is proper subset
# print(b < a)     ## True
# print(a > b)     ## True            is proper superset

#--------------------------------------------------------------

''' Set members must be hashable, since elements are accessed by hashing.
Mutable sequences(e.g. list, set and dict) are non-hashable.
Number, str, immutable sequences(e.g. tuple) are hashable.  '''
s = {1, 2, 3}
# s.add({0})            ## Error
# s.add([6])            ## Error
s.add((4, 5))
print(s)                ## {(4, 5), 1, 2, 3}

''' frozenset: is immutable and hashable.
A frozenset can be used mostly as set, except mutable operations
 (e.g. add and remove) are not allowed. '''
def frozen_set():
    ''' Sets cannot be keys of dict, since set is non-hashable. '''
    d = {}
    # d[ {1, 2} ] = 'hello'         ## error

    ''' Frozensets should be created with initial value. '''
    fs = frozenset({1, 2})
    # fs.add(3)                   ## Error

    ''' A frozenset can be a key of a dict. '''
    d[ fs ] = 'hello'
    print(d[fs])                  ## hello

    ''' A frozenset can be member of a set. '''
    print( {0, fs} )              ## {0, frozenset({1, 2})}
# frozen_set()

''' collections.Counter: Multiset is a set that allows elements to have
more than one occurrence.
It is implemented as a dict with item of <value>:<number of occurrence>. '''
import collections
def counter_test():
    ## A counter is very useful for frequency count.
    c = collections.Counter()
    c.update({'A': 1, 'B': 3, 'C': 5})
    print(c)        ## Counter({'C': 5, 'B': 3, 'A': 1})
    c.update({'B': 1, 'C': 2, 'F': 2})
    print(c)        ## Counter({'C': 7, 'B': 4, 'F': 2, 'A': 1})

    ''' Unique elements,  Total number of elements.'''
    print(len(c), sum(c.values()))          ## 4 14

    ''' Counter is applicable to str, list, tuple, and set. '''
    for k,v in collections.Counter('Hello').items():
        print('%s(%d)' % (k, v), end=' ')  ## H(1) e(1) l(2) o(1)
    print()

    ''' Anagrams are strings that contain the same set of characters. '''
    print(collections.Counter('night') == collections.Counter('thing')) ## True
# counter_test()

#############################################################

''' Set are used mostly for eliminate dupicated values. '''
# print(set('Hello'))             ## {'H', 'o', 'e', 'l'}

''' Ex. Generating a deck of random cards.
Suppose a card is represented by an int and a deck is [0, 1, ..., 51].  '''
import random
''' Using list '''
def rand_deck1():
    deck = []
    while len(deck) < 52:
       x = random.randrange(0,52)
       if x not in deck:
          deck.append(x)
    print(deck)
# rand_deck1()

''' Using set '''
def rand_deck2():
    deck = set()
    while len(deck) < 52:
        deck.add(random.randrange(0,52))
    print(deck)
# rand_deck2()

''' Using swap '''
def rand_deck3():
    deck = list(range(52))
    for i in range(52):
        x = random.randint(0, 51)
        deck[i], deck[x] = deck[x], deck[i] # swap at position i and x.
    print(deck)
# rand_deck3()

''' Using Permutation '''
def rand_deck4():
    deck = list(range(52))
    random.shuffle(deck)
    print(deck)
# rand_deck4()
