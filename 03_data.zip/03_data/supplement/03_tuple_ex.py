''' tuple() factory creates tuple from other types.  '''
# print(tuple('Hello'))               ## ('H', 'e', 'l', 'l', 'o')
# print(tuple(range(3)))              ## (0, 1, 2)
# print(tuple( [1, 2, 3] ))           ## (1, 2, 3)
# print(tuple( {1, 2, 1} ))           ## (1, 2)

''' Tuple cannot be created with comprehension.
( <comprehension> ) results a generator.  '''
# print( type( (i for i in range(3))  ))   ## <class 'generator'>

#################################################################

''' Passing lists as parameters may have side effect, but not for tuples. '''
def tuple_param():
    def f(a, t):
        a += 'x'
        # t += 'x'     ## error

    a = ['a','b']
    t = ('a','b')
    f(a, t)
    print(a)          ## ['a', 'b', 'x']
# tuple_param()

''' Tuples allow a function to return more than one values.  '''
def div10(n):
    return n//10, n%10  ## Automatic tuple packing.
# print(div10(12))          ## (1, 2)

''' Python integers are not allowed to begin with 0.
Sometime it is safer to work with str.
car(<seq>) returns a tuple of <head> and <tail>.     '''
def car(n: str):  ## Type annotation
   return (n[0], n[1:])
# print(car('123'))       ## ('1', '23')
# print(car('1023'))      ## ('1', '023')

''' Ex. Count the number of <digit> at the beginning of <number>. '''
def prefix_count(digit: str, number: str):
   c = 0
   while len(number) > 0:
      head, tail = car(number)
      if digit == head:
         c += 1
      else:
         break
      number = tail
   return c
# print(prefix_count('1', '11123'))     # 3
# print(prefix_count('1', '110123'))    # 2

''' Find a square number n**2 with the most 7 prefixed for n below 1_000_000. '''
def most7_prefix(m):
    n, max = None, 0
    for i in range(2, m):
        x = prefix_count('7', str(i*i))
        if x > max:
            max = x
            n = i
    return (n, n*n)
# print(most7_prefix(1_000_000))    # (881917, 777777594889)
#----------------------------------------------------------------

''' If no modification toa sequence, tuples are more efficient than lists.

Ex. Lion and Tiger.
Lion always lies on Monday, Tuesday, and Wednesday,
    and tell the truth for the rest of the week.
Tiger lies on Thursday, Friday, and Saturday,
    and tell the truth for the rest of the week.
Today the lion say 'Yesterday I am a liar.'
The tiger say 'Me too'.
What is the day of the week, today?   '''
def lion_tiger():
    def yesterday(day):
        return (day - 1) % 7

    lion = ('T', 'T', 'T', 'T', 'L', 'L', 'L')
    def lion_say(day):
        say  = lion[yesterday(day)] == 'L'
        if lion[day] == 'T':
            return say
        return not say

    tiger = ('T', 'L', 'L', 'L', 'T', 'T', 'T')
    def tiger_say(day):
        say  = tiger[yesterday(day)] == 'L'
        if tiger[day] == 'T':
            return say
        return not say

    days =('sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat')
    for day in range(len(days)):
        if lion_say(day) and tiger_say(day):
            print(days[day])
# lion_tiger()
