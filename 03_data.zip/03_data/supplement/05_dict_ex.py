''' Dicts can be created from json str. '''
import json
js = '{ "id": 2, "name": "jack"}'   ## str
d = json.loads(js)
# print(type(d), d)       ## <class 'dict'> {'id': 2, 'name': 'jack'}

''' dict -> str. '''
s = json.dumps(d)
# print(type(s), s)       ## <class 'str'> {"id": 2, "name": "jack"}

''' Dict can be created from list or tuple (but not a set) with its factory. '''
# print( dict([ ['id', 2],
#               ('name', 'Joe Green'),
#               ('gpa', 2.0) ]) )
    ## {'id': 2, 'name': 'Joe Green', 'gpa': 2.0}

''' Dict can be created from two lists with zip(). '''
k = ['a', 'b', 'c']
v = [1, 2, 3]
# print(dict(zip(k, v)))      ## {'a': 1, 'b': 2, 'c': 3}

''' Dict can be created with comprehension, using : for separator between
   <key> and <value> in <expression>.  '''
# print( {x: x * x for x in range(5)} )  ## {0: 0, 1: 1, 2: 4, 3: 9, 4: 16}
# print( {_id: name for _id in [1, 2] for name in ['john','jack'] })
                                      ## {1: 'jack', 2: 'jack'}

''' Since Python 3.0, keys(), values(), and items() do not return a list,
    but return something that iterable (for iteration).  '''
d = { 'x': 1, 'y': 2 }
# print(d.keys())       ## dict_keys(['x', 'y'])
# print(d.values())     ## dict_values([1, 2])
# print(d.items())      ## dict_items([('x', 1), ('y', 2)])

''' Dict Iteraion '''
def for_dict():
    d = {'zero': 0, 'one': 1, 'two': 2}

    ''' Default iteration get only the keys.
    keys() returns an iterable view of keys. '''
    for i in d:
    # for i in d.keys():        ## Alternatively
        print(i, end=', ')      ## zero, one, two,
    print()

    ''' values() returns iterable view of values. '''
    for i in d.values():
        print(i, end=', ')      ## 0, 1, 2,
    print()

    ''' items() returns iterable view of items represented as tuple. '''
    for k,v in d.items():
        print(k, v, end='   ')  ## zero 0   one 1   two 2
    print()
# for_dict()

###########################################################

''' Dict provides mapping like array but 'index' may be anything that hashable.
Ex. Day Mapping: Suppose
   sat = 0, sun = 1, mon = 2, tue = 3, wed = 4, thu = 5, fri = 6   '''
dm = {'sun': 1, 'mon': 2, 'tue': 3, 'wed': 4, 'thu': 5, 'fri': 6, 'sat': 0 }
# print(dm['mon'])        ## 2

''' Ex. Morse Code '''
code = {
    'A': 'o-', 'B': '-ooo', 'C': '-o-o', 'D': '-oo', 'E': 'o', 'F': 'oo-o',
    'G': '--o', 'H': 'oooo', 'I': 'oo', 'J': 'o---', 'K': '-o-', 'L': 'o-oo',
    'M': '--', 'N': '-o', 'O': '---', 'P': 'o--o', 'Q': '--o-', 'R': 'o-o',
    'S': 'ooo', 'T': '-', 'U': 'oo-', 'V': 'ooo-', 'W': 'o--', 'X': '-oo-',
    'Y': '-o--', 'Z': '--oo', ' ': ' ',
    '1': 'o----', '2': 'oo---', '3': 'ooo--', '4': 'oooo-', '5': 'ooooo',
    '6': '-oooo', '7': '--ooo', '8': '---oo', '9': '----o', '0': '-----' }

def encode(msg):
    def enc(k):
        return code[k]
    morse = ''
    for m in msg:
        morse += enc(m) + ','       ## Using ',' as separator.
    return morse[0: len(morse)-1]   ## remove the last ','

def decode(morse):
    def dec(v):
        for i in code.keys():
            if code[i] == v:
                return i
    msg = ''
    for m in morse.split(','):
        msg += dec(m)
    return msg

def morse_code():
    msg = list('HELLO HOW DO YOU DO')
    morse = encode(msg)
    print(morse)         ## oooo,o,o-oo,o-oo,---, ,oooo,---,o--, ,-oo,---, ,-o--,---,oo-, ,-oo,---
    print(decode(morse)) ## HELLO HOW DO YOU DO
# morse_code()

#--------------------------------------------------------------

''' Ex. Chinese Zodiac:
The Chinese bound animals to years in a 12 year cycle.
The pattern repeats before and from there:
      2000 Dragon         % 12  == 8
      2001 Snake                   9
      2002 Horse                  10
      2003 Sheep                  11
      2004 Monkey                  0
      2005 Rooster                 1
      2006 Dog                     2
      2007 Pig                     3
      2008 Rat                     4
      2009 Ox                      5
      2010 Tiger                   6
      2011 Hare                    7

def zodiac(year):
    r = year % 12
    if r == 8:
        return 'Dragon'
    elif r == 9:
        return 'Snake'
    elif r == 10:
        return 'Horse'
    elif r == 11:
        return 'Sheep'
    elif r == 0:
        return 'Monkey'
    elif r == 1:
        return 'Rooster'
    elif r == 2:
        return 'Dog'
    elif r == 3:
        return 'Pig'
    elif r == 4:
        return 'Rat'
    elif r == 5:
        return 'Ox'
    elif r == 6:
        return 'Tiger'
    else:
        return 'Hare'

## Alternativelytively
def zodiac(year):
    r = year % 12
    return 'Dragon'  if r == 8 else     \
           'Snake'   if r == 9 else     \
           'Horse'   if r == 10 else    \
           'Sheep'   if r == 11 else    \
           'Monkey'  if r == 0 else     \
           'Rooster' if r == 1 else     \
           'Dog'     if r == 2 else     \
           'Pig'     if r == 3 else     \
           'Rat'     if r == 4 else     \
           'Ox'      if r == 5 else     \
           'Tiger'  if r == 6 else 'Hare'
'''

''' A tuple can be used for mapping. '''
z = ( 'Monkey', 'Rooster', 'Dog', 'Pig', 'Rat', 'Ox', 'Tiger',
      'Hare', 'Dragon', 'Snake', 'Horse', 'Sheep' )
def zodiac(year):
    return z[year % 12]

''' Using a dict to store zodiac preditions. '''
predict = { 'Rat': 'Charm, smart, adroit, agile',
            'Ox': 'Mild, prudent, honest, endure',
            'Tiger': 'Bold, allure, quick-tempered',
            'Hare' : 'Bland, courtesy, politeness, good taste',
            'Dragon': 'Leader, astute, dexterous, attractive, ambitious',
            'Snake': 'Mysterious, elegant, individual, indolent',
            'Horse': 'Honesty, shy, intensive, athlete',
            'Sheep': 'Artist, romantic, imaginative, unreliable',
            'Monkey': 'Clever, playful, persuasive, talkative',
            'Rooster': 'Confident, generous, lively, entertainment',
            'Dog': 'Trustworthy, instinct, intuitive unrest',
            'Pig': 'Simple mind, forgiveness, kindness, careless'}
def zodiac_test(year):
    zod = zodiac(year)
    print('%s:\t%s' % (zod, predict[zod]))
# zodiac_test(2023)
