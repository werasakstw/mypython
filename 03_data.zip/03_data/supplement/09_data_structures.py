# Stack:
# Lists are implemented as dynamic arrays which need to resize occasionally.
# Lists over-allocate storage so that not every push or pop requires resizing.
# List provide terrible performance when add/remove at the front or in the
#   middle since the remain elements must be shifted.
# List provides efficient random access and append()/pop() at the end.
# Therefore list is a decent stack.
def stack_test():
    s = list()
    s.append(1); s.append(2); s.append(3);
    print(s.pop(), s.pop(), s.pop())    # 3 2 1
# stack_test()

# collections.deque: Stacks and Queues
# Deque supports fast add/remove elements from either ends,
#  that serve well for both stack and queue.
# But deque is implemented as doubly-linked lists which consumes a lot of
#  memory for points. Poor performance for random access but decent
#  add/remove elements in the middle since no shifting required.
import collections
def deque_test():
    dq = collections.deque()

    # add/remove at the end (right end)
    dq.append(1); dq.append(2); dq.append(3);
    print(dq.pop(), dq.pop(), dq.pop())  # 3 2 1

    # add/remove at the front (left end)
    dq.appendleft(1); dq.appendleft(2); dq.appendleft(3);
    print(dq.popleft(), dq.popleft(), dq.popleft())  # 3 2 1

    # add at the end, remove at the front
    dq.append(1); dq.append(2); dq.append(3);
    print(dq.popleft(), dq.popleft(), dq.popleft())  # 1 2 3
# deque_test()

#------------------------------------------------------------------

# heapq: List-Based Binary Heaps (priority queue)

import heapq
def heapq_test():
    a = []
    heapq.heappush(a, (3, 'john'))
    heapq.heappush(a, (1, 'jim'))
    heapq.heappush(a, (2, 'jack'))
    print(a)    # [(1, 'jim'), (3, 'john'), (2, 'jack')]

    while a:
        print(heapq.heappop(a), end=', ')
# heapq_test()    # (1, 'jim'), (2, 'jack'), (3, 'john'),

# queue.PriorityQueue: synchronized to support concurrent users.
import queue
def pq_test():
    pq = queue.PriorityQueue()
    pq.put((3, 'john'))
    pq.put((1, 'jim'))
    pq.put((2, 'jack'))

    while not pq.empty():
        print(pq.get(), end=', ') # (1, 'jim'), (2, 'jack'), (3, 'john'),
# pq_test()

#-------------------------------------------------------------------

def ordered_dict():
    ''' Originally dicts use hashing <key> to store the item, so the
      item order is not accroding to insertion order.
    'OrderedDict' is introduced to preserve insertion order of keys. '''
    od = collections.OrderedDict(john=1, jack=2)
    od['joe'] = 3
    print(od) ## OrderedDict([('john', 1), ('jack', 2), ('three', 3)])

    ''' But since Python 3.6, dict preserve insertion order of keys. '''
    d = dict()
    d['john'] = 1; d['jack'] = 2;  d['joe'] = 3;
    print(d)   ## {'john': 1, 'jack': 2, 'joe': 3}
# ordered_dict()

def default_dict():
    ''' Accessing non-exist key of a dict results an error. '''
    d = { 'john':1 }
#    print(d['jack'])  ## error

    ''' 'defaultdict' allows accroding non-exist key results no error
      and a key may have more than one values.  '''
    dd = collections.defaultdict(list)
    dd['cs'].append('john')
    print(dd['ce'])     ## []
    print(dd['cs'])     ## ['john']
    dd['cs'].append('jack')
    print(dd['cs'])    ## ['john', 'jack']
# default_dict()

def chain_map():
    d1 = { 'john': 1, 'jack': 2 }
    d2 = { 'jack': 3, 'joe': 4 }

    ''' Chain two or more dict to be searched at once. '''
    cd = collections.ChainMap(d1, d2)
    print(cd)    ''' The first occurence value is returned. '''
    print(cd['jack'], cd['joe']) # 2 4
# chain_map()

import types
def read_only_dict():
    d = { 'john': 1, 'jack': 2 }

    ''' A wrapper for read only view. '''
    rod = types.MappingProxyType(d)
    print(rod['jack'])          ## 2

    ''' Item modification is not allowed. '''
##    rod['jack'] = 3           ## error

    '''  Adding more item is not allowed. '''
##    rod['joe'] = 3           ## error

    ''' The original is still mutable. '''
    d['joe'] = 3
    print(rod)          ## {'john': 1, 'jack': 2, 'joe': 3}
# read_only_dict()
