''' List: is an sequence of elements.
A list has memory to store its elements while a range has none.
List literals are enclosed in [ ] with , as separator.       '''
a = [1, 2, 3]
# print(a)                       ## 1, 2, 3]

''' Lists are order-oriented and may contain duplicate elements.  '''
# print( [1, 2, 1] )              ## [1, 2, 1]

''' Lists are accessed by position(indexing with zero-base).  '''
# print( a[0] )                   ## 1

''' Lists are generic and nestable.  '''
# print([1, 2.0, '3', True])      ## [1, 2.0, '3', True]
# print([1, [2, 3]])              ## [1, [2, 3]]

''' list() factory creats an empty list.  '''
# print( [], list() )             ## [] []

''' A comma after the last element is optional in list literals.
That allows each elements in separated line with consistent comma. '''
# print([1, 2, 3,])               ## [1, 2, 3]

''' Lists are mutable: modify the whole  '''
a = ['a', 'b', 'c']
# print(a)                        ## ['a', 'b', 'c']

''' Modify element:
List indexing is allowed on the left side of assignment.  '''
a[1] = 'x'
# print(a)                         ## ['a', 'x', 'c']

''' + operor is overloaded for list concatenation.  '''
a += ['d']
# print(a)                        ## 'a', 'x', 'c', 'd']

''' Delete an element at position.  '''
del a[1]
# print(a)                        ## ['a', 'c', 'd']

''' Clear all elements.  '''
a.clear()
# print(a)                        ## []

''' Delete the whole.  '''
del a;
# print(a)                        ## error
