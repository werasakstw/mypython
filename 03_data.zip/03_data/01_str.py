''' Strings are objects of 'str' class.
Mostly strings are defined as literals. '''
s = 'abc'
# print(s, type(s))           ## abc  <class 'str'>

''' Python does not support 'char' type.
A character is a str of one character. '''
# print(s[0], type(s[0]))     ## a   <class 'str'>

''' String is immutable, so appending has more overhead than creating at once. '''
''' Bad '''
# print('Hello' + ' ' + 'how' + ' ' + 'are' + ' ' + 'you?')
''' Good  '''
# print(' '.join(['Hello', 'how', 'are', 'you?']))

''' Python supports 4 styles of String Formats:
1. Old Style String Format: Similar to C's printf().
          <str with format characters> % values
If values have more than one values, they must enclosed in ().
Values are substituted in order of format characters.

Format Characters:
    b binary
    c character - convert to unicode character
    d decimal (default)
    n decimal with locale specific separators
    o octal
    x hex (lower-case)
    X hex (upper-case)
    e/E Exponent. Lower/upper-case e
    f Fixed point
    g/G General. Fixed with exponent for large, and small numbers ( g default)
    n g with locale specific separators
    % Percentage (multiplies by 100)            '''
def old_style():
    print('Hello! %s.' % 'John')            ## Hello! John.
    print('Hello! %s.' % ['John', 'Jack'])  ## Hello! ['John', 'Jack'].
    print('Hello! %s  and %s.' % ('John', 'Jack')) # values are wrapped as a tuple
                                            ## Hello! John  and Jack.
    ''' Format with number bases.    %b is not supported.  '''
    print('%o, %d, %x' % (10, 10, 10))      ## 12, 10, a

    ''' Float format '''
    print('%.2f' % 123.456)                 ## 123.46

    ''' Sequences can be formatted to str.  '''
    print('%s, %s' % ([1, 2, 3], {1, 2, 3})) # [1, 2, 3], {1, 2, 3}
# old_style()

''' 2. New Style String Formatting: (Python 3.0)
Create a str from a template by substitute values in place holders.
          <str with place holders>.format(<values>)
format() here is a method of class 'str'.
A place holder is specified with {} (no %).
The place holders can be specified by order, position or name.
Values may be formatted by default, according to the types.  '''
def new_style():
    ''' {} are place holder for formatted values.  '''
    print('Hello {} and {}.'.format('John', 'Jack'))  ## Hello John and Jack.

    ''' The place holder may specify value position.  '''
    print('Please bring me {1} {0}.'.format('books', 10))
                                                    ## Please bring me 10 books.
    ''' Place holder with names.  '''
    print('Hello {n1} and {n2}.'.format(n2 = "John", n1 = "Jack"))
                                                    ## Hello! Jack and John.
    ''' name/position with format characters.  '''
    print('Hello {n1:s} and {n2:s}.'.format(n2 = 'John', n1 = 'Jack'))
                                                    ## Hello! Jack and John.
    print('{0:s}, {1:.2f}, {2:3d}'.format('books', 1.2, 12)) # books, 1.20,  12

    ''' Number Bases Format '''
    print('{:b}, {:d}, {:o}, {:x}'.format(10, 10, 10, 10))  ## 1010, 10, 12, a

    ''' Float format '''
    print('{:.2f}'.format(123.456))                 ## 123.46

    ''' Default list/set format.  '''
    print('{}, {}'.format([1, 2, 3], {1, 2, 3}))    ## [1, 2, 3], {1, 2, 3}
# new_style()

''' There is a built-in function:
             format(<value>, <pattern>)
   that formats <value> of any types to str.
  <pattern> is  [sign][width][.precision][type]
'''
def format_function():
    ''' 'd' is for displayed as decimal.  '''
    print(format(12, '+4d'))    ##  +12

    x = 12.3456
    ''' f    Float format with default 6 precision.
        F    Same as f , except 'nan' is converted to NAN and 'inf' to INF. '''
    print(format(x, 'f'))       ## 12.345600
    print(format(x, '+4.2f'))   ## +12.35

    ''' e, E Exponential format, with e/E to mark the exponent. '''
    print(format(x, 'e'))       ## 1.234560e+01
    print(format(x, '.2E'))     ## 1.23E+01

    ''' g, G, n General format, rounded to the given precision. '''
    print(format(x, 'G'))       ## 12.3456

    ''' % multiplied by 100, displayed in f format with a percentage sign. '''
    print(format(0.25, '.1%'))  ## 25.0%

    ''' Convert int to str, with number bases. '''
    print(format(10, 'b'))      ## 1010
    print(format(10, 'o'))      ## 12
    print(format(10, 'd'))      ## 10
    print(format(10, 'x'))      ## a
    print(format(10, 'X'))      ## A
# format_function()

''' 3. f-string (Function String, Interpolation) introduced in Python 3.6,
  allows evaluating expressions that embedded inside string literal.
A function string is prefixed with 'f'. e.g.  f'hello'.
An expression is surrounded by { }.
Expressions are evaluated at runtime and results are inserted at the positions. '''
def interpolation():
    name = 'John'
    print(f'Hello {name}')      ## Hello John

    a, b = 1, 2
    print(f'a + b = {a + b}')   ## a + b = 3
# interpolation()

''' 4. Template String: less powerful but simple and more suitable in some cases.
All values are automatically formatted according to the type.
It allows creating a str from a template which default format.
Template strings are not a core language feature but supplied by standard library. '''
from string import Template   ## 'string' is a standard lib.
def temp_str():
    t = Template('Hello $name please send me $value buck.')
    print(t.substitute(name='John', value='10')) ## Hello John please send me 10 buck.
# temp_str()

''' Zen of Python: There should be one obvious way to do something.
Rich languages provide many ways to do the samething. '''
