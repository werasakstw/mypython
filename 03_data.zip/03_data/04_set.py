''' Set: is a mutable value oriented sequence of elements.
Sets cannot contain duplicate elements.
Set literals are enclosed with { }. '''
s = { 2, 1, 2, 3 }
# print(s)                        ## {1, 2, 3}

''' There is no empty set literal, {} is an empty dict.
 An empty set is denoted by its factory. '''
# print( set() )                 ## set()

''' Set elements have no position.
Elements cannot be accessed by indexed, but can only be checked
  that if a value  is 'in' the set. '''
# print(1 in s)                   ## True

''' Sets are generic but not nestable.
 Set elements must be hashable, e.g. number, str and tuple.'''
# print({1, 2.0, '3', True, (1,)})


''' Set is mutable so can be created constructively from an empty set. '''
s = set()

''' Adding duplicated elements have no effect nor error. '''
s.add(1); s.add(2); s.add(3); s.add(2)
# print(s)                    ## {1, 2, 3}

''' remove() a non-member is an error, but discard() is not. '''
# s.remove(2); print(s)       ## {1, 3}
# s.remove(0)                 ## Error
# s.discard(0)                ## 1

''' pop() Remove and return an arbitrary element. '''
s = {1, 2, 3}
# print(s.pop())              ## 1
# print(s)                    ## {2, 3}

''' update() union itself with the other. '''
s.update({'a', 'b'})
# print(s)                    ## {2, 3, 'a', 'b'}
