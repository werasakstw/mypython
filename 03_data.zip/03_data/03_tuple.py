''' Tuples are immutable order-oriented sequences.
Tuples are more efficient than lists.
Tuples have no methods to modifies their state e.g.
   append(), extends(), insert(), remove(), pop() reverse() and sort().  '''

''' Tuple literals are enclosed in ( ).  '''
# print( (1, 2, 3) )              ## (1, 2, 3)

''' Tuples are order-oriented and may contain duplicate elements.  '''
# print( (1, 2, 1) )              ## (1, 2, 1)

''' Empty tuple  '''
# print( (), tuple() )            ## ()  ()

''' Single element tuple listeral. '''
# print( (1) )            ## integer 1 in parenthesis.
# print( (1,) )           ## tuple with 1 element.

''' Tuples are generic and nestable.  '''
# print((1, 2.0, '3', True))
# print((1, (2, 3)))

''' + is overloaded for merging tuples.  '''
# print((1, 2) + (2, 'b'))            ## (1, 2, 2, 'b')

''' Tuple can be created with initialized value using * <number>.  '''
# print((True,)*3)                    ## (True, True, True)

''' Tuples are immutable. '''
t = ('a', 'b', 'c')
''' Elements cannot be modified.  '''
# t[0] = 0                  ## error

''' Tuple cannot be appended.  '''
# t.append('d')             ## error

''' Tuple Element cannot be deleted.  '''
# del(t[2])                 ## error

''' Tuples can be changed as a whole.  '''
t = ('x', 'y')
# print(t)            ## ('x', 'y')

''' Tuples can be deleted as a whole. clear() is not supported.  '''
del(t)
# print(t)            ## error

''' If a tuple element is mutable, the element may be modified.  '''
b = (1, [2, 3])
b[1].append(4)        ## Lists are mutable.
# print(b)            ## (1, [2, 3, 4])
#------------------------------------------------------------------

''' Tuple Unpacking: is an assignment of a tuple to several variables. '''
a, b, c = ('John', 'Jack', 'Joe')
# print(a, b, c)            ## John Jack Joe

''' Multiple Tuples Unpacking  '''
(a, b), (c, d, e) = (1, 2), (3, 4, 5)
# print(a, b, c, d, e)      ## 1 2 3 4 5

''' Nested Tuples Unpacking  '''
(a, (b, c)) = (1, (2, 3))
# print(a, b, c)            ## 1 2 3

''' The left and right sides of tuple unpacking must have the same size.  '''
# (a, b) = (1, 2, 3)    ## error
# (a, b, c) = (1, 2)    ## error

''' Wildcards(*) accepts all as a list. '''
(a, b, *c) = (1, 2, 3, 4, 5)
# print(a, b, c)         ## 1 2 [3, 4, 5]

''' * may not be the last, it gets just what it takes.  '''
(a, *b, c) = (1, 2, 3, 4, 5)
# print(a, b, c)        ## 1 [2, 3, 4] 5

''' * may accept empty.  '''
(a, b, *c) = (1, 2)
# print(a, b, c)        ## 1 2 []

''' Automatic tuple packing.
 On a value context e.g. right side of =, () is optional.  '''
t = 1, 2, 3
# print(t)              ## (1, 2, 3)

''' Multiple Assignment is a tuple unpacking in disguise.  '''
x, y, z = 1, 2, 3
# print(x, y, z)        ## 1 2 3

''' Automatic tuple pack/unpack.  '''
a, b, *c = 1, 2, 3, 4, 5
# print(a, b, c)        ## 1 2 [3, 4, 5]

''' Tuple unpacking can exchange values in one statement
 without using a temporary holder. '''
x, y = 1, 2
y, x = x, y
# print(x, y)            ## 2 1
