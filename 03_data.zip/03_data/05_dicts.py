''' 'dict' is a set of elements in the form of <key>:<value>.
<key> must be hashable (e.g. int, float, bool, str and immutable types),
<value> can be of any types.
Dicts supports very efficient operations: lookup, insert,

Dict literals are denoted as {<element>,}.
A comma after the last element is optional. '''
d = { 'id': 1, 'name': 'john'}
# print(type(d), d)       ## <class 'dict'> {'id': 1, 'name': 'john'}

''' Mostly <key> are str but can be anything that hashable. '''
fac = {0: 1, 1: 1, 2: 2, 3:6 }

''' Immutable objects are hashable, so can be <key>. e.g. tuple.'''
students = { (1, 'john'): 1.5, (2, 'jack'): 3.8 }

''' A dict may has <key> and <value> of different types. '''
t = {0: False, True: 'yes', 'gpa': 3.8}

''' Dicts do not allow duplicate <key> but a new one overrides an existing one. '''
names = { 'name': 'john', 'name': 'jack'}
# print(names)          ## {'name': 'jack'}
#---------------------------------------------------------------

''' Dicts are mutable '''
d = {'x': 1}

''' Add new element '''
d['y'] = 2
# print(d)                    ## {'x': 1, 'y': 2}

'''  Replace an element '''
d['x'] = 0
# print(d)                    ## {'x': 0, 'y': 2}

''' Delete an element '''
del d['y']
# print(d)                    ## {'x': 0}

''' Update element value '''
d['x'] += 1.0
# print(d)	                ## {'x': 1.0}

''' Update a dict with another dict. '''
a = { 'x': 1, 'y': 2 }
b = { 'y': 3, 'z': 4 }
a.update(b)
# print(a, b)     ## {'x': 1, 'y': 3, 'z': 4} {'y': 3, 'z': 4}

''' Clear all elements, the dict still exist. '''
a.clear()
# print(a)        ## {}

''' Delete the whole '''
del(a)
# print(a)      ## error
#---------------------------------------------------------------

''' Dict elements are accessedd by indexing with the element's key. '''
d = { 'x': 1, 'y': 2 }
print(d['x'])                       ## 1

''' Indexing with non-exist key is an error. '''
# print(d['z'])                     ## error

''' get() does not cause error and allows returning default value. '''
print(d.get('z'), d.get('z', 0))   ## None 0

''' 'in' checks if the <key> is exist in a dict. '''
print('x' in d, 'z' in d)          ## True False
