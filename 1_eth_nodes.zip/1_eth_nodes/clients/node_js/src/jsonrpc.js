// npm install -save ethers
const { ethers } = require("ethers")

// const URL = 'http://127.0.0.1:8545'
const URL = "https://rinkeby.infura.io/v3/1c33caf701824d43882200b69d5e0849"
const jpv = new ethers.providers.JsonRpcProvider(URL)

function json_rpc() {
	jpv.send("web3_clientVersion", []).then(console.log)
	jpv.send("eth_gasPrice", []).then(console.log)
	jpv.send("eth_blockNumber", []).then(console.log)
        jpv.send("eth_accounts", []).then(console.log)
}
json_rpc()
