const Web3 = require('web3')

// const URL = 'http://127.0.0.1:8545'
const URL = url = "https://rinkeby.infura.io/v3/1c33caf701824d43882200b69d5e0849"

// const web3 = new Web3(new Web3.providers.HttpProvider(URL))
const web3 = new Web3(URL)		// default

function web3_js() {
	web3.eth.getNodeInfo().then(console.log)
	web3.eth.getGasPrice().then(res => console.log('Gas Price: ' + res))
	web3.eth.getBlockNumber().then(res => console.log('Last Block: ' + res))
	web3.eth.getAccounts().then(res => console.log('Accounts: ' + res))
}
web3_js()
