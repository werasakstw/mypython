# pip install python-binance

from binance.client import Client
API_KEY = 'MFiwBMqiOoNjJvYeIAcPxJKW4O393Wbc7rXcufRECohY3JuR410MSTFA2aYiozmz'
SERECT_KEY = 'RGgn4cHmSe61X3xCinmh5mWkglbwHFA97w5XaK99z6x4cxHRY1j2fKcULNHsE2E0'
c = Client(API_KEY, SERECT_KEY)
c.API_URL = 'https://testnet.binance.vision/api'

import json
def print_json(ob):
   print(json.dumps(dict(ob), indent=3))

##print_json(c.get_account())

# Get all balances
##[ print(b) for b in c.get_account()['balances']]

# Get specific balance.
##print(c.get_account()['balances'][0])
##print(c.get_asset_balance(asset='BNB'))

# Det Price
##print(c.get_symbol_ticker(symbol='BNBUSDT'))
##print(c.get_symbol_ticker(symbol='BTCUSDT'))
##print(c.get_symbol_ticker(symbol='ETHUSDT'))

