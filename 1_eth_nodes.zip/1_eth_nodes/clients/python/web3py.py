# https://web3py.readthedocs.io/en/stable/

# pip install --save web3
from web3 import Web3
# URL = 'http://127.0.0.1:8545'
URL = "https://rinkeby.infura.io/v3/1c33caf701824d43882200b69d5e0849"
w3 = Web3(Web3.HTTPProvider(URL))

# Infura needs a middleware between client and provider
#  for modifying requests and responses to conform to
#  the communication protocol.
from web3.middleware import geth_poa_middleware
w3.middleware_onion.inject(geth_poa_middleware, layer=0)

# print(w3.clientVersion)
# print(w3.eth.gasPrice)
# print(w3.eth.blockNumber)

# Geth: supports creating new account via IPC only.
# https://stackoverflow.com/questions/41296993/not-able-to-create-accounts-for-private-ethereum-blockchain-using-geth-and-web3

# Openthereum: supports creating new accounts via http.
# print(w3.personal.newAccount('john'))
# print(w3.eth.accounts.create('seed'))
# print(w3.eth.accounts)

# Transactions must specify the chain id.
# print(w3.eth.chain_id)

# Openthereum does not support balance checking if syncing is not done.
me_addr = "0x16c25A4cb42906a367Cce89043f3e39F9f892eb0"
# print(w3.eth.getBalance(me_addr))

# Infura: is not a wallet and do not perform mining.
# print(w3.eth.accounts)  # []
# print(w3.eth.mining)    # False
# But provides balance checking for valid addresses.
# print(w3.eth.getBalance(me_addr))

#---------------------------------------------------

import json
def print_json(obj):        # AttributeDict
   st = w3.toJSON(obj)     # str
   js = json.loads(st)
   print(json.dumps(js, indent=4, sort_keys=True))

# Get recent block.
def recent_block():
    lb = w3.eth.get_block('latest')     # eth.blockNumber
    print(lb.number, w3.toHex(lb.hash))
    print_json(lb)
recent_block()
