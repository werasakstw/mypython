import requests

# URL = 'http://127.0.0.1:8545'
URL = "https://rinkeby.infura.io/v3/1c33caf701824d43882200b69d5e0849"
HEADERS = {'Content-type': 'application/json', 'Accept': 'text/plain'}

def jsonrpc(method, param):
   DATA = '{"jsonrpc":"2.0", "method": "%s","params": %s, "id": 1}' \
         % (method, param)
   return requests.post(URL, data=DATA, headers=HEADERS).text

import json
def print_json_str(st):
   print(json.dumps(json.loads(st), indent=4, sort_keys=True))

def print_result(st):
   print(json.loads(st)['result'])

print(jsonrpc('web3_clientVersion', []))
# print_json_str(jsonrpc('web3_clientVersion', []))
# print_result(jsonrpc('web3_clientVersion', []))

# print_result(jsonrpc('eth_gasPrice', []))
# print_result(jsonrpc('eth_blockNumber', []))
