''' 'variable' is a value which can be reffered to by its name.
A variable has 'name', 'identifier'(or address) and 'value'. '''
def variable():
    x = 1

    ## On right-hand side of assignment:  'name' is mapped(de-referenced) to 'value'.
    print(x)            # 1

    ## On left-hand side of assignment: 'name' is mapped(referenced) to 'identifier'.
    x = x + 1
    print(x)            # 2

    ''' Identifiers can be anything that can be used for accessing the values.
    CPython identifier is the memory address that store the value.
    Identifiers should not be used directly, they are useful only for checking
      if values are the same object.
    The built-in function id(<var|value>) returns the 'identifier'of <var|value>. '''
    print(id(x), id(0))

    ''' The built-in function type(<var|value>) returns the type of <var|value>.
    The type is belonged to the value and cannot be changed.
    The variable's type is the type of its value but a variable may change its value. '''
    print(type(x), type('0'))      # <class 'int'> <class 'str'>
# variable()

## Python creates variable dynamically, when a name is first initialized with a value.
def dyn_create():  ## A function definition creates its scope.
    ## Create a variable named 'a' in the current scope.
    a = 1

    ## The built-in function dir() return a list of names in the current scope.
    print(dir())         # ['a']

    ## Python creates variables when the definition is executed.
    b = 2
    print(dir())         # ['a', 'b']

    ## If the definition is not executed the variable is not created.
    if a > 1:
        x = 3
    else:
        y = 4
    print(dir())        # ['a', 'b', 'y']
# dyn_create()

''' A type may be either:
    - Immutable: its value can not be modified. e.g. Numbers, str and tuple.
    - Mutable: its value may be modified. e.g. list, set, and dict.  '''
def immutable():
    ''' 'x' is the variable name.
    = assigns address of value(1) to the identifier of 'x'.
    The value(1) is associated with type 'int' that is immutable. '''
    x = 1
    print(id(x), x)     # 1692706736 1

    ''' Operation on immutable value results a new value(2).
    The address of value(2) is assigned to the identifier of 'x'. '''
    x = x + 1
    print(id(x), x)     # 1692706768 2

    ''' Python assignments change the variable's identifier to the
    new value location, not change the value since 'int' type is immutable. '''
# immutable()

''' Mutable types have methods to modify their values. That means
modification is performed on the value and no new value created. '''
def mutable():
    ## 'list' is mutable.
    a = [0]
    print(id(a), a)     # 62217640 [0]

    ## append() results side effect on the value.
    a.append(1)
    print(id(a), a)     # 62217640 [0, 1]
# mutable()

''' Unlike C and Java, Python associates type to variable value, not
 to the variable name. Variable identifier is not associted with type
 and can access values of any types.

Python variables may change type dynamically. But Python is a 'typed language'
since type checking is performed before operations. '''
def dyn_type():
    x = 1     ## 'x' is int.
    print(x, id(x), type(x))       # 1 1833478064 <class 'int'>

    x /= 3    ## Now 'x' is float.
    print(x, id(x), type(x))       # 0.3333333333333333 48831424 <class 'float'>
# dyn_type()

''' Immutability is belonged to the value not to the variable name.
If a value is mutable, it can be modified even it is in an immutable collection. '''
def mutability():
    ## Tuple is an immutable type.
    t = ([1], [2])    ## a tuple of list.
    # t.append(3)     # error

    ## But modify its element is allowed since 'list' is mutable.
    t[1].append(3)
    print(t)        # ([1], [2, 3])
# mutability()

#--------------------------------------------------------------

''' Alias: is the condition that two or more vatiables share the same value.
That is their identifiers point to the same location.
In Python assignment and parameter passing create alias. '''
def alias():
    ## If the shared value is immutable, modification results broken alias.
    x = 1
    y = x                   ## 'x' and 'y' are alias.
    print(id(x) == id(y))   # True
    x += 1
    print(id(x) == id(y))   # False  They have different value.

    ## If the shared value is mutable, modification maintain alias.
    a = b = [1]
    print(id(a) == id(b))   # True
    a += [2]
    print(id(a) == id(b))   # True
# alias()

#----------------------------------------------------------------------

''' Interning (Value Pool):
To keep the number of values low, Python creates a pool to prevent
creating duplicated values. During compile time, when a value is encountered
it is checked if not in the pool it will be added to the pool but if it is
already in the pool the value is used.
Python performs interning for Number and str only, not for other types. '''
def intern():
    x, y = 1, 1
    print(id(x) == id(y))      # True

    ## Other types (e.g. list) are non-interned.
    a, b = [1], [1]
    print(id(a) == id(b))      # False

    ## User defined types are non-interned.
    class A: pass
    a1 = A()
    a2 = A()
    print(id(a1) == id(a2))    # False
# intern()

''' Interning is performed if the value is known at compile time.
Values that created at runtime are not interned. '''
def static_intern():
    a = 1.0
    b = 0.5 + 0.5           ## performed at compile time.
    print(id(a) == id(b))   # True

    s = 'Hello'
    v = 'He' + 'llo'        ## performed at compile time.
    print(id(s) == id(v))   # True

    ## The variable values cannot be determined at compile time.
    w1 = 'He'
    w2 = 'llo'
    w = w1 + w2             ## performed at runtime
    print(id(s) == id(w))   # False
# static_intern()

''' Python 3.9 allows 'type annotation' (or type hint) for specifying
 variable type. The syntax is:      <variable>: <type>.    '''
def type_anno():
    x: int = 0      ## initial value is optional.
    s: str

    ''' But the type annotations are not enforced.
    That only makes the code more readable and some linters to detect type error. '''
    x = 'Hi'
    s = 1.0
    print(x, s)
# type_anno()

#----------------------------------------------------------------

''' Python supports two kinds of comparisons.
  1. == and != compares values.
        x == y is True, if x and y have the same values.

  2. 'is' and 'is not' compares identifiers.
        x is y is True, if x and y is the same object.
    That means if id(x) == id(y).

'is' is more efficient since compare addresses.
But it is unsafe for dynamic values and non-interned values.

Interning is undocumented, different Python implementations may use
 different techniques. So it is safer to use == .

'is' is used mostly for checking if variables are alias. '''
def comparison():
    ## Compare interned values.
    x = 1; y = 1
    print(x == y, x is y)   # True True

    ## Compare value that created at runtime.
    z = (x+y)/2
    print(x == z, x is z)   # True False

    ## Compare non-interned value.
    a = [1, 2]
    b = [1, 2]
    print(a == b, a is b)    # True False

    ## Set is value-oriented.
    x = {1, 2}
    y = {2, 1}
    print(x == y, x is y)    # True False

    ## 'n is not m' is the same as 'not n is m' but more reable.
    n, m = 1, 2
    print(n is not m, not n is m)      # True True
    # 'is' cannot be used with !.
# comparison()

#-------------------------------------------------------------

''' Copy:
There is no reasons to copy immutable values.
It is more efficient to alias immutable values. '''
def factory_copy():
    ## Factory methods of immutable types return the same value.
    ## Immutable types have no copy().
    x1 = 1
    x2 = int(x1)
    print(x1 is x2)         # True

    y1 = 'Hello'
    y2 = str(y1)
    print(y1 is y2)         # True

    t1 = (1, 2)
    t2 = tuple(t1)
    print(t1 is t2)         # True

    ## Factory methods and copy() of mutable values returns new values.
    a1 = [1, 2]
    a2 = list(a1)
    a3 = a1.copy()            # Try: a1[:]
    print(a1 is a2, a1 is a3) # False False

    s1 = {1, 2}
    s2 = set(s1)
    s3 = s1.copy()
    print(s1 is s2, s1 is s3) # False False

    d1 = {'a':1}
    d2 = dict(d1)
    d3 = d1.copy()
    print(d1 is d2, d1 is d3) # False False
# factory_copy()

## Shallow Copy VS Deep Copy:
def shallow_deep():
    ## 'Shallow Copy' copies bitwisely only the top level of value.
    ## copy() is shallow.
    a = [1, [2]]
    b = a.copy()
    print(a, b)			# [1, [2]], [1, [2]]
    a[1].append(3)
    print(a, b)			# [1, [2, 3]], [1, [2, 3]]

    ## 'Deep Copy' copies all levels of the value.
    ## copy.deepcopy() is deep.
    import copy
    a = [1, [2]]
    b = copy.deepcopy(a)
    print(a, b)			# [1, [2]], [1, [2]]
    a[1].append(3);
    print(a, b)     		# [1, [2, 3]] [1, [2]]
# shallow_deep()
