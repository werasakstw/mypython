''' A 'block' is a sequence of statements in a namespace.
Python uses indentation to define block scopes.
Statements in the same block must be equally indented. '''
# print('Hello')
# print('Bye')
#     print('Error')     # error

''' Python uses \n, \r, and ; as statement separators.
; at the end of line is not needed but not an error, mostly
 it is used for separating statements in the same line. '''
# print('Hello'); print('Bye')

''' Python controls such as 'for', 'while', 'if', 'else', and 'elif'
  create a nested block, which must begin with : . '''
if True:
    print('Hello')
else:
    print('Hi')

for i in range(3):
    print('Hello')
    print('Bye')

## A function has its body scope which must begin with a : .
def hello():
    print('Hello')
    print('Hi')

''' When a script file is executed, statements in globle scope
will be executed but function definitions are not executed.
To execute a function it must be explicitly invoked. '''
# hello()
