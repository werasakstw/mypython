print('Hello')

#  This is a one line comment.

''' This a multiple lines comment.
Evaluated at runtime to a string and ignored.
So one line comment is more favorable.
But multiple lines comments look better and colored red in most IDEs.

Multiple lines comments must be properly indented,
 while one line comments may appear freely.
'''

''' For our convention:
	#  is for test comment.
	## is for permanent comment.
Using multiple lines comment for document mades it stand out.

Toggling one line comment in VScodeand Atom:
                     ctrl+/
'''
