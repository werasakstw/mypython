## print(<arg>) evaluates <arg>, converts to a string and send to standard output.
# print(1+2)                  # 3

''' print() allows var-arg (accepts more than one arguments).
Arguments are generic(may be any types) and uses ',' as separator.
An extra space is added between argument values. '''
# print(1, '2', 3.0)      # 1 2 3.0

''' Python has no println().
By default, print() adds newline to the end of the line. '''
# print()
# print('John')
# print('Jack')

''' To print without newline, the 'end' argument is assigned with
  an end-of-line string. Python has no character type. '''
# print('Hello', end=' '); print('John')  # Hello John

## Consecutive strings with no separators are combined into a string.
# print('Hello' 'John')         # HelloJohn
## Beware of missing list separator.
# print(['a', 'b' 'c'])           # ['a', 'bc']

''' New line characters are allowed between arguments of print().
A '\' (line break) is not needed and no block identation.
That allows separating a long str into multiple lines. '''
# print('Hello',
# 'Jack')

## Since Python 3.5, new line characters are allowed in expression.
# print('Hello ' +
#   'Joe')

#--------------------------------------------------------------

# input() read a string from the keyboard.
# n = input('Enter a name: ')
# print('Hello', n)

# The input() result is a string.
# To read an integer, the result must be conversed with int().
# r = int(input('Enter a number: '))
# print(int(r) + 1, type(r))

# 'getpass' is for reading password (in standalone execution).
# import getpass
# print(getpass.getpass('Password: '))
