''' Text Mode Output:
print(<expression>) evaluates <expression>,
 converts to a string and send to the standard output. '''
print(1+2)

''' Python allows newline(\n), return(\r) and semicolon(;)
      as statements separator.
A semicolon at the end of statement is not needed but not an error.
A valid use of ';' is allow more than one statements in a line.
print() always add newline. So there is no println(). '''
# print('Hello'); print('Bye')

''' To print without newline, specify the attribute 'end' to be null. '''
# print('Hello', end=''); print('Bye')

''' print() allows variable length arguments (var-arg).
  that means accepting more than one parameters using ',' as the separator.
All parameters are printed in the same line, with an extra space between items. '''
# print('Hello', 'John')            ## Hello John

''' print() is generic that means arguments may be different types. '''
# print("Hello", 1, 2.0, True)      ## Hello 1 2.0 True

''' The operator '+' is overloaded for string appending. '''
# print("Hello " + "John.")

''' Interploration: a C-like format string.  '''
# print("This %s costs $%1.2f." % ("books", 12.345))
                        ## This books costs $12.35.

#--------------------------------------------------------

''' Input: Run in standard alone mode.
input() suppends the execution until <return> is enterred
It reads the input line and returns as a string.   '''
# s = input("Enter a name: ")
# print("Hello! %s." % s)

''' Other type input must be explicitly converted. '''
# n = int(input("Enter a number. "))
# print(n + 1)
