# Single Line Comment:
# The compiler will ignore the content after # to the end of line.

## A convention for 'document comment'.

# Triple Quote (''' or """) Strings can be used as multiple
#  line comments, but not the single and double quote strings.

''' Multiple Lines Comment:
Global triple quoted strings are evaluated at runtime.
Single line comments are ignored at compile time.

Idel:
Alt+3   comment the current line or selected lines.
Alt+4   uncomment the current line or selected lines.

Atom:
Clrl+/  comment/uncomment current or selected lines.
'''
print('Hello')
