''' 'type'(or data type) defines how to access a value of the type.
That includes operations allowed on the value.

Types may be built-in or user defined using mechanisms provided by the language.
Python use 'class' to define types.
Python has no primitive types, all values are created as objects of a class.

Python is a pure object-oriented language, but tries (very hard) not to look like one.
So in some text books, 'object/instance' is called 'veriable' and 'class' is called 'type'.

All Python classes are implemented as objects of class 'type'.
The built-in function type(<arg>) returns the class of <arg>.  '''
# print(type(int), type(str))  # <class 'type'> <class 'type'>
# print(type(1), type('1'))    # <class 'int'> <class 'str'>

''' The most commonly used built-in types:
        Number: int, float, boolean and complex.
        Collection: str, list, tuple, set, and dict. (There are a lot more).
Python has no byte, short, long, double and char.

All built-in types implement a 'factory' function, which is used for
        - Create default or empty values.
        - Type conversions.  '''
def default_values():
    print(bool())           # False
    print(int())            # 0
    print(float())          # 0.0
    print(str())            # <empty str>
    print(list())           # []
    print(tuple())          # ()
    print(set())            # set()
    print(dict())           # {}
# default_values()

def type_conversions():
    ## bool: Values are False if it is zero or empty, and True otherwise.
    print(bool(0), bool(''), bool([]))        # False False False
    print(bool(1), bool('hello'), bool([1]))  # True True True

    ## int:
    print(int(False), int(1.2), int('2'))       # 0 1 2

    ## float:
    print(float(True), float(1), float('1.2'))  # 1.0 1.0 1.2

    ## str:
    print(str(True), str(1), str(1.2))          # True 1 1.2
# type_conversions()

#------------------------------------------------------------------

''' Typed Languages: performs type checking to ensure that the operand types
 must be correspond to the operator. Python is a 'typed language',
 but not all type errors can be detected at compile time.

Mix-mode expressions allow operations for operands of different types e.g. 1 + 1.0.
Python performs automatic type conversion for Number types: bool, int and float. '''
# print(True + 1, 1 + 1.2, 1.2 + False)     # 2 2.2 1.2

## Mix-mode is not allowed for non-numberic type, explicit conversion is needed.
# print(1 + '2')            # error
# print(1 + int('2'))       # 3
# print(str(1) + '2')       # 12

''' 'coercion' is automatic type conversion that converts a value of
 any types to bool for using as condition. '''
def coercion():
    x = 1
    if x:           # x != 0
        print('Not Zero')           # Not Zero

    if not x:       # x == 0
        print('Zero')

    a = [0]
    if a:           # len(a) > 0
        print('Not Empty')          # Not Empty
    if not a:       # len(a) == 0
        print('Empty')

    # Coercion should be used in condition only, not in expression nor comparisons.
##    print(a + True)                  # error
    print(x and False, x or True, a and False, a or True) # False 1 False [0]
    print(x == True, a == True)      # True False
# coercion()

####################################################################

''' Python supports a lot of data structures e.g.
     array    Sequence of homogeneous data type
     heapq    Min Heap
     bisect   Sorted List
     queue    Thread Safe Queue
     struct   Binary Data Structures

'collections' module provides a lot of data structures e.g.
    ChainMap, Counter, defaultdict, namedtuple, deque, OrderedDict

'''
