''' A 'statement' is a unit of execution that the execution flows
 through sequentially. e.g. assignment, control, function/class definitions.
'Block' is a sequence of statements in the same scope.  '''
def statements():
    ''' Assignments are of the form:   <variable> = <expression>
    The value of <expression> is assigned to the <variable>. '''
    x = 1 + 2

    ## 'if' control is a statement.
    if x > 0:
        print(x)

    ''' Function definition is a statemt, it creates function objects in the scope.
    The function is not executed when created, it must be explicitly invoked. '''
    def hello():
        print('Hello')
    ## Function calls are expression that can be in statement context.
    hello()

    ''' Statements do not return a value, not even a None.
    Statements cannot appaer in the context of expression e.g. argument. '''
    # print(x = 1)               # error

    ## Conditions (of 'if' and 'while') must be expressions..
    # if x = 1:
    #     print('one')

    ## Python allows multiple assignments (right associative).
    x = y = 1

    ## () breaks multiple assignments syntax.
    # x = (y = 1)                   # error
# statements()

def assignment_expression():
    ''' input() is an expression, the result is normally assigned to a variable.
     Assinments cannot be conditions. '''
    # while s = input('Enter: '):   # error
    #     print(s)

    ## Therefore commonly used 'input' loops are so clumsy.
    s = input('Enter: ')
    while s != '':
        print(s)
        s = input('Enter: ')

    ## Python 3.8 introduced Assignment Expression ':='.
    while s := input('Enter: '):
        if s == '':
            break
        print(s)
# assignment_expression()

''' An 'expression' is evalulable into a value.
Expressions may be literal, variable, operator expression and function call. '''
def expression():
    ## The left hand side of assignment and arguments must be expression.
    x = 1
    print(0, x, x+1)

    ## Expressions may appear at statement level, its value is ignored.
    0
    x
    x + 1

    ''' Projections are operations to access elements in objects.
        e.g. list/tuple indexing and accessing object elements.
    Since projections return values they must be expressed as expressions.  '''
    a = [1, 2, 3]
    a[0]

    ## 'for' loop is a statement.
    for x in range(3):
        print(x)
    ## Comprehension is an expression since it returns a value.
    print([x for x in range(3)])

    ## None is a value(for no values), it may appear in context of expression.
    None
    print(None)

    ## 'pass' is a statement(for no statements), cannot be in context of expression.
    pass
    # print(pass)           # error
# expression()
