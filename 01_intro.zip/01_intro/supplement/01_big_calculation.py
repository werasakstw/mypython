''' Python stores a small value integer in 32 bits or 64 bits
 depends on the cpu word size. But the storage may increase
 as needed as long as memory still available.   '''
# print(123**1234)

''' Ex. How many billion(10**9) years, 2**64 seconds is? '''
# seconds = 2**64
# minutes = seconds / 60              ## 1 minute = 60 seconds
# hours = minutes / 60                ## 1 hour = 60 minutes
# days = hours / 24                   ## 1 day = 24 hours
# years = days / 365.25               ## 365.25 day = 1 year
# billion_years = years / 1_000_000_000    ## Embedded underscore.
                       ## 1_000_000_000 years = 1 billion year
# print(billion_years)                ## 584.5420460906263

''' String formatting '''
# print('2**64 = %.2f billion_years' % billion_years)
                              ## 2**64 = 584.54 billion_years
''' Function string  '''
# print(f'2**64 = {billion_years:.2f} billion_years')
                              ## 2**64 = 584.54 billion_years

''' Exercise:
1. ชื่อบริษัท Google มาจากคำว่า googol ซึ่งเท่ากับ 10 ยกกำลัง 100 คือ 10**100
        จงคำนวณ 1 googol วินาทีเท่ากับกี่ billion(10**9) ปี

 2. ชาวตะวันตกเชื่อว่า 6 เป็นเลขอาถรรพ์ และ 666 เป็นเลขชั่วร้ายสุดๆ
        จงคำนวณว่า 666**666 กับ 6**(6**6) ค่าใดมากกว่า

 3. ในทวีปยุโรป 1 billion มีค่าเท่ากับ 1 ล้านล้าน (คือ 10**12)
    แต่ในอเมริกา 1 billion มีค่าเท่ากับ 1 พันล้าน (คือ 10**9)
 กำหนดให้ 1 นาทีมี 60 วินาที 1 ชั่วโมงมี 60 นาที 1 วันมี 24 ชั่วโมง และ 1 ปีมี 365.25 วัน
 สมมติว่า คนทุกคนหายใจหนึ่งครั้งทุกวินาที ตั้งแต่เกิด และไม่หยุดหายใจจนตาย
 คนยุโรปจะไม่สามารถมีอายุอยู่ถึงตอนที่หายใจครั้งที่ 1 billion (10**12)
      แต่คนอเมริกันจะหายใจครั้งที่ 1 billion (10**9) ตอนอายุประมาณกี่ปี

 4. Alpha Centauri คือกลุ่มดาวที่อยู่ห่างจากโลกประมาณ 4.37 ปีแสง (light year)
    1 ปีแสง คือระยะทางที่แสงเดินทางหนึ่งปี มีค่าประมาณ 9.4605284 × 10**12 กิโลเมตร
 เครื่องบินเจ็ท MIG-25 ทำความเร็วได้สูงสุด 3,089 กิโลเมตร/ชั่วโมง
 สมมติว่า MIG-25 สามารถทำความเร็วสูงสุดออกจากโลกไปตลอดเส้นทาง โดยน้ำมันไม่หมด
 จงคำนวณว่า MIG-25 ต้องใช้เวลากี่ปี จึงจะไปถึง Alpha Centauri
 '''
