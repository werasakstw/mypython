''' 'Factories' are methods with the same name as the type(class).
All built-in type implements 'factory' methods.
Mostly 'factories' are used for:
     - Creating object of the class with default values.
     - Type conversions.    '''
def default_values():
    print(bool())           ## False
    print(int())            ## 0
    print(float())          ## 0.0
    print(str())            ## <empty str>
    print(list())           ## []
    print(tuple())          ## ()
    print(set())            ## set()
    print(dict())           ## {}
# default_values()

def type_conversions():
    ''' bool: Values are False if it is zero or empty, and True otherwise. '''
    print(bool(0), bool(''), bool([]))          ## False False False
    print(bool(1), bool('hello'), bool([1]))    ## True True True

    ''' Factories converts other types to the type, if valid. '''
    print(int(False), int(1.2), int('2'))       ## 0 1 2
    print(float(True), float(1), float('1.2'))  ## 1.0 1.0 1.2
    print(str(True), str(1), str(1.2))          ## True 1 1.2
# type_conversions()
