''' All literals have characteristic that indicate the type.
Compilers can determine the literal's type at the compile time. e.g.
       1                 int
       1.0               float
       True              bool
       1+2j              complex
       'Hello'           str  (string type)
       [1, 2]            list
       (1, 2)            tuple
       {1, 2}            set
       {'a':1, 'b':2}    dict        '''
       
def int_bases():
    ''' Python allows number based 'int' literals with prefixed.  '''
    print(10)	        ## 10   decimal (default)
    print(0b10)	        ## 2    binary
    print(0o10)	        ## 8    octal
    print(0x10)	        ## 16   hexadecimal

    ''' Built-in functions to converse decimal value to specified base. '''
    print(bin(10))	     ## 0b1010
    print(oct(10))	     ## 0o12
    print(hex(10))	     ## 0xa

    '''  int(<str>) creates an int object with value of <str> in decimal base.
         int(<str>, <base>) creates an int value of <str> in <base>.  '''
    print(int('007'))       ## 7
    print(int('100', 2))    ## 4
    print(int('100', 5))    ## 25
    print(int('a', 16))     ## 10
    # print(int('a', 10))   ## error: no 'a' in base 10.
# int_bases()

''' Python creates an 'int' value as a PyIntObject for small integers
  (-5 -> 256), its memory size varies with versions and os.
Bigger integers are created with increasing size as needed.
sys.getsizeof(<var>) returns the size of <var> in bytes.  '''
import sys
def int_size():
    print(sys.getsizeof(2))           ## 28
    print(sys.getsizeof(2**10))       ## 28
    print(sys.getsizeof(2**100))      ## 40
    print(sys.getsizeof(2**10000))    ## 1360
# int_size()

''' Problem with float computation: Do not compare exact floats. '''
x = 0.1 + 0.2
# print(x, x == 0.3)         ## 0.30000000000000004  False

''' Floats should be compared by 'relative comparison'.
Python allows ternary operators. '''
# print(0.29 < x < 0.31)      ## True

''' Divide by 0(int) or 0.0(float) are ZeroDivisionError.
Python has no undefined, Infinity and NaN.  '''
# print(1/0.0)               ## error

''' Embedded Underscore:
'int' and 'float' literals allow embedded _ within digits.
That do not affect the values just improve readablility. '''
def underscore_embedded():
    print(1_000)                    ## 1000
    print(1_000.00)                 ## 1000.0
    print(0b1000_1100_1110_1111)    ## 36079
    print(0x8C_EF)                  ## 36079
# underscore_embedded()

''' 'None' is a literal for representing no value, not empty value. '''
def none():
    n = None
    ''' None is converted to False in conditions. '''
    if not n:
        print('None')        ## None

    ''' None is not equal to False and not an Empty value.  '''
    print(n == False)        ## False
    print(n == [])           ## False

    ''' None should not take part in any expressions.  '''
    print(n and False)       ## None
    # print(n + 1)           ## error
# none()
