
print('I am hello.py')

def main():
    print('I am main().')
