
def main():
	print('This is the starting point of the app.')

if __name__ == '__main__':
	main()