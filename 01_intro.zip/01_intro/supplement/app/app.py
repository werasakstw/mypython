''' Python files are supposed to be used as:
    - scripts (applications) which is executed by the python.exe.
    - modules (libraries) which is imported by others.

Python programs do not have a main() as the starting point.
Statements at the top level will be executed when the script is executed
 or the module is imported. e.g.
Ex. hello.py is in the working directory.
Try:  python hello.py
    Only the print('I am hello.py') is executed, but main() is not.

Try: importing hello.py  '''
# import hello

## print('I am hello.py') is also executed

#----------------------------------------------

## All python file(.py) has attributes __name__, __file__.
def attr_test():
    print(__name__)     ## __main__
    print(__file__)     ## C:\mypython\src\01_intro\supplement\app\app.py
# attr_test()

## Try: imported file the __name__ will be the file name.
# import name

#--------------------------------------------------

''' Modules are created to be imported. But some must be executable by itself,
 e.g. as for testing.
Python proposed a pattern for a file that can be both script and module as:
  - No statements at top level.
  - Has a main() for starting point.
  - Has an 'if' statement to execute main() if it is executed as a script.
Try: python app_main.py

Try: Importing app_main.py module, the main() would not be executed. '''
# import app_main

#----------------------------------------------------------------

''' Python Application:
An application may have many files(modules) and created as a package.
Python allows specifying the application's main script (the first to be executed)
 by creating a __main__.py in the package directory.
The application is executed with option -m.
Normally __main__.py would not be imported so the 'if' statement is not needed.
Try:  python -m myapp       '''
