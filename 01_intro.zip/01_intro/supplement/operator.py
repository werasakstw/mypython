﻿''' Arithmetic Operators:
 + addition,   - subtraction,  * multiplication,   ** power
If both operands are int, the result is an int.
If one or both operands are float, the result is a float.
'''
def arithmetic_op():
    print(1 + 2)          # 3
    print(4 ** 0.5)	      # 2.0

    # / is floating point division returns a float.
    print(3 / 2)          # 1.5

    # // is integer division returns the quotient as an int.
    # It may be applied to floats and results in float.
    print(3 // 2)         # 1
    print(3.0 // 2.1)     # 1.0

    # % returns the remainder as an int or float.
    print(5 % 2)          # 1
    print(5.0 % 2.5)      # 0.0

    # Python functions may retrn a tuple.
    # divmod() returns a tuple of quotient and remainder.
    q, r = divmod(5, 2)
    print(q, r)	          # 2, 1
# arithmetic_op()

#-----------------------------------------------------------------

''' In-Place Operators:  (produces side effect)
           <variable> <op>= <expression>
        +=   -=   *=   /=   //=   %=   **=
'''
def inplace_op():
    a = 1
    a += 1          # same as a = a + 1
    print(a)        # 2

    a *= 2
    print(a)        # 4
# inplace_op()

#-----------------------------------------------------------------

''' Logical Operators:
    not        unary negation
    and        conditional and
    or         conditional or
The operands and result are boolean.
Logical operators cannot be applied as in-place.
'''
def logical_op():
    print(not True)         # False
    print(True and True)    # True
    print(True or False)    # True
# logical_op()

''' Expression are evaluated from left to right.
If the result can be determined before finishing the
expression the evaluation of the rest may be ignored.
'''
def short_circuit():
    def true_func():
        print("true_func()")
        return True

    def false_func():
        print("false_func()")
        return False

    print(true_func() or false_func())  # true_func() True
    print(false_func() or true_func())  # false_func() true_func() True
    print(true_func() and false_func()) # true_func() false_func() False
    print(false_func() and false_func())# false_func() False

    # Short-cut can be used to prevent devided by zero.
    x = 1; y = 0
    # print(x // y)             ## error: div by zero
    print(y != 0 and x // y)    ## False
# short_circuit()

#-----------------------------------------------------------------

''' Bitwise Operators:
   ∼  bitwise complement (prefix unary operator)
   &  bitwise and
   |  bitwise or
   ^  bitwise exclusive-or
The operands and result are int.
'''
def bit_op():
    a = 0b01
    b = 0b11
    x = a & b
    y = a | b
    z = a ^ b
    print(x, bin(x))        # 1 0b1
    print(y, bin(y))        # 3 0b11
    print(z, bin(z))        # 2 0b10

    # Bitwise operators may be in-place.
    # Any values that exclusive-or to itself result a zero.
    a ^= a
    print(a)  # 0
# bit_op()

''' Bit-Shift Operators.
  x << n     shifted left n bits, filling in with zeros
          ==  x * 2**n        multuplied by 2 to the power of n
  x >> n     shifted right n bits, filling in with zeros
          ==  x / 2**n        divided by 2 to the power of n
Bit shift allows multiply and divide integers by multiple of 2.
'''
def bit_shift():
    x = 1
    for _ in range(5):
        x <<= 1
        print(x, end=', ')   # 2, 4, 8, 16, 32,
    print()

    for _ in range(5):
        x >>= 1
        print(x, end=', ')   # 16, 8, 4, 2, 1,
# bit_shift()

#-----------------------------------------------------------------

''' Comparison Operators:
     <   less          <=    less equal
     >   greater       >=    greater equal
     ==  equal         !=    not equal
May be mix_mode, the result are alway boolean.
Comparison operators cannot be in-place.
Numeric operands are compared by cardinal order.
String operands are lexicographically compared.
An exception is raised if the operands are incomparable types. '''
def comp_op():
    print(1 == 1.0)             # True         equal to
    print(False < True)         # True         less than
    print('jack' <= 'john')     # True         less than or equal to
    print(1 > True)             # True         greater than
    print(0 >= 0.0)             # True         greater than or equal to

    # Python allows comparison expressions.
    x = 1; y = 12
    print(0 < x < 10 < y)	# True
# comp_op()

###################################################################

''' Exercises:
How many billion(10**9) years are 2**64 seconds?
'''
def ex():
    seconds = 2**64
    minutes = seconds / 60              # 1 minute = 60 seconds
    hours = minutes / 60                # 1 hour = 60 minutes
    days = hours / 24                   # 1 day = 24 hours
    years = days / 365.25               # 365.25 day = 1 year
    billion_years = years / 1_000_000_000  # embedded underscore
                            # 1_000_000_000 years = 1 billion year
    print(billion_years)

    # String formatting
    print('2**64 = %.2f billion years' % billion_years)

    # Function string
    print(f'2**64 = {billion_years:.2f} billion year')
# ex()

#-------------------------------------------------------

'''
1. Semantics of // and %
For q = n // m and r = n % m, that means q * m + r == n.
Python guarantees that:
   For m is positive, 0 ≤ r < m.
   For m is negative, m < r ≤ 0.
'''
# print(-27 // 4, -27 % 4)        # -7 1
# print(27 // -4, 27 % -4)        # -7 -1

'''
2. Precedence:
For expression,    <operand_1> <op1> <operand_2> <op2> <operand_3>
If it is evaluated as ((<operand_1> <op1> <operand_2>) <op2> <operand_3>)
Then the operator <op1> has more priority than <po2>, else otherwise.

          Order of Precedence in Python
1. Tuple, List and Dictionary creations.
2. Indexing and Slicing operations.
3. Bracket: (), [], {}.
4. Attribute Accessing: .
5. Function invocation.
6. Arithmetic operators: unary(-), exponential(^), (*, /), and (+, -)
7. Bitwise operators.
8. Comparison and Identity operators.
9. Logical operators
10. Anonymous operators

3. Associative:
For expression,    <operand_1> <op> <operand_2> <op> <operand_3>
If it is evaluated as ((<operand_1> <op> <operand_2>) <op> <operand_3>)
   Then the operator <op> is left associative.
If it is evaluated as (<operand_1> <op> (<operand_2> <op> <operand_3>))
   Then the operator <op> is right associative.
'''
#--------------------------------------------------------------

# Ex:
# Given an integer n, compute the following expression:
#      ((((n * 2) - 16) * 4) / 8) + 15 - n
def seven_up1(n):
    a = n * 2
    b = a - 16
    c = b * 4
    d = c // 8
    e = d + 15
    return e - n
# print([seven_up1(i) for i in range(10)])

# If a variable is not used anymore, we should reuse it.
def seven_up2(n):
    a = n * 2
    a = a - 16
    a = a * 4
    a = a // 8
    a = a + 15
    return a - n
# print([seven_up2(i) for i in range(10)])

# Using bit shift operatopns.
def seven_up3(n):
    a = n * 2
    a -= 16
    a <<= 2         ## a *= 4
    a >>= 3         ## a //= 8
    a += 15
    a -= n
    return a
# print([seven_up3(i) for i in range(10)])

# Using parentheses to override the precedence and associative rules.
def seven_up4(n):
    return ((((n * 2) - 16) * 4) // 8) + 15 - n
# print([seven_up4(i) for i in range(10)])
