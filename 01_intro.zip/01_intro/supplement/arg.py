''' Many python applications are designed to be started from
 command prompt. The command line arguments are passed as sys.argv. '''

import sys
print(len(sys.argv))
for n in sys.argv:
    print('Hello', n)

## python arg.py john jack joe
