''' Ex. Seven Up: Let's compute the following expression.
        Given an integer n,
                  ((((n * 2) - 16) * 4) / 8) + 15 - n
'''
def seven_up1(n):
    a = n * 2
    b = a - 16
    c = b * 4
    d = c // 8          ## Try: /
    e = d + 15
    return e - n
# print(seven_up1(12345))

''' Input Test. '''
def seven_up_input():
    n = int(input('Enter a number: '))
    print(seven_up1(n))
# seven_up_input()

''' If a variable value is not needed anymore, it should be reused. '''
def seven_up2(n):
    a = n * 2
    a = a - 16
    a = a * 4
    a = a // 8
    a = a + 15
    return a - n
# print(seven_up2(12))

''' In-place operators.  '''
def seven_up3(n):
    a = n * 2
    a -= 16
    a *= 4
    a //= 8
    a += 15
    a -= n
    return a
# print(seven_up3(123))

''' Bit-shift Operator. '''
def seven_up4(n):
    a = n * 2
    a -= 16
    a <<= 2             ## a *= 4
    a >>= 3             ## a //= 8
    a += 15
    a -= n
    return a
# print(seven_up4(1234))

''' Expressions are evaluated with precedence and associative rules.
e.g.      x + y + z      -->    (x + y) + z
          x + y * z      -->    x + (y * z)             '''
# print(1 + 2 - 3)            ## 0
# print(1 + 2 * 3)            ## 7

''' Parentheses override the precedence and associative rules. '''
def seven_up5(n):
    # return n * 2 - 16 * 4 // 8 + 15 - n
    return ((((n * 2) - 16) * 4) // 8) + 15 - n
# print(seven_up5(12345))

#----------------------------------------------------------------

''' Ex. Favarite Number
Ask your friend what is the favarite number, from 0 to 9.
Suppose the answer is n.  Then compute 12345679 * n * 9      '''
# n = int(input('Eneter a number: '))
# print('%10d' % (12345679 * 9 * n))
