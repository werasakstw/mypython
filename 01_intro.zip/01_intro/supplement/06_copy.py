''' There is no reasons to copy immutable values
 since it can be shared safely and more efficient. '''
def factory_copy():
    ''' Factory methods of immutable types return the same value.
    Immutable types have no copy().  '''
    x1 = 1
    x2 = int(x1)
    print(x1 is x2)         ## True

    y1 = 'Hello'
    y2 = str(y1)
    print(y1 is y2)         ## True

    t1 = (1, 2)
    t2 = tuple(t1)
    print(t1 is t2)         ## True

    ''' Factory methods and copy() of mutable values returns new values. '''
    a1 = [1, 2]
    a2 = list(a1)
    a3 = a1.copy()    ## Try: a1[:]
    print(a1 is a2, a1 is a3) ## False False

    s1 = {1, 2}
    s2 = set(s1)
    s3 = s1.copy()
    print(s1 is s2, s1 is s3) ## False False

    d1 = {'a':1}
    d2 = dict(d1)
    d3 = d1.copy()
    print(d1 is d2, d1 is d3) ## False False
# factory_copy()

''' Shallow Copy VS Deep Copy:  '''
def shallow_deep():
    ''' 'Shallow Copy' bitwisely copies value.
      copy() is shallow that means only the top level of value is copied. '''
    a = [1, [2]]
    b = a.copy()
    print(a, b)			## [1, [2]], [1, [2]]
    ''' Modification to element causes side effect. '''
    a[1].append(3)
    print(a, b)			## [1, [2, 3]], [1, [2, 3]]

    ''' 'Deep Copy' copies all levels of the value.
       copy.deepcopy() is deep that prevents side effect. '''
    import copy
    a = [1, [2]]
    b = copy.deepcopy(a)
    print(a, b)			# [1, [2]], [1, [2]]
    a[1].append(3);
    print(a, b)     		# [1, [2, 3]] [1, [2]]
# shallow_deep()
