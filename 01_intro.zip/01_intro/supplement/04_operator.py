''' Arithmetic Operators:
      + addition,   - subtraction,  * multiplication,   ** power
If both operands are int, the result is an int.
If one of operands are float, the result is a float.  '''
def ari_op():
    print(1 + 2)          ## 3
    print(4 ** 0.5)	      ## 2.0

    ''' / is floating point division returns a float. '''
    print(3 / 2)          ## 1.5

    ''' // is integer division returns the quotient as an int.
    But may be applied to floats and results in float.  '''
    print(3 // 2)         ## 1
    print(3.0 // 2.1)     ## 1.0

    '''  % is the remainder opertor.
    If both operands are int, the result is an int.
    If one of operands are float, the result is a float. '''
    print(5 % 2)          ## 1
    print(5 % 2.5)        ## 0.0

    ''' divmod() returns a tuple of (quotient, remainder).  '''
    q, r = divmod(5, 2)
    print(q, r)	          ## 2, 1
# ari_op()

'''  In-Place Operators: causes side effect to the <variable>.
           <variable> <op>= <expression>
        +=   -=   *=   /=   //=   %=   **=                  '''
def in_place():
    a = 1
    a += 1     ## Same as:  a = a + 1
    print(a)        ## 2

    a *= 3
    print(a)        ## 6
# in_place()

''' Logical Operators:
            not        unary negation
            and        conditional and
            or         conditional or
The operands and result are boolean.  '''
def logical_op():
    print(not True)         ## False
    print(True and True)    ## True
    print(True or False)    ## True
# logical_op()

''' 'Short Cicuit' is a feature that expressions do not need to perform
       all operations if the result can be inferred. '''
def short_circuit():
    def true_func():
        print("true_func()")
        return True

    def false_func():
        print("false_func()")
        return False

    print(true_func() or false_func())   ## true_func() True
    print(false_func() or true_func())   ## false_func() true_func() True
    print(true_func() and false_func())  ## true_func() false_func() False
    print(false_func() and false_func()) ## false_func() False
# short_circuit()

''' Bitwise Operators:
           ∼  bitwise complement (prefix unary operator)
           &  bitwise and
           |  bitwise or
           ^  bitwise exclusive-or
The operands and result are int.     '''
def bit_op():
    a = 0b01
    b = 0b11

    x = a & b; print(x, bin(x))        ## 1 0b1
    y = a | b; print(y, bin(y))        ## 3 0b11
    z = a ^ b; print(z, bin(z))        ## 2 0b10
# bit_op()

''' Bit-Shift Operators.
  x << n     shifted left n bits, filling in with zeros
          ==  x * 2**n        multuplied by (2 to the power of n)
  x >> n     shifted right n bits, filling in with zeros
          ==  x / 2**n        divided by (2 to the power of n)
Bit shift allows efficient multiply and divide by multiple of 2.  '''
def bit_shift():
    x = 1
    x <<= 1; print(x)              ## 2
    x <<= 1; print(x)              ## 4
    x <<= 1; print(x)              ## 8

    x >>= 1; print(x)              ## 4
    x >>= 1; print(x)              ## 2
    x >>= 1; print(x)              ## 1
# bit_shift()

''' Comparison(Relative) Operators:
             <   less          <=    less equal
             >   greater       >=    greater equal
             ==  equal         !=    not equal
May be mix_mode, the result are alway boolean.
Numeric operands are compared by cardinal order.
String operands are lexicographically compared.
An exception is raised if the operands are incomparable types. '''
def comp_op():
    print(1 == 1.0)             ## True         equal to
    print(False < True)         ## True         less than
    print('jack' <= 'john')     ## True         less than or equal to
    print(1 > True)             ## False        greater than
    print(0 >= 0.0)             ## True         greater than or equal to

    ''' Python allows ternary comparison expressions.  '''
    x = 1; y = 12
    print(0 < x < 10 < y)	     ## True
# comp_op()
