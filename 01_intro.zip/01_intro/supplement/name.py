'''
All Python variables, functions, classes, and objects have names.
Names are case sensitive and contain only the following:
  Lowercase letters (a through z)
  Uppercase letters (A through Z)
  Digits (0 through  9)
  Underscore '_'
Names cannot begin with a digit and cannot contain special symbols
 such as:   $, &, %, # ^, ! and spaces.
 '''
_x = 1
# 1x = 1        # error
# x$ = 1        # error
# x y = 1       # error
# if = 1        # error

''' Python Reserved Words:
Reserved words cannot be used as names.
   False    class      finally   is 	    return
   None     continue   for       lambda    try
   True     def        from      nonlocal  while
   and      del        global    not       with
   as       elif       if        or        yield
   assert   else       import    pass      break
   except   in         raise
help(<name>) is a built-in function to print the help of <name>.
There is no help for reserved words.
'''
# help(_x)
# help(print)   # 'print' is a built-in function
# help(if)      # error

# dir(<name>) returns the properties of the <name>.
# print(dir(_x))  # as a list

#--------------------------------------------------------------------
''' Naming Convention: does not impose syntax rules.

Public names should be meaningful.
Local names should be concise.

Underscore separator is more readable than camel case.

Variable, function and type names should begin with a lower case letter.
User-defined Class names should begin with an upper case letter and may be camel case.
Constant names should be capitalized.

Function names that begin with 'get' return a value.
Function names that begin with 'is' return a boolean.
Function names that ended with 'by' siginifies the parameter as input.

Single Leading Underscore, eg _x is intended for internal use that should not
  be referred to by other programmers.

Single Trailing Underscore, eg if_ is used when the name is already taken or it is a keyword.

Single Underscore names, _ is used in a "don’t care" name.

PEP 8 recommended wildcard imports should be avoided.
'''
