'''  'Variable' is a named storage of value.
A variable has 'name', 'identifier'(or address) and 'value'.
Identifiers can be anything that can be used for accessing the values.
CPython identifier is the memory address that store the value.
Identifiers should not be handled directly, they may vary with implementations. '''
def variable():
    ''' A variable is created when its name is assigned a value for the first time.
    Assignment assigns address of value 1 to the identifier of 'x'. '''
    x = 1         ## A variable definition.

    ''' In value context(places where value is expected e.g right-hand side of assignment)
          'name' is mapped(de-referenced) to 'value'. '''
    print(x)            ## 1

    ''' In reference context(places where reference is expected e.g left-hand side of assignment)
            'name' is mapped(referenced) to 'identifier'. '''
    x = x + 1
    print(x)            ## 2
# variable()

''' Python is a typed language, since type checking is performing before operation
      and invalid types are rejected.
But a variable type may change as needed. '''
def dyn_type():
    ''' Initially a variable types is the type of the assigned value. '''
    x = 1

    ''' id(<var|value>) returns the 'identifier'of <var|value>.
        type(<var|value>) returns the type of <var|value>.   '''
    print(id(x), type(x))           ## 140716258816808 <class 'int'>

    ''' All values have associated type and cannot be changed.
    The type is belonged to the value, not to the variable.
    A variable may change its value even with different types, that will be
       fine as long as opertions on the variables are type valid. '''
    print(x, type(x))       ## 1 <class 'int'>
    x /= 10
    print(x, type(x))       ## 0.1  <class 'float'>
# dyn_type()

''' Python creates variable dynamically that is when its definition is encountered. '''
def dyn_create():  ## A function definition creates its scope.
    a = 1   ## 'a' is created in the current scope.

    ''' dir() returns a list of names in the current scope. '''
    print(dir())         ## ['a']
    b = 2
    print(dir())         ## ['a', 'b']

    ''' If the definition is not executed the variable is not created.
    Control blocks do not create a new scope. '''
    if a > 1:
        x = 3
    else:
        y = 4
    print(dir())        ## ['a', 'b', 'y']
# dyn_create()

#-------------------------------------------------------

''' 'Alias' is the condition that two or more vatiables share the same value.
That means their identifiers point to the same value.
Python assignment and parameter passing are performed by reference. '''
def alias():
    x = 1            ## 'int' is immutable.
    y = x            ## 'x' and 'y' are alias.
    print(id(x) == id(y))   ## True

    ''' If the shared value is immutable, modification results broken alias. '''
    x += 1
    print(id(x) == id(y))   ## False

    a = [1]          ## 'list' is mutable.
    b = a            ## 'a' and 'b' are alias.
    print(id(a) == id(b))   ## True

    ''' If the shared value is mutable, modification maintain alias. '''
    a += [2]
    print(id(a) == id(b))   ## True
# alias()

''' Interning (Value Pool):
To keep the number of values low, Python creates a pool to prevent
  creating duplicated values. During compile time, when a value is encountered
  it is checked, if it is not in the pool it will be added to the pool but
  if it is already in the pool the value is used.
Python performs interning for Number and str only, not for other types. '''
def intern():
    x, y = 1, 1
    print(id(x) == id(y))      ## True

    ''' Other types (e.g. list) are non-interned. '''
    a, b = [1], [1]
    print(id(a) == id(b))      ## False

    ''' User defined types are non-interned. '''
    class A: pass       ## Create an empty class.
    a1 = A()            ## Create two ojects of class A.
    a2 = A()
    print(id(a1) == id(a2))    ## False
# intern()

''' Interning is performed if the value is known at compile time.
Values that created at runtime are not interned. '''
def static_intern():
    a = 1.0
    b = 0.5 + 0.5    ## performed at compile time.
    print(id(a) == id(b))   ## True

    s = 'Hello'
    v = 'He' + 'llo' ## performed at compile time.
    print(id(s) == id(v))   # True

    w1 = 'He'
    w2 = 'llo'
    w = w1 + w2       ## performed at runtime
    print(id(s) == id(w))   # False
# static_intern()

#----------------------------------------------------------------

''' Python supports two kinds of comparisons.
  1. == and != compares values.
        x == y is True, if x and y have the same values.

  2. 'is' and 'is not' compares identifiers.
        x is y is True, if x and y point to the same value.
    That means if id(x) == id(y).

'is' is more efficient since compare references.
But it is unsafe for dynamic values and non-interned values.
Interning is undocumented, different Python implementations may use
  different techniques. So it is safer to use == .

'is' is used mostly for checking if variables are alias. '''
def comparison():
    ''' Compare interned values.  '''
    x = 1; y = 1
    print(x == y, x is y)   # True True

    ''' Compare dynamic values(created at runtime).  '''
    z = (x+y)/2
    print(x == z, x is z)   ## True False

    ''' Compare non-interned value. '''
    a = [1, 2]
    b = [1, 2]
    print(a == b, a is b)    ## True False

    ''' Set is value-oriented.  '''
    x = {1, 2}
    y = {2, 1}
    print(x == y, x is y)    ## True False

    ''' 'n is not m' is the same as 'not n is m' but more reable.
    'is' cannot be used with !.  '''
    n, m = 1, 2
    print(n is not m, not n is m)      ## True True
# comparison()
