''' 'Type' defines how to access a value that implies allowed operations
  and memory layout.
All values are associated with its type.
Python implements types using class, no primitive types.

The most commonly used built-in types:
    1. Number: int, float, boolean and complex.
    2. Sequence: str, list, tuple, set, and dict. (There are a lot more).
Python has no byte, short, long, double and char.
--------------------------------------------------------

'Literals' are texts in source codes that represent values.

'bool' literals are True and False.
type(<arg>) returns the type of <arg> which may be literal, variable or type. '''
# print(True, type(False))    ## True <class 'bool'>

'''  'int' literal represents integer value which is a sequence
  of digits (0-9) that do not begin with 0 and contain no decimal point.  '''
# print(1, type(1))       ##  1 <class 'int'>
# print(012)              ## error

'''  'float' literal represents floating-point value.
There are two representations:
    - floating-point notation  e.g  1.23
    - scientific notation      e.g  1.2e3
Zero trailing are optional. '''
# print(1.230, 1.23e4)           ## 1.23  12300.0

#------------------------------------------------------------------

''' A type may be either:
    - Immutable: values can not be modified. e.g. Numbers, str and tuple.
    - Mutable: values may be modified. e.g. list, set, and dict.  '''
def immutable():
    ''' id(<var>) returns address of the <var>.  '''
    x = 1         ## 'int' is immutable.
    print(id(x), x)     ## 1692706736 1

    ''' Operation on immutable value results a new value.
    The address of new value is assigned to the identifier of 'x'. '''
    x = x + 1
    print(id(x), x)     # 1692706768 2
# immutable()

''' Mutable types have methods to modify their values.
The modification is performed on the value, no new value created. '''
def mutable():
    a = [0]         ## 'list' is mutable.
    print(id(a), a)     ## 62217640 [0]

    ''' append() results side effect on the value. '''
    a.append(1)
    print(id(a), a)     ## 62217640 [0, 1]
# mutable()

''' If a value is mutable, it can be modified even it is in an immutable collection. '''
def mutability():
    t = ([1], [2])    ## Tuple is an immutable type.
    # t.append(3)     # error

    ''' But modify its element is allowed since 'list' is mutable. '''
    t[1].append(3)
    print(t)        # ([1], [2, 3])
# mutability()

#------------------------------------------------------------------

''' 'Typed Languages' performs type checking at compile time to ensure
       operators valid for the operands .
Python is a typed language, but not all type errors can be detected at compile time.

If operand types are miss-matched it is called 'mix-mode' expression e.g. 1 + 1.2.
Python performs automatic type conversion for Number types: bool, int and float.  '''
# print(True + 1, 1 + 1.2, 1.2 + False)     ## 2 2.2 1.2

''' But non-numberic types are not automatic conversed. '''
# print(1 + '2')              ## error
# print(1 + int('2'))         ## 3
# print(str(1) + '2')         ## 12

''' 'Coercion' is an automatic type conversion from any types to boolean, mostly
  used as conditions for 'if' and 'while'.  '''
def coercion():
    x = 1
    if x:           ## x != 0
        print('Not Zero')           ## Not Zero

    if not x:       ## x == 0
        print('Zero')

    a = [0]
    if a:           ## len(a) > 0
        print('Not Empty')          ## Not Empty
    if not a:       ## len(a) == 0
        print('Empty')

    ''' Coercions are performed in comparisons and logical/math expressions,
          but not encouraged.  '''
    print(x == True, a == True)      ## True False
    print(x and False, x or True, a and False, a or True) # False 1 False [0]
    print(x + True, x + False)       ## 2 1

    ''' Non-numbers are not coerced. '''
    # print(a + True)                  ## error
# coercion()

''' Python 3.9 introduces 'type annotation' for type hint but no enforcement.
                <variable>: <type>
It only makes the code more readable and for some tools to detect error.  '''
def type_anno():
    x: int = 0   ## initial value is optional.
    s: str

    x = 'Hi'
    s = 1.0
    print(x, s)         ##  Hi 1.0
# type_anno()
