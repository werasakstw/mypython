''' Literals: are symbols that appear in source codes to represent values.
A literal has a fixed type.
All literals have characteristic that identifies its type.
Literal's types are known at the compile time. e.g.
       1                 int
       1.0               float
       True              bool
       1+2j              complex
       'Hello'           str  (string type)
       [1, 2]            list
       (1, 2)            tuple
       {1, 2}            set
       {'a':1, 'b':2}    dict

'bool' literal represents truth values which are True or False.
type(<arg>) is a built-in function that returns type of <arg>. '''
# print(True, type(False))    # True <class 'bool'>

''' 'int' literal represents integer value which is a sequence
 of digits (0-9) that do not begin with 0 and contains no decimal point. '''
# print(1, type(1))   #  1 <class 'int'>
# print(012)          # error

''' 'int' value are created as a PyIntObject for small integers(-5 -> 256).
Bigger integers are created with increasing size as needed.  '''
# print(123**123)

## sys.getsizeof(<var>) returns the size of <var> in bytes.
import sys
def int_size():
    print(sys.getsizeof(2))           # 14
    print(sys.getsizeof(2**10))       # 14
    print(sys.getsizeof(2**100))      # 26
    print(sys.getsizeof(2**10000))    # 1346
# int_size()

## 'int' literals allow number based using prefixed.
def int_bases():
    print(10)	        # 10   decimal (default)
    print(0b10)	        # 2    binary
    print(0o10)	        # 8    octal
    print(0x10)         # 16   hexadecimal

    ## There are built-in functions to convert decimal value to the based values.
    print(bin(10))	    # 0b1010
    print(oct(10))	    # 0o12
    print(hex(10))	    # 0xa

    ## int(<str>) creates an int value from <str> in decimal base.
    ## int(<str>, <base>) creates an int value from <str> in <base>.
    print(int('007'))       # 7
    print(int('100', 2))    # 4
    print(int('100', 5))    # 25
    print(int('a', 16))     # 10
    # print(int('a', 10))   # error: there is no 'a' symbols in base 10.
# int_bases()

''' 'float' literal represents floating-point value, there are two representations:
        - floating-point notation  e.g  1.23
        - scientific notation      e.g  1.2e3  '''
# print(1.23, 1.23e4)  # 1.23 12300.0

## Zero trailing are optional.
# print(001.230000)    # 1.23

## Python (and others languages) have problem with float computation.
# print(0.1 + 0.2)      # 0.30000000000000004

''' Divide by 0(int) and 0.0(float) are ZeroDivisionError.
Python has no literals for 'undefined', 'Infinity' or 'NaN'.  '''

## 'None' is a literal for representing the absence of value, not an empty value.
def none():
    n = None
    ## None is coerced to False
    if not n:
        print('None')        # None

    ## But None is not equal to False.
    print(n == False)        # False

    ## None is not an empty value nor zero.
    print(n == [], n == 0)   # False False

    ## None should not take part in any expressions.
    print(n and False)       # None
    # print(n + 1)           # error
# none()

''' Embedded Underscore: 'int' and 'float' literals allow _ within
digits which do not affect the values but improve readablility. '''
def underscores():
    print(1_000)                    # 1000
    print(1_000.00)                 # 1000.0
    print(0b1000_1100_1110_1111)    # 36079
    print(0x8C_EF)                  # 36079
# underscores()
