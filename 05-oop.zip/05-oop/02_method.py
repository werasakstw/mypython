## Methods are similar to functions, they are not the same.
def fun_met():
   ## A function is an object of <class 'function'>.
   print(type(fun_met))    # <class 'function'>

   ## An 'object method' is of <class 'method'>.  !!
   class A:
      def f(self):
         pass
   print(type(A().f))      # <class 'method'>

   ## A 'class method' and 'static method' are of <class 'function'>.
   class A:
      def f():
         pass
      
      @staticmethod
      def s():
         pass
   print(type(A.f))      # <class 'function'>
   print(type(A.s))      # <class 'function'>
# fun_met()

""" There are three kinds of methods:
1. 'Class Methods' are belong to class (created in the class namespace).
    - must be accessed via the class name.
    - no 'self' as a parameter.
'self' is the predefined reference to the object.

All methods are implemented as functions.
Compilers convert 'class method' calls by passing the class as the first argument.
    <class>.<method>(<arguments>) -> <method>(<class>, <argument>)
  e.g.
     A.hello('John')   -> hello(A, 'John') """

def class_method():
   class A:
      def hello(n):		
         print('Hello', n )
         
   A.hello('John')         # Hello John
# class_method()

""" Alternatively:
@classmethod is used to annotate a 'class method'.
The method must have 'cls' as the first parameter.
'cls' is a reference to the 'class object' of the class. """
def classmethod_decorator():
   class A:
      @classmethod
      def hello(cls, name):
         print('Hello', name)

      ## Non-annotated 'class method' does not need the 'cls'.
      def hi(name):
         print('Hi', name) 

   A.hello('Jack')         # Hello Jack
   A.hi('Joe')             # Hi Joe
# classmethod_decorator()

""" 2. 'Object Methods' are belong to object (created in the object namespace).
    - must be accessed via the object.
    - must have 'self' as the first parameter.
Compilers convert 'object method' call by passing the object 
  as the first argument.
           a.hello('John')   --> hello(a, 'John') """
def object_method():
   class A:
      def hello(self, n):        
         print('Hello', n)
         
   a = A()
   a.hello('John')         # Hello John
# object_method()

""" 3. 'Static Methods' do not belong to class nor object.
    - must be accessed via the class name.
    - no 'self' nor 'cls' as the first parameter.
    - annotated with @staticmethod.
Static methods are not considered members but go with the class. """
def static_method():
   ## Ex. A boundary class is used for grouping relelated members, not representing an object.
   class MyMath:
      @staticmethod
      def sq(x):
         return x * x     
      
   print(MyMath.sq(2))     # 4

   ## Python allows accessing static methods via object.
   print(MyMath().sq(3))   # 9
# static_method()

#-------------------------------------------------------------

## Python does not support method overloading.
def overloading():
   class A:
      def f(self):
         print('f(self)')
      
      # Redefining method with the same name is shadowing, not overloading.       
      def f(self, x):  # Only the last definition is uasable.
         print('f(self, x)')

   a = A()
   # print(dir(a))      # There is only one 'f'.
   # a.f()            # error:
   a.f(1)
# overloading()
