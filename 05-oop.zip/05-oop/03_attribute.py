""" Attributes are data member of class/object.
Method and attribute can be shadowed so their names should be different.
There are two kinds of attributes.
1. 'Class Attributes' are belong to class.
    - defined and created in the class namespace.
    - must be accessed via the class.  """
def class_attribute():
   class A:
      x = 1
      def f():
         print(A.x)  ## The namespace must be explicit.

      ## Class and object methods can access class attributes.
      def g(self):
         print(A.x)

   print(A.x)
   A.f()
   A().g()
# class_attribute()

""" 2. 'Object Attributes' are belong to object.
    - defined with 'self' in the object namespace.
    - accessed via the object reference or 'self'.
That is why 'self' must be passed to 'object methods'. """
def object_attribute():
   class A:
      # self.x = 0     # error: no 'self' in the class scope.
      def set_x(self, x):
         self.x = x

      def get_x(self):
         return self.x

   a = A()
   a.set_x(1)
   print(a.get_x())     # 1
# object_attribute()

""" A class definition creates its namespace.
An object has a reference to its class namespace. """
def class_np():
   class A():
      x = 1
   print(dir(A))     ## inherited names and 'x'.

   A.y = 2           ## 'y' is added to 'A' namespace.
   print(dir(A))

   ## 'a' namespace have reference to 'A' namespace.
   a = A()
   print(dir(a))     ## same as 'A' namespace.

   ## Modifying object namespace does not effect class namespace.
   a.z = 3
   print(dir(a))     ## 'z' is added to 'a' namespace.
   print(dir(A))     ## But not to 'A' namespace.

   # Modifying class namespace effects object namespace.
   A.w = 4           ## Added to 'A' namespace.
   print(dir(a))     ## 'w' is accessible in 'a' namespace.
# class_np()

""" C++ and Java add 'this' to names referred in class scope by default, but
Python does not. The names must be explicitly referred by namespace.
In python class and object members may have the same name, because they are
 bound to different namespaces. """
def ex_ref():
   class A:
      x = 1
      def f(self):
         self.x = 2           # Try: comment this line
##         print(x)           # error:
         print(A.x, self.x)   # 1 2

   A().f()
# ex_ref()

''' Python 'dict' is mutable.
Class/object members are stored in __dict__.
Members can be changed at runtime, it is the matter of safty VS flexible.
Objects of the same class may be different and cannot be used in the same way.
Classes may not be as they are initially defined. '''
def dyn_modify():
   class A:
      pass

   class B:
      def hello(self):
         print('Hello')
      def hi():
         print('Hi')

   a = A()
   ## Add 'x' to be data member of object 'a'.
   a.x = 1
   print(a.x)        # 1

   # Add object method to be member of object 'a'.
   a.greet = B().hello
   a.greet()         # Hello

   ## Add class method to be member of class 'A'
   A.hi = B.hi
   A.hi()            # Hi
# dyn_modify()
""" Classes should be modified by subclassing.
Not by making modification to the existing class. """

#--------------------------------------------------------------

""" States are values that stored in object attributes.
Object states should be initialized when the object is created.
Python provides initialization method:
               __init__(self, <args>)
__init__() cannot be overloaded.
__init__() should never be called explicitly.
<args> are values that passed to be initial state of the created object. """
def initialization():
   class A:
      def __init__(self, x, y):
         self.x = x
         self.y = y

   ## Creating an object would execute __init__() eventually.
   a = A(1, 2)
   print(a.x, a.y)         # 1 2
# initialization()

""" Python does not support 'information hiding'.
Class/object members are public and cannot be private.
In the old time, there is a convention that names begin with _ are
   supposed to be used locally. Python does not enforce this convention. """
def _name():
   class A:
      def __init__(self, x):
         self._x = x

   a = A(1)
   print(a._x)           # _x is accessible.
# _name()

""" Python provides its own 'name mangling', names that begin
 with __ are not directly accessible in other scopes. """
def __name():
   class A:
      def __init__(self, x):
         self.__x = x

      def x(self):
         print(self.__x)  # Ok.

      def __f(self):
         print('Hello')

   a = A(1)
   # print(a.__x)   # error
   # a.__f()        # error

   # Names that begin with __ are created with _<class name> prefixed.
   # So __ does not hide the name completely.
   print(a._A__x)    # 1
   a._A__f()         # Hello
# __name()

""" A global name that defined as:
             _<class>__<name>
  can be accessed in the <class> as __<name>.
The name is intended to be used in the <class> exclusively. """
_A__x = 123
def _A__hello():
   print('Hello')
class A:
   def test():
      print(__x)     # 123
      __hello()      # Hello
# A.test()

## But that does not excluded accessing the name directly.
class B:
   def test():
      print(_A__x)     # 123
      _A__hello()      # Hello
# B.test()

#--------- ----------------------------------------------------

""" Memory Concern:
Objects store attributes in a dict, which have memory overhead
 for the mutability and underlying hash table.

Python allows objects to use tuple for storing attributes.
If __slots__ is assigned with a tuple of attribute names, the class
 will used a tuple to store attributes instead of a dict.
A class with slots must be defined at top-level scope. """
class A:
   __slots__ = ('x', 'y')
   def __init__(self, x, y):
      self.x, self.y  = x, y

def slots_test():
   a = A(1, 2)
   print(a.x, a.y)      # 1 2
# slots_test()

## Memory Profiler:
## pip install memory_profiler
class B:
   def __init__(self, x, y):
      self.x, self.y  = x, y

# @profile        ## uncomment this line.
def mp_test():
   [A(1, 2) for _ in range(10000)]
   [B(1, 2) for _ in range(10000)]
# mp_test()
##  python -m memory_profiler 03_attribute.py
