''' Sometime we need objects that have only data.
There are many alternatives:

1. Tuples may reperent structured data without creating a class.  '''
def tuple_obj():
 john = (1, 'John Rambo', 3.8)

 # Tuple elements must be accessed by position.
 print(john[0], john[1], john[2])

 # Tuple has no protection against missing, extra and wrong order fields.
 jack = (1, 'John Rambo', 'cs', 3.8)
# tuple_obj()

''' 2. 'types' package has 'SimpleNamespace' class for creating objects
  without defining a class and do not have dict to store attributes.
Objects of 'SimpleNamespace' store attributes like normal objects,
  but use less memory. '''
import types
def simple_namespace():
    c = types.SimpleNamespace()
    c.x, c.y = 1, 2
    print(c.x, c.y)

    ## SimpleNamespace does not have a dict.
#    print(c.__dict__)      # error
# simple_namespace()

''' 2. 'collections' package has 'namedtuple' for creating class of data objects,
 which are immutable and more memory efficient than regular objects. '''
from collections import namedtuple
def named_tuple():
    ## namedtuple(<type name>, <fields_str>) returns a type.
    Student = namedtuple('Student', 'id name gpa')

    ## 'Student' may be used as a class.
    john = Student(1, 'John', 1.8)
    print(john)     # Student(id=1, name='John', gpa=1.8)

    ## Fields can be accessed by names.
    print(john.id, john.name, john.gpa)

    ## 'nametuples' are tuples, states cannot be modified.
    # john.gpa = 4.0

    ## 'nametuples' has protection against missing and extra fields.
    # jack = Student(2, 'Jack')             # error
    # joe = Student(3, 'Joe', 3.5, 'cs')    # error

    # But no protection against type or wrong order fields.
    print(Student(4, 3.5, 'Joe'))   # Student(id=4, name=3.5, gpa='Joe')
# named_tuple()

''' 3. 'typing' module provides 'NamedTuple' which is used as parent class
  of class for data objects. It has more readable syntax and provides
  filed type annotations. '''
import typing
def typing_namedtuple():
    class Student(typing.NamedTuple):
        sid: int
        name: str
        gpa: float

    ## Supports positional arguments only.
    john = Student(1, 'John', 1.8)
    print(john)
    print(john.sid, john.name, john.gpa)

    ## Proivdes protection against missing and extra fields.
    # jack = Student(2, 'Jack')                 # error
    # joe = Student(3, 'Joe', 3.5, 'cs')        # error

    ## But type annotations are not enforced.
    jim = Student(4, 3.5, 'Joe')
# typing_namedtuple()

#-------------------------------------------------------

''' Python 3.5 introduces 'dataclass' for classes that contain only data.
'dataclass' tag is defined in 'dataclasses' package. '''
from dataclasses import dataclass
def dataclass_test():
    ''' A dataclass is annotated with @dataclass.
    Dataclass fields must be defined with type hints. '''
    @dataclass
    class Point:
        x: int
        y: int

    ## Type hints are not enforced.
    p = Point(1, 2.0)
    print(p.x, p.y)            # 1 2.0

    ## Objects of dataclass are mutable.
    p.y = 3
    print(p.x, p.y)             # 1 3

    ## Protection against missing and extra fields.
    # print(Point(1))           # error
    # print(Point(1, 2, 3))     # error
# dataclass_test()

## Dataclass fields provide optional of default value and metadata.
from dataclasses import field, fields
def field_test():
    @dataclass
    class Point:
        x: int = field(default=0, metadata={'unit': 'pixel'})
        y: int = field(default=0, metadata={'unit': 'pixel'})
        z: int = -1

    ## Positiona and keyword arguments are allowed.
    p =Point(x=1)
    print(p.x, p.y, p.z)                    # 1 0 -1
    print(fields(p)[0].metadata['unit'])    # pixel
# field_test()

''' A dataclass implements a default __init__ unless it
 is specified not to create one. '''
def init_test():
    ## Static dataclasses have no __init__.
    @dataclass(init=False)
    class StaticPoint:
        x: int = 1
        y: int = 2
    # p = StaticPoint(3, 4)               # error
    print(StaticPoint.x, StaticPoint.y)   # 1 2

    ''' A dataclass may implement __init__ to specify how to
    init data. '''
    @dataclass(init=True)
    class Point:
        x: int
        y: int
        def __init__(self, x, y):
            self.x = x+1
            self.y = y+1

    p = Point(1,2)
    print(p.x, p.y)     # 2 3
# init_test()

''' Default dataclass arguements:
init=True, repr=True, eq=True, order=False, unsafe_hash=False,
 frozen=False, match_args=True, kw_only=False, slots=False '''
def dataclass_args():
    @dataclass(repr=True, eq=True, order=True, frozen=True)
    class Point:
        x: int
        y: int

    ## __repr__()
    print(Point(1,2))   # dataclass_args.<locals>.Point(x=1, y=2)

    ## __eq__()
    print(Point(1,2) == Point(1,2))  # True

    ## __lt__(), __le__(), __gt__(), and __ge__()
    print(Point(1,2) < Point(2,2))

    ## Immutable
    p = Point(1,2)
    # p.x = 0               # error
# dataclass_args()
