''' A class is defined as:
         class <name> [(<parents>, <meta class>)]:
            [<doc string>]
            <body>
<doc string> is optional.
Default <parents>  and <meta class> is 'object'.

A class with empty <bocy> and no <doc string> must 
 has 'pass' as the body. An empty class with <doc string>
 may not have 'pass'. '''
class G:
   '''G doc string'''

''' The following terminologies are vary among textbooks:
  'Type' define how to access value of a variable/object.
  'Class' is a mechanism for defining a type.
  'Object' is an instance(or variable) of a class.
  'Class members' are members that belong to an object/class,
      which may be attributes, methods, or classes.
  'Attributes' are data. 'Method' are functions.
Python is a pure object-oriented language that means data,
  function and class are implemented as objects.

By convention, class names are begin with capital letters and
 object(instance or variable) names are begin with lower case letters. '''

def classes():
   ''' Built-in and compiled classes are created statically.
     Newly defined classes are created at runtime. '''
   print(dir())      # []
   
   ## Classes can be defined locally and accessible within the scope.
   class A:
      def greet():
            print('Hello')
   print(dir())      # ['A']

   ''' All classes have their own namespace to store class members, which
    is created as __dict__.  '''
   # print(dir(A))            # list of members in 'A' namespace.
   print(A.__dict__['greet']) # <function classes.<locals>.A.greet at 0x034B33D0>
   A.greet()                  # Hello

   ## Class definition can be shadowed within the same namespace.
   class A:
      def greet(self):
            print('Hi')
   print(dir())      # ['A']

   ''' Python hss a class named 'type' for creating any classes.
   So a class is an object of <class 'type'>. '''
   print(type(A))    # <class 'type'>

   ''' We can create an object(instance/variable) of a class by:
                  <class name>(<arguments>)
      Ex. Here object 'a' is created from the class 'A'.
      So It is ok to say that 'a' is an object/instance/variable of type 'A'. '''   
   a = A()

   ''' A locally defined class is named as:
         <module>.classes.<locals>.<class name>   '''
   print(type(a))    # <class '__main__.classes.<locals>.A'>
   ''' Here type(a) is the 'class object' of class 'A' which 
    stores information about class 'A'.   '''
      
   ''' A module level defined class is named as:
        <module>.<class name>     '''
   print(type(G()))  # <class '__main__.G'>

   ## Objects of the same class have the same members.
   a.greet()            # Hi
   A().greet()          # Hi
   ## Since they share the same 'class object'.
   print(type(a) is type(A()))      # True
   ## But the 'class object' of object is not the same as class.
   print(type(a) is type(A))        # False

   ''' All classes have built-in attributes, e.g.
       __name__    the name of the class which is a str.
       __doc__     a doc string
       __class__   'class object' that the class is created from. '''
   print(G.__name__)    # G
   print(G.__doc__)     # G doc string
   print(G.__class__)   # <class 'type'>    same as type(G)

   ## Objects have __class__ which is the 'class object'.
   print(a.__class__.__name__)   # A

   ## Python 'int' is a class and an integer is an object.
   x = int()
   print(x.__class__)            # <class 'int'>
   print(x.__class__.__name__)   # int
# classes()
