﻿''' Most OO languages encapsulate data with getter/setter methods.
getter/setter allow decoupling data representation and access control. '''
def encapsulate():
   ## Python allows implementing getter/setter.
   class A:
      def __init__(self, x):
         self.x = x
      def set_x(self, x):
         self.x = x
      def get_x(self):
         return self.x

   a = A(0)
   a.set_x(1)
   print(a.get_x())     # 1

   ## But getter/setter does not prevent accessing attributes directly,
   ##  since all attributes are public.
   a.x = 2
   print(a.x)           # 2

   ## Therefore encapsulation is not an issue in Python
   ## Pushing more work done is better than spending effort hiding somethings.
# encapsulate()

''' Properties are methods that can be used like attributes (no ()).
It is easy to add attributes to a class, but not with properties.

Property in Python is not for encapsulation, but to:
       - hide the postfix syntax.
       - action injection.
Action injection means performing something when an attribute is accessed.
That allows implementing access policy and access event handling.

Properties can defined with two approaches:
1. Using property():  the old style.
       <property> = property(<fget>=None, <fset>=None, <fdel>=None, <doc>=None)
  <fget> and <fset> are getter/setter of the <property>.
  <fdel> is executed when the <property> is deleted.
  <doc> is the <property> string doc.
Instead of set() and get(), naming on_read() and on_write() are more meaningful. '''
def prop_def():
   class A:
      def on_read(self):
         print('on_read()')
         return self._x

      def on_write(self, x):
         print('on_write()')
         self._x = x

      def on_del(self):    # optional.
         print('on_del()')
         del self._x

      ''' Property names should be different from class and object attributes.
      So the object attribute '_x' is usual be prefixed. '''
      x = property(fget=on_read, fset=on_write, fdel=on_del)

   '''' Now the property 'x' can be accessed as attributes, not methods.
   And can be on the left side of assignment. '''
   a = A()
   a.x = 1        # on_write() is executed.
   print(a.x)     # on_read() is executed.

   ## But _x is still accessible. So properties do not encapsulate data.
   a._x = 2
   print(a._x)

   ''' a.on_write() and a.on_read() are still usable.
   But that is postfix syntax and requires OO concepts. '''
   a.on_write(3)
   print(a.on_read())

   del(a.x)       # on_del()
# prop_def()

''' 2. Using Decorators:
     @property       to annotate the on_read()
     @<name>.setter  to annotate the on_write()
     @<name>.deleter to annotate the on_del()  '''
def prop_deco():
   class A:
      @property
      def x(self): 	        # x become the getter
         print('on_read()')
         return self._x

      @x.setter
      def x(self, x):       # x become the setter
         print('on_write()')
         self._x = x

      @x.deleter
      def x(self):          # x become the deleter
         print('on_del()')
         del self._x

   a = A()
   a.x = 1         # a.x(1) is not allowed.
   print(a.x)      # a.x() is not allowed.
   del a.x
# prop_deco()

''' Property allows using attribute that does not directly exist.
A backup property has attribute that stores the state.
A computed property computes its value from others.
Mostly computed properties are read-only.  '''
import math
class Circle():
   def __init__(self, radius):
      self.radius = radius

   ''' This class does not store 'area' but computes from 'radius'.
   The property 'area' is read-only because there is only the getter. '''
   @property
   def area(self):
      return math.pi * (self.radius ** 2)
# print(Circle(10).area)

''' Properties implement 'attribute controls' into the class.
That is ok for classes with few attributes. For a class with a lot of
attributes there would be a lot of 'control methods' in the class.

Descriptors simplify the situation by delegate the 'attribute controls'
 to another class and allows reusing.
A 'descriptor' is a class that implements the following special methods:
  __get__(self, <object>, <owner>) creates or returns a value
  __set__(self, <object>, <value>) set the <value> in <object>
  __delete__(self, <object>)       deletes <object>

There are two kinds of descriptors:
   1. Data descriptors have __get__() and __set__().
   2. Nondata descriptors have only __get__().
'''
def data_descriptor():
   class my_descriptor:
      def __init__(self, initval=None, name='myvar'):
         self.val = initval
         self.name = name

      def __get__(self, obj, owner):
         print('__get__', self.name)
         return self.val

      def __set__(self, obj, value):
         print('__set__', self.name)
         self.val = value

      def __delete__(self, obj):
         print('__delete__', self.name)
         del self

   class A:
      ''' A descriptor is created as class attribute.
      The same descriptor can be reused with other attributes. '''
      x = my_descriptor(1, 'x')
      y = my_descriptor(2, 'y')

   a = A()
   print(a.x, a.y)  # __get__ x
                    # __get__ y
                    # 1 2
   a.x = 3          # __set__ x
   print(a.x)       # __get__ x
                    # 3
   del a.x          # __delete__ x
# descriptor()

## Non Data Descriptors are used for implementing python static methods.
def non_data():
    class my_staticmethod:
        ## Let the descriptor be the owner of the method.
        def __init__(self, f):
            self.f = f
         ## allows only getting the method from the descriptor.
        def __get__(self, obj, owner):
            return self.f

    class A:
        def hello(name):
            print('Hello', name)
        hello = my_staticmethod(hello)

    A.hello('John')
# non_data()
