''' Every classes have their own 'meta class'.
A 'meta class' controls the creation of objects of the class.
A meta class must extends <class 'type'> explicitly and has
  __call__(<args>) to return a newly created object.
<args> is a tuple, which first element is the class to be created. '''
def meta_class():
    ## For simplicity this meta class creates a str 'Hello'.
    class A_meta(type):
        def __call__(*args):
            print(args[0].__name__)
            return 'Hello'

    ## A class defines its meta class by assign to its argument 'metaclass'.
    class A(metaclass = A_meta):
        def __init__(self):         ## Not executed. !!!
            print('A.__init__()')

    ''' Creating an object with () causes its meta class __call__() to be executed.
    So the result of A() is 'Hello' that returned from A_meta's __call__(). '''
    a = A()     # A
    print(a)    # Hello
# meta_class()

''' Normally __call__() does not create the object but calls to the class
       __new__() to create object and
       __init__() to initialize the object.
That allows us to define how to create and initialize within the class.
This mechanism is called 'two steps creation' proposed in Objective-C.

To simplify the matter:
<class 'object'> has default implementation of __new__() and __init__().
Mostly we can use the default implements of __new__() in <class 'object'>
 and define just how to initialize the object state in __init__().

Ex. A typical implemention of meta class __call__().  '''
class A_meta(type):
    def __call__(*args):
        ## Get class object of the class to be created.
        cla = args[0]

        ## If the class has __new__() then calls it else call to
        ##   the <class 'object'>'s __new__().
        if '__new__' in cla.__dict__:
            new_method = getattr(cla, '__new__', None)
            ins = new_method(cla)
        else:
            ins = object.__new__(cla)

        ## If the class has __init__() then calls it else call to
        ##   the <class 'object'>'s __init__().
        if '__init__' in cla.__dict__:
            init_method = getattr(cla,'__init__', None)
            init_method(ins, *args[1:])
        else:
            ins = object.__init__(ins)

        ## Then return the instance.
        return ins

## Implementions of both __new__() and __init__().
def new_init():
    class A(metaclass = A_meta):
        def __new__(*args):
            print('__new__()')
            ## using the <class 'object'>'s __new__().
            return object.__new__(*args)

        def __init__(self, x):
            print('__init__()')
            self.x = x

    a = A(1)
    print(a.x)      # __new__()
                    # __init__()
                    # 1
# new_init()

''' Python silently adds the <class 'type'> as the metaclass in class definition:
        class <name>(<parent class>, metaclass=type):
If a class does not define its meta class then <class 'type'> is the default.
<class 'type'> has a __call__() that performs the default task.
Mostly a class does not need to define its meta classes, and defines only
  __init__() for its initialization. '''
def just_init():
    ## <class 'type'> is metaclass by default.
    class A:                        ## Try:  A(metaclass=A_meta):
        def __init__(self, x):
            self.x = x

    a = A(1)
    print(a.x)       # 1
# just_init()

''' Two steps creation: separates a creation into 'new' and 'init' steps.
    'new' takes care of memory allocation for the objects.
    'init' takes care of initialization the object state.
Mostly the default implementation of 'new' would do, only for special
propose memory layouts we need to define our own 'new'.
'''
#------------------------------------------------------------------------

''' Meta-Programming is a mechanism to create programs at runtime.
It is the most promising approach to AI in the old time.
Now it can do many wonderful things behind the scenes.

Class Creation:
A callable object is an object that can be called as a function.
<class 'type'> is callable which returns a class:
          type(<name> ,  <bases> , dict)
  <name> is the name of the class, stored in __name__.
  <bases> is a tuple of base classes, stored in __base__.
  <dict> is the namespace of the class, stored in __dict__.  '''

def hello():
    print('Hello')

def create_class():
    ## Create by definition:
    class A(object):
        x = 1
        def hi():
            print('Hi')
    print(A.x, A.__dict__['x'])             # 1 1
    A.hi()                                  # Hi
    print(A.__dict__['hi'].__name__)        # hi
    print(A.__name__, A.__base__.__name__)  # A object

    ## Create by type():
    B = type('B', (object,), {'y': 2, 'greet': hello})
    print(B.y, B.__dict__['y'])             # 2 2
    B.greet()                               # Hello
    print(B.__dict__['greet'].__name__)     # hello
    print(B.__name__, B.__base__.__name__)  # B object
# create_class()

## Alternatively Python allows class assembly, that means assigning members manually.
def class_assembly():
    class A:
        pass

    A.x = 1
    A.hello = hello

    print(A.x)          # 1
    A.hello()           # Hello
# class_assembly()

''' Adding class members can be performed using 'decorators'.
A decorator takes a class as input, modifies the class and returns the result. '''
def class_decorator():
    def to_a(cls):
        cls.x = 1
        cls.hello = hello
        return cls

    @to_a
    class A:
        pass

    print(A.x)          # 1
    A.hello()           # Hello
# class_decorator()
