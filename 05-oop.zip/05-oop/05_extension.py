''' Class definition with parent classes:
           class <name>(<parent classes>):
               <body>
If no <parent  classes>, it is given <class 'object'> by default.
<class 'object'> is the top most class of all classes.
<parent classes> may be more than one, multiple inheritance is allowed.
All classes have an attribute __base__ which is the parent class object. '''
def base_cls():
   class A:
      pass

   class B(A):
      pass

   print(A.__base__)    # <class 'object'>
   print(B.__base__)    # <class '__main__.base_cls.<locals>.A'>
   print(B.__base__.__name__)       # A
# base_cls()

''' isintance(<obj>, <class>) returns True
 if <obj> is an object of descendant classes of the <class>.  '''
def isintance_test():
   class A:
      pass
   class B(A):
      pass
   class C(B):
      pass
   class D:
      pass
   a, b, c, d = A(), B(), C(), D()
   print(isinstance(a, A), isinstance(b, A), isinstance(c, A), isinstance(d, A))
               # True True True False

   # 'class object' allows comparison by names.
   print(type(a))           # <class '__main__.isintance_test.<locals>.A'>
   print(type(a) == A)      # True
   print(type(b) == A)      # False
# isintance_test()

## A child class inherites members from its parent class.
class A:
    '''A Doc String'''
    a = 'class attribute'
    def __init__(self):
        print('A.__init__()')
        self.x = 'object attribute'

    @property
    def p(self):
        print('property')
        return 0

    @classmethod
    def cls_method(cls):
        print('class method')

    def obj_method(self):
        print('object method')

    @staticmethod
    def sq(n):
        print('static method', n*n)

def inheritance():
   class B(A):
      pass

   print(B.__doc__)      # None           !! Doc string is not inherited.
   print(B.a)            # class attribute
   B.cls_method()        # class method
   B.sq(2)               # static method 4

   b = B()               # A.__init__()   !! chained
   b.obj_method()        # object method
   print(b.x)            # object attribute
   print(b.p)            # property  0
# inheritance()

## Inherited members may be overrided.
def override():
   class C(A):
       '''C Doc String'''
       a = 'C class attribute'
       def __init__(self):
           print('C.__init__ ')
           self.x = 'C object attribute'
       @property
       def p(self):
           print('C property')
           return 10
       @classmethod
       def cls_method(cls):
           print('C class method')
       def obj_method(self):
           print('C object method')
       @staticmethod
       def sq(n):
           print('C static method', n*n)

   print(C.__doc__)      # C Doc String
   print(C.a)            # C class attribute
   C.cls_method()        # C class method
   C.sq(2)               # C static method 4

   c = C()               # C.__init__
   print(c.x)            # C object attribute
   c.obj_method()        # C object method
   print(c.p)            # C Properties 10
# override()

#----------------------------------------------------------

## Java 'super' is a reference, but Python 'super' is a class.
# print(type(super))     # <class 'type'>

''' The class 'super' is callable so it can be used like a function.
super() returns an object to access the superclass of the 'self' object.
super() must be called inside a scope that contains a 'self'. '''
def super_test():
    class A:
        def f(self, name):
            print('Hello', name)

    class B(A):
        def f(self, name):
            super().f(name)
        def g(name):
            super().f(name)  # error: there is no 'self' here.

    B().f('John')
    # B.g('John')          # error
# super_test()

''' super() should be used mostly for:
  1. method extension.       '''
def method_ext():
    class A:
        def f(self):
            print('A.f')

    class B(A):
        def f(self):        ## overriding
            print('B.f')

    class C(A):
        def f(self):        ## extension
            super().f()
            print('C.f')

    B().f()
    C().f()
# method_ext()

''' 2. Passing parameters to superclass __init__().
In typical OO languages, when an object is created there should be a machanism
 to pass parameters to superclasses constructors to perform initialization chain.

C++ and Java support automatic initialization chain, but Python does not.
In Python the initialization chain is not mandatory and super() need not
   to be the first statement in __init__().
But mostly Python subclass should call super().__init__() explicitly.  '''
def init_chain():
    class A:
        def __init__(self):
            print('A', end=', ')

    class B(A):
        def __init__(self):
            super().__init__()   # try: comment this line
            print('B')
    B()                    # A, B
# init_chain()

''' A class should take care of attribute initialization in its own class,
  and use super() to pass initial values to its super class. '''
def init_pass():
   class Student:
      def __init__(self, _id, name):
         self.id = _id
         self.name = name

   class GradStudent(Student):
      def __init__(self, _id, name, thesis):
         super().__init__(_id, name)
         self.thesis = thesis

   s = Student(1, 'John')
   print(s.id, s.name)

   g = GradStudent(2, 'Jack', 'oop')
   print(g.id, g.name, g.thesis)
# init_pass()

#---------------------------------------------------------------

''' A Python class may extends more than one classes.
Multiple Inheritance may simplify class designing but may cause
  a lot of problems, use it on your own risk. '''
def multiple_inheritance():
   class A:
      def f(self):
         print('A.f')

   class B:
      def f(self):
         print('B.f')
      def g(self):
         print('B.g')

   class C(A, B):
     pass

   c = C()
   print(isinstance(c, A), isinstance(c, B)) # True True
   c.f()    # A.f  !!!
   c.g()    # B.g
# multiple_inheritance()

''' Multiple inheritance performs searching for super() in the
'method resolution order' (mro) which is defined as the built-in __mro__.
The order may be simplified as 'top-down' and 'left-right'.  '''
def mro():
   class A:
      def f(self):
         print('A.f')
   class B(A):
      def f(self):
         print('B.f')
   class C(A):
      def f(self):
         print('C.f')

   class D(B, C):    # Try: D(C, B):
      pass

   D().f()        # B.f
   print([x.__name__ for x in D.__mro__])
      # ['D', 'B', 'C', 'A', 'object']
# mro()

''' Extension and Composition can be used for code reuse.
Extension is good for 'is-a' relationship.
Composition is better for 'has-a' relationship.  '''
def com_ext():
   class A:
      def f(self):
         print('A.f')
   class B:
      def g(self):
         print('B.g')

   class C:          # composition
      def __init__(self):
         self.a = A()
         self.b = B()
      def f(self):
         self.a.f()
      def g(self):
         self.b.g()

   class E(A, B):   # extension
      pass

   c = C(); c.f(); c.g()
   e = E(); e.f(); e.g()
# com_ext()

''' Python may reuse code without extension or composition by
  creating a class that shares other class members. '''
def share():
   class A:
      def f(self): print('a.f()')
   class B:
      x = 1
      def g(): print('B.g()')

   class C:
      f = A.f
      x = B.x
      g = B.g

   C.g()             # B.g()
   print(C.x)        # 1

   c = C()
   c.f()             # a.f()
# share()

''' Java has interfaces for creating classes that conforms to a protocol.
That allows creating class specification and class with multiple types.
Python does not have interfaces and not support polymorphism in the OO sense.
Since a Python identifier can be bound to values of any types.

Duck Types: Anything that quacks as a duck can be used as a duck.
If an object can perform in a certain context that is good enough
  without having to conform to a certain type.  '''
def duck_type():
    # class A and B are     not related.
   class A:
      def f(self):
         print('A')
   class B:
      def f(self):
         print('B')

   def test(x): # x can be an instance of any class that has f().
      x.f()

   test(A())   # A
   test(B())   # B
# duck_type()

#--------------------------------------------------------------------------

''' A protocol is a specification that defines the set of operations which allowed
  to preformed on an object of a class.

Python allows creating a protocol using an abstract class.
An 'abstract class' contains specification but not implementation.
It can be used to define references but not to create objects
  since some of its methods had not been implemented yet which
  are called 'abstract methods'.

Python 'abc' lib provides 'ABCMeta' class for creating abstract classes.
An abstract class must have the 'ABCMeta' as it metaclass. !!
An abstract method must be annotated with @abstractmethod.  '''
from abc import ABCMeta, abstractmethod
def protocol():
    ## Defining 'Greet' protocol that must have hello() and hi().
    class Greet(metaclass=ABCMeta):
        ## Abstract methods should have empty body or raises an error.
        @abstractmethod
        def hello(self, name):
            pass
            # raise NotImplementedError()

        ## Abstract methods with implementation is acceptable.
        @abstractmethod
        def hi(self, name):
            print('hi ' + name)

    ## Instantiating an abstract class is not allowed.
    # Greet()               # error

    ## Partially implementation is not allowed.
    class MyGreetBad(Greet):
        def hello(self, name):
            print('Hello ' + name)
    # MyGreetBad()          # error

    # To conform to 'Greet' protocol, 'MyGreet' must extends 'Greet'
    #   and implements both hello() and hi().
    class MyGreet(Greet):
        def hello(self, name):
            print('Hello ' + name)
        def hi(self, name):
            print('Hi ' + name)

    g = MyGreet()
    g.hello('John')
    g.hi('Jack')
# protocol()
