## pip install flask

from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/doHello/<name>')
def doHello(name):
    return 'Hello %s.' % name

@app.route('/doGet')
def do_get():
    return 'Get: %s.' % request.args['name']

@app.route('/doPost', methods=['POST'])
def do_post():
    return 'Post: %s.' % request.form['name']

@app.route('/doPut', methods=['PUT'])
def do_put():
    return 'Put: %s.' % request.form['name']

@app.route('/doDelete', methods=['DELETE'])
def do_delete():
    return 'Delete: %s.' % request.form['name']

## Using Ajax

@app.route('/ptt')
def ptt():
    return render_template('ptt.html')

@app.route('/jq')
def jq():
    return render_template('jq.html')


if __name__ == '__main__':
    app.run(port=8080, debug=True)


