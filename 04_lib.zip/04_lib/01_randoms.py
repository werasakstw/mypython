import random

'''  Random Integers:
    randint(a, b) returns random integer in [a, b] (inclusive). '''
# print([random.randint(1, 5) for _ in range(10)])

''' randrange(a) returns random integer in [0, a) (exclusive). '''
# print([random.randrange(5) for _ in range(10)])

''' randrange(a, b) returns random integer in [a, b). '''
# print([random.randrange(1, 5) for _ in range(10)])

''' randrange(a, b, c) returns a random integer in [a, b) with c step. '''
# print([random.randrange(1, 10, 3) for _ in range(10)])

''' Random Floats:
    random() returns random float in [0.0, 1.0). '''
# print([random.random() for _ in range(10)])

''' Seed:
Python uses pseudo random generator, which produces a deterministic sequence.
The result sequence can be reproduced by setting the seed.
random() automatically uses time as default seed, so sequence is not reproducible.
Normally a seed is an integer, but string, bytes, or bytearray are acceptable. '''
def seed_test():
    ''' No seed '''
    print([random.randint(1, 10) for _ in range(10)])
    print([random.randint(1, 10) for _ in range(10)])

    ''' Set seed '''
    random.seed(7);  print([random.randint(1, 10) for _ in range(10)])
    random.seed(7);  print([random.randint(1, 10) for _ in range(10)])
# seed_test()

''' Random Bits '''
def rand_bits():
    ''' getrandbits(n) returns random n bits as an integer. '''
    print([bin(random.getrandbits(8)) for _ in range(5)])

    import os
    ''' os.urandom(n) returns random n bytes as a 'bytes'. '''
    print([os.urandom(4) for _ in range(5)])
# rand_bits()

#-------------------------------------------------------------------

''' Randomly Select
choice(<sequence>) randomly returns an element from <sequence>.
sample(<sequence>, n)) randomly returns n selected elements from the <sequence>.
The results are list, inputs may be listor tuple.  '''
def select(a):
    print([random.choice(a) for _ in range(5)])
    print([random.sample(a, 4) for _ in range(5)])
# select([1,2,3,4,5])
# select([1,2,3,4,5])

''' shuffle(<list>) randomly in-place shuffles elements in <list>.
Str, tuple, set, dict  and rangeare not allowed. '''
def shuffle(a):
    for _ in range(5):
        random.shuffle(a)
        print(a)
# shuffle([1, 2, 3])

#########################################################################

''' There are probabilistic algorithms that give approximate result
  but easier to compute than direct approach.
Ex.  Pi Approximation with Randomness  '''
import math
def pi(n):
    k = 0;
    for _ in range(n):
        x = random.random()
        y = random.random()
        if math.sqrt(x*x + y*y) <= 1.0:
            k += 1
    return 4 * k / n
# print(pi(1000000))

''' Ex. Kumon: randomly generte elementary mathenmatic questions. '''
def kumon():
    ops = ['+', '-', 'x', '%']
    def gen():
        x = random.randint(2, 99)
        op = random.choice(ops)
        y = random.randint(2, 99)
        return '%2d %s %2d = ___' % (x, op, y)

    [print(gen()) for _ in range(10)]
# kumon()

''' Ex. Random Password Generator:
Suppose the password constraints:
  - length between 8 to 10 characters.
  - begins with an upper case letter then follow by digits, lower case
      or upper case letters. '''
import string
def gen_pwd():
    sym = []
    sym.extend(list(string.digits))
    sym.extend(list(string.ascii_uppercase))
    sym.extend(list(string.ascii_lowercase))
    def gen():
        p = random.choice(string.ascii_uppercase)  ## The first character.
        for i in range(random.randint(7, 9)):
            p += random.choice(sym)
        return p

    print([gen() for _ in range(10)])
# gen_pwd()
#---------------------------------------------------------------

''' Ex. Digit-Number Puzzle
Find the correspond digit for each character that satisfies the math.
                         S E N D
                       + M O R E
                       ---------
                       M O N E Y
Hint: There are many solutions.    '''

def test(s, e, n, d, m, o, r, y):
    return (s*1000 + e*100 + n*10 + d) + \
           (m*1000 + o*100 + r*10 + e) == \
           (m*10000 + o*1000 + n*100 + e*10 + y)

def print_(s, e, n, d, m, o, r, y):
    a = str(s) + str(e) + str(n) + str(d)
    b = str(m) + str(o) + str(r) + str(e)
    c = str(m) + str(o) + str(n) + str(e) + str(y)
    print(a, '+' , b, '=',  c)

''' Using Brute Force Simple'''
def send_money1():
    [(s, e, n, d, m, o, r, y)] = [(s, e, n, d, m, o, r, y)
        for s in range(1, 10)
        for e in range(0, 10) if (s != e)
        for n in range(0, 10) if (n not in [s, e])
        for d in range(0, 10) if (d not in [s, e, n])
        for m in range(1, 10) if (m not in [s, e, n, d])
        for o in range(0, 10) if (o not in [s, e, n, d, m])
        for r in range(0, 10) if (r not in [s, e, n, d, m, o])
        for y in range(0, 10) if (y not in [s, e, n, d, m, o, r]) and \
                                    test(s, e, n, d, m, o, r, y)
    ]
    print_(s, e, n, d, m, o, r, y)
# send_money1()

''' Using itertools.sample() '''
def send_money2():
    while True:
        a = random.sample(range(10), 8)
        if test(*a):
            print_(*a)
            break
# send_money2()

''' Exercises:
Find the correspond digit for each character that satisfies the math.
            SANTA
          - CLAUS
          -------
             XMAS
'''
#-------------------------------------------------------------

''' Logic Puzzle
Ex. Big Peppers.
In a mystery foreign language:
       'le ka bu' means 'buy green peppers',
       'ma bu gu' means 'big green cars',
       'ko le ma' means 'quickly buy cars'.
How do you say 'big peppers' in this language?
'''
def big_peppers():
    a = ['le', 'ka', 'bu']
    b = ['ma', 'bu', 'gu']
    c = ['ko', 'le', 'ma']
    while True:
        random.shuffle(a)
        random.shuffle(b)
        random.shuffle(c)
        buy, green, peppers = a
        big, _green, cars = b
        quickly, _buy, _cars = c
        if (green == _green) and (buy == _buy) and (cars == _cars):
            print(big, peppers)
            break
big_peppers()

#-----------------------------------------------------------------

''' Probability
Events A and B are 'independent' if A occurs does not affect B.
The probability that A and B heppen is the product of the probabilities of A and B.
          P(E, F) = P(E) P(F)
Ex. Coin Flipping:    P(HEAD) = 1/2
                      P(HEAD, HEAD) = 1/2 x 1/2
                      P(HEAD, HEAD, HEAD) = 1/2 x 1/2 x 1/2     '''
HEAD, TAIL = 0, 1
def flip():
    return random.choice([HEAD, TAIL])
def flip_test(n):
    h = hh = hhh = 0
    for _ in range(n):  ## 3 flips for n times.
        a, b, c = flip(), flip(), flip()
        if a == HEAD:
            h += 1
        if a == HEAD and b == HEAD:
            hh += 1
        if a == HEAD and b == HEAD and c == HEAD:
            hhh += 1
    print(round(h/n, 3), round(hh/n, 3), round(hhh/n, 3))
# flip_test(10000)

''' Die Rolling
  The probabilities of facing each value is 1/6.
      ex. P(ONE) = 1/6,  P(TWO) = 1/6,  .....      '''
ONE, TWO, THREE, FOUR, FIVE, SIX = 1, 2, 3, 4, 5, 6
def roll():
    return random.choice([ONE, TWO, THREE, FOUR, FIVE, SIX])

''' The probabilities of rolling a coin and a die which facing
  HEAD and ONE is P(HEAD, ONE) = 1/2 x 1/6 = 1/12 = 0.08333... '''
def coin_die(n):
    ho = 0
    for _ in range(n):
        f = flip()
        r = roll()
        if f == HEAD and r == ONE:
            ho += 1
    print(round(ho/n, 3))
# coin_die(10000)

#----------------------------------------------------------------

''' Events A and B are 'dependent' if one event affects the other.
Let P(B | A) is the probability of B given that A happened.
              P(A, B) = P(A) P(B|A)
Ex. A deck of 52 cards has 4 queens.
The probability of drawing two queens from a deck, without put back.
      P(FIRST_Q)            = 4 /52
      P(SECOND_Q | FIRST_Q) = 3 /51
      P(FIRST_Q, SECOND_Q) = 4 /52 x 3 /51   = 1/221   = 0.00452     '''
QUEEN = -1
def two_queen(n):
    qq = 0.0
    for _ in range(n):
        deck = list(range(48)) + [QUEEN]*4    ## create a deck
        first = random.choice(deck)
        if first == QUEEN:
            deck.remove(first)
            second = random.choice(deck)
            if second == QUEEN:
                qq += 1
    print(round(qq/n, 5))
# two_queen(100_000)
