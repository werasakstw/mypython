''' Problem solving with 'Generate and Test' often needs permutation.
Brute Force Permutation with nested loops is simple but limited to
  fixed number of elements and requires a lot of 'if'. '''
def permute_loop():
    a = [1, 2, 3]
    return  [[a0, a1, a2]
                for a0 in a
                for a1 in a if a1 != a0
                for a2 in a if a2 not in [a0, a1]]
# print(permute_loop())

''' Recursive Permutation allows vary number of elements.
But the algorithm is complicated and hard to collect the results.  '''
def permute_recur(a, i):
    def swap(i, j):
        # tmp = a[i]; a[i] = a[j]; a[j] = tmp
        a[i], a[j] = a[j], a[i]

    if i == len(a):
        print(a)
    else:
        j = i
        while j < len(a):
            swap(i, j)
            permute_recur(a, i+1)
            swap(i, j)
            j += 1
# permute_recur([1, 2, 3, 4], 0)

''' Python provides a very efficent permutation in 'itertools' lib. '''
import itertools
def permute_tool():
    for x in itertools.permutations(range(1, 4)):
        print(x)        ## Resulting a tuple
# permute_tool()

#################################################################

'''  Ex. Magic Squares
Fill numbers 1 to 9 in a 3x3 square such that the sum in rows, columns,
   and diagonals are equal.     '''
def magic_square():
    def test(a):
        if sum(a[0:3]) == sum(a[3:6]) == sum(a[6:10]) == \
           sum(a[0:10:3]) == sum(a[1:10:3]) == sum(a[2:10:3]) == \
           sum(a[0:10:4]) == sum(a[2:8:2]):
               return True
        return False

    def print_(a):
        print(a[0:3]); print(a[3:6]); print(a[6:9], end='\n\n')

    for a in itertools.permutations(range(1, 10)):
        if test(a):
            print_(a)
# magic_square()

''' Homework:
The magic_square() produces similar squares which are the results
of flipping or rotating. Write a program that eliminates such the cases.

Exercises:
Find digit for each letter to fill a 3x3 square so that:
          a b c               x d a
        + d e f             + y e b
          x y z               z f c
The second square is the result of rotating the first square 90 degree.  '''
#-------------------------------------------------------------------

''' Logic Puzzle
Ex. Three Gods:
There are 3 gods which are a truth teller, a liar, and a free will.
But we don't know who is who?
    God0 say: 'God1 is a liar(L).'
    God1 say: 'I am a free will (F)'
    God2 say: 'God1 is a truth teller (T).'
Who is the truth teller?
'''
def three_gods():
    def say(x, y, t):   ## x say 'y is t'.
        if x == 'T':
            return y == t
        elif x == 'L':
            return not (y == t)
        else:
            return True

    for gods in itertools.permutations(['F', 'L', 'T']):
        if say(gods[0], gods[1], 'L') and \
           say(gods[1], gods[1], 'F') and \
           say(gods[2], gods[1], 'T'):
                print('God0 = %s, God1 = %s, God2 = %s' % gods)
# three_gods()
