
import matplotlib.pyplot as pp

''' Define x and y axises as list.
The lists must have the same size.  '''
def xy_plot():
    x = [1, 5, 10, 14, 19]
    y = [1, 0, 4, 2, 5]
    pp.plot(x, y)
    pp.show()
xy_plot()

''' Same-Default x-axis Plot  '''
y1 = [0, 3, 1, 4]
y2 = [1, 0, 2, 3]
def same_x():
    pp.plot(y1)
    pp.plot(y2)
    pp.show()
# same_x()

''' Separate x-axis  '''
x1 = range(0, 4)
x2 = range(0, 10, 3)
def sep_x():
    pp.plot(x1, y1, x2, y2)
    pp.show()
# sep_x()

''' A figure can be separated into subplot.
        subplot(<row><column><number>)
The figure is devided into <row> by <column> and this plot is <number>. '''
def subplot():
    pp.subplot(121)
    pp.title(1)
    pp.plot(y1)
    pp.plot(y2)

    pp.subplot(122)
    pp.title(2)
    pp.plot(x1, y1, x2, y2)

    pp.show()
# subplot()

''' Plots in separate figures. '''
def two_figure():
    pp.figure(1)
    pp.plot([1, 2, 5])
    pp.title('Figure 1')

    pp.figure(2)
    pp.plot([1, 3, 1, 2])
    pp.title('Figure 2')

    pp.show()
# two_figure()

###############################################################
''' Ex. Math Function Plot '''
import math
def math_plot():
    ''' Square '''
    pp.subplot(311)
    xr = range(1, 10)
    pp.plot(xr, [i*i for i in xr])

    ''' Parabola '''
    pp.subplot(312)
    xr = range(-10, 10)
    pp.plot(xr, [x**2 + x + 1 for x in xr])

    ''' Log  '''
    pp.subplot(313)
    xr = range(1, 100)
    pp.plot(xr, [math.log2(x) for x in xr])
    pp.plot(xr, [math.log10(x) for x in xr])
    pp.show()
# math_plot()

#----------------------------------------------------------------

''' NumPy provides an efficient math library and supports range of floats.
pip install numpy   '''
import numpy as np

''' Ex. Plot  y = 1 - n / x   for 0 <= x < 10 and 1 <= n <= 3  '''
def np_range():
    ''' Python range() creates a list of ints. '''
    xr = range(1, 10);      # print(len(xr))   ## 9
    pp.plot(xr, [1 - (1/x) for x in xr])

    ''' numpy's arange() creates a list of floats. '''
    xa = np.arange(1, 10);  # print(len(xa)) ## 9
    pp.plot(xr, 1 - (2/xa)) ## Numpy supports aggregate operations.

    ''' numpy's linspace() creates a list of many floats for ploting. '''
    xs= np.linspace(1, 10);   # print(len(xs)) ## 50
    pp.plot(xs, 1 - (3/xs))
    pp.show()
# np_range()

def sin_cos():
    xr = np.arange(0, 4*math.pi);
    pp.plot(xr, [math.sin(x) for x in xr])

    xr = np.linspace(0, 4*np.pi)
    pp.plot(xr, [np.cos(x) for x in xr])
    pp.show()
# sin_cos()

import random
def random_plots():
    uniform = [random.uniform(0, 2.0) for _ in range(1000)] ## 0.0 -> 2.0
    pp.plot(uniform, 'r')

    standard = [random.random() for _ in range(1000)]   ## 0.0 -> 1.0
    pp.plot(standard, 'g')

    gaussian = [random.gauss(0.5, 0.2) for _ in range(1000)] ## mean, sd
    pp.plot(gaussian, 'b')

    pp.show()
# random_plots()
