''' pip install matplotlib  '''
import matplotlib.pyplot as pp

''' Bar Charts '''
def bar():
    x = range(10)
    y = [7, 2, 5, 3, 3, 8, 9, 1, 2, 3]
    pp.bar(x, y)

    ''' Stem plots: draw a vertical line from (x, 0) to (x, y). '''
    # pp.stem(x, y)

    pp.show()       ## To actually draw the plot.
# bar()

''' Stacked Bar Charts  '''
import random
def sta_bar():
    x = range(10)
    first = [ random.randrange(1, 10) for _ in range(10) ]
    second = [ random.randrange(1, 10) for _ in range(10) ]
    pp.bar(x, first, color = 'r')
    pp.bar(x, second, bottom=first, color = 'g')
    pp.show()
# sta_bar()

'''  Histograms  '''
def histogram():
    y = np.random.randn(1000)

    pp.subplot(321)
    pp.hist(y)

    ''' 'bins' is the number of equal-width gap in the range, default is 10. '''
    pp.subplot(323)
    pp.hist(y, bins=100)

    pp.subplot(322)
    pp.hist(y, align='left')       ## align: mid(default),left,right

    pp.subplot(324)
    pp.hist(y, histtype='step')   ## histtype: 'barstacked'(default), 'step', 'stepfilled'

    pp.subplot(325)
    pp.hist(y, color='r', edgecolor='g')      ## color, edgecolor

    pp.subplot(326)
    pp.hist(y, orientation='horizontal')   ## orientation: 'vertical'(default), 'horizontal'
    pp.show()
# histogram()

''' Pie Charts '''
def pie():
    d = [5, 15, 40, 30, 10]     ## The sum must be 100.

    pp.subplot(131)
    pp.pie(d)

    pp.subplot(132)
    pp.pie(d, colors=('r', 'g', 'b', 'y', 'm'))   ## colors: default=('b', 'g', 'r', 'c', 'm', 'y', 'k', 'w')

    pp.subplot(133)
    grades = 'A', 'B', 'C', 'D', 'F'
    exp=(0.1, 0.1, 0.1, 0.1, 0.1)   ## explode = fraction of the radius to offset each wedge.
    pp.title('OOP Spring 2017')     ## labels and title
    pp.pie(d, autopct='%1.1f%%', labels=grades, explode=exp)

    pp.show()
# pie()

''' Scatter Plot
Scatter plots display points that are not related by any known functions. '''
def scatter():
    x = np.random.randn(10)
    y = np.random.randn(10)
    pp.scatter(x, y)
    # pp.scatter(x, y, c='red')
    # pp.scatter(x, y, marker='s')
    pp.show()
# scatter()

''' A scatter plot is often used to visual the correlation or
a potential association between two variables. '''
def scatter_ex():
    ''' The control x values '''
    x = np.random.randn(1000)

    ''' Random measurements, no correlation '''
    y1 = np.random.randn(len(x))

    ''' Some (unknow function) correlation '''
    y2 = np.exp(x) - x/1.3

    pp.scatter(x, y1, c='red')
    pp.scatter(x, y2, c='green')
    pp.show()
# scatter_ex()
