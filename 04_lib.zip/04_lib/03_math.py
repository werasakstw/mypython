''' Algebra
pip install sympy      '''
from sympy import Symbol, symbols
x = Symbol('x')
w, y, z = symbols('w,y,z')
# print(x**2 - y*z)

from sympy import expand, factor, simplify, together, apart
def sympy_ex():
    ''' expand() expands into sum of individual terms. '''
    e = (x-y)*(x+y)    ## Try: (x+y)**3
    print(e.expand())       ## x**2 - y**2

    ''' factor() decomposes into its factors. '''
    print( (x**2 - y**2).factor() ) ## (x - y)*(x + y)

    ''' simplify() simplifies into the lowest number of terms. '''
    print( ((x ** 3 + x ** 2 - x - 1)/(x ** 2 + 2 * x + 1)).simplify() )
                                    ## x - 1

    ''' together() combines into a ratio. '''
    print( (1 + 1/x).together() )   ## (x + 1)/x

    ''' apart() reverse together(), handle one symbol only. '''
    print( ((x + 1)/x).apart() )   ## 1 + 1/x
# sympy_ex()

''' Exerices:
    1. expand() the following:
         x*(x+1)
         (x+1)*(x+2)
         (x+y)*(x-y)
         (x+y)**2
         (x+y)**(x+y)
         (x**2 + x*2 + x + 1)*(x**3 + x*3 + x + 2)

    2. factor() the following:
        x**2 + x
        x**2 + 2*x + 1
        x**2 + 2*x*y + y**2
        x**2 - y**2                             '''

''' Trigonometry '''
from sympy import sin, cos
def tri_ex():
    print(simplify(sin(x)**2 + cos(x)**2))    ## 1
# tri_ex()

''' Calculus '''
from sympy import integrate, diff
def calculus_ex():
    print(diff(x+y, x))                    ## 1
    print(diff(x**2 + y**3 + z*y, x))      ## 2*x
    print(diff((x+y)**2, x))               ## 2*x + 2*y
    print(integrate(x**2 + x + 1, x))      ## x**3/3 + x**2/2 + x
    print(integrate(x/(x**2 + 2*x), x))    ## log(x + 2)
# calculus_ex()

''' Substitution '''
def subs_ex():
    print((2*x**2 - x - 1).subs({x:1.0}))           ## 0
    print((x**2 - 2*x*y + y**2).subs({x:1, y:2}))   ## 1
# subs_ex()

''' Equation Solving '''
from sympy import solve
def solv_ex():
    ''' 2*x + 1 = 7    --->   2*x + 1 - 7   '''
    print(solve( 2*x + 1 - 7 ))     ## [3]

    ''' Polynomials         I is sqrt(-1). '''
    print(solve( x**2 + 2*x - 3 ))  ## [-3, 1]
    print(solve( x**2 + 1 ))        ## [-I, I]
    print(solve( x**3 - x ))        ## [-1, 0, 1]

    ''' Two variables equation return solutions as a dict. '''
    print(solve([2*x + y - 4, 5*x - 3*y],[x, y])) ## {x: 12/11, y: 20/11}
    print(solve( 2*x + y - 1, dict=True ))        ## [{x: 1/2 - y/2}]

    ''' Solution in term of others veriable.  '''
    print(solve( x**2 - 2*y + z, x ))   ## [-sqrt(2*y - z), sqrt(2*y - z)]

    ''' Linear Equations: n variables need n equations. '''
    exp1 = x + 3*y + z + 1
    exp2 = 3*x + y - z - 1
    exp3 = x + y + 3*z + 1
    print(solve( (exp1, exp2, exp3) )) ## {x: 1/3, y: -1/3, z: -1/3}

    ''' Quadratic equation:   a*x**2 + b*x + c     '''
    a, b, c = symbols('a, b, c')
    print(solve( a*x**2 + b*x + c, x ))
        ## [(-b - sqrt(-4*a*c + b**2))/(2*a), (-b + sqrt(-4*a*c + b**2))/(2*a)]
# solv_ex()

#------------------------------------------------------------------

''' Fractions '''
from fractions import Fraction
def frac_test():
    x = Fraction(1, 2)      ## Try: Fraction('1/2')
    y = Fraction(3, 4)

    ''' Math operations '''
    print(x + y, x - y, x * y, x / y, x**(1/x)) ## 5/4 -1/4 3/8 2/3 1/4

    ''' Comparison '''
    print(x < y, x <= y, x > y, x >= y, x == y) ## True True False False False
# frac_test()

''' Ex. Compute the area of a rectangle with 1+(2/3) width and 2+(3/4) height. '''
def fract_ex():
    area = 1+Fraction(2, 3) * 2+Fraction(3, 4)
    print(area)                             ## 37/12

    ''' Simplify Fraction '''
    n, d = area.numerator, area.denominator
    print('%d+(%d/%d)' % (n/d, n%d, d))     ## 3+(1/12)
# fract_ex()

#----------------------------------------------------------------

## Decimals: high precision floating points.
from decimal import Decimal
from decimal import getcontext
def dec_ex():
    print(1/7)                      ## 0.14285714285714285
    print(Decimal(1) / Decimal(7))  ## 0.1428571428571428571428571429
    ''' Default precision '''
    print(getcontext().prec)        ## 28

    ''' Set precision to 100 positions. '''
    getcontext().prec = 100
    print(Decimal(1) / Decimal(7))
        ## 0.1428571428571428571428571428571428571428571428571428571428571428571428571428571428571428571428571429
# dec_ex()
