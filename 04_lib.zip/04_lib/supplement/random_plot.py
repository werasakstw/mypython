import numpy as np
import matplotlib.pyplot as pp
import random

xr = range(1000)
''' Random Distributions '''
standard = [random.random() for _ in xr]        ## 0.0 -> 1.0
uniform = [random.uniform(0, 2.0) for _ in xr]  ## 0.0 -> 2.0
gaussian = [random.gauss(0.5, 0.1) for _ in xr] ## mean = 0.5, sd = 0.1

''' NumPy Random Distributions  '''
np_normal = np.random.standard_normal(size=1000)  # mean=0, sd=1
np_uniform = np.random.uniform(low=0, high=2.0, size=1000)
np_gaussian = np.random.normal(loc=0.5, scale=0.1, size=1000)

''' Text Statistics '''
def random_stats():
    print('\t\t\tstandard', '\t\tuniform', '\t\tgaussian')
    print('min/max: \t(%.2f/%.2f)\t(%.2f/%.2f)\t(%.2f/%.2f)' %
          (min(standard), max(standard),
           min(uniform), max(uniform),
           min(gaussian), max(gaussian)))
    print('Mean: \t\t%.2f\t\t\t%.2f\t\t\t%.2f' %
          (np.mean(standard), np.mean(uniform), np.mean(gaussian)))
    print('Sd: \t\t\t%.2f\t\t\t%.2f\t\t\t%.2f' %
          (np.std(standard), np.std(uniform), np.std(gaussian)))
# random_stats()

''' Random Scatter Plot '''
def random_scatter():
    pp.figure(1)
    pp.title('Python Random')
    pp.scatter(xr, standard, color='r')
    pp.scatter(xr, uniform, color='g')
    pp.scatter(xr, gaussian, color='b')

    pp.figure(2)
    pp.title('Numpy Random')
    pp.scatter(xr, np_normal, color='tab:orange')
    pp.scatter(xr, np_uniform, color='tab:purple')
    pp.scatter(xr, np_gaussian, color='tab:pink')
    pp.show()
# random_scatter()

''' Random Histogram Plot '''
def random_hist():
    pp.subplot(231)
    pp.title('standard')
    pp.hist(standard)

    pp.subplot(232)
    pp.title('uniform')
    pp.hist(uniform)

    pp.subplot(233)
    pp.title('gaussian')
    pp.hist(gaussian)

    pp.subplot(234)
    pp.title('triangular 1')
    t1 = [random.triangular(-1.0, 1.0, 0.5) for _ in xr] # min, max, peak
    pp.hist(t1)

    pp.subplot(235)
    pp.title('triangular 2')
    t2 = [random.triangular(0.0, 10.0, 2.0) for _ in xr]
    pp.hist(t2)

    pp.subplot(236)
    pp.title('triangular 3')
    t3 = [random.triangular() for _ in xr] # Default: min = 0, max = 1, peak = 0.5
    pp.hist(t3)

    pp.tight_layout()
    pp.show()
# random_hist()

''' Uniform Distribution in Range
random.random() is random.uniform(0, 1.0)   '''
def uniform_range():
    u1 = [random.uniform(-1.0, 1.0) for _ in xr] ## -1 -> 1
    u2 = [random.uniform(0, 1.0) for _ in xr]    ## 0 -> 1
    u3 = [random.uniform(0, 2.0) for _ in xr]    ## 0 -> 2
    pp.scatter(xr, u1, color='r')
    pp.scatter(xr, u2, color='g')
    pp.scatter(xr, u3, color='b')
    pp.show()
# uniform_range()

''' Uniform distribution with steps
random.randrange(<start>, <stop>, <step>)      '''
def uniform_step():
    u1 = [random.randrange(0, 100) for _ in xr]
    u2 = [random.randrange(0, 100, 10) for _ in xr]
    u3 = [random.randrange(0, 100, 30) for _ in xr]
    pp.scatter(xr, u1, color='r')
    pp.scatter(xr, u2, color='g')
    pp.scatter(xr, u3, color='b')
    pp.show()
# uniform_step()

''' Gaussian (Normal) with vary means
random.gauss(<means>, <sd>)       '''
def gauss_mean():
    g1 = [random.gauss(1.0, 0.1) for _ in xr] ## mean = 1.0, sd = 0.1
    g2 = [random.gauss(2.0, 0.1) for _ in xr] ## mean = 2.0, sd = 0.1
    g3 = [random.gauss(3.0, 0.1) for _ in xr] ## mean = 3.0, sd = 0.1
    pp.scatter(xr, g3, color='b')
    pp.scatter(xr, g2, color='g')
    pp.scatter(xr, g1, color='r')
    pp.show()
# gauss_mean()

''' Gaussian (Normal) with vary SD '''
def gauss_sd():
    g1 = [random.gauss(1.0, 0.1) for _ in xr] ## mean = 1.0, sd = 0.1
    g2 = [random.gauss(1.0, 0.2) for _ in xr] ## mean = 1.0, sd = 0.2
    g3 = [random.gauss(1.0, 0.3) for _ in xr] ## mean = 1.0, sd = 0.3
    pp.scatter(xr, g3, color='b')
    pp.scatter(xr, g2, color='g')
    pp.scatter(xr, g1, color='r')
    pp.show()
# gauss_sd()
