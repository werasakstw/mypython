''' pip install tk '''
from tkinter import *

''' 'tk' is the toplevel(root) window, which is created
  and returned when Tk is initialized. '''
tk = Tk()

''' 'Canvas' is a view that allows drawing and shown on screen. '''
w, h = 500, 500
cv = Canvas(tk, width=w, height=h)

''' 'Canvas' provides create_<shape>() to draw on.
The origin (0, 0) is at the left-top most of the frame.
x axis is to the right and y axis is downward. '''
def graphics():
                ##  x1,  y1,  x2,  y2
    cv.create_line(100, 100, 400, 400)

                ##       x1,  y1,  x2,  y2
    cv.create_rectangle(200, 200, 300, 250, fill="blue")

                ##   x1,  y1,  x2,  y2
    cv.create_oval(200, 300, 300, 400, outline="green", width=4)

                ##  x1,  y1,  x2,  y2      angle
    cv.create_arc(100, 100, 200, 160, extent=180, style='arc')

                ##     x1,  y1,  x2,  y2,  x3,  y3
    cv.create_polygon(200, 100, 300, 50, 350, 200, fill="red", outline="black")

    t = cv.create_text(50, 50, text='Hello')

    ''' The component must be pack() to show on the screen.
    'tk' must start mainloop() to handle events. At the end ofthis file.
    cv.pack()
    tk.mainloop()               '''
# graphics()

''' Colors are defined by:
    - name   e.g. red, green, blue etc.
    - hex-string (like in HTML) '#RRGGBB'  e.g. '#FF0000'
Create a color from three integers. '''
def to_color(r, g, b):
    return '#' + format(r, '02x') + format(g, '02x') + format(b, '02x')
def color_test():
    cv.create_line(100, 100, 400, 100, width=5, fill='black')
    cv.create_line(100, 200, 400, 200, width=5, fill='#FF0000')
    cv.create_line(100, 300, 400, 300, width=5, fill=to_color(150, 50, 200))
# color_test()

##################################################################

import math
''' To draw a point withsizeand color. '''
def point(x, y, size, color):
    d = size // 2
    x1, y1 = (x - d), (y - d)
    x2, y2 = (x + d), (y + d)
    cv.create_oval(x1, y1, x2, y2, fill=color, outline=color)

''' Ex. Draw a circle. '''
cx, cy = w//2, h//2
def circle():
    r, a = 100, 0.0
    two_pi = 2*math.pi
    while a < two_pi:
        x = r*math.sin(a) + cx
        y = r*math.cos(a) + cy
        point(x, y, 4, 'red')
        a += 0.05
# circle()

''' Alternatively:  x**2 + y**2 = radius**2      '''
def circle2():
    r = 100
    rsq1 = r*r
    rsq2 = (r+1)*(r+1)
    for x in range(-r, r+1):
        for y in range(-r, r+1):
            rr = x*x + y*y
            if rr > rsq1 and rr < rsq2:
                cv.create_oval(x+cx, y+cy, x+cx, y+cy, outline="blue", width=1)
# circle2()

''' Ex. Draw a sinewave. '''
def sine():
    sx, sy  = 40, 100
    a = 0.0
    four_pi = 4*math.pi
    while a < four_pi:
        x = sx*a
        y = sy*math.sin(a) + cy
        point(x, y, 4, 'blue')
        a += 0.1
# sine()

def spirograph(r1, r2, p):
    ''' r1, r2 are radius of the outer and inner circles.
    p is pen position relative to the center of the rolling circle.  '''
    d = math.pi / 90
    max = 10 * math.pi
    a = 0.0
    x1 = (r1+r2)* math.cos(a)- p * math.cos((r1+r2)*a/r2) + cy
    y1 = (r1+r2)* math.sin(a)- p * math.sin((r1+r2)*a/r2) + cy
    x2, y2 = 0, 0
    while a < max:
        x2 = (r1+r2)* math.cos(a)- p * math.cos((r1+r2)*a/r2) + cy
        y2 = (r1+r2)* math.sin(a)- p * math.sin((r1+r2)*a/r2) + cy
        cv.create_line(x1,  y1,  x2,  y2)
        x1, y1 = x2, y2
        a += d
# spirograph(60, 40, 30)
# spirograph(60, 40, 60)
# spirograph(60, 50, 60)

#-----------------------------------------------------------------

''' bind(<event>, <function>)  '''
def key_event():
    def do_key(event):
        print(event.char)

    def do_return(event):
        print('return')

    cv.focus_set()
    cv.bind("<Key>", do_key)
    cv.bind("<Return>", do_return)
# key_event()           ## Run in standalone mode.

def paint(point, color):
    def draw_dot(event):
       cv.create_oval((event.x - point), (event.y - point),
                      (event.x + point), (event.y + point),
                      fill=color, outline=color)
    cv.focus_set()
    # cv.bind("<Button-1>", draw_dot)      ## Left Mouse Button
    # cv.bind("<Button-2>", draw_dot)      ## Middle Mouse Button
    # cv.bind("<Button-3>", draw_dot)      ## Right Mouse Button
    # cv.bind("<Double-1>", draw_dot)      ## <Double-2>  <Double-3>
    cv.bind("<B1-Motion>", draw_dot)     ## <B2-Motion>  <B3-Motion>
# paint(3, 'green')

def move():
    def do_move(event):
        cv.coords(r, event.x, event.y, event.x+100, event.y+50)

    r = cv.create_rectangle(50, 25, 150, 75)
    cv.itemconfig(r, fill="blue")
    cv.bind("<B1-Motion>", do_move)
# move()

cv.pack()
tk.mainloop()
