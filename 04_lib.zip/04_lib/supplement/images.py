''' python -m pip install Pillow '''
from PIL import Image

''' open(<path>) reads image file into an object. '''
def image_info():
    im = Image.open('image/tree.jpg')
    print(im.filename)
    print(im.size)      ## a tuple.
    print(im.format)
    print(im.mode)
# image_info()

''' show() saves image a temporary BMP file and uses a BMP display
  program to show it. '''
# Image.open('image/tree.jpg').show()

''' save(<path>) converts image to the format and save to file. '''
# Image.open('image/bird.png').save('b.gif')

''' resize(<size>) converts image to the <size> which is (w,h). '''
def resize():
    im = Image.open('image/rose.jpg')
    im.show()
    im = im.resize((50, 50))
    im.show()
    # im.save('thumb_rose.png')
# resize()

''' crop(box=<box>) crops image at the <box> which is (x,y,w,h). '''
def crop():
    im = Image.open('image/bird.png').crop(box=(5, 27, 38, 92))
    im.show()
    # im.save('cropped_bird.png')
# crop()

''' <im1>.paste(<im2>, <position>) pastes <im2> on <im1> at <position>
  which is (x,y).  '''
def paste():
    bird = Image.open('image/bird.png')
    sea = Image.open('image/sea.png')
    sea.paste(bird, (100, 100))
    sea.show()
# paste()

''' rotate(<angle>) rotates image to <angle> in degree counterclockwise.  '''
# Image.open('image/bird.png').rotate(-20).show()

''' transpose(<option>) transform image with <option>. '''
import PIL
# Image.open('image/bird.png').transpose(PIL.Image.FLIP_LEFT_RIGHT).show()
# Image.open('image/bird.png').transpose(PIL.Image.FLIP_TOP_BOTTOM).show()

''' A mapping from 'i' position to (w, h). '''
def pos(i, w, h):
    return (0,0) if i == 1 else (w,0) if i == 2 else (0,h) if i == 3 else (w,h)

''' Image Enhancements  '''
from PIL import ImageEnhance
def enhance():
    # im = Image.open('image/tree.jpg')
    im = Image.open('image/sea.png')
    w, h = im.size
    ims = Image.new('RGBA', (2*w, 2*h))
    for i in range(1, 5):
        e = ImageEnhance.Contrast(im).enhance(i)
        # e = ImageEnhance.Sharpness(im).enhance(i*1.5)
        # e = ImageEnhance.Brightness(im).enhance(i/2)
        # e = ImageEnhance.Color(im).enhance(i)
        ims.paste(e, pos(i, w, h))
    ims.show()
# enhance()

''' Image Filtering '''
from PIL import ImageFilter
def filter():
    im = Image.open('image/sea.png')
    # im = Image.open('image/tree.jpg')
    # im = Image.open('image/tomcat.png')
    w, h = im.size
    ims = Image.new('RGBA', (2*w, 2*h))
    ims.paste(im.filter(ImageFilter.EDGE_ENHANCE), (0,0))
    ims.paste(im.filter(ImageFilter.EMBOSS), (w,0))
    ims.paste(im.filter(ImageFilter.FIND_EDGES), (0,h))
    ims.paste(im.filter(ImageFilter.CONTOUR), (w,h))
    ims.show()
# filter()

''' Image Processing
getpixel() and putpixel() access individual pixels in the image. '''
def process():
    im = Image.open('image/tree.jpg')
    w, h = im.size
    for x in range(w):
        for y in range(h):
            r, g, b = im.getpixel((x, y))
            im.putpixel((x,y), (g, r, b))  ## Swapping red with green.
                                           ## Try:  (b, g, r)
    im.show()
# process()

########################################################################

''' Ex. Mandelbrot Set
The Julia shapes are divided into connected and disconnected
  depended on the value of complex numbers c (in z*z + c).
Mandelbrot set is the set of complex numbers c which makes
  the Julia shapes connected.

There is a quick method for testing the connectivity of a Julia set.
Starting from z = 0 and a value of c then orbiting for some iterations
  if the value does not go beyond 2 then the Julia set is connected.

Mandelbrot ploted the set of c (called Mandelbrot set) that makes
  the Julia shapes connected using the real part as x and
  the imagine part as y.  '''
def mandelbrot():
    w, h = 600, 600
    iters = 200
    rgb_range = [0, 120, 255]  #  [255, 160, 80, 0]
    colors = [(i, j, k) for i in rgb_range for j in rgb_range for k in rgb_range]
    colors_len = len(colors)

    im = Image.new("RGB", (w, h), 255)
    for x in range(w):
        for y in range(h):
            z = 0
            ''' A scaling to show the "interesting" part of the Mandelbrot fractal. '''
            c = (y*2/w - 1.5) + 1j*(x*2/h - 1)
            for k in range(iters):
                z = z*z + c
                if abs(z) > 2:
                    im.putpixel((x, y), colors[k % colors_len])
                    break
    im.show()  ## Resulting the most magnificent shape in mathematics.
# mandelbrot()

''' The shape of Julia sets are symmetry but the Mandelbrot sets are not.
When we zoom in on Julia sets we see exactly the same shapes on different scales.
For Mandelbrot sets we see similar shapes but not the same.  '''
