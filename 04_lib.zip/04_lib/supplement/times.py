''' Epoch
Most OS support Epoch time, which is the number of seconds passed
  since 1st January 1970.    https://www.epochconverter.com     '''
import time, datetime
def epoch():
    ''' The total elapsed time since epoch, a float in seconds with 1 μs precision. '''
    print(time.time())

    ''' Current time in 'struct time' (a structure that represent time). '''
    t = time.localtime()
    tt = t.tm_year, t.tm_mon, t.tm_mday, t.tm_hour, t.tm_min, t.tm_sec
    print(tt)

    ''' Time to epoch '''
    epoch = datetime.datetime(*tt).timestamp()
    print(epoch)

    ''' Epoch to time '''
    now = datetime.datetime.fromtimestamp(epoch)
    print(now)
# epoch()

def to_epoch(*t):
    return datetime.datetime(*t).timestamp()
# print(to_epoch(2023, 1, 1))                 ## 1672506000.0
# print(to_epoch(2022, 12, 31, 23, 59, 59))   ## 1672505999.0

''' The Universal Time Coordinated (UTC) is based on Gregorian calendar.
The epoch is the UTC 00.00 h which is Jan 1, 1970 at 0° longitude.

ISO8601 suggested a day-time format:
       		YYYY-MM-DD:hh:mm:ss
  'M' is for month and 'm' is for minute.
Most operating systems do not allow file name with colon :.
So they use:	YYYY-MM-DD-hh-mm-ss        '''

''' <str>.split(<separator>) returns a list of strings in the <str>. '''
s = '2020-12-31-00-01-02'
# print(s.split('-'))     # ['2020', '12', '31', '00', '01', '02']

''' String Time Parser '''
from time import strptime
st = strptime(s, '%Y-%m-%d-%H-%M-%S')
# print(st)
# print(st.tm_year, st.tm_mon, st.tm_mday, st.tm_hour,   ## 2020 12 31 0
#       st.tm_min, st.tm_sec, st.tm_wday, st.tm_yday)    ## 1 2 3 366
''' struct_time represents: year, month, day, hours, minutes, and seconds '''
def struct_test():
    print(time.gmtime())    ## struct_time of the current UTC
    print(time.localtime()) ## struct_time of local time.
    print(time.ctime())     ## compact format string of the current UTC
    print(time.asctime())   ## compact format string of local time.
# struct_test()

def local_time():
    lt = time.localtime()
    print(lt)
    print(lt[:6])  ## slice the first six elements.
    print('%4d-%02d-%02d' % lt[:3])
    print('%02d-%2d-%2d' % lt[3:6])  ## hour min sec
    print('%02d-%2d-%2d' % lt[6:9])    ## wday, yday, isdst
    ''' wday is the number of the day in the week (starting with 0 = Mon).
        yday is the number of the day in the year.
        isdst indices whether the daylight change is implemented. '''

# local_time()

''' Time Formater
time.strftime(format_str, struct_time) returns a ‘compact format’ of time.
    %a (abbreviated weekday name)  %A (full weekday name)    %w (weekday number)
    %b (abbreviated name of month) %B (full name of month)   %m (month number)
    %d (day of month)              %y (year without century) %Y (four digit year)
    %H (hour)   %M (minutes)       %S  (seconds)             %p (AM/PM)
    %c (appropriate date and time) %x (appropriate date)     %X (appropriate time)
'''
def fmt_test():
    t = time.localtime()
    print(time.strftime("%a,%d %b %Y %H:%M:%S", t))
    print(time.strftime("%c", t))
# fmt_test()

'''
time.perf_counter() returns the highest precision possible system clock in nano seconds.
time.process_time() returns the clocks the processor spends on the specific process.
'''
def clock_test():
    print(time.perf_counter())  ##  system wide time
    print(time.process_time())  ##  time for the specific process
# clock_test()

def profile_test():
    start = time.perf_counter()
    x = 123 ** 123  ## compute something
    stop = time.perf_counter()
    print('%.10f ns' % ((stop-start)*(10**9)))
# profile_test()

''' datetime Module '''
import datetime  ## contains date, time, datetime, and timedelta.
def datetime_test():
    ''' Date constants '''
    print(datetime.date.min, datetime.date.max)  ## 0001-01-01 9999-12-31

    d = datetime.date.today()   ## Try: datetime.date(YYYY, MM, DD)
    print(d)
    print(d.year, d.month, d.day, d.weekday())

    ''' Date constants  '''
    print(datetime.time.min, datetime.time.max)

    t = datetime.time(1, 2, 3, 4)  ## hh, mm, ss, microsecond
    print(t)
    print(t.hour, t.minute, t.second, t.microsecond)

    ''' DateTime constants  '''
    print(datetime.datetime.min, datetime.datetime.max) ## 0001-01-01 00:00:00 9999-12-31 23:59:59.999999

    print(datetime.datetime.now())
    print(datetime.datetime.today())
# datetime_test()

''' Calendar '''
import calendar
def calendar_test():
    c = calendar.TextCalendar()     ## firstweekday = 1    (starts from Mo)
    # c = calendar.TextCalendar(firstweekday = 6)      ##  (starts from Su)
    ''' Print month calendar '''
    c.prmonth(2023, 3)              ## 2023 March
    # c.prmonth(2017, 3, w = 4)     ## column width = 4

    ''' Print year calendar '''
    # c.pryear(2017)
    # c.pryear(2017, m = 2)         ## month column

    ''' Calendar may be saved as string for using in programs. '''
    m = c.formatmonth(2023, 6)
    print(m)
    y = c.formatyear(2023)
    # print(y)
# calendar_test()

#------------------------------------------------------------------------

''' File Name Factory
Embedding the date and time to file names is a good practice.  '''
def get_file_name(title, ext):
    ts = '%4d-%02d-%02d-%02d-%02d-%02d' % time.localtime()[:6]
    return '%s-%s.%s' % (title, ts, ext)
# print(get_file_name('MyLog', 'log'))  ## MyLog-2021-05-14-12-16-55.log

''' Flie Time Stamp
time.ctime() converts date and time to printable format. '''
import os
def time_stamp():
    print(time.ctime(os.path.getatime(__file__)))   ## access time
    print(time.ctime(os.path.getmtime(__file__)))   ## modificationtime
    print(time.ctime(os.path.getctime(__file__)))   ## creation time
# time_stamp()
