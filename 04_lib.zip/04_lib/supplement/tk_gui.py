from tkinter import *

tk = Tk()

''' Setting 'tk' window options. '''
def tk_option():
    tk.title('This is a Title')
    tk.minsize(width=200, height=200)
    tk.geometry('300x100')              ## width,height,
    # tk.geometry('400x200+50+20')      ## width,height, x, y
    # tk.resizable(0, 0)	## Prevent resizing
    Label(tk, text='Hello').pack()
# tk_option()

''' Widgets are things that can be drawn on creen. e.g. label,
 button, text areas, checkboxes, scrollbars, frame and so on.
A widget is created with a parent is passed as a parameter.
A widget must be rendered with pack() or grid().
A widget is not garbage collected even no referenced.
pack() put the widget is the middle of the frame.
There are two sets of widgets, default and ttk.    '''
from tkinter import ttk
def widget_test():
    tk.geometry('300x100')
    Button(tk, text='Hello').pack()
    ttk.Button(tk, text='Hello').pack()
# widget_test()

def positioning():
    tk.geometry('300x200')
    Button(tk, text='John').pack()
    Button(tk, text='Jack').pack(pady=20) ## add and set default to 20
    Button(tk, text='Joe').place(x=100, y=100)
# positioning()

def side_pack():
    tk.geometry('300x200')
    Label(text='top').pack(side=TOP)
    Label(text='left').pack(side=LEFT)
    Label(text='right').pack(side=RIGHT)
    Button(text='Hello').pack() ## Try: Move to before 'top'.
    Label(text='bottom').pack(side=BOTTOM)
# side_pack()

def grid_test():
    tk.geometry('300x200')
    Button(tk, text='John').grid(row=0, column=0)
    Button(tk, text='Jack').grid(row=0, column=1)
    Button(tk, text='Joe').grid(row=1, column=1)
    Button(tk, text='Jame').grid(row=2, column=2, padx=20, pady=20)
# grid_test()

def color_test():
    tk.minsize(width=200, height=200)
    Label(text='Hello', fg='blue', bg='yellow').pack(pady=30)
    Button(text='Hello', fg='red', bg='white').pack(pady=30)
# color_test()

#---------------------------------------------------------------

''' Event handling '''
def doHello():
    print("Hello!")
def doHi():
    print("Hi!")

def button():
    tk.minsize(width=200, height=200)
    ttk.Button(tk, text='Hello', command=doHello).pack()
    ttk.Button(tk, text='Hi', command=doHi).pack()

    ''' An event handling function may be a lambda. '''
    ttk.Button(tk, text='What up', command=lambda: print("What's up?")).pack()
# button()              ## Run in standalone mode.

''' Mouse Events '''
def mouse():
    tk.minsize(width=200, height=200)
    l = Label(tk, text='Hello')     ## Try: ttk.Label
    l.pack(padx=50, pady=50)
    l.bind('<Enter>', lambda e: l.configure(text='Enter'))
    l.bind('<Leave>', lambda e: l.configure(text='Leave'))
    l.bind('<1>', lambda e: l.configure(text='Single left clicked'))
    l.bind('<Double-1>', lambda e: l.configure(text='Double left clicked'))
    l.bind('<B1-Motion>', lambda e: l.configure(text='Left button drag to %d,%d' % (e.x, e.y)))
# mouse()

def login():
    tk.title("Login")
    tk.minsize(width=300, height=150)
    ttk.Label(tk, text="Name").grid(row=0, column=0, padx=10, pady=10)
    ttk.Entry(tk, None).grid(row=0, column=1)
    ttk.Label(tk, text="Password").grid(row=1, column=0, padx=10, pady=10)
    ttk.Entry(tk, None).grid(row=1, column=1)
    ttk.Button(tk, text="Cancel").grid(row=2, column=0, padx=20, pady=10)
    ttk.Button(tk, text="Ok").grid(row=2, column=1, padx=20, pady=10)
# login()

''' StringVar: is a variable for storing input string. '''
def string_var_test():
    sv = StringVar()
    ttk.Entry(tk, textvariable=sv).pack()
    ttk.Label(tk, textvariable=sv).pack()
# string_var_test()

def entry_test():
    def doHello():
        l.config(text='Hello ' + name.get())
##        b.config(state='disable')

    tk.minsize(width=200, height=100)
    name = StringVar()
    e = ttk.Entry(tk, textvariable=name)
    e.grid(column=0, row=0, padx=10, pady=10)   ## grid() returns None.
    e.focus()

    b = ttk.Button(tk, text="Hello", command=doHello)
    b.grid(column=  1, row=0, padx=10, pady=10)

    l = ttk.Label(tk, text="")
    l.grid(column=0, row=1, padx=10, pady=10)
# entry_test()

def check_button_test():
    def doGet():
        l.config(text=str(v1.get())+ "," + str(v2.get()))

    tk.minsize(width=200, height=100)
    v1 = IntVar()
    cb1 = ttk.Checkbutton(tk, text="Enabled", variable=v1, state='disable')
    cb1.grid(column=1, row=0, sticky='w', padx=10, pady=10)

    v2 = IntVar()
    cb2 = ttk.Checkbutton(tk, text="Enabled", variable=v2, state='enable',
                          command=lambda:print("Checked"))
    cb2.grid(column=2, row=0, sticky='w', padx=10, pady=10)

    b = ttk.Button(tk, text="Get", command=doGet)
    b.grid(column=2, row=2, padx=10, pady=10)

    l = ttk.Label(tk, text="")
    l.grid(column=1, row=2, padx=10, pady=10)
# check_button_test()

def radio_button():
    def doGet():
        l.config(text=str(v.get()))

    tk.minsize(width=200, height=100)

    v = IntVar()
    rb1 = ttk.Radiobutton(tk, text='Hello', variable=v, value=1,command=doGet)
    rb1.grid(column=0, row=0, padx=10, pady=10)
    rb2 = ttk.Radiobutton(tk, text='Hi', variable=v, value=2, command=doGet)
    rb2.grid(column=1, row=0, padx=10, pady=10)
    rb3 = ttk.Radiobutton(tk, text='What up?', variable=v, value=3, command=doGet)
    rb3.grid(column=2, row=0, padx=10, pady=10)

    l = ttk.Label(tk, text="")
    l.grid(column=1, row=2, padx=10, pady=10)
# radio_button()

def combobox_test():
    def doGet():
        l.config(text=name.get()+ ", " + str(number.get()))

    tk.minsize(width=200, height=100)

    ttk.Label(tk, text="Name").grid(column=0, row=0, padx=10, pady=10)
    name = StringVar()
    n = ttk.Combobox(tk, width=10, textvariable=name)
    n.grid(column=1, row=0, padx=10, pady=10)
    n['values'] = ('John', 'Jack', 'Joe')
    n.current(0)

    ttk.Label(tk, text="Number").grid(column=0, row=1, padx=10, pady=10)
    number = IntVar()
    v = ttk.Combobox(tk, width=10, textvariable=number)
    v.grid(column=1, row=1, padx=10, pady=10)
    v['values'] = (0, 1, 3, 6)
    v.current(0)

    b = ttk.Button(tk, text="Get", command=doGet)
    b.grid(column=3, row=2, padx=10, pady=10)

    l = ttk.Label(tk, text="")
    l.grid(column=1, row=2, padx=10, pady=10)
# combobox_test()

def label_frame_test():
   def do_login():
      print(name.get() + ',' + pwd.get())

   lf = ttk.LabelFrame(tk, text='Login Frame ')
   lf.grid(column=0, row=0, padx=20, pady=20)

   ttk.Label(lf, text="Name").grid(column=0, row=0, padx=4, pady=4)
   name = StringVar()
   ne = ttk.Entry(lf, width=12, textvariable=name)
   ne.grid(column=2, row=0, sticky='w')

   ttk.Label(lf, text="Password").grid(column=0, row=1, padx=8, pady=4)
   pwd = StringVar()
   pe = ttk.Entry(lf, width=12, textvariable=pwd)
   pe.grid(column=2, row=1, sticky='w')

   b = ttk.Button(lf, text='Login', command=do_login)
   b.grid(column=2, row=31, sticky='w')
# label_frame_test()

def scrollbar_test():
    tk.grid_columnconfigure(0, weight=1)
    tk.grid_rowconfigure(0, weight=1)

    l = Listbox(tk, height=5)
    l.grid(column=0, row=0, sticky=(N,W,E,S))
    for i in range(1,101):
        l.insert('end', 'Item %d' % i)

    s = ttk.Scrollbar(tk, orient=VERTICAL, command=l.yview)
    s.grid(column=1, row=0, sticky=(N,S))
    l['yscrollcommand'] = s.set

    ttk.Sizegrip().grid(column=1, row=1, sticky=(S,E))
# scrollbar_test()

tk.mainloop()
