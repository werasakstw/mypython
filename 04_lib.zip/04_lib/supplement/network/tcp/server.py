import socket

HOST = '127.0.0.1'
PORT = 12345
MAX_BYTES = 1024

def server1():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        print('Listening on', (HOST, PORT))
        while True:
            conn, addr = s.accept()
            with conn:
                name = conn.recv(MAX_BYTES).decode()
                if name == 'bye':
                    print('Server shutdown.')
                    break
                print('Connected from:', addr, name)
                res = 'Hello ' + name
                conn.send(res.encode())
# server1()

## Factoring Handler
def my_handler(conn):
    name = conn.recv(MAX_BYTES).decode()
    print(name)
    conn.send(('Hello %s!' % name).encode())
    conn.close()

import threading
def server2():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((HOST, PORT))
    s.listen(5)                ## max connection = 5
    print('Listening at {}'.format(s.getsockname()))
    while True:
        conn, addr = s.accept()
        print('Connection from: %s: %d' % (addr[0], addr[1]))
        threading.Thread(target=my_handler, args=(conn,)).start()
# server2()

## Simplified server.
def server3():
    with socket.create_server((HOST, PORT)) as s:
        print('Listening at {}'.format(s.getsockname()))
        while True:
            conn, addr = s.accept()
            print('Connection from: %s: %d' % (addr[0], addr[1]))
            threading.Thread(target=my_handler, args=(conn,)).start()
# server3()

from socketserver import BaseRequestHandler, TCPServer
class MyHandler(BaseRequestHandler):
    def handle(self):
        print('Connection from: ', self.client_address)
        while True:
            name = self.request.recv(MAX_BYTES).decode()
            if not name:
                break
            self.request.send(('Hello ' + name).encode())

# if __name__ == '__main__':
#     TCPServer(('', 12345), MyHandler).serve_forever()

## netstat -an
