import math, random
import statistics as stt  ## Python standard lib
import numpy as np        ## pip install numpy

''' To Round Off '''
# print(round(1.2345, 2))    ## 1.23
# print('%.2f' % 1.2345)     ## 1.23

a = list(range(10))     ## [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
b = list(range(11))     ## [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

''' Built-in Python Functions and Numpy '''
# print(len(a), sum(a), min(a), max(a))               ## 10 45 0 9
# print(np.size(a), np.sum(a), np.min(a), np.max(a))  ## 10 45 0 9

#-----------------------------------------------------------

''' Mean is the average of elements in the sequence. '''
def mean_test():
    def mean(d):
        return sum(d)/len(d)
    print(mean(a), stt.mean(a), np.mean(a)) ## 4.5 4.5 4.5
    print(mean(b), stt.mean(b), np.mean(b)) ## 5.0 5 5.0
# mean_test()

''' Median is the middle element in the sorted sequence. '''
def median_test():
    def median(d):
        n = len(d)
        d.sort()
        m1 = n//2
        if n % 2 == 0:     ## n is even
            return (d[m1] + d[m1 - 1])/2
        return d[m1] ## n is odd

    print(median(a), stt.median(a), np.median(a)) ## 4.5 4.5 4.5
    print(median(b), stt.median(b), np.median(b)) ## 5.0 5 5.0

    ''' Float Mean runs faster and always returns a float. '''
    print(stt.fmean(a))           ## 4.5

    c = a[1:]           ## Exclude 0 position.
    ''' Geometric Mean '''
    print(stt.geometric_mean(c))   ## 4.147166274396913

    ''' Harmonic Mean '''
    print(stt.harmonic_mean(c))    ## 3.1813718614111375
# median_test()

''' Variance  is the average of the square of deviations from the mean.
         variance = sum((i - mean)**2)/n            '''
def variance(d):
    m = stt.mean(d)
    s = [(i - m)**2 for i in d]
    return sum(s)/len(d)
def variance_test():
    print(variance(a), np.var(a))       ## 8.25 8.25

    ''' Statistics Population variance  '''
    print(stt.pvariance(a))              ## 8.25
    ''' Statistics Sample variance  '''
    print(stt.variance(a))               ## 9.166666666666666
# variance_test()

''' The variance is the square of the value unit.
Standard Deviation(SD) is the square root of variance.
            sd = sqrt(variance)                     '''
def sd(d):
    return math.sqrt(variance(d))
def sd_test():
    print(sd(a), np.std(a))  # 2.8722813232690143 2.8722813232690143

    ''' Statistics Population SD '''
    print(stt.pstdev(a))      # 2.8722813232690143
    ''' Statistics Sample SD  '''
    print(stt.stdev(a))       # 3.0276503540974917
# sd_test()

''' Quantile is the rank of an interval in a sequence.  '''
def quantile_test():
    a = list(range(10))
    ''' stt.quantiles(<seq>) divides <seq> into n intervals with equal probability.
      By default n=4, method='exclusive'. '''
    print(stt.quantiles(a))                          # [1.75, 4.5, 7.25]
    print(stt.quantiles(a, method='inclusive'))      # [2.25, 4.5, 6.75]
    print(stt.quantiles(a, n=10)) # [0.1, 1.2, 2.3, 3.4, 4.5, 5.6, 6.7, 7.8, 8.9]

    ''' np.quantile(<seq>, q) Compute the q-th quantile of the <seq>. '''
    print(np.quantile(a, 0.1))   # 0.9
    print(np.quantile(a, 0.5))   # 4.5
    print(np.quantile(a, 1.0))   # 9.0
# quantile_test()

#############################################################

''' Ex. Happy Index '''
import csv
def happy_index():
    with open('data/happy.csv', 'r') as f:
        d = [ r['happy_index'] for r in csv.DictReader(f) ]
        a = np.array(d, dtype=np.float32)
    print('sum: %1.2f' % a.sum())
    print('Min: %1.2f  Max: %1.2f' % (a.min(), a.max()))
    print('Mean: %1.2f' % a.mean())
    print('Median: %1.2f' % np.median(a))
    print('Variance: %1.2f' % a.var())
    print('Std: %1.2f' % a.std())
# happy_index()

''' Ex. Box Plot
A box shows <min>-<lower>-<median>-<upper>-<max> values. '''
import matplotlib.pyplot as pp
def box_plot():
    d = [2, 1, 5, 4, 3]
    # d = [[2, 1, 5, 4, 3], [2, 1, 1, 4, 3], [2, 4, 5, 3, 6]]
    pp.boxplot(d)
    pp.show()
# box_plot()

def stock_box():
    with open('data/stock.csv') as f:
        s = [[int(row['v1']), int(row['v2']), int(row['v3']), int(row['v4']), int(row['v5'])]
                    for row in csv.DictReader(f)]
    pp.boxplot(s, labels=('abc', 'ddd', 'xyz', 'cnn', 'mtv', 'ptt'))
    pp.show()
# stock_box()

#----------------------------------------------------------

''' Frequency Count '''
from collections import Counter
def frequency_count():
    scores = [4, 2, 1, 3, 1, 1, 2, 3, 1, 3]
    c = Counter(scores)
    print(c.most_common())  ## [(1, 4), (3, 3), (2, 2), (4, 1)]
    print(c.most_common(1)) ## [(1, 4)]
    print(c.most_common(2)) ## [(1, 4), (3, 3)] ## Two second most frequency

    m = c.most_common(1)
    print('Mode:', m[0][0])         ## Mode: 1  (The most frequency value. )
    print('Frequency: ', m[0][1])   ## Frequency:  4
# frequency_count()

########################################################

''' Ex. Frequency Table '''
def frequency_table():
    grades = ['D', 'C', 'C', 'B', 'C', 'F', 'D', 'C', 'D', 'A', 'B']
    c = Counter(grades)
    mc = c.most_common()
    # mc.sort()
    print(['(%s: %d)' % (m[0], m[1]) for m in mc ])
# frequency_table()    ## ['(C: 4)', '(D: 3)', '(B: 2)', '(F: 1)', '(A: 1)']

#----------------------------------------------------------------

''' Numpy provides frequency counter which is faster but elements must be int. '''
scores = [1, 4, 1, 0, 1, 1, 2, 2, 2, 4]   ## has no 3.
def numpy_frequency_count():
    ''' unique() returns <count> and <value> in separated lists.
        The zero frequenciesare are excluded. '''
    count, value = np.unique(scores, return_counts=True)
    print(count, value)          ## [0 1 2 4] [1 4 3 2]
        ## The means one 0, four 1, three 2 and two 4

    ''' np.bincount() returns a list of count according to the position values. '''
    c = np.bincount(scores)
    print(c)        ## [1 4 3 0 2]

    ''' Frequency count '''
    for i, v in enumerate(c):
        print('(%d: %d)' % (i, v), end=', ')
            ## (0: 1), (1: 4), (2: 3), (3: 0), (4: 2),
    print()
# numpy_frequency_count()

#################################################################

''' Ex. Bin Sort is a very efficient sorting but limited to discrete values
  with narrow range.  '''
def bin_sort():
    c = np.bincount(scores)
    s = list()
    for i, v in enumerate(c):
        for _ in range(v):
            s.append(i)
    print(s)    # [0, 1, 1, 1, 1, 2, 2, 2, 4, 4]
# bin_sort()
