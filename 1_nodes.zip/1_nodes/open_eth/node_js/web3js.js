var Web3 = require('web3')
var web3 = new Web3('http://localhost:8545')

web3.eth.getNodeInfo().then(console.log)
// web3.eth.getAccounts().then(res => console.log(res))
// addr = '0x39a4E8b045139617861E7D2991bA040b4c1FE072'
// web3.eth.getBalance(addr).then(console.log)