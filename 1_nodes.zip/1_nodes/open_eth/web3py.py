from web3 import Web3

url = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(url))

print(w3.clientVersion)
##print(w3.eth.gasPrice)
##print(w3.eth.accounts)

##addr = '0x39a4E8b045139617861E7D2991bA040b4c1FE072'
##print(w3.eth.getBalance(addr))

