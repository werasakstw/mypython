from web3 import Web3
url = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(url))

print(w3.clientVersion)
print(w3.eth.mining)  # False
##print(w3.personal.newAccount())

# Connect metamask to 127.0.0.1:8545
# Import 'john' account by 'john' private key
