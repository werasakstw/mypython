# https://blog.logrocket.com/web3-py-tutorial-guide-ethereum-blockchain-development-with-python/

from web3 import Web3
url = "https://rinkeby.infura.io/v3/1c33caf701824d43882200b69d5e0849"
w3 = Web3(Web3.HTTPProvider(url)) # , request_kwargs={'timeout': 60}

# A middleware sit between client and provider
#  which may modify request and response to conform to
#  the communication protocol.
from web3.middleware import geth_poa_middleware
w3.middleware_onion.inject(geth_poa_middleware, layer=0)

##print(w3.clientVersion)
##print(w3.eth.gasPrice)

# Infura is not a wallet and do not perform mining.
##print(w3.eth.mining)    # False

# Infura is not a wallet.
##print(w3.eth.accounts)

# But may provide balance for valid addresses.
##addr = '0x39a4E8b045139617861E7D2991bA040b4c1FE072'
##print(w3.eth.getBalance(addr))

# Most transactions need to specify the chain id.
# Get chain id.
##print(w3.eth.chain_id)      # 4

# Get recent block.
def recent_block():
    print(w3.eth.blockNumber)
    lb = w3.eth.get_block('latest')
    print(lb.number)
    print(w3.toHex(lb.hash))  
##recent_block()
