import requests

URL = 'http://127.0.0.1:8545'
HEADERS = {'Content-type': 'application/json',
           'Accept': 'text/plain'}

def jsonrpc(method, param):
   DATA = '{"jsonrpc":"2.0", "method": "%s","params": %s, "id": 1}' \
         % (method, param)
   return requests.post(URL, data=DATA, headers=HEADERS).text

import json
def print_json_str(st):
   print(json.dumps(json.loads(st), indent=4, sort_keys=True))

print(jsonrpc('web3_clientVersion', []))
##print_json_str(jsonrpc('web3_clientVersion', []))
##print_json_str(jsonrpc('eth_gasPrice', []))
##print_json_str(jsonrpc('admin_nodeInfo', []))
