const Web3 = require('web3')
const web3 = new Web3('http://localhost:8545')

web3.eth.getNodeInfo().then(console.log)
web3.eth.getGasPrice().then(console.log)
web3.eth.getAccounts().then(console.log)

// https://web3js.readthedocs.io/en/v1.2.9/