# pip install web3   
# https://web3py.readthedocs.io/en/stable/

from web3 import Web3
URL = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(URL))

print(w3.clientVersion)
print(w3.eth.gasPrice)
print(w3.eth.accounts)

# Must be connected via IPC.
# https://stackoverflow.com/questions/41296993/not-able-to-create-accounts-for-private-ethereum-blockchain-using-geth-and-web3
##print(w3.personal.newAccount('jack'))
##print(w3.eth.accounts.create())

