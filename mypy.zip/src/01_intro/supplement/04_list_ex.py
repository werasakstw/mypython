''' Lists are order-oriented and may contain duplicate elements.  '''
# print( [1, 2, 1] )              ## [1, 2, 1]

''' Lists are accessed by position(indexing with zero-base).  '''
# print( a[0] )                   ## 1

''' Lists are generic and nestable.  '''
# print([1, 2.0, '3', True])      ## [1, 2.0, '3', True]
# print([1, [2, 3]])              ## [1, [2, 3]]

''' list() factory creats an empty list.  '''
# print( [], list() )             ## [] []

''' A comma after the last element is optional in list literals.
That allows each elements in separated line with consistent comma. '''
# print([1, 2, 3,])               ## [1, 2, 3]

''' Lists are mutable: modify the whole  '''
a = ['a', 'b', 'c']
# print(a)                        ## ['a', 'b', 'c']

''' Modify element:
List indexing is allowed on the left side of assignment.  '''
a[1] = 'x'
# print(a)                         ## ['a', 'x', 'c']

''' + operor is overloaded for list concatenation.  '''
# print([1,2] + [3])              ## [1, 2, 3]

''' List can be created with initialized value using * <number>. '''
# print([1,2]*2)                  ## [1, 2, 1, 2]

def list_create():
    # list() can create list from other types.
    print(list('Hello'))            # ['H', 'e', 'l', 'l', 'o']
    print(list(range(3)))           # [0, 1, 2]
    print(list( (1, 2, 1) ))        # [1, 2, 1]
    print(list( {1, 2, 1} ))        # [1, 2]

    # List can be created with comprehension.
    print( [i for i in range(10) if i % 2 == 0] )   # [0, 1, 2]
# list_create()

def list_op():
    a = ['a', 'b']

    # <list>.append(<item|list>) add <item|list> to the end
    a.append(1); print(a)         # ['a', 'b', 1]
    a.append([2, 3]); print(a)    # ['a', 'b', 1, [2, 3]]

    # <list>.extend(<list>) or += combines two lists
    a = ['x', 'y']
    a.extend([1, 2]); print(a)       # ['x', 'y', 1, 2]

    # <list>.insert(<pos>,<item>) insert <item> before the <pos>.
    a = ['a', 'b']
    a.insert(1, 'x')
    print(a)                    # ['a', 'x', 'b']

    # <list>.remove(<item>) remove the first occurrence of <item>.
    a = ['a', 'x', 'b', 'x']
    a.remove('x')
    print(a)                    # ['a', 'b', 'x']

    # <list>.pop(<pos>) pop element at <pos> and returns the element.
    #   default <pos>: is -1 (the end).
    print(a.pop(), a)               # x ['a', 'b']
    print(a.pop(0), a)              # a ['b']
##list_op()

##################################################################

''' Lists can be used as mapping function but only from integer to object.
Ex. Day Mapping:
  sat = 0, sun = 1, mon = 2, tue = 3, wed = 4, thu = 5, fri = 6  '''
dm = ['sat', 'sun', 'mon', 'tue', 'wed', 'thu', 'fri' ]
# print(dm[6])        # fri

''' List allows storing results for using later instead of recompute.
Ex. Factorial:
        n! = fac(n) = n * (n-1) * (n-2) .... * 1       '''
def fac(n):
    r = 1;
    for i in range(1, n+1):
        r *= i
    return r
# print(fac(5))

''' Find a 3 digits integer 'abc' such that:
             abc = a! + b! + c!
   hint:     145 = 1! + 4! + 5!             '''
def abc():
    for a in range(1, 10):
        for b in range(0, 10):
            for c in range(0, 10):
                if 100*a+10*b+c == fac(a) + fac(b) + fac(c):
                    print(a, b, c)
##abc()

''' Trading memory for speed. '''
def abcx():
    fac = [1, 1]
    for i in range(2, 10):
        fac.append(fac[i-1]*i)
    for a in range(1, 10):
        for b in range(0, 10):
            for c in range(0, 10):
                if 100*a+10*b+c == fac[a] + fac[b] + fac[c]:
                    print(a, b, c)
##abcx()
#-----------------------------------------------------------

''' List allows representing order oriented data.
 ex.  Polynomial:  1 + 2*x + 3*x**2 + 4*x**3
    represented as a list of coefficient  [1, 2, 3, 4]     '''
def eval_poly(p, x):
    r = 0
    for i, c in enumerate(p):
        r += c*x**i
    print(r)
# eval_poly([1, 2, 3, 4], 1.5)
#-------------------------------------------------------------

# Lists allows passing a collection of values to/from a function.
# Ex. Create a list of n booleans, filled with True except the first two.
def gen_list(n):
    a = [False, False]  # position 0 and 1 are False.
    for i in range(2, n+1):
        a.append(True)
    return a
# print(gen_list(5))      # [False, False, True, True, True, True]
#---------------------------------------------------------------

''' List allows random access with index.
Mapping with Indexing.       '''
grade_map = ('A', 'B', 'C', 'D', 'F')
def score_map(score):
    return 0 if 90 <= score else    \
           1 if 80 <= score else    \
           2 if 70 <= score else    \
           3 if 50 <= score else 4
def frequency_count(): # (histogram)
    scores = (83, 74, 51, 79, 91, 80, 94, 89, 43, 77, 56, 67, \
              88, 57, 33, 57, 66, 78, 64, 71, 85, 72, 76, 70, 76, 74)
    grades = [0, 0, 0, 0, 0]
    for s in scores:
       grades[score_map(s)] += 1

    for i in range(len(grades)):
       print(grade_map[i], end=': ')
       for j in range(grades[i]):
          print('*', end='')
       print()
# frequency_count()

''' Ex. Sieve of Eratosthenes: efficiently create a lot of primes.  '''
def sieve(n):
    a = gen_list(n)
    ''' From 2 to the half of n. '''
    for i in range(2, n // 2):
        ''' Start at a prime position. '''
        if a[i]:
            ''' Jump by i '''
            for j in range(i*2, n+1, i):
                ''' Mark the j position is not prime. '''
                a[j] = False
    ''' Return a list of prime positions. '''
    return [i for i in range(n+1) if a[i]]
# print(sieve(100))

''' Ex. Binary Sort:
Sorting a list of integers of narrow range.  '''
def bin_sort():
    a = [3, 2, 6, 2, 6, 4, 9, 6, 1, 7]  ## <range> 0 -> 9

    ''' Create list of size <range> filled with 0. '''
    r = 10
    c = [0]*r

    ''' Using the element value as position. '''
    for i in a:
        c[i] += 1

    ''' Collecting the result.  '''
    b = []
    for i in range(r):
        for _ in range(c[i]):
            b.append(i)
    print(b)
# bin_sort()
#---------------------------------------------------------------

''' Lists allows symbolic manipulation. e.g. add, remove, and shift.
Ex. Josephus Problem:
When an Egyptian troop chased a group of Hebrew up to a mountain.
They surrounded the mountain and won't let any escape.
The Hebrews despairingly wanted to die rather than captured.
They invented an amazing mass suicide method:
 - They will form a circle.
 - Then start at a person counts 1, person on the left counts 2, and the next counts 3.
 - The person who counts 3 will be killed by the other.
 - Then the counting 1, 2, 3 and killing continue for the next person.
 - The last person must perform suicide.
While the last farewell was going on, a once high ranking gerneral in the group
  spotted Josephus a well known mathematician. He approached Josephus and asked,
     "Are you ready to die?".  Josephus promptly replied, "No".
The general said: "You must quicky compute the last survive two positions.
As an old general, I can arrange the circle and appoint anyone to start first.
You and I will be in that positions."
The legend said there were 41 persons, what are the two positions?   '''
def josephus():
    a = list(range(1, 42))
    while len(a) > 2:
       a.append(a.pop(0))
       a.append(a.pop(0))
       a.pop(0)
    print(a)                ## [16, 31]
# josephus()
#--------------------------------------------------------------

'''                     Built-in Functions
    e.g. max(), min(), len()
          https://docs.python.org/3/library/functions.html
Ex. Summation:   sum(<seq>).        The parameter is a sequence. '''
# print(sum([2, 1, 3]))       ## 6
# print(sum(range(10)))       ## 45

''' Let define sum_(n) where the parameter is an integer.
        sum_(n) = 1 + 2 + 3 + ... + n  =  n*(n+1)/2    '''
def sum_(n):
    s = 0
    for i in range(1, n+1):
        s += i
    return s
# print(sum_(100), 100*(100+1)//2, sum(range(1, 101)))    ## 5050  5050 5050

''' Exercises: Show that sum_(n) = n*(n+1)/2 for n from 1 to 1000. '''
