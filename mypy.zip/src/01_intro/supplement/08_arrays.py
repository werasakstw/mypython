''' Lists are sequences of objects which have memory overhead.
Arrays store homogeneous sequence of int or float as binary, so that
  can be as lean as C array.
Python provides 'array' as a standard lib.
Python arrays need 'typecode' for determining the type of elements.
   Type code       Underline Type    Minimum size in bytes
     'b'         signed integer              1
     'B'         unsigned integer            1
     'u'         Unicode character           2
     'h'         signed integer              2
     'H'         unsigned integer            2
     'i'         signed integer              2
     'I'         unsigned integer            2
     'l'         signed integer              4
     'L'         unsigned integer            4
     'q'         signed integer              8
     'Q'         unsigned integer            8
     'f'         floating point              4
     'd'         double-precision float      8          '''
import array
def array_test():
    ''' Array of 'b' (signed integer) with initialized values in range(10).  '''
    a = array.array('b', range(10))
    print(a)            ## array('b', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    print(len(a))       ## 10

    ''' Arrays can be indexed.  '''
    print(a[0])         ## 0

    ''' Arrays can be iterated.  '''
    for x in a:
        print(x, end=",")   ## 0,1,2,3,4,5,6,7,8,9,
    print()

    ''' Arrays are mutable.  '''
    a.append(10)
    print(a)            ## array('b', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    a[1] = 11
    print(a)            ## array('b', [0, 11, 2, 3, 4, 5, 6, 7, 8, 9, 10])

    ''' Arrays are type safe.  '''
    # a[1] = 'a'        ## Compile time error

    ''' Arrays can be convered to lists.  '''
    print(a.tolist())   ## [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
array_test()

''' Array has methods for fast transfer to/from file. '''
def file_test():
    size = 10
    a = array.array('H', range(size))  ## two bytes unsigned int

    with open('test.bin', 'wb') as fp:
        a.tofile(fp)

    with open('test.bin', 'rb') as fp:
        b = array.array('H')          ## two byte signed int
        # b = array.array('b')        ## one byte signed int
        b.fromfile(fp, size)
    print(b)
# file_test()

''' Memory View: A 'memorview' is a shared-memory sequence type.
memoryview.cast() allows change the way the array bytes are read or written,
  without copying or moving data. It returns another memory view object
  that shares the same memory. '''
def mv_test():
    ''' 1 byte signed int.  '''
    a = array.array('b', [-2, -1, 0, 1, 2, 3])
    print(a.tolist())               ##  [-2, -1, 0, 1, 2, 3]

    mv = memoryview(a)
    ''' 1 byte unsigned int.  '''
    print(mv.cast('B').tolist())    ## [254, 255, 0, 1, 2, 3]

    ''' 2 byte unsigned int.  '''
    print(mv.cast('H').tolist())    ## [65534, 256, 770]
# mv_test()

#---------------------------------------------------------------------

''' 'bytes' is immutable array of bytes.
A byte is an integer in range [0, 256).
'bytes' literal is a str prefixed with 'b'.   '''
b = b'123'
# print(len(b), b[0])     ## 3 49       '1' is 49 in ascii
# b[0] = 0                ## Error

''' 'bytes' can be created with factory. (input must be a tuple) '''
# print( bytes((0, 1, 2, 3)) )    ## b'\x00\x01\x02\x03'

#---------------------------------------------------

''' 'bytearray' is mutable arrays of bytes. '''
def byte_array():
    b = bytearray((0, 1, 2, 3))
    print(b)           ## bytearray(b'\x00\x01\x02\x03')

    ''' Bytearrays are mutable.  '''
    b.append(4)
    print(b)           ## bytearray(b'\x00\x01\x02\x03\x04')

    b[1] = 0
    print(b)           ## bytearray(b'\x00\x00\x02\x03\x04')

    ''' Bytearrays can shrink. '''
    del b[1]
    print(b)           ## bytearray(b'\x00\x02\x03\x04')
# byte_array()

''' bytes and bytearray can be converted to and from. '''
# print(bytes(bytearray((0, 1, 2))))  ## b'\x00\x01\x02'
# print(bytearray(bytes((0, 1, 2))))  ## bytearray(b'\x00\x01\x02')

''' Python 2: has 'str' and 'unicode' types.
    Python 3: has 'str' and 'bytes' types.

'bytes' is a bytes array. Its literal is prefixed with 'b'. '''
# print(type('Hello'))             ## <class 'str'>
# print(type(b'Hello'))            ## <class 'bytes'>

def bytes_string():
    ## str
    print('Hello\tJohn.')       ## Hello	John.

    ## raw string
    print(r'Hello\tJack.')      ## Hello\tJack.

    ## bytes string
    print(b'Hello\tJoe.')       ## b'Hello\tJoe.'

    for c in 'Hello\tJack.':
        print(c, end=',')       ## H,e,l,l,o,	,J,a,c,k,.,
    print()
    for c in r'Hello\tJack.':
        print(c, end=',')       ## H,e,l,l,o,\,t,J,a,c,k,.,
    print()
    for c in b'Hello\tJack.':   ## A bytes string must be iterated to get bytes data.
        print(c, end=',')       ## 72,101,108,108,111,9,74,97,99,107,46,
# bytes_string()

''' encode(<encoding>='utf-8')  str -> bytes
    decode(<encoding>='utf-8')  bytes -> str     '''
def encode_decode():
    b = 'Hello'.encode()
    print(b)          ## b'Hello'
    print(type(b))    ## <class 'bytes'>

    s = b.decode()
    print(s)          ## Hello
    print(type(s))    ## <class 'str'>

    print('ก'.encode())                     ## b'\xe0\xb8\x81'
    print('ก'.encode('utf-16'))             ## b'\xff\xfe\x01\x0e'
    print(b'\xe0\xb8\x81'.decode())                 ## ก
    print(b'\xff\xfe\x01\x0e'.decode('utf-16'))     ## ก
# encode_decode()

def str_iterate():
    s = 'กขค'

    ''' str is iterated by character.  '''
    for c in s:
        print(c, end=',')       ## ก,ข,ค,
    print()

    ''' bytes is iterated by byte.  '''
    for c in s.encode():
        print(c, end=',')       ## 224,184,129,224,184,130,224,184,132
# str_iterate()

''' chr(<int>) returns unicode character of the int value.
    ord(<character>) return unicode of <character>.  '''
# print(chr(65), ord('A'))        ## A 65

''' Letter A Unicode is U0041 in hex. '''
# print(hex(65))                   ## 0x41
# print('\u0041')                  ## A

''' Since 'A' is a str, to get the bytes we need iteration. '''
# [print(hex(c)) for c in 'A'.encode()]   ## 0x41

def ord_test():
    ''' Accessing each character in a string as unicode. '''
    for c in 'ABC':
        print('%s(%d)' % (c, ord(c)), end=', ')  ## A(65), B(66), C(67),
    print()

    for c in 'กขค':
        print('%s(%d)' % (c, ord(c)), end=', ')  ## ก(3585), ข(3586), ค(3588),
# ord_test()
