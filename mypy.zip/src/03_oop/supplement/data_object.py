''' Oo is expensive. Doo is to dilute oo. For example:
If something is needed to hold just data, can we avoid creating a class.
There are many alternatives:

1. Tuples may reperent structured data without creating a class.  '''
john = (1, 'John Rambo', 3.8)

''' But tuple elements must be accessed by position. '''
# print(john[0], john[1], john[2])        ## 1 John Rambo 3.8

''' And tuple has no protection against missing, extra and wrong order fields. '''
jack = (1, 'John Rambo', 'cs', 3.8)

''' 2. 'types.SimpleNamespace' provides creating objects without defining
  a class and do not have dict to store attributes.
It can be used like a normal object but use less memory. '''
import types
p = types.SimpleNamespace()
p.x, p.y = 1, 2
# print(p.x, p.y)             ## 1 2
# print(c.__dict__)           ## error    no dict

''' 2. 'collections.namedtuple' provides creating class of immutable
  data objects which is more memory efficient.
        namedtuple(<name>, <fields_str>) returns a class with <name>.
 '<fields_str> contains attribute names, separated by a space. '''
import collections
Student = collections.namedtuple('Student', 'id name gpa')
john = Student(1, 'John', 1.8)
# print(john.id, john.name, john.gpa)         ## 1 John 1.8

''' 'nametuple' are immutable. '''
# john.gpa = 4.0

''' 'nametuples' has protection against missing and extra fields. '''
# jack = Student(2, 'Jack')             # error
# joe = Student(3, 'Joe', 3.5, 'cs')    # error

''' But no protection against type or wrong order fields. '''
# print(Student(4, 3.5, 'Joe'))   # Student(id=4, name=3.5, gpa='Joe')

''' 3. 'typing.NamedTuple' is a parent class for subclassing a nametuple class.
More readable syntax and provides field type annotations but not enforced. '''
import typing
class Student(typing.NamedTuple):
    sid: int
    name: str
    gpa: float

john = Student(1, 'John', 1.8)      ## Supports positional arguments only.
# print(john.sid, john.name, john.gpa)    ## 1 John 1.8

''' Protection against missing and extra fields. '''
# jack = Student(2, 'Jack')                 # error
# joe = Student(3, 'Joe', 3.5, 'cs')        # error

''' No enforcing type annotations. '''
jim = Student(4, 3.5, 'Joe')

#-------------------------------------------------------

''' 4. Python 3.5 introduces 'dataclass' for classes that contain only data.
A data class must be annotated with '@dataclasses.dataclass' tag and fields
  must be defined with type hints. '''
import dataclasses
@dataclasses.dataclass
class Point:
    x: int
    y: int

p = Point(1, 2.0)       ## Type hints are not enforced.
# print(p.x, p.y)            ## 1 2.0

''' 'dataclass' are mutable. '''
p.y = 3
# print(p.x, p.y)           ## 1 3

''' Protection against missing and extra fields. '''
# print(Point(1))           ## error
# print(Point(1, 2, 3))     ## error

''' Dataclass fields provide optional of default value and metadata. '''
from dataclasses import field, fields
@dataclasses.dataclass
class Point:
    x: int = field(default=0, metadata={'unit': 'pixel'})
    y: int = field(default=0, metadata={'unit': 'pixel'})
    z: int = -1

''' Positiona and keyword arguments are allowed. '''
p = Point(x=1)
# print(p.x, p.y, p.z)                    ## 1 0 -1
# print(fields(p)[0].metadata['unit'])    ## pixel
