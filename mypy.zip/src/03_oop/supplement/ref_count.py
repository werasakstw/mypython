''' An object's value gets its reference when its identifier is bound to a name,
 that is called 'object binding' which occurs in assignment, parameter passing
 and returning value.

Within a value there is a variable 'reference count' (called 'rc') that
 store the number of identifiers bound to the value currently.

There are two kind of references: strong and weak.
When a value is bound to a strong reference, its rc is increased by one.
When the strong reference is unbound or dead, the rc is decreased by one.
Binding and Unbinding weak references do not affect the rc.

A value is a garbage if its rc is zero, no strong references to the value.
The value's memory is reclaimed as soon as it be come a garbage,
this is the work of property injected to all values by default.
    sys.getrefcount(<obj>) return rc of value of the <obj>. '''
import sys
def rc_test():
    x = []      ## list are not interned.
    y = x       ## The []'s rc is 2.
    print(sys.getrefcount(x))       ## 3
    print(sys.getrefcount(y))       ## 3
    ''' The extra reference is the parameter of the getrefcount(). '''
# rc_test()

''' 'rc' of interned popular values are usually high. '''
# print(sys.getrefcount(0))

''' 'rc' are updated dynamically according to the value scope. '''
def rc_scope():
    x = []
    print(sys.getrefcount(x))           ## 2

    def f(a):
        print(sys.getrefcount(a))

    f(x)                                ## 4
    print(sys.getrefcount(x))           ## 2
# rc_scope()

''' Weak reference is provided by ref() of the 'weakref' module. '''
import weakref
class A:
    def hello(self):
        print('Hello')

def weak_reference():
    a = A()
    print(sys.getrefcount(a))   ## 2

    ''' A weak reference to the value of a. '''
    wr = weakref.ref(a)

    ''' Weak references have no effect to the rc. '''
    print(sys.getrefcount(a))   ## 2

    ''' Weak reference cannot directly access the object. '''
    # w.hello()             ##   error:

    ''' A strong reference can be retrieved from a weak reference, if it still alive. '''
    r = wr()
    r.hello()                   ## Hello
    print(sys.getrefcount(a))   ## 3

    ''' wr = None         Nullify the weak reference
        del(a)            Delete the object including it value.
    Testing if a weak reference is still alive. '''
    if wr != None and wr() is not None:
        wr().hello()
# weak_reference()

''' Weak referencs cannot point to immutable types, sequence types, except set. '''
# w1 = weakref.ref(1)           ## error: int, float, boolean
# w2 = weakref.ref('hello')     ## error: string, list, tuple, dict
w3 = weakref.ref({1})

''' We can handle the event when a garbage is collected by:
       weakref.finalize(<obj>, <handler function>)   '''
def gc_handler():
    def bye():
        print('Bye')

    a = A()
    wf = weakref.finalize(a, bye)
    ''' Checking if a weak reference is 'alive'. '''
    print(wf.alive)     # True

    # a = None      ## Nullify the reference
    del a           ## Or explicitly delete the object
                        ## Bye          executed by the handler
    print(wf.alive)     ## False
# gc_handler()

''' Nullify or 'del' just reduces the rc but the object may not be garbaged.
        e.g. the value is aliased by other object. '''
def alive_test():
    a1 = a2 = A()
    print(sys.getrefcount(a1))	    ## 3

    a2 = None
    # del a2
    print(sys.getrefcount(a1))	    ## 2
    a1.hello()                      ## Hello
# alive_test()

''' Owner Problems '''
class A:                ## Ownee
    def hello(self):
        print('Hello')
class B:                ## Owner
    def __init__(self, a):
        self.a = a      ## reference to ownee.

    def hello(self):
        self.a.hello()  ## call method of ownee.

def owner_problem():
    a = A()
    b = B(a)
    print(sys.getrefcount(a))	    ## 3
    ''' The extra reference is in 'b' object. '''

    ''' Deleting 'a' just nullify the reference but not make it is a garbage. '''
    del a
    b.hello()                       ## Hello
# owner_problem()

''' Solving the problem with weak reference. '''
class C:  ## Owner hold a weak reference to an ownee.
   def __init__(self, a):
        self.a = weakref.ref(a)
   def hello(self):
        if self.a != None and self.a() is not None:
            self.a().hello()
        else:
            print('The object is dead.')

def weak_owner():
    a = A()
    c = C(a)
    print(sys.getrefcount(a))	    ## 2

    del a
    c.hello()       ## The object is dead.
# weak_owner()

''' Sequences (e.g. list, tuple, dict and set) hold strong references to elements.
Deleting the elements won't make them garbages.  '''
def dict_test():
    d = dict()
    a = A()
    d['a'] = a

    del a
    d['a'].hello()	# Hello
# dict_test()

''' Python provides 'weakref' collections (e.g. WeakValueDictionary,
 WeakKeyDictionary and WeakSet) that hold weak references to elements. '''
def weak_dict():
    wd = weakref.WeakValueDictionary()
    a = A()
    wd['a'] = a

    del a
    print(wd.get('a'))		## None
# weak_dict()
