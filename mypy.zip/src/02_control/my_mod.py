
x = 1
names = ['John', 'Jack', 'Joe']

def hello():
    print("Hello")

def _hi():
    print("Hi")

class A:
    pass
