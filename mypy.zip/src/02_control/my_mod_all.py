__all__ = ('john', 'hello')

john = 'John Rambo'
jack = 'Jack Ripper'

def hello():
	print("Hello")

def hi():
	print("Hi")
