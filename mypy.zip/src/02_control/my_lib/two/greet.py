
def hello():
	print("Hello (pack.two).")

def hi():
	print("Hi (pack.two).")
