
def hello():
	print('Hello I am in my_lib\greet.py')
