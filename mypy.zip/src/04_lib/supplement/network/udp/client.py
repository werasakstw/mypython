import socket

HOST = '127.0.0.1'
PORT = 12345
MAX_BYTES = 1024

name = 'John'
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.sendto(name.encode(), (HOST, PORT))
data, address = sock.recvfrom(MAX_BYTES)
print(data.decode())

