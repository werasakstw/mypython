import socket

HOST = '127.0.0.1'
PORT = 12345
MAX_BYTES = 1024

def client_test(name):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        s.send(name.encode())
        data = s.recv(MAX_BYTES)
    print(data.decode())
client_test('John')

def connection_test(name):
    with socket.create_connection((HOST, PORT)) as c:
        c.send(name.encode())
        print(c.recv(MAX_BYTES).decode())
connection_test('Jack')
