## pip install dnspython
## pip install pymongo

import pymongo as pm

## "mongodb+srv://$[username]:$[password]@$[hostlist]/$[database]?authSource=$[authSource]")
URI = 'mongodb+srv://werasakstw:mu-prolog@cluster0.cvkr5.mongodb.net/mydb?retryWrites=true&w=majority'
def connect():
    try:
        con = pm.MongoClient(URI)
        print('Connection successes.')
        return con
    except:
        print('Connection fails.')
# connect()

from pprint import pprint
def status():
   with connect() as con:
       pprint(con['mydb'].command('dbstats'))
# status()

def list_tables():  ## in a database
   with connect() as con:
       print(con['mydb'].list_collection_names())
# list_tables()

def insert():
    john = {'name': 'John', 'dep': 'cs', 'gpa': 2.8}
    jack = {'name': 'Jack', 'dep': 'ee', 'gpa': 4.0}
    joe = {'name': 'Joe', 'dep': 'cs', 'gpa': 1.8}
    jim = {'name': 'Jim', 'dep': 'cs', 'gpa': 3.5}
    jame = {'name': 'Jame', 'dep': 'ce', 'gpa': 0.7}
    with connect() as con:
        tb = con['mydb']['students']
        tb.insert_many([john, jack, joe, jim, jame])
        print('Insert success.')
# insert()

def list():
    with connect() as con:
        tb = con['mydb']['students']
        # for r in tb.find():
        for r in tb.find({}, {'_id': False}):
            print(r)
# list()

def find():
    with connect() as con:
        tb = con['mydb']['students']
        for s in tb.find({'name': 'Jack'}):
        # for s in tb.find({'dep': 'cs'}, {'_id': False}):
        # for s in tb.find({'gpa': {"$lt": 2.0}}, {'_id': False, 'name': True, 'gpa': True}):
            print(s)
# find()

def delete():
    with connect() as con:
        tb = con['mydb']['students']

        ## Delete one (the first).
        tb.delete_one({'cs': 'cs'})

        ## Delete many with <filter>:
        x = tb.delete_many({'gpa': {"$lt": 2.0}})
        print(x.deleted_count)
        list()
# delete()

def drop():
    with connect() as con:
        con['mydb']['students'].drop()
    print('Drop success.')
# drop()
