import shutil, os
try:
	shutil.rmtree('mydb')
	os.mkdir('mydb')
	print('Reset success.')
except OSError as e:
        print(e)
