## pip install pymongo
import pymongo as pm

# client = pm.MongoClient() ## Default
## USer specified.
# client = pm.MongoClient("localhost", 27017)
# client = pm.MongoClient('mongodb://localhost:27017/')
# print(client)

def connect():
    connection = None
    try:
        connection = pm.MongoClient()
        print('Connection successes.')
    except:
        print('Connection fails.')
    return connection
# print(connect())

## Create 'mydb' database and 'students' table.
def create(db, table):
    with connect() as con:
        con[db][table]
        print("Create success.")
    ## The table is not created until there is data.
# create('mydb', 'students')

## For simplicity, the default is 'mydb' database and 'students' table.
from pprint import pprint
def status():
   with connect() as con:
       pprint(con['mydb'].command('dbstats'))
# status()

## A collection is a table.
def list_tables():  ## in a database
   with connect() as con:
       print(con['mydb'].list_collection_names())
# list_tables()

def insert():
    with connect() as con:
        tb = con['mydb']['students']

        # insert_one()  Records are represented as dict(json).
        tb.insert_one({'name': 'John', 'dep': 'cs', 'gpa': 2.8})
        tb.insert_one({'name': 'Jack', 'dep': 'ee', 'gpa': 4.0})

        # insert_many()
        joe = {'name': 'Joe', 'dep': 'cs', 'gpa': 1.8}
        jim = {'name': 'Jim', 'dep': 'cs', 'gpa': 3.5}
        jame = {'name': 'Jame', 'dep': 'ce', 'gpa': 0.7}
        tb.insert_many([jim, jame, joe])
        print('Insert success.')
# insert()

def find_one():
    with connect() as con:
        tb = con['mydb']['students']
        pprint(tb.find_one())
    ## '_id' is automatically created.
# find_one()

def find_all():
    with connect() as con:
        tb = con['mydb']['students']
        for r in tb.find():
        # for r in tb.find().limit(2):
        # for r in tb.find().skip(2):
            print(r)
            # print(r['name'])
# find_all()

def filter():
    with connect() as con:
        tb = con['mydb']['students']

        ## find(<filter>)      {} filter is allow all.
        for s in tb.find({'dep': 'cs'}):
        # for s in tb.find({'gpa': {"$lt": 2.0}}):
        # for s in tb.find({'name': {'$regex': '^Ja'}}):

        ## find(<filter>, <projection>)
        # for s in tb.find({}, {'name', 'gpa'}):
        # for s in tb.find({}, {'_id': False, 'name': True, 'gpa': True}):
            print(s)
# filter()

def cursor():
    with connect() as con:
        tb = con['mydb']['students']

        ## find() returns a cursor.
        cs = tb.find({}, {'_id': False, 'name': True})

        ''' The cursor starts at before the first.
        A next() is needed to access the first record.  '''
        print(cs.next())        ## {'name': 'John'}

        ## An exception is raised when next() passes the last.
        try:
            while(True):
                print(cs.next()['name'], end=', ')
        except Exception:   ## Jack, Jim, Jame, Joe, End
            print('End')

        ## rewind() moves the cursor back to the beginning.
        cs.rewind()
        print(cs.next()['name'])            ## John

        ''' Indexing [] does not moved the cursor.
        But the cursor must be at the beginning.   '''
        cs.rewind()
        print(cs[0]['name'], cs[1]['name']) ## John Jack

        # 'for' loop simplifies cursor iteration.
        for i in cs:
            print(i['name'], end=', ')
        print()             ## John, Jack, Jim, Jame, Joe,
        ## The cursor is run out after iteration.

        ## Slicing allows accessing partial range.
        cs.rewind()
        for i in cs[1:3]:
            print(i['name'], end=', ')  ## Jack, Jim,
# cursor()

## Mongo items are json not structured records.
def update_test():
    with connect() as con:
        tb = con['mydb']['students']

        # update_one()
        condition = { 'name': 'Jim' }
        new_value = { "$set": { 'dep': 'it' } }
        tb.update_one(condition, new_value)

        # update_many()
        tb.update_many(
            {'gpa': {"$lt": 2.0}},
            { '$set': {'isPro': True}}
        )
        find_all()
# update_test()

def sort_test():
    with connect() as con:
        tb = con['mydb']['students']

        for s in tb.find().sort('name'):    ## Default is pm.ASCENDING
        # for s in tb.find().sort('name', pm.DESCENDING):
            print(s)
# sort_test()

def json_test():
    with connect() as con:
        tb = con['mydb']['students']

        ## A cursor is an iterable object.
        cs = tb.find({}, {'_id': False, 'name': True, 'gpa': True})
        for d in cs:
            print(d)
        cs.rewind()

        ## A cursor can be collected into a list of dicts.
        print(list(cs))
# json_test()

def delete():
    with connect() as con:
        tb = con['mydb']['students']

        ## Delete the first.
        tb.delete_one({'dep': 'cs'})

        ## Delete many with <filter>:
        x = tb.delete_many({'gpa': {"$lt": 2.0}})
        print(x.deleted_count)

        find_all()
# delete()

def drop_table():
    with connect() as con:
        con['mydb']['students'].drop()
    print('Drop table success.')
# drop_table()
