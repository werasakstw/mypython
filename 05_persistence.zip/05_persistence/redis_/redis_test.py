# pip install redis

import redis
r = redis.Redis() ## host='localhost', port=6379, db=0,
                  ## password=None, socket_timeout=None,...
# print(r)
# print(r.ping())
## Redis implements a connections pool, 'r' needs no closing.

''' Items are stored as <key>:<value>.
<key> is a str.
<value> is converted and stored as bytes array.  '''
def set_get():
    r.set('john', 'john@rambo.com')
    r.set('jack', 'jack@ripper.com')

    print(r.get('john'))
    print(r.get('jack').decode())
# set_get()

''' When the server is closed or as defined by:
            save <seconds> <changes>
The current data is dumped into 'dump.rdb' in the directory that starts
the server. If the 'dump.rdb' is deleted all data will be lost.
Try closing the server and delete 'dump.rdb' then restart.  '''
# print(r.get('john'))

## An item <value> may be a list. rpush() inserts a value at the tail.
def list_test():
    r.rpush('a', 'john')
    r.rpush('a', 'jack')
    r.rpush('a', 'joe')

    ## lrange(<key>, start, stop) returna a specified range.
    print(r.lrange('a', 0, 2))  ## [b'john', b'jack', b'joe']

    ## -1 is the last.
    print(r.lrange('a', 0, -1)) ## [b'john', b'jack', b'joe']

    ## rpop(<key>) returns the last in the list.
    print(r.rpop('a'))          ## b'joe'

    ## rpop(<key>) returns the first in the list.
    print(r.lpop('a'))          ## b'john'
# list_test()

# Delete all saved items
r.flushall()

## An item <value> may be a set. sadd() adds a value to the set.
def set_test():
    r.sadd('s', 'john')
    r.sadd('s', 'jack')
    r.sadd('s', 'joe')
    r.sadd('s', 'john')

    ## smembers(<key>) return the set.
    print(r.smembers('s'))      ## {b'jack', b'john', b'joe'}

    ## sismember(<key>, <value>) checks if <value> is in the set.
    print(r.sismember('s', 'joe'))  ## True
    print(r.sismember('s', 'jim'))  ## False
# set_test()

## mset(<dict>) creates items of <key>:<value> from a dict.
def dict_test():
    d = { 'john': 'Rambo',
          'jack': 'ripper',
          'john': 'rambo' }
    r.mset(d)

    print(r.get('john'))          ## b'rambo'

    ## mget(<keys>) return a list of values of the <keys>.
    print(r.mget('jack', 'john')) ## [b'ripper', b'rambo']

    ## set(<key>, <newvalue>) updates the <key> value with <newvalue>.
    r.set('john', 'Rambo')
    print(r.get('john'))        ## b'Rambo'

    ## If the <key> does not exists, set() creates a new item.
    r.set('joe', 'green')
    print(r.get('joe'))         ## b'green'

    ## delete(<key>) deletes the <key> item.
    r.delete('joe')
    print(r.get('joe'))         ## None

    ## exists(<key>) checks if the <key> exists.
    print(r.exists('jack'))     ## 1
    print(r.exists('joe'))      ## 0
# dict_test()

''' hset(<key> <field>, <value>) creates a <key> with
multiple <field> and <value>.  '''
def hash_test():
    r.hset('john', 'sid', 1)
    r.hset('john', 'dept', 'cs')
    r.hset('john', 'gpa', 3.8)

    print(r.hget('john', 'sid'), r.hget('john', 'dept'))  ## b'1' b'cs'
    print(r.hmget('john', 'sid', 'gpa'))  ## [b'1', b'3.8']

    ## hlen(<key>) returns number of fields.
    print(r.hlen('john'))     ## 2

    ## hkeys(<key>) returns the list of fields.
    print(r.hkeys('john'))    ## [b'sid', b'dept', b'gpa']

    ## hvals(<key>) returns the list of values.
    print(r.hvals('john'))    ## [b'1', b'cs', b'3.8']

    ## hgetall(<key>) returns the item as dict.
    print(r.hgetall('john'))  ## {b'sid': b'1', b'dept': b'cs', b'gpa': b'3.8'}

    ## hscan_iter(<key>) return the iterator of the item.
    for i in r.hscan_iter('john'):
        print(i, end='  ')     ## (b'sid', b'1')  (b'dept', b'cs')  (b'gpa', b'3.8')
# hash_test()

#-----------------------------------------------------------------

import hashlib as hl     ## A standard Python's lib
def register(name, pwd):
    r.set(name, hl.sha256(pwd.encode()).hexdigest())
# register('john', 'john123')
# register('jack', 'jack123')

def verify(name, pwd):
    return r.get(name).decode() == hl.sha256(pwd.encode()).hexdigest()
# print(verify('john', 'john124'))
# print(verify('jack', 'jack123'))
