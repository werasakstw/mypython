import sqlite3       ## Included in Python standard lib.

''' Create student Table  '''
def create():
    try:
        con = sqlite3.connect('mydb.db')
        cur = con.cursor()
        print("Successfully Connected to SQLite")
        cur.execute("""CREATE TABLE students (id INT, name TEXT, gpa REAL)""")
        cur.execute("""INSERT INTO students VALUES(1, 'John Rambo', 1.2)""")
        cur.execute("""INSERT INTO students VALUES(2, 'Jack Ripper', 4.0)""")
        cur.execute("""INSERT INTO students VALUES(3, 'Joe Green', 2.8)""")
        con.commit()
        print("Student table created")
        cur.close()
    except sqlite3.Error as err:
        print(err)
    finally:
        if con:
            con.close()
            print("Successfully close connection.")
# create()
''' Form now on, exclude error handling for simplicity. '''

''' Select: records as a list. '''
def list_all():
    con = sqlite3.connect('mydb.db')
    cur = con.cursor()
    cur.execute('SELECT * FROM students')   ## The result is in the cursor.
    lis = cur.fetchall()       ## returns a list of records (as tuples).
    for r in lis:
        print(r)
    ''' After fetchall() the result is run out. '''
    con.close()
# list_all()

''' execute() return a cursor which is iterable.
We can manually iterate a cursor without extra memory and not all
  records need to be processed. '''
def itr_cur():
    con = sqlite3.connect('mydb.db')
    cur = con.cursor()
    for r in cur.execute('SELECT * FROM students'):
        print(r)
    con.close()
# itr_cur()

''' Template Interpolation
A template is a string with ? as place holder.
execute(<temp>,<tuple>) interpolates <temp> with <tuple> and executes the result. '''
INSERT = 'INSERT INTO students VALUES(?, ?, ?)'
def insert(student):
    con = sqlite3.connect('mydb.db')
    cur = con.cursor()
    cur.execute(INSERT, student)
    con.commit()
    con.close()
# insert((4, 'Jame Bond', 1.8))

SELECT_STUDENT_BYNAME = 'SELECT * FROM students WHERE name = ?'
def find(name):
    con = sqlite3.connect('mydb.db')
    cur = con.cursor()
    for r in cur.execute(SELECT_STUDENT_BYNAME, (name,)):
        print(r)
    con.close()
# find('Jack Ripper')

def update(name, gpa):
    UPDATE_STUDENT = 'UPDATE students SET gpa = ? WHERE name = ?'
    with sqlite3.connect('mydb.db') as con:
        cur = con.cursor()
        cur.execute(UPDATE_STUDENT, (gpa, name))
        con.commit()
    list_all()
# update('Jame Bond', 3.8)

def delete_by_name(name):
    DELETE_STUDENT_BYNAME = 'DELETE FROM students WHERE name = ?'
    with sqlite3.connect('mydb.db') as con:
        cur = con.cursor()
        cur.execute(DELETE_STUDENT_BYNAME, (name,))
        ''' No error if the name is not found or the table is empty. '''
        con.commit()
    list_all()
# delete_by_name('Jame Bond')

def delete_all():
    with sqlite3.connect('mydb.db') as con:
        cur = con.cursor()
        cur.execute('DELETE FROM students')
        ''' No error if the table is empty. '''
        con.commit()
    list_all()      ## The table is empty.
# delete_all()

def drop_table(tname):
    with sqlite3.connect('mydb.db') as con:
        cur = con.cursor()
        cur.execute('DROP TABLE '+ tname)
        # error: if no table
        con.commit()
   # list_all()                 ## error
drop_table('students')
