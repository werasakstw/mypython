import csv
''' Write CSV file  '''
names = ["John", "Jack", "Joe", "Jame"]
gpa = [1.8, 4.0, 3.8, 1.2]
def csv_write():
    with open('tmp/test.csv', 'wt') as f:
        wt = csv.writer(f, lineterminator='\n')
        wt.writerow( ('id', 'name', 'gpa') )
        i = 1
        for n, g in zip(names, gpa):
            wt.writerow( (i, n, g) )
            i += 1
        # wt.writerow( (None, 'Average', '=AVERAGE(C2:C5)') )
# csv_write()
''' Attribute Options:
 delimeter           the items separate character
 lineterminator      the line separate character
 skipinitialspace    skip all the leading spaces after a delimiter  '''

''' Read CSV file '''
def csv_read():
    with open('tmp/test.csv') as f:
        f_csv = csv.reader(f)
        header = next(f_csv)    ## Read header as a list.
        print(header[0], header[1], header[2])
        for row in f_csv:
            print(row[0], row[1], row[2])
# csv_read()

''' Read CSV into a dict  '''
def csv_read_dict():
    with open('tmp/test.csv') as f:
        for r in csv.DictReader(f):  ## Read into a dict
            print(r['id'], r['name'], r['gpa'])
# csv_read_dict()

###############################################################

''' Ex. Compute Student Grade
Suppose the policy to compute total score and grade are the following: '''
def total(hw, mid, fin):
    return float(hw) + float(mid) * 0.4 + float(fin) * 0.5
def to_grade(t):
    return 'A' if t >= 90 else 'B' if t >= 80 else 'C' \
        if t >= 70 else 'D' if t >= 60 else 'F'
grades = {'A': 0, 'B': 0, 'C': 0, 'D': 0, 'F': 0 }

def student_grades():
    with open('data/students.csv') as f:
        for row in csv.DictReader(f):
            g = to_grade(total(row['hw'], row['mid'], row['fin']))
            print('%s:\t%s' % (row['name'], g))
            grades[g] += 1
        for g in ['A', 'B', 'C', 'D', 'F']:
            print('%s: %d' % (g, grades[g]), end='  ')
# student_grades()

def student_pie():
    with open('data/students.csv') as f:
        c = 0
        for row in csv.DictReader(f):
            g = to_grade(total(row['hw'], row['mid'], row['fin']))
            grades[g] += 1
            c += 1
        d = [ grades[i]*100/c for i in grades]
        pp.pie(d, autopct='%1.1f%%', labels=('A', 'B', 'C', 'D', 'F'))
        pp.show()
# student_pie()

def student_plot():
    with open('data/students.csv') as f:
        tt = [total(row['hw'], row['mid'], row['fin'])  for row in csv.DictReader(f) ]
        pp.bar(range(len(tt)), tt)
        # pp.hist(tt)       ## Histogram
        pp.show()
# student_plot()

#---------------------------------------------------------------

''' Student statistics using numpy array. '''
import numpy as np
def student_stat():
    def read(file):
        totals = []
        with open(file) as f:
            f_csv = csv.DictReader(f)
            for row in f_csv:
                totals.append(total(row['hw'], row['mid'], row['fin']))
        return np.array(totals, dtype=np.float32)

    d = read('data/students.csv')
    print('Number of students: %d' % d.size)
    print('Min: %1.2f  Max: %1.2f' % (d.min(), d.max()))
    print('Mean: %1.2f' % d.mean())
    print('Sd: %1.2f' % d.std())
# student_stat()

#----------------------------------------------------------------
