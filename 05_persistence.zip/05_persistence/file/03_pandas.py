''' pip install pandas  '''
import pandas as pd

student_dict = { 'name': ['John', 'Jack', 'Joe'],
                  'id': [1, 2, 3],
                  'gpa': [3.8, 4.0, 2.7],
                  'dep': ['cs', 'math', 'it'] }
''' A 'dataframe' represents a table (a collection of records) which
  is implemented as a dict. '''
def data_frame():
    ''' Create a dataframe from dict '''
    df = pd.DataFrame(student_dict)
    print(df)
##                  id  name   dep  gpa
##               0   1  John    cs  3.8
##               1   2  Jack  math  4.0
##               2   3   Joe    it  2.7
##       Thefirst column is 'index'.

    print(df.values)      ## list of list (without index).
##               [[1 'John' 'cs' 3.8]
##                [2 'Jack' 'math' 4.0]
##                [3 'Joe' 'it' 2.7]]

    ''' DataFrame to dict '''
    print(df.to_dict())
    ## {'name': {0: 'John', 1: 'Jack', 2: 'Joe'}, 'id': {0: 1, 1: 2, 2: 3}, 'gpa': {0: 3.8, 1: 4.0, 2: 2.7}, 'dep': {0: 'cs', 1: 'math', 2: 'it'}}

    ''' DataFrame to a list of records '''
    print(df.to_dict('records'))
    ## [{'name': 'John', 'id': 1, 'gpa': 3.8, 'dep': 'cs'}, {'name': 'Jack', 'id': 2, 'gpa': 4.0, 'dep': 'math'}, {'name': 'Joe', 'id': 3, 'gpa': 2.7, 'dep': 'it'}]

    ''' Listing dataframe '''
    print(df.head())    ## default is 5 rows.
    print(df.head(1))   ##       id  name dep  gpa
                        ##   0   1  John  cs  3.8
    print(df.head(1).values) ## [[1 'John' 'cs' 3.8]]

    ''' Dataframe info  '''
    # print(df.info())

    ''' Statistic for only number type columns, exclude object type. '''
    # print(df.describe())
# data_frame()

def df_create():
    ''' Create a dataframe from dict. '''
    df1 = pd.DataFrame({ 'name': ['John', 'Jack'],
                          'dep': ['cs', 'it'] })
    print(df1)
##               name dep
##            0  John  cs
##            1  Jack  it

    ''' Create a dataframes from list of rows and columns. '''
    df2 = pd.DataFrame(data=[['Joe', 'ce'], ['John', 'cs']],
                   columns=['name', 'dep'])
    print(df2)
##               name dep
##            0   Joe  ce
##            1  John  cs

    ''' Concatenate Dataframe:
    1. Horizontal concatenate is (axis=0). '''
    df = pd.concat([df1, df2], axis=0)
    print(df)
##               name dep
##            0  John  cs
##            1  Jack  it
##            0   Joe  ce
##            1  John  cs      ##  duplicate row

    ''' Remove duplicate '''
    df = df.drop_duplicates()
    print(df)
##               name dep
##            0  John  cs
##            1  Jack  it
##            0   Joe  ce      ## duplicate index.
    ''' Reset index() creates new default index and moves old index
          to 'index' column.'''
    df = df.reset_index()
    print(df)
##               index  name dep
##            0      0  John  cs
##            1      1  Jack  it
##            2      0   Joe  ce

    ''' Drop column: normally after reset_index(), 'index' column is removed. '''
    df = df.reset_index().drop(columns=['index'])
    print(df)
##               name dep
##            0  John  cs
##            1  Jack  it
##            2   Joe  ce

    '''2. Vertical Cancatenate is (axis=1). '''
    df3 = pd.DataFrame({ 'grade': ['A', 'B', 'C']} )
    print(pd.concat([df, df3], axis=1))
##                   name dep grade
##                0  John  cs     A
##                1  Jack  it     B
##                2   Joe  ce     C

#-------------------------------------------------------------

    ''' merge() combines dataframes by column.'''
    df1 = pd.DataFrame( data=[['John', 'it'],
                          ['Jack', 'cs'],
                          ['Joe', 'ce'] ],
                    columns=['name', 'dep'])
    print(df1)
##                   name dep
##                0  John  it
##                1  Jack  cs
##                2   Joe  ce

    df2 = pd.DataFrame( data=[['Jack', 'A'],
                              ['Jame', 'B'] ],
                        columns=['name', 'grade'])
    print(df2)
##                  name grade
##                0  Jack     A
##                1  Jame     B

    print(df1.merge(df2, how='inner', on=['name']))
##                   name dep grade
##                0  Jack  cs     A

    print(df1.merge(df2, how='left', on=['name']))
##                   name dep grade
##                0  John  it   NaN
##                1  Jack  cs     A
##                2   Joe  ce   NaN

#------------------------------------------------------------

    ''' join() combines dataframes by index. '''
    df1 = pd.DataFrame( data=[['John', 'it'],
                              ['Jack', 'cs'],
                              ['Joe', 'ce'] ],
                        columns=['name', 'dep'],
                        index=['john', 'jack', 'joe'])
    # print(df1)
##                  name dep
##            john  John  it
##            jack  Jack  cs
##            joe    Joe  ce

    df2 = pd.DataFrame( data=[[4.0, 'A'], [1.8, 'B'] ],
                        columns=['total', 'grade'],
                        index=['jack', 'jame'])
    # print(df2)
##                  total grade
##            jack    4.0     A
##            jame    1.8     B

    print(df1.join(df2, how='left'))
##                  name dep  total grade
##            john  John  it    NaN   NaN
##            jack  Jack  cs    4.0     A
##            joe    Joe  ce    NaN   NaN

    print(df1.join(df2, how='right'))
##                  name  dep  total grade
##            jack  Jack   cs    4.0     A
##            jame   NaN  NaN    1.8     B

    print(df1.join(df2, how='outer'))
##                  name  dep  total grade
##            jack  Jack   cs    4.0     A
##            jame   NaN  NaN    1.8     B
##            joe    Joe   ce    NaN   NaN
##            john  John   it    NaN   NaN
# df_create()

#------------------------------------------------------------

''' A 'series' represents a column which is implemented as list. '''
def column():
    df = pd.DataFrame(student_dict)
    print(df)
    print(df.columns) ## Index(['name', 'id', 'gpa', 'dep'], dtype='object')
    print(df.columns.values)  ## ['name' 'id' 'gpa' 'dep']

    ''' Columns may be reordered. '''
    print(df.loc[:, ['id', 'name', 'dep', 'gpa']])
##               id  name   dep  gpa
##            0   1  John    cs  3.8
##            1   2  Jack  math  4.0
##            2   3   Joe    it  2.7

    ''' Column names can be renamed. '''
    print(df.rename(columns={'id': 'sid', 'name': 'student name'}))
##               student name  sid  gpa   dep
##            0         John    1  3.8    cs
##            1         Jack    2  4.0  math
##            2          Joe    3  2.7    it

    ''' Selected Columns '''
    print(df.drop(columns=['id', 'dep']))
##               name  gpa
##            0  John  3.8
##            1  Jack  4.0
##            2   Joe  2.7

    ''' Transpose a datafrome flips to present horizontally. '''
    print(df.transpose())   ## Try:   df.T
##                     0     1    2
##            name  John  Jack  Joe
##            id       1     2    3
##            gpa    3.8   4.0  2.7
##            dep     cs  math   it

    ''' Projection is indexing for speciied column. '''
    print(df['name'].values)   ## ['John' 'Jack' 'Joe']

    ''' Dot projection (compile time binding). '''
    print(df.dep.values)       ## ['cs' 'math' 'it']

    ''' List of projection rows. '''
    print([(name, gpa) for name, gpa in zip(df.name.values, df.gpa.values)])
              ## [('John', 3.8), ('Jack', 4.0), ('Joe', 2.7)]
# column()

''' Index is 'row label'. '''
def index():
   df = pd.DataFrame(student_dict,
            index=['A', 'B', 'C'])  ## Default index is [0, 1, ...]
   print(df)
##               id  name   dep  gpa
##            A   1  John    cs  3.8
##            B   2  Jack  math  4.0
##            C   3   Joe    it  2.7

   print(df.index)   ## Index(['A', 'B', 'C'], dtype='object')
   print(df.index.values)  ## ['A' 'B' 'C']

   ''' Index can be assigned a meaningful name. '''
   df.index.name = 'sid'
   print(df)
##                 id  name   dep  gpa
##            sid
##            A     1  John    cs  3.8
##            B     2  Jack  math  4.0
##            C     3   Joe    it  2.7

   ''' reset_index() turns the index into a column and replacing
          the index with the default index.
       set_index() turns a column into the index.   '''
   newdf = df.reset_index().set_index("name")
   print(newdf)
##                 sid  id   dep  gpa
##            name
##            John   A   1    cs  3.8
##            Jack   B   2  math  4.0
##            Joe    C   3    it  2.7

   ''' Index can be sorted. '''
   print(newdf.sort_index())
##                 sid  id   dep  gpa
##            name
##            Jack   B   2  math  4.0
##            Joe    C   3    it  2.7
##            John   A   1    cs  3.8

   ''' Index allows efficient access to elements. '''
   print(newdf.gpa['Jack'])   ## 4.0
   print(newdf.gpa.John)      ## 3.8
# index()

#---------------------------------------------------------

df = pd.DataFrame(student_dict,
            columns=['id', 'name', 'dep', 'gpa'],
            index=['john', 'jack', 'joe'])
# print(df)
##                      id  name   dep  gpa
##                john   1  John    cs  3.8
##                jack   2  Jack  math  4.0
##                joe    3   Joe    it  2.7

''' Selection
loc[] is selection expression that can be used similar to SQL select
   but more compact .   '''
def selection():
    ''' Select with <index> and <column>.
    loc[<index>, <column>] returns value in the <column> of the rows
        specified by the <index>.  '''
    print(df.loc['jack', 'gpa'])           ## 4.0

    ''' <index> may be specified as a list. '''
    print(df.loc[['john', 'joe'], 'gpa'])  ## john    3.8
                                           ## joe     2.7
                                           ## Name: gpa, dtype: float64
    ''' 'values' attribute is the list of selected values.  '''
    print(df.loc[['john', 'joe'], 'gpa'].values)  ## [3.8 2.7]

    ''' <index> and <column> can be specified as 'range' which is
           <start>:<stop> if <start> or <stop> is not specified
           the default is all.  '''
    print(df.loc[:, 'name'].values)     ## ['John' 'Jack' 'Joe']
    print(df.loc[:, ['name', 'gpa']].values) ## [['John' 3.8]
                                             ##  ['Jack' 4.0]
                                             ##  ['Joe' 2.7]]
    print(df.loc[:, 'name':'gpa'].values)   ## [['John' 'cs' 3.8]
                                            ##  ['Jack' 'math' 4.0]
                                            ##  ['Joe' 'it' 2.7]]
    print(df.loc['john', :].values)         ## [1 'John' 'cs' 3.8]
    print(df.loc['john':'joe', :].values)   ## [[1 'John' 'cs' 3.8]
                                            ##  [2 'Jack' 'math' 4.0]
                                            ##  [3 'Joe' 'it' 2.7]]

    ''' Select by 'condition' which is an expression that returns boolean. '''
    cond = df.gpa < 3.0
    print(cond.values)                       ## [False False  True]
    print(df.loc[cond, :].values)             ## [[3 'Joe' 'it' 2.7]]

    ''' <column>.isin(<list>) returns True if the <column> is in <list>. '''
    cond = df.dep.isin(['cs', 'it'])
    print(cond.values)                       ## [ True False  True]
    print(df.loc[cond, 'gpa'].values)         ## [3.8 2.7]

    ''' iloc[] allows specifying <index> and <column> by index.'''
    print(df.iloc[1, 3])                  ## 4.0
    print(df.iloc[[0, 2], 3].values)      ## [3.8 2.7]
# selection()

''' Selection by a query which is a string of expression that returns boolean. '''
def query():
    print(df.query('id == 1').values)         # [[1 'John' 'cs' 3.8]]
    print(df.query('name == "Jack"').values)  # [[2 'Jack' 'math' 4.0]]

    ''' @ de-references variable in query string. '''
    id = 2
    print(df.query('id == @id').values) # [[2 'Jack' 'math' 4.0]]
# query()

''' Sorting Dataframe '''
def sort():
    ''' Sort by columns '''
    print(df.sort_values(by='gpa'))  ## default is ascending=True
##                  id  name   dep  gpa
##            joe    3   Joe    it  2.7
##            john   1  John    cs  3.8
##            jack   2  Jack  math  4.0

    print(df.sort_values(by='gpa',  ascending=False))
##                  id  name   dep  gpa
##            jack   2  Jack  math  4.0
##            john   1  John    cs  3.8
##            joe    3   Joe    it  2.7

    ''' Sort by multiple columns, left most is the most priority. '''
    print(df.sort_values(['dep', 'name']))
##                  id  name   dep  gpa
##            john   1  John    cs  3.8
##            joe    3   Joe    it  2.7
##            jack   2  Jack  math  4.0
# sort()

#--------------------------------------------------------------

''' loc[] allows modification (with side effect) to dataframe. '''
def modification():
    ''' Set value at <index>, <column>.  '''
    newdf = df.copy()
    newdf.loc['john', 'name'] = 'John Rambo'
    print(newdf)
##                  id        name   dep  gpa
##            john   1  John Rambo    cs  3.8
##            jack   2        Jack  math  4.0
##            joe    3         Joe    it  2.7

    ''' Set at <index> specified by condition. '''
    newdf = df.copy()
    newdf.loc[newdf.name == 'Jack', 'name'] = 'Jack Ripper'
    print(newdf)
##                  id         name   dep  gpa
##            john   1         John    cs  3.8
##            jack   2  Jack Ripper  math  4.0
##            joe    3          Joe    it  2.7

    ''' Set multiple rows '''
    newdf = df.copy()
    newdf.loc[['john', 'joe'], 'gpa'] = [3.9, 3.2]
    print(newdf.loc[['john', 'joe'], ['name', 'gpa']].values)
                                ## [['John' 3.9]
                                ##  ['Joe' 3.2]]
    ''' Add new column '''
    newdf = df.copy()
    newdf['birth_year'] = [2002, 1999, 2003]   ## Dot syntax is not allowed.
    print(newdf)
##               id  name   dep  gpa  birth_year
##        john   1  John    cs  3.8     2002
##        jack   2  Jack  math  4.0     1999
##        joe    3   Joe    it  2.7     2003

    ''' Add new column by condition. '''
    newdf['age'] = 2023 - newdf.birth_year
    print(newdf)
##              id  name   dep  gpa  age  birth year   age
##        john   1  John    cs  3.8   20        2002    21
##        jack   2  Jack  math  4.0   23        1999    24
##        joe    3   Joe    it  2.7   19        2003    20

    ''' Add new column with loc[] and condition. '''
    newdf = df.copy()
    newdf.loc[newdf.gpa < 3.0, 'is_pro'] = True
    print(newdf)
##                  id  name   dep  gpa is_pro
##            john   1  John    cs  3.8    NaN
##            jack   2  Jack  math  4.0    NaN
##            joe    3   Joe    it  2.7   True

    ''' Replace NaN with a value '''
    newdf = newdf.fillna(False)
    print(newdf)
##                  id  name   dep  gpa  is_pro
##            john   1  John    cs  3.8   False
##            jack   2  Jack  math  4.0   False
##            joe    3   Joe    it  2.7    True

    ''' Replace the entire table '''
    newdf = newdf.replace(False, 'No').replace(True, 'Yes')
    ''' Replace at specified column '''
    # newdf = newdf.replace({'is_pro': {True: 'Yes', False: 'No'}})
    print(newdf)
##                  id  name   dep  gpa is_pro
##            john   1  John    cs  3.8     No
##            jack   2  Jack  math  4.0     No
##            joe    3   Joe    it  2.7    Yes
# modification()

#-------------------------------------------------------------

''' Correcting irregular values '''
df = pd.DataFrame({ 'id': ['12-3', '1 2', '007'],
                    'fname': ['john  ', '  jack', '  jame  '],
                    'lname': ['rambo', 'ripper', 'bond'] })
# print(df)
##                    id     fname   lname
##                0  12-3    john     rambo
##                1   1 2      jack  ripper
##                2   007    jame      bond

## Python str methods can be applied to text columns.
def str_method():
    print(df.id.str.isnumeric().values)        ## [False False  True]
    print(df.id.str.contains(' ').values)      ## [False  True False]
    print(df.id.str.replace('-', '').values)   ## ['123' '1 2' '007']
    print(df.id.str.replace(' ', '').values)   ## ['12-3' '12' '007']
    print(df.fname.str.startswith('jo').values) ## [ True False False]
    print(df.fname.str.strip().str.capitalize().values) ## ['John' 'Jack' 'Jame']

    def strip_zero(s):
        if s.startswith('0') and s.isnumeric():
            return int(s)
        return s
    print(df.id.map(strip_zero).values)  ## ['12-3' '1 2' 7]

    ''' Create 'name' column from 'fname' and 'lname'. '''
    df['name'] = df.fname.str.strip().str.capitalize() + ' ' + df.lname.str.capitalize()
    print(df.drop(columns=['id', 'fname', 'lname']))
##                            name
##                  0   John Rambo
##                  1  Jack Ripper
##                  2    Jame Bond
# str_method()

def phone():
    df['phone'] = ['123-111-2222', '333-444-5555', '000-777-7777']

    df['phone'] = df.phone.str.replace('-', '')
    print(df.phone.values)  ## ['1231112222' '3334445555' '0007777777']

    def dash(p):
        x, y, z = p[0:3], p[3:6], p[6:]
        return '%s-%s-%s' % (x, y, z)
    df['phone'] = df.phone.map(dash)
    print(df.phone.values) ## ['123-111-2222' '333-444-5555' '000-777-7777']
# phone()

def date():
    df['date'] = ['1/13/2021', '02/10/2022', '3/33/2022']     ## m/d/y

    def date_trans(date):
        m, d, y = date.split('/')
        return '%s:%s:%s' % (d.zfill(2), m.zfill(2), y)

    df['date'] = df.date.map(date_trans)
    print(df.date.values)  ## ['13:01:2021' '10:02:2022' '33:03:2022']
# date()

#------------------------------------------------------------------

''' Dirty Data
None is a missing value. An empty str '' is an invalid value. '''
def dirty():
    df = pd.DataFrame({ 'name': ['John', 'Jack', ''],
                        'gpa': [2.1, None, 3.8] })
    # print(df)
##                     name   gpa
##                  0  John   2.1
##                  1  Jack   NaN
##                  2         3.8

    ''' Non-dirty count, '' is not considered dirty. '''
    print(df.name.values, df.name.count())   ## ['John' 'Jack' ''] 3
    print(df.gpa.values, df.gpa.count())     ## [2.1 nan 3.8] 2

    ''' Aggregate test for None, returns a list of boolean. '''
    print(df.gpa.isnull().values)    ## [False  True False]
    print(df.gpa.notnull().values)   ## [ True False  True]

    ''' Remove None '''
    print(df.name.dropna().values)   ## ['John' 'Jack' '']
    print(df.gpa.dropna().values)    ## [2.1 3.8]

    ''' Replace None with a value. '''
    print(df.gpa.fillna(0).values)   ## [2.1 0.  3.8]
    newdf = df.fillna({'gpa': df.gpa.mean()})   ## Alternatively
    print(newdf.gpa.values)          ## [2.1  2.95 3.8 ]

    ''' Add a None row '''
    newdf = df.copy()
    newdf.loc[3, :] = None
    print(newdf)
##                        name  gpa
##                     0  John  2.1
##                     1  Jack  NaN
##                     2        3.8
##                     3  None  NaN

    ''' Remove missing data rows '''
    print(newdf.dropna())
##                        name  gpa
##                     0  John  2.1
##                     2        3.8

    ''' Remove rows which all values are missing '''
    print(newdf.dropna(how='all'))
##                        name  gpa
##                     0  John  2.1
##                     1  Jack  NaN
##                     2        3.8
# dirty()

def duplicate():
    df = pd.DataFrame({ 'name': ['John', 'Jack', 'John', 'John'],
                       'grade': ['C', 'B', 'C', 'A'],
                       'dep': ['cs', 'ce', 'it', 'cs']})
    print(df)
##                        name grade dep
##                     0  John     C  cs
##                     1  Jack     B  ce
##                     2  John     C  it
##                     3  John     A  cs

    ''' Check if all value in a certain column are unique. '''
    print(df.name.is_unique)         ## False

    ''' Get unique values of a certain column. '''
    print(df.name.unique())          ## ['John' 'Jack']

    ''' Get boolean list of indexs of column contains duplicates. '''
    print(df.name.duplicated().values)
                ## [False False True  True]

    ''' Remove duplicate by certain column. '''
    print(df.name.drop_duplicates())
##                    0    John
##                    1    Jack

    ''' Get row that duplicates in a certain column, leave the first occurrence. '''
    print(df.loc[df.name.duplicated(), :])
##                        name grade dep
##                     2  John     C  it
##                     3  John     A  cs

    ''' Get all row that duplicates in a certain column. '''
    print(df.loc[df.name.duplicated(keep=False), :])
##                        name grade dep
##                     0  John     C  cs
##                     2  John     C  it
##                     3  John     A  cs

    ''' Drop rows that contain duplicates in a certain column, leave the first occurrence. '''
    print(df.drop_duplicates(['name']))
##                        name grade dep
##                     0  John     C  cs
##                     1  Jack     B  ce

    ''' Drop rows that contain duplicates in a certain column, include the first occurrence. '''
    print(df.drop_duplicates(['name'],  keep=False))
##                        name grade dep
##                     1  Jack     B  ce

    ''' Drop rows of duplicate multiple columns. '''
    print(df.drop_duplicates(['name', 'dep']))
##                        name grade dep
##                     0  John     C  cs
##                     1  Jack     B  ce
##                     2  John     C  it
# duplicate()

def manipulate():
    df = pd.DataFrame({ 'name': ['John', 'Jack', 'Jame'],
                       'mid': [65, 98, 43],
                       'fin': [72, 95, 37]})
    print(df)
##                        name  mid  fin
##                     0  John   65   72
##                     1  Jack   98   95
##                     2  Jame   43   37

    ''' Drop columns '''
    newdf = df.drop(columns=['name', 'mid'])
    print(newdf)
##                        fin
##                    0    72
##                    1    95
##                    2    37

    ''' Aggregate arithmetics on the entire dataframe, numberic values only. '''
    print(newdf + 1)
##                          fin
##                      0    73
##                      1    96
##                      2    38

    ''' Aggregate arithmetics on a certain column, retruns a series. '''
    print((newdf['fin'] + 2).values)    ## [74 97 39]
    ''' Dot syntax is allowed. '''
    print((newdf.fin + 2).values)       ## [74 97 39]

    ''' map() applies a function to each elements. '''
    print(newdf.fin.map(lambda x : x+3).values) ## [75 98 40]

    ''' Aggregate and modify a certain column. '''
    print(newdf.fin + 3)
##                       fin
##                    0   75
##                    1   98
##                    2   40
# manipulate()

#----------------------------------------------------

''' pip install openpyxl '''

''' CSV and Dataframe. '''
def pandas_csv():
    ''' Read dataframe from csv file. '''
    df = pd.read_csv('data/students.csv')
    print(df)

    ''' Write a dataframe as csv file. '''
    df.to_csv('tmp/test.csv', index=False)
    ''' Write a dataframe as xlsx file. '''
    df.to_excel('tmp/test.xlsx', index=False)

    ''' Read XLSX:  (Python 3.9+ and Pandas 1.2+). '''
    df = pd.read_excel('tmp/test.xlsx')
    print(df)
# pandas_csv()

def csv_read_params():
    print(pd.read_csv('data/thai.csv', encoding='ISO-8859-11' ))
    # print(pd.read_csv('data/students.csv', usecols=['name', 'fin']))
    # print(pd.read_csv('data/students.csv', skiprows=[2, 5]))
    # print(pd.read_csv('data/students.csv', nrows=3))
    # print(pd.read_csv('data/students.csv', header=None))
    # print(pd.read_csv('data/students.csv', skiprows=1, names=['sid', 'sname', 'homework', 'midterm', 'final']))
# csv_read_params()

def csv_miss_value():
    ''' Missing value is NaN, by default. '''
    print(pd.read_csv('data/missing.csv'))
    # print(pd.read_csv('data/missing.csv', keep_default_na=False))
    # print(pd.read_csv('data/missing.csv', na_values='Missing')) ## add 'Missing as NaN.

    def fix_grade(x):
        return '-' if x in ['', 'None'] else x
    def fix_pro(x):
        return '-' if x in ['', 'Missing'] else x
    print(pd.read_csv('data/missing.csv', converters={'grade': fix_grade, 'pro': fix_pro} ))
# csv_miss_value()

''' Excel stores all numbers internally as floats.
Pandas transforms numbers without meaningful decimals to integers. '''
def formats():
   df = pd.read_csv('data/formats.csv')
   print(df)
   # df.info()
# formats()
