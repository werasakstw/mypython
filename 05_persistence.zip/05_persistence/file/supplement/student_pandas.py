import pandas as pd

''' Create 'total' column:  total = hw + 40% mid + 50% fin   '''
def add_column():
    df = pd.read_csv('../data/students.csv')
    df['total'] = round((df.hw) + (0.4 * df.mid) + (0.5 * df.fin), 2)
    print(df)
    df.to_csv('../tmp/students.csv', index=False)
# add_column()

def to_grade(total):
  return 'A' if total >= 90 else 'B' if total >= 80 else \
         'C' if total >= 60 else 'D' if total >= 50 else 'F'

def grade_report():
    df = pd.read_csv('../tmp/students.csv')

    ''' Compute grades from totals. '''
    df['grade'] = df.total.map(to_grade)
    # print(df)

    ''' Create result dataframe. '''
    rdf = pd.DataFrame()
    rdf['name'] = df.name
    rdf['total'] = df.total
    rdf['grade'] = df.grade
    # print(rdf)

    rdf = rdf.sort_values(by='total', ascending=False)
    print(rdf)

    rdf.to_csv('../tmp/report.csv', index=False)
# grade_report()

import numpy as np
def statistic_report():
    df = pd.read_csv('../tmp/report.csv')
    with open('../tmp/result.txt', 'w') as f:
        print('Number of students: ', df.name.count(), file=f)                      ## 3
        print('Min:', df.total.min(), file=f)
        print('Max:', df.total.max(), file=f)
        print('Mean: %.2f' % round(df.total.mean(),2), file=f)
        print('Median: %.2f' % df.total.median(), file=f)
        print('SD: %.2f' % df.total.std(), file=f)
        print('Frequency count:',  file=f)
        gc = df.grade.value_counts()        ## a dict
        for g, c in sorted(gc.items(), key=lambda item: item[0]):
            print('\t%s: %d' % (g, c),  file=f)
# statistic_report()

import matplotlib.pyplot as pp
def students_pie():
    df = pd.read_csv('../tmp/report.csv')

    pp.figure(1)
    pp.title('Total Histogram')
    pp.hist(df.total)


    pp.figure(2)
    pp.title('Grade Histogram')
    df = df.sort_values(by='grade')
    pp.hist(df.grade)

    pp.figure(3)
    pp.title('Grade Pie')
    gc = df.grade.value_counts()
    pp.pie(gc, autopct='%.1f%%', labels=('C', 'B', 'A', 'F'))

    pp.show()
# students_pie()
