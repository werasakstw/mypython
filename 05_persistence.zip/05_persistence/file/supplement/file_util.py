def write_file(name, data):
    with open(name, 'w') as f:
        f.write(data)

def read_file(name):
    with open(name, 'r') as f:
        return f.read()
