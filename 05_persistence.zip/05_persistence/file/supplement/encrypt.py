''' Encryption:
1. 'Caesar Method' encodes a message(string) with key(int).  '''
import string
def caesar():
    _chars = string.printable  ## Distinguish characters are favorable.
    _clen = len(_chars)
    print(_clen)              ## 93
    def encode(msg, key):
        def enc(c, key):
            ec = (_chars.find(c) + key) % _clen
            return _chars[ec]
        emsg = ''
        for i in msg:
            emsg += enc(i, key)
        return emsg

    def decode(emsg, key):
        def dec(c, key):
            dc = _chars.find(c) - key
            if dc >= _clen:
                dc -= _clen
            elif dc < 0:
                dc += _clen
            return _chars[dc]
        dmsg = ''
        for i in emsg:
            dmsg += dec(i, key)
        return dmsg

    msg = 'Hello how to you do?'
    key = 123
    em = encode(msg, key)
    print(em)
    print(decode(em, key))

    ''' Suppose we don't know the key, but know that the message
          contains 'Hello'. '''
    for i in range(_clen):
        dm = decode(em, i)
        if 'Hello' in dm:
            print(dm)
            break
# caesar()

''' 2. Transposition encodes a message with a key. '''
def transposition():
    def encode(msg, key):
        slot = [''] * key
        for col in range(key):
            cur = col
            while cur < len(msg):
                slot[col] += msg[cur]
                cur += key
        return ''.join(slot)

    def decode(emsg, key):
        import math
        ncol = math.ceil(len(emsg) / key)
        nrow = key
        nboxes = (ncol * nrow) - len(emsg)
        dmsg = ['']*ncol
        col, row = 0, 0
        for i in emsg:
            dmsg[col] += i
            col += 1
            if (col == ncol) or (col == ncol-1 and row >= nrow-nboxes):
                col = 0
                row += 1
        return ''.join(dmsg)

    msg = "Hello it's nice to see you."
    key = 5
    emsg = encode(msg, key)
    print(emsg)
    print(decode(emsg, key))
# transposition()

''' 3. XOR encodes a message with password which is string. '''
def xor():
    def encode(msg, pwd):
        key = int.from_bytes(pwd.encode(), 'big')
        text_int = int.from_bytes(msg.encode(), 'big')
        return key ^ text_int      ## Returns an int

    def decode(enc, pwd):
        key = int.from_bytes(pwd.encode(), 'big')
        text_int = key ^ enc
        length = text_int.bit_length()
        text = text_int.to_bytes((length+ 7) // 8, 'big')
        return text.decode()        ## Returns a string

    msg = 'Hello long time no see.'
    pwd = 'hello123'
    enc = encode(msg, pwd)
    print(enc)
    print(decode(enc, pwd))
# xor()

''' 4. Swapping encodes a message without keys. '''
def swap():
    def partition(msg):
        evens = []  ## For characters at even positions.
        odds = []   ## For characters at odd positions.
        for i, c in enumerate(msg):
            if i % 2 == 0:
                evens.append(c)
            else:
                odds.append(c)
        return evens, odds
    msg = 'Hello! how do you do?'
    # print(partition(msg))

    ''' Swap adjacent characters. '''
    def swap(msg):
        # For odd length msg adds an extra space.
        if len(msg) % 2 != 0:
            msg += ' '
        even_letters, odd_letters = partition(msg)
        letters = []
        for i in range(0, int(len(msg)/2)):
            letters.append(odd_letters[i])
            letters.append(even_letters[i])
        return ''.join(letters)

    ''' swap(<msg>) results an encoded <msg>. '''
    emsg = swap(msg)
    print(emsg)             ## eHll!oh wod  ooy uod ?
    ''' Decoding iscall swap() again.'''
    print(swap(emsg))       ## Hello! how do you do?

    #-----------------------------------------------------

    ''' An improve version: adding a random fake letter at odd positions. '''
    from random import choice
    fake_letters = string.digits + string.punctuation + string.ascii_uppercase
    def encode(msg):
        enc = []
        for c in msg:
            enc.append(choice(fake_letters))
            enc.append(c)
        return ''.join(enc)
    emsg = encode(msg) ## Encoded msg is double in size .
    print(emsg)

    ''' Only the even positions contain the msg. '''
    def decode(msg):
        _, evens = partition(msg)
        return ''.join(evens)
    print(decode(emsg))
# swap()

''' Mapping create mappings for encrypt and decrypt. '''
import random
def mapping():
    def gen_map():
        l = list(string.printable)
        random.shuffle(l)
        target = ''.join(l)
        return str.maketrans(string.printable, target), \
               str.maketrans(target, string.printable)
    encrypt_map, decrypt_map = gen_map()
    # print(encrypt_map)  ## For encoder.
    # print(decrypt_map)  ## For decoder.
    ''' Exposing any of the maps would be disastrous. '''

    msg = 'Hello! how are you?'
    ''' Encoding is translate with encrypt_map. '''
    emsg = msg.translate(encrypt_map)
    print(emsg)
    ''' Decoding is translate with decrypt_map. '''
    print(emsg.translate(decrypt_map))
# mapping()

#----------------------------------------------------------
''' AES encoding:
A key is 16 bytes (hex str) generated from message.
An encoded message contains initialized vector(iv)
 and ciphertext(ct) represented as json with base64 values.
Resulting 'key' and 'emsg' files.

pip install pycryptodome
pip install eth_utils                 '''
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
from base64 import b64encode, b64decode
from eth_utils import encode_hex, decode_hex
import json
from file_util import write_file, read_file
def aes():
    def encode(msg):
        data = msg.encode()
        key = get_random_bytes(16)
        cipher = AES.new(key, AES.MODE_CBC)
        ct_bytes = cipher.encrypt(pad(data, AES.block_size))
        iv = b64encode(cipher.iv).decode('utf-8')
        ct = b64encode(ct_bytes).decode('utf-8')
        write_file('key', encode_hex(key))
        write_file('emsg', json.dumps({'iv':iv, 'ct':ct}))
    encode("Hello how do you do?")

    def decode():
        try:
            key = decode_hex(read_file('key'))
            enc = json.loads(read_file('emsg'))
            iv = b64decode(enc['iv'])
            ct = b64decode(enc['ct'])
            cipher = AES.new(key, AES.MODE_CBC, iv)
            return unpad(cipher.decrypt(ct), AES.block_size).decode()
        except (ValueError, KeyError):
            print("Error")
    print(decode())
# aes()

#----------------------------------------------------------

''' 'Digital Signature' provides ferification if a messageis modified. '''
import hashlib
def hash(msg):
    h1 = hashlib.md5()           ## MD5
    h2 = hashlib.sha1()          ## SHA1
    h3 = hashlib.sha256()        ## SHA256
    m = msg.encode()
    h1.update(m); print(h1.digest())
    h2.update(m); print(h2.hexdigest())
    h3.update(m); print(h3.hexdigest())
# hash('Hello')

def sig_test():
    def gen_sig(msg):
        h = hashlib.sha256()
        h.update(msg.encode())
        with open('../tmp/test.sig', 'w') as f:
            f.write(h.hexdigest())

    def verify(msg):
        h = hashlib.sha256()
        h.update(msg.encode())
        new_sig = h.hexdigest()
        with open('../tmp/test.sig', 'r') as f:
            old_sig = f.read()
        return new_sig == old_sig

    msg = 'Hello how do you do?'
    gen_sig(msg)
    # msg += '.'           ## Try: Modify msg.
    print(verify(msg))
# sig_test()
