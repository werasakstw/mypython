
''' Compress into a string '''
import zlib
doc = ''' Hello! how are you. Long time no see. It's nice to see you.
  See you again. Goodbye.'''
def zlib_test():
    zipdoc = zlib.compress(doc.encode())
    print(len(doc), len(zipdoc))
    print(zlib.decompress(zipdoc).decode())
# zlib_test()

#---------------------------------------------------------

''' 'GZip' is simple zip lib but handle only one file. '''
import gzip, os
from file_util import write_file, read_file
def gzip_test():
    file = '../data/students.csv'
    doc = read_file(file)
    print(os.stat(file).st_size)

    with gzip.open('../tmp/students.gz', 'wb') as f:
        f.write(doc.encode())
    print(os.stat('../tmp/students.gz').st_size)

    with gzip.open('../tmp/students.gz', 'rb') as f:
         print(f.read().decode())
# gzip_test()

##------------------------------------------------------------##

''' 'zipfile' is a zip lib that can handle many files. '''
import zipfile
def zipfile_test():
    ''' Write zip file '''
    with zipfile.ZipFile( "../tmp/students.zip", "w" ) as f:
        f.write('../data/students.csv')
        f.write('../data/students.json')

    ''' Read zip file '''
    with zipfile.ZipFile( "../tmp/students.zip", "r" ) as f:
        f.printdir()         ## print all zipped file names
        # print(f.read('../data/students.csv').decode())  ## extract a specified file
        # f.extractall()         ##  extract all files to current directory
        ## Print all files.
        # for file in f.infolist():
        #     with f.open(file) as m:
        #         print(m.read().decode(), end='\n\n')
# zipfile_test()
