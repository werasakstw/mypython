''' File Opening
Files are write/read via file references which is obtained by opening.
open(<file path>, <mode>, <options>) returns a file reference.
  e.g. open('file', 'r', newline='')
       open('file', 'w', encoding='ascii')
       open('file', 'r', errors='replace')
Modes:
      'r' Read text file (default)
      'w' Write text file (truncates if exists)
      'x' Write text file, throw  FileExistsError if exists.
      'a' Append to text file (write to end)
      'rb' Read binary file
      'wb' Write binary (truncate)
      'w+b' Open binary file for reading and writing
      'xb' Write binary file, throw  FileExistsError if exists.
      'ab' Append to binary file (write to end)         '''

def open_test():
    ''' 'write' open mode, if the file already exists it will be overriden. '''
    f = open('tmp.txt', 'w')
    print(f.name)       ## tmp.txt
    print(f.mode)       ## w
    print(f.closed)     ## False

    f.write('Hello how are you today?')

    ''' A file must ends with an end-of-file unless the file is no valid.
    A 'write' opened file must be closed unless no end-of-file. '''
    f.close()
    print(f.closed)     ## True

    ''' A closed file can be reopened even with different mode. '''
    f = open('tmp.txt', 'r')
    print(f.read())         ## read the whole file
    # print(f.readline())   ## read one line

    ''' A 'read' opened file already has an end-of-file, if not closed
      just the waste of file pointer.
    All opened files will be closed when Python VM is shutdown. '''
    # f.close()
# open_test()

''' File Error Handling
Many things may go wrong while handling files. '''
import os
def try_file(file_name):
    if os.path.exists(file_name):
        print('The file already exists.')
    try: ## 'try' block does not create a new namespace.
        f = open(file_name, 'w')
        f.write('Hello')
    except FileNotFoundError as err:
        print(err)
    finally:
        if f is not None:
            f.close()
    ''' File existing should be checked if overriding is not allowed.
    Write/Read File should be performed within a 'try' block.
    File closing should be done in 'finally' block'.
    Before closing should check if the reference is not null. '''
# try_file('tmp.txt')

''' A 'context manager' sets up a scope where an object can be created
  and used then it is automatically closed at end of the scope.
Pyton provides 'with' statement to supports Context Manager.
             with <expression> as <reference>:
                 <body>
<expression> is executed to create an object that is referred by the
<reference> which can be used in the <body>. Then at the end of the <body>
the object's close() will be called.
'as' is optional, in case the object does not needed to be referred. '''
def with_statement(file_path):
    try:
        with open(file_path, 'r') as f:
            print(f.readline())
    except Exception as err:
        print(err)
# with_statement('tmp.txt')

#-------------------------------------------------------

''' File Info
File Path Separator (Windows uses \, Unix uses /).
Python uses / but allows \ with escaping.  '''
# print('c:/tmp/test.txt')            ## c:/tmp/test.txt
# print('c:\\tmp\\test.txt')          ## c:\tmp\test.txt
def file_info():
    print('File path separator:', os.sep)           ## \
    print('File extension separator:', os.extsep)   ## .
    print('Current directory symbol:', os.curdir)   ## .
    print('Parent directory symbol:', os.pardir)        ## ..
    print('Current Working Directory:', os.getcwd())
    print('Current file path:', __file__)
    ## List names in the current directory
    print(os.listdir())
# file_info()

def path_info():
    cwd = os.getcwd()
    print(cwd)                  ## C:\mydata\src\file_handling

    ''' Change Directory '''
    os.chdir('..')
    print(os.getcwd())          ## C:\mydata\src
    os.chdir(cwd)
    print(os.getcwd())          ## C:\mydata\src\file_handling

    ''' Create a file path with extension. '''
    f = cwd + '\\tmp.txt'
    print(f)                    ## C:\mydata\src\file_handling\tmp.txt

    ''' Split a file path into a tuple of path and file. '''
    print(os.path.split(f))     ## ('C:\\mydata\\src\\file_handling', 'tmp.txt')

    ''' Extract file name (with extension) from a file path. '''
    print(os.path.basename(f))  ## tmp.txt

    ''' Extract directory path from a file path. '''
    print(os.path.dirname(f))   ## C:\mydata\src\file_handling

    ''' Create a file path from components. '''
    print(os.path.join('c:','com','mycomp','my.txt'))
                                ## c:com\mycomp\my.txt

    ''' Create a file path from the User Directory with expand path. '''
    print(os.path.expanduser('~\\tmp'))  ## C:\Users\Mac mini\tmp
# path_info()

#-------------------------------------------------------------------

''' Make Directory: error if the directory exists. '''
# os.mkdir('tmp')

''' Remove Directory: error if the directory does not exist
  or the directory is not empty. '''
# os.rmdir('tmp')

''' Remove Tree: removes non-empty directory, error if the directory does not exist. '''
import shutil
# shutil.rmtree('tmp')

''' Copy Files '''
def copy_file(src, tar):
    if os.path.isdir(src):
        return '<src> must be a file.'
    if os.path.isdir(tar):
        return '<tar> must be a file.'
    if os.path.exists(tar):
        return '<tar> already exists.'
    try:
        data = None
        with open(src, 'r') as f:
            data = f.read()
        with open(tar, 'w') as f:
            f.write(data)
        return 'Success'
    except FileNotFoundError as er:
        return er
# print(copy_file('tmp.txt', 'tmp/tmp.txt'))
# print(copy_file('tmp/tmp.txt', 'tmp'))

''' shutil.copy(<src>, <tar>)
<src> must be a file or file path.
If <tar> is an already exist file, it will be overwritten.
If <tar> is a directory, <src> will be copied to the directory.
The file's contents and permissions are copied, but not other meta data. '''
# shutil.copy(__file__, 'tmp/tmp.py')

''' Remove File:
os.remove(<file>)  error if <file> does not exist. '''
# os.remove('tmp/tmp.py')

''' Copy Directory:
shutil.copytree(<src>, <tar>)  returns an error if <src> does not exist
  or <tar> already exists. '''
# shutil.copytree('tmp', 'tmp/tmp')

''' Rename File:
os.rename(<old>, <new>) error if <old> does not exist or <new> already exists. '''
# os.rename('tmp/target.txt', 'tmp/tmp.txt')

''' Move File:
shutil.move(<src>, <tar>) : error if <tar> directory does not exist
<src> may be file or directory.
If <src> and <tar> are files it is a renaming. '''
# shutil.move('tmp/tmp.txt', 'tmp/tmp1.txt')

''' List Directory:
os.listdir('.') returns a list of names(files and directory).
os.path.isfile(<name>) returns True if <name> isa file. '''
import fnmatch
def list_dir():
    print([f for f in os.listdir('.')
                    # if os.path.isfile(f)
                    # if f.endswith('.py')
                    # if f.startswith('01')
                    # if fnmatch.fnmatch(f, '*file*')
            ])
# list_dir()

''' os.scandir(<path>) returns a directory iterator. '''
def scan_dir(d):
    for f in os.scandir(d):
        if f.is_file():
            print(f.name)
        elif f.is_dir():
            print('\\' + f.name)
            scan_dir(f)         ## Explicit recursive.
# scan_dir('.')

'''os.walk(<dir>) returns a tuple of <path>, <dirs> and <files> of names
  recursively each directories.
<path> is the current dir path.
<dirs> and <files> are lists of names in the directory. '''
# print([file_names for (dir_path, dir_names, file_names) in os.walk('.')])
def walk_dir(d):
    for path, dirs, files in os.walk(d):
        print('%s \t %s \t %s' % (path, dirs, files))
        for f in files:
            print(f)
        print()
# walk_dir('.')

''' 'glob' lib provides accessing files with name matching pattern. '''
import glob
def globing(pattern):
    for name in glob.glob(pattern):
        print(name)
# globing('*.py')
# globing('*hand*.py')
# globing('???')

######################################################

''' Ex. Create Create 'tmp' directory and 15 files. '''
def init():
    try:
        os.mkdir('tmp')
        for i in range(15):
            with open('tmp/myfile_' + str(i), 'w') as f:
                f.write('Hello ' + str(i))
    except FileExistsError as e:
        print('The directory already exists.')
        return
    except Error as err:
        print(err)
# init()

''' Ex. Move even files to \even. '''
def move_even():
    try:
        os.mkdir('even')
    except FileExistsError as e:
        print('even directory already exists.')

    for f in os.listdir('tmp'):
        i = f[7:]
        if int(i) % 2 == 0:
            shutil.move('tmp/'+str(f), 'even/'+str(f))
# move_even()

''' Ex. Rename even files. '''
def rename_even():
    for f in os.listdir('even'):
        s = str(f)
        s = s.replace('file', '')
        os.rename('even/'+str(f), 'even/'+s)
# rename_even()

''' Merge directory '''
def merge():
    for f in os.listdir('even'):
        shutil.move('even/' +f, 'tmp/' + str(f))
    os.rmdir('even')
# merge()

''' Exercises: Rename all files in 'tmp' directory to
        <number>_my_file.txt                '''

#-----------------------------------------------------------
'''                 File Formats
Txt File
Python text file reading operates in 'universal newline' mode, that means
  all newline characters are converted to \n while reading.
Windows text files have '\r\n' as the end of line symbol. '''
def print_file():
    with open('tmp/test.txt', 'w') as f:
        ''' write() does not append '\n' to the end of line. '''
        f.write('Hello')
        f.write('John')

        ''' print() always writing to a file and append '\n'
        ('\n\r' in Windows) to the end of line by default. '''
        print('Hello', file=f)
        print('Jack', file=f, end='.')

    ''' open() for reading returns a file iterator (by line). '''
    with open('tmp/test.txt', 'r') as f:
        for line in f:
            print(line, end='\n')  ## To suppress '\r'.
# print_file()

''' Structured data txt file. '''
students = [ (1, 'John Rambo', 6, 78, 82),
             (2, 'Jack Ripper', 10, 97, 91),
             (3, 'Joe Green', 8, 87, 82),
             (4, 'Jame Bond', 3, 67, 78),
             (5, 'Jet Ready', 7, 76, 65),
             (6, 'Janet Long', 4, 86, 78),
             (7, 'Jessie Howdy', 0, 42, 52),
             (8, 'Jim Morrison', 9, 79, 73),
             (9, 'Judy Anne', 6, 84, 81),
             (10, 'Jude Zebra', 7, 72, 83),
        ]
def student_txt():
    ''' Write txt file '''
    with open('tmp/students.txt', 'w') as f:
        for s in students:
            _id, name, hw, mid, fin = s
            print(_id, name, hw, mid, fin, file=f)

    ''' Read the whole file '''
    with open('tmp/students.txt', 'r') as f:
        print(f.read())
    print()

    ''' Read by line '''
    with open('tmp/students.txt', 'r') as f:
        for line in f:
            print(line, end='')     #  end='' suppress '\n'.
        print()

    ''' Split line (string tokenization) '''
    with open('tmp/students.txt', 'r') as f:
        for line in f:
            _id, first_name, last_name, hw, mid, fin = line.split()
            print(_id, first_name, last_name, hw, mid, fin)
# student_txt()

''' Ex. Write n multiplication tables to a file. '''
def mul_tables(n):
    with open('mul.txt', 'w') as f:
        for i in range(2, n):
            for j in range(2, 13):
                f.write('%3d x %2d = %4d\n' % (i, j, i*j))
            f.write('\n')
# mul_tables(100)
''' Exercises: Write 100 kumon problems of integers less 1000 to a file. '''

#-------------------------------------------------------------------

''' Write/Raed Binary '''
import array
def array_test(size):
    a = array.array('i', range(size))
    with open('tmp/test.bin', 'wb') as f:
        a.tofile(f)

    b = array.array('i')
    with open('tmp/test.bin', 'rb') as f:
        b.fromfile(f, size)
    # print(b)
    print(list(b))
# array_test(5)

''' Pickling saves objects to files in binary. '''
import pickle
def pickle_test():
    a = list(range(5))

    with open('tmp/obj.bin', 'wb') as f:
        pickle.dump(a, f)

    with open('tmp/obj.bin', 'rb') as f:
        print(pickle.load(f))
# pickle_test()

''' Writing image file supports file format byfiel extension. '''
def image_conversion():
    with open('data/john.png', 'rb') as rf:
        img = rf.read()
        with open('tmp/john.jpg', 'wb') as wf:
            wf.write(img)
# image_conversion()

#-------------------------------------------------------------------

''' Reading XML file '''
from xml.etree import ElementTree
def xml_read():
    with open('data/students.xml') as f:
        doc = ElementTree.parse(f)
        for s in doc.findall('student'):
            _id = s.find('id').text
            name = s.find('name').text
            department = s.find('department').text
            print(_id, name, department)
# xml_read()

''' Reading JSON file '''
import json
def json_read():
    with open("data/students.json") as f:
        for s in json.loads(f.read()):
            print(s['id'], s['name'], s['department'])
# json_read()

''' Write PDF file
pip install fpdf        '''
from fpdf import FPDF
def pdf_write():
    p = FPDF(format='letter')
    p.add_page()
    p.set_font('Arial', 'B', 18)
    p.cell(200, 40, txt="Hello how do you do?", ln=1, align="C")
    p.output("tmp/test.pdf")
# pdf_write()

#-----------------------------------------------------

''' 'Temp Files' are used for temporary data which cannot be accessed by other processes.
It is not likely that someone can guess the temp file names and steal the data. '''
import tempfile, linecache
def tempfile_test():
    fd, fname = tempfile.mkstemp()
    os.close(fd)       ## To allow unlink the file.
    print(fname)       ## Temp file names are generated randomly.
    print(tempfile.gettempdir())    ## C:\WINDOWS\TEMP
    print(tempfile.gettempprefix()) ## tmp

    with open(fname, 'w') as f:
        f.write('Hello\nGoodbye.')
    with open(fname, 'r') as f:
        print(f.read())

    ''' 'linecache' allows simple reading at specified line number. '''
    print(linecache.getline(fname, 1))   # line number starts with 1.
    print(linecache.getline(fname, 2))

    ''' Unlink and remove the temp file. '''
    # os.unlink(fname)
# tempfile_test()

##-------------------------------------------------------

''' String IO: is a string that can be used as a file.
  which are faster and more secure than temp files. '''
import io
def string_io():
    s = io.StringIO()
    s.write('Hello!')
    s.write('Hi')
    print(s.getvalue())     ## Hello!Hi

    ''' Alternatively, print to string io. '''
    print('John', end='', file=s)
    print(s.getvalue())     ## Hello!HiJohn
# string_io()
