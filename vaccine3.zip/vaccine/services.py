from flask import Flask, render_template, request
from flask_admin import Admin, BaseView, expose
from flask_bootstrap import Bootstrap
from admins import StudentForm, stu_json, connect, \
     FacultyForm, fac_json, InjectionForm, inj_json
from time import localtime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'hello123'
app.config['FLASK_ADMIN_SWATCH'] = 'cerulean'
bootstrap = Bootstrap(app)
admin = Admin(app, name='Services', template_mode='bootstrap3')

@app.route('/')
def index():
    return render_template('index.html')

class StudentView(BaseView):
    @expose('/')
    def index(self):
        return self.render('student_view.html')

    @expose('/add', methods=['GET', 'POST'])
    def add(self):
        now = '%4d-%02d-%02d' % localtime()[:3]
        form = StudentForm(cid='1470000000000', sid='581103000000', \
            prefix_='นาย', fname='John', lname='Rambo',
            dept='วิทยาศาสตร์และเทคโนโลยี', major='วิทยาการคอมพิวเตอร์',\
            status='ปกติ', phone='081-0000000', \
            email='john@rambo.com', birth=now)
        if form.validate_on_submit():
            cid = form.cid.data
            sid = form.sid.data
            prefix_ = form.prefix_.data
            fname = form.fname.data
            lname = form.lname.data
            dept = form.dept.data
            major = form.major.data
            status = form.status.data
            phone = form.phone.data
            email = form.email.data
            birth = form.birth.data       
            db = connect().mydb
            tb = db['student']
            tb.insert_one(stu_json(cid, sid, prefix_, fname, lname, \
                dept, major, status, phone, email, birth))
            return 'Register ' + fname + ' success.'
        return self.render('student_add.html', form=form)

    @expose('/find')
    def find(self):
        return self.render('student_find.html')
admin.add_view(StudentView(name='Student'))

@app.route('/student/find_by_name', methods=['POST'])
def student_find_by_name():
    if request.method == 'POST':
        fname = request.form.get('fname')
        lname = request.form.get('lfname')
        db = connect().mydb
        tb = db['student']
        for s in tb.find({'fname': fname, 'lfname': lname }, \
                {'_id': False, 'sid': True, 'dept': True}):
            return str(s)
    return 'No found'

@app.route('/student/find_by_sid', methods=['POST'])
def student_find_by_sid():
    if request.method == 'POST':
        sid = request.form.get('sid')
        db = connect().mydb
        tb = db['student']
        for s in tb.find({'sid': sid }, \
            {'_id': False, 'fname': True, 'lname': True, 'dept': True}):
            return str(s)
    return 'No found'
    
@app.route('/student/insert', methods=['POST'])
def student_insert():
    cid = request.form.get('cid')
    sid = request.form.get('sid')
    prefix_ = request.form.get('prefix_')
    fname = request.form.get('fname')
    lname = request.form.get('lname')
    dept = request.form.get('dept')
    major = request.form.get('major')
    status = request.form.get('status')
    phone = request.form.get('phone')
    email = request.form.get('email')
    birth = request.form.get('birth')
    db = connect().mydb
    tb = db['student']
    tb.insert_one(stu_json(cid, sid, prefix_, fname, lname, \
                dept, major, status, phone, email, birth))
    return 'Insert' + fname + ' success.'

#------------------------------------------------------------------

class FacultyView(BaseView):
    @expose('/')
    def index(self):
        return self.render('faculty_view.html')

    @expose('/add', methods=['GET', 'POST'])
    def add(self):
        now = '%4d-%02d-%02d' % localtime()[:3]
        form = FacultyForm(cid='1000000000000', prefix_='นาย', \
           fname='Jack', lname='Ripper', phone='081-0000000')
        if form.validate_on_submit():
            cid = form.cid.data
            prefix_ = form.prefix_.data
            fname = form.fname.data
            lname = form.lname.data
            phone = form.phone.data     
            db = connect().mydb
            tb = db['faculty']
            tb.insert_one(fac_json(cid, prefix_, fname, lname, phone))
            return 'Register ' + fname + ' success.'
        return self.render('faculty_add.html', form=form)

    @expose('/find')
    def find(self):
        return self.render('faculty_find.html')
admin.add_view(FacultyView(name='Faculty'))

@app.route('/faculty/find_by_name', methods=['POST'])
def faculty_find_by_name():
    if request.method == 'POST':
        fname = request.form.get('fname')
        lname = request.form.get('lfname')
        db = connect().mydb
        tb = db['faculty']
        for s in tb.find({'fname': fname, 'lfname': lname }, \
                {'_id': False, 'cid': True, 'phone': True}):
            return str(s)
    return 'No found'

@app.route('/faculty/find_by_cid', methods=['POST'])
def faculty_find_by_cid():
    if request.method == 'POST':
        cid = request.form.get('cid')
        db = connect().mydb
        tb = db['faculty']
        for s in tb.find({'cid': cid }, \
            {'_id': False, 'fname': True, 'lname': True, 'phone': True}):
            return str(s)
    return 'No found'

@app.route('/faculty/insert', methods=['POST'])
def faculty_insert():
    cid = request.form.get('cid')
    prefix_ = request.form.get('prefix_')
    fname = request.form.get('fname')
    lname = request.form.get('lname')
    phone = request.form.get('phone')
    db = connect().mydb
    tb = db['faculty']
    tb.insert_one(fac_json(cid, prefix_, fname, lname, phone))
    return 'Insert' + fname + ' success.'

#------------------------------------------------------------------

class IdGenerator():
    n = 0
    @staticmethod
    def get():
        IdGenerator.n += 1
        return IdGenerator.n

class InjectionView(BaseView):
    @expose('/')
    def index(self):
        return self.render('injection_view.html')

    @expose('/add', methods=['GET', 'POST'])
    def add(self):
        now = '%4d-%02d-%02d' % localtime()[:3]
        form = InjectionForm(iid=IdGenerator.get(),  \
           fname='Jack', lname='Ripper', \
           vaccine='sinovac', dose='1', date=now, \
           location='โรงพยาบาลเพชรบูรณ์', athority='สุดหล่อ นิยมไทย')
        if form.validate_on_submit():
            iid = form.iid.data
            fname = form.fname.data
            lname = form.lname.data
            vaccine = form.vaccine.data     
            dose = form.dose.data
            date = form.date.data
            location = form.location.data
            athority = form.athority.data
            db = connect().mydb
            tb = db['injection']
            tb.insert_one(inj_json(iid, fname, lname, vaccine, \
                dose, date, location, athority))
            return 'Register ' + fname + ' success.'
        return self.render('injection_add.html', form=form)

    @expose('/find')
    def find(self):
        return self.render('injection_find.html')
admin.add_view(InjectionView(name='Injection'))

@app.route('/injection/find_by_name', methods=['POST'])
def injection_find_by_name():
    if request.method == 'POST':
        fname = request.form.get('fname')
        lname = request.form.get('lfname')
        db = connect().mydb
        tb = db['injection']
        for s in tb.find({'fname': fname, 'lfname': lname }, \
                {'_id': False, 'iid': True, 'vaccine': True, 'dose': True}):
            return str(s)
    return 'No found'

@app.route('/injection/find_by_iid', methods=['POST'])
def injection_find_by_iid():
    if request.method == 'POST':
        iid = request.form.get('iid')
        db = connect().mydb
        tb = db['injection']
        for s in tb.find({'iid': iid }, \
            {'_id': False, 'fname': True, 'lname': True, 'vaccine': True, 'dose': True}):
            return str(s)
    return 'No found'

@app.route('/injection/insert', methods=['POST'])
def injection_insert():
    iid = request.form.get('iid')
    fname = request.form.get('fname')
    lname = request.form.get('lname')
    vaccine = request.form.get('vaccine')
    dose = request.form.get('dose')
    date = request.form.get('date')
    location = request.form.get('location')
    athority = request.form.get('athority')
    db = connect().mydb
    tb = db['injection']
    tb.insert_one(inj_json(iid, fname, lname, vaccine, dose, date, location, athority))
    return 'Insert' + fname + ' success.'


if __name__ == '__main__':
    app.run(port=8080, debug=True)
