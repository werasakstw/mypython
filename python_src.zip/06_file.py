''' Files must be write/read via file reference.
open(<file path>, <mode>) returns the opened file reference,
some named arguments are allowed.
  e.g. open('file', 'r', newline='')
       open('file', 'w', encoding='utf8')
    Modes:
      'r' Read text file (default)
      'w' Write text file (truncates if exists)
      'x' Write text file, throw  FileExistsError if exists.
      'a' Append to text file (write to end)
      'rb' Read binary file
      'wb' Write binary (truncate)
      'w+b' Open binary file for reading and writing
      'xb' Write binary file, throw  FileExistsError if exists.
      'ab' Append to binary file (write to end)
'''
def write_file(fname, data):
    with open(fname, 'w') as f:
        f.write(data)
# write() does not append '\n' to the end of line.

def read_file(fname):
    with open(fname, 'rb') as f:
        return f.read() # Read the whole file.

##write_file('tmp.txt', 'Hello how do you do?')
##print(read_file('tmp.txt'))

# print() to file.
# print() always append '\n' to the end of line.
# To suppress '\n' uses: print(<str>, end='')
def print_test():
    with open('tmp.txt', 'w') as f:
        print('Hello', file=f)
        print('Hi', file=f)
##print_test()

#----------------------------------------------------

# Self File Reference: __file__
##print(__file__)  # C:\mypython\src\06_file.py

# File Manipulations:
import os, shutil
##os.mkdir('tmp')

''' shutil.copy(<src>, <tar>) 
<src> must be a file or file path.
If <tar> is an already exist file, it will be overwritten.
If <tar> is a directory, <src> will be copied to the directory.
The file's contents and permissions are copied, but not other meta data. '''
##print(shutil.copy(__file__, 'tmp.txt')) # Return the copied file name.

# shutil.move(<src>, <tar>) : error if <tar> directory does not exist
# <src> may be file or directory.
##shutil.move('tmp.txt', 'tmp')

# os.rename(<old>, <new>): error if <old> does not exist or <new> already exists.
##os.rename('tmp/tmp.txt', 'tmp1.txt')  # '/' as path separator.

# os.listdir(<dir>): return a list of file and directory names in the <dir>.
##print(os.listdir('data'))

# shutil.rmtree(<dir>): remove directory.
##shutil.rmtree('tmp')

# Flie Time Stamp
import time
# time.ctime() converts date and time values into printable format.
def file_time():    


    print(time.ctime(os.path.getatime(__file__)))   # get access time

    print(time.ctime(os.path.getmtime(__file__)))   # get modificationtime

    print(time.ctime(os.path.getctime(__file__)))   # get creation time

##file_time()

#--------------------------------------------------

# Save to files:
import random
def kumon(n):
    with open('kumon.txt', 'w') as f:
        for i in range(n):
            ops = ['+', '-', 'x', '%']
            x = random.randint(2, 99)
            op = random.choice(ops)
            y = random.randint(2, 99)
            f.write('%2d %s %2d = ___\n' % (x, op, y))
##kumon(100)

# 100 Multiplication-Tables.
def mul_tables(n):
    with open('mul.txt', 'w') as f:
        for i in range(2, n):  # Iterations can be nested.
            for j in range(2, 13):
                f.write('%3d x %2d = %4d' % (i, j, i*j))
            f.write('\n')
##mul_tables(100)

#----------------------------------------------------

# Example Student Grades:
# Grading policy:
#     <total> = <home work> + 0.4*<mid term> + 0.6*<final>
#  <home work>: Range 0->10
#  <total>, <mid term>, <final>: Range 0->100 
import math
def to_total(hw, mid, fin): 
    total = hw + 0.4*mid + 0.6*fin
    return math.ceil(total)
##print(to_total(6, 78, 82)

def to_grade(total):
    return 'A' if 90 <= total else \
           'B' if 80 <= total else \
           'C' if 70 <= total else \
           'D' if 50 <= total else 'F'
##print(to_grade(78))

def histogram(scores):
    grade_count = {'A': 0, 'B': 0, 'C': 0, 'D': 0, 'F': 0}
    for s in scores:
       grade_count[to_grade(s)] += 1
##    print(grade_count)
       
    # Print grade count
    for g, c in grade_count.items():
        print(g, end=': ')
        for _ in range(c):
            print('*', end='')
        print()
scores = (83, 74, 51, 79, 91, 80, 94, 89, 43, 77, 56, 67,
              88, 57, 33, 57, 66, 78, 64, 71, 85, 72, 76, 70, 76, 74)     
##histogram(scores)

# Structured Data Txt File.
def read_student_txt():
    with open('data/students.txt', 'r') as f:
        for line in f:  
            _id, fname, lname, hw, mid, fin = line.split()
##            print(_id, fname, lname, hw, mid, fin)
            total = to_total(int(hw), int(mid), int(fin))
            print(fname, to_grade(total))
##read_student_txt()

import csv
def read_student_csv():
    with open('data/students.csv') as f:
        data = csv.DictReader(f)    # dict
        for r in data:
##            print(r)
            print(r['id'], r['name'], r['hw'], r['mid'], r['fin'])
##read_student_csv()

def student_scores():
    scores = []
    with open('data/students.csv') as f:
        for r in csv.DictReader(f):
            scores.append(to_total(int(r['hw']), int(r['mid']), int(r['fin'])))
    return scores
##histogram(student_scores())

#-----------------------------------------------------------------

# Compression:
import gzip  # Zip only one file.
def to_gzip(ifile, ofile):
    with open(ifile, 'rb') as f:
        data = f.read()
    with gzip.open(ofile, 'wb') as f:
        f.write(data)
##to_gzip('06_file.py', 'tmp.gz')

# Check file sizes:
##print(os.stat('06_file.py').st_size, os.stat('tmp.gz').st_size)

def from_gzip(ifile):
    with gzip.open(ifile, 'rb') as f:
        return f.read()
##print(from_gzip('tmp.gz'))

# Zip files: # Zip more than one file.
import zipfile
def zip_test():
    with zipfile.ZipFile('tmp.zip', 'w') as f:
        f.write('data/students.csv')
        f.write('data/students.txt')

    with zipfile.ZipFile('tmp.zip', 'r') as f:
        f.printdir() # print all zipped file info.
##        print(f.read('data/students.csv').decode())  # extract a specified file
##        f.extractall()         #  extract all files to current directory
##zip_test()

#----------------------------------------------------------

# Encryption:
# Ex. Caesar Method.
import string
_chars = string.printable
_clen = len(_chars)
def encode(ifile, ofile, key):  # key must be an integer.
    def enc(c, key):
        ec = (_chars.find(c) + key) % _clen
        return _chars[ec]
    
    emsg = ''
    for i in read_file(ifile):
        emsg += enc(i, key)
    write_file(ofile, emsg)
##encode(__file__, 'tmp.enc', 1234)

def decode(ifile, ofile, key):
    def dec(c, key):
        dc = (_chars.find(c) - key) % _clen
        if dc >= _clen:
            dc -= _clen
        elif dc < 0:
            dc += _clen        
        return _chars[dc]

    dmsg = ''
    for i in read_file(ifile):
        dmsg += dec(i, key)
    write_file(ofile, dmsg)
##decode('tmp.enc', 'tmp.txt', 1234)

#----------------------------------------------------

## Hasing and Digital Signature:
import hashlib
from Crypto.Hash import SHA256
def hash(msg):
    m = msg.encode()
    h1 = hashlib.md5()           ## MD5
    h2 = hashlib.sha1()          ## SHA1
    h3 = SHA256.new()            ## SHA256 (Bitcoin)
    
    h1.update(m)
    h2.update(m)
    h3.update(m)
    
    print(h1.hexdigest())
    print(h2.hexdigest())
    print(h3.hexdigest())
##hash('Hello how do you do?')

def sign(ifile, ofile):
    h = SHA256.new()
    h.update(read_file(ifile))
    write_file(ofile, h.hexdigest())
##sign('tmp.txt', 'tmp.sig')

def verify(ifile, sfile):
    h = SHA256.new()
    h.update(read_file(ifile))
    new_sig = h.hexdigest()
    old_sig = read_file(sfile).decode()
    return new_sig == old_sig
##print(verify('tmp.txt', 'tmp.sig'))


