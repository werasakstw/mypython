import matplotlib.pyplot as pp
import numpy as np

## Scatter Plot:
def scatter():
    x = range(10)
    y = [i*i for i in range(10)]
##    pp.scatter(x, y)      # color='green'
    pp.show()
##scatter()

def random_scatter():
    s = 1000
    x = np.arange(s)
    # Standard distribution
    pp.scatter(x, np.random.randn(s), color='blue')

    # Gaussian distribution
    pp.scatter(x, np.random.normal(size=s), color='yellow')

    # Uniformly distribution
    pp.scatter(x, np.random.uniform(size=s), color='red')
    pp.show()
##random_scatter()

# Bar Charts:
def bar():
    x = range(10)
    y = [i*i for i in range(10)]
    
    pp.figure(1); pp.title('Default')
    pp.bar(x, y)
    
    # align {'center'(default), 'edge'}
    pp.figure(2); pp.title('Edge')
    pp.bar(x, y, align='edge')
    
    # width
    pp.figure(3); pp.title('Width')
    pp.bar(x, y, width=0.5)
   
    # color and edgecolor
    pp.figure(5); pp.title('Color')
    pp.bar(x, y, color='g', edgecolor='r')

    # Horizontal bar
    pp.figure(6); pp.title('Horizontal')
    pp.barh(x, y)
    pp.show()
##bar()

# Histograms:
def histogram():
    y = np.random.randn(1000)
##    y = np.random.uniform(size=1000)

    pp.figure(1); pp.title('Default')
    pp.hist(y)

    # align  {mid(default), left, right}
    pp.figure(2); pp.title('Align')
    pp.hist(y, align='left')
    
    ## bins
    pp.figure(3); pp.title('Bins')
    pp.hist(y, bins=100)

    # histtype {'barstacked' (default), 'step', 'stepfilled' }
    pp.figure(4); pp.title('Step')
    pp.hist(y, histtype='step')

    # color, edgecolor
    pp.figure(5); pp.title('Color')
    pp.hist(y, color='g', edgecolor='r')

    # orientation {'vertical'(default), 'horizontal' }
    pp.figure(6); pp.title('Orientation')
    pp.hist(y, orientation='horizontal') 
    pp.show()
##histogram()

# Pie Charts:
def pie():
    d = [5, 15, 40, 30, 10]  # sum to 100.
    pp.figure(1); pp.title('Default')
    pp.pie(d)

    # autopct
    pp.figure(2); pp.title('Autopct')
    pp.pie(d, autopct='%1.1f%%')

    # colors   default('b', 'g', 'r', 'c', 'm', 'y', 'k', 'w')
    pp.figure(3); pp.title('Colors')
    pp.pie(d, colors=('r', 'g', 'b', 'y', 'm'))
    
    # startangle (The default is from 15 min, counter-clolkwise.)
    pp.figure(3); pp.title('Start Angle')
    pp.pie(d, startangle=90)  

    # counterclock {True, False}
    pp.figure(4); pp.title('Counter Clock')
    pp.pie(d, counterclock=False)

    # shadow {True, False}
    pp.figure(5); pp.title('Shadow')
    pp.pie(d, shadow=True)

    # explode = fraction of the radius to offset each wedge.
    pp.figure(6); pp.title('Explode')
    exp=(0.1, 0.1, 0.1, 0.1, 0.1)
    pp.pie(d, explode=exp) 

    # labels and title
    pp.figure(7); pp.title('Labels and Title')
    grades = 'A', 'B', 'C', 'D', 'F'
    pp.title('OOP Spring 2017')
    pp.pie(d, autopct='%1.1f%%', labels=grades)

    pp.show()
##pie()

#----------------------------------------------------

# Student Grade:
def to_grade(total):
    return 'A' if total >= 90 else 'B' if total >= 80 else \
           'C' if total >= 70 else 'D' if total >= 60 else 'F'
# pip install pandas
import pandas as pd
import csv
def students_grade():
    df = pd.read_csv('data/students.csv')

    # Dataframes allow adding new columns.
    # Create 'total' column:  total = hw + 40% mid + 50% fin
    df['total'] = (df.hw) + (0.4 * df.mid) + (0.5 * df.fin)

    # Create 'grade' column:
    df['grade'] = df['total'].map(to_grade)

    # Sort by total.
    df = df.sort_values(by='total',  ascending=False)

    # Save.
    df.to_csv('tmp.csv', index=False)

    # Print Statistics.
    print(df, end='\n\n')
        
    td = df.total.describe()
    print('Number of Students: %d' % td['count'])
    print('Min: %.2f\tMax: %2.f' % (td['min'], td['max']))
    print('Mean: %2.f' % td['mean'])
    print('Sd: %.2f' % (td['std']))
    print('Frequency count:', end='')
    gc = df.grade.value_counts()        # dict
    for g, c in sorted(gc.items(), key=lambda item: item[0]):
        print('(%s: %d), ' % (g, c), end='')

    # Plots.
    pp.figure(1);  pp.title('Total Bar')
    pp.hist(df.total)

    pp.figure(2); pp.title('Grade Bar')
    df = df.sort_values(by='grade')
    pp.hist(df.grade)

    pp.figure(3); pp.title('Pie')
    gc = df.grade.value_counts()
    pp.pie(gc, autopct='%.1f%%', labels=('C', 'D', 'B', 'A', 'F'))
    pp.show()


students_grade()

    
