## Fraction:
## 'fractions' module provides fraction mainpulating.
from fractions import Fraction
def fraction_test():
    x = Fraction(1, 2)
    y = Fraction(0.25)
    print(x)        # 1/2
    print(y)        # 1/4
   
    # Mathematic operations
    print(x + y, x - y, x * y, x / y)

    # Comparision operations
    print(x < y, x <= y, x > y, x >= y, x == y)

    # Fraction Simplification
    def simplify(f): 
        a, b = f.as_integer_ratio()
        return '%d+(%d/%d)' % (a/b, a%b, b)
    print(simplify(Fraction(3, 2)))         ## 1+(1/2)

    # Ex. Area of a rectangle with 1+(1/5) width and 2+(3/4) height.
    area = 1+Fraction(1, 5) * 2+Fraction(3, 4)                     
    print(area, simplify(area))             ## 43/20 2+(3/20)

    # Volume of a cube of 1+(2/3) on each sides.
    volume = (1 + Fraction(2, 3)) ** 3
    print(simplify(volume))                 ## 4+(17/27)
##fraction_test()

## Ratio:
import math
def ratio(): # A ration is 'numerator' divide by 'denominator'.
    # as_integer_ratio() convert a float into a tuple of ratio
    print(0.5.as_integer_ratio())        # (1, 2)
    print(1.5.as_integer_ratio())        # (3, 2)
    print((22.0/7.0).as_integer_ratio()) # (7077085128725065, 2251799813685248)
    print(math.pi.as_integer_ratio())    # (884279719003555, 281474976710656)
##ratio()

#------------------------------------------------------
    
# Decimal:
# 'decimal' module provides floating point operations of arbitrary precision.

from decimal import Decimal, getcontext
def dec_test():
    print(1/3)                     # 0.3333333333333333
    print(Decimal(1) / Decimal(3)) # 0.3333333333333333333333333333

    # default precision
    print(getcontext().prec)  # 28  

    ## set precision to 100 positions
    getcontext().prec = 100  
    print(Decimal(1) / Decimal(3))
##dec_test()

''' David Bailey, Peter Borwein and Simon Plouffe proposed a formula for pi,
      pi = sum(n=0,inf)( 4/(8*n+1) - 2/(8*n+4) - 1/(8*n+5) - 1/(8*n+6) ) / 16**n
Increasing n would increase the precision.
Python float values are 8 bytes, the precision is approximately 15 position.
'''
def dps_pi(n):
    s = 0.0
    for i in range(n):      
        i8 = 8*i
        s += (4.0/(i8+1) - 2.0/(i8+4) - 1.0/(i8+5) - 1.0/(i8+6)) / 16**i
    return s
##print(dps_pi(10))   # 3.1415926535897913
##print(math.pi)      # 3.141592653589793
    
# 1000 decimal points Pi:
def dps_1000pi():
    getcontext().prec = 1000
    d4 = Decimal(4.0)
    d2 = Decimal(2.0)
    d1 = Decimal(1.0)
    s = Decimal(0.0)
    for i in range(1000):
        i8 = Decimal(8*i)
        s += (d4/(i8+1) - d2/(i8 +4) - d1/(i8+5) - d1/(i8+6)) / 16**i 
    return s
##print(dps_1000pi())

#----------------------------------------------------------------##

''' A Complex Number has two parts,
      - the real part is a number (may be integer or float).
      - the imaginary part is a number multiplies with sqrt(-1).
Python handles complex number in two alternative forms:
    - Representing the sqrt(-1) with j.
    - Using complex object.
'''
def complex_test():
    m = 1 + 2j              # 1 + 2*sqrt(-1)
    n = complex(3, 4)       # 3 + 4*sqrt(-1)

    print(m, m.real, m.imag)  # (1+2j) 1.0 2.0
    print(n, n.real, n.imag)  # (3+4j) 3.0 4.0
    
    # Operations on complex numbers.
    print(m+n, m-n, m*n, m/n, m**2)
    # (4+6j) (-2-2j) (-5+10j) (0.44+0.08j) (-3+4j)

    # Built-in functions.
    print(abs(n), pow(m, 3)) # 5.0 (-11-2j)

    ## Standard library for complex numbers.
    import cmath
    print(cmath.sqrt(m))
    print(cmath.sin(m))
    print(cmath.log10(m))
##complex_test()

#----------------------------------------------------------

''' Number Bases:
Literals are values that may appear in source codes.
All literal data types must be identifiable. 
Integer literals:     '''
def int_lit():
    print(10)	    # 10     decimal (default)
    print(0b10)	    # 2      binary prefixed with '0b'
    print(0o10)	    # 8      octal prefixed with '0o'
    print(0x10)	    # 16     hexadecimal prefixed with '0x'
##int_lit()

''' Python has built-in functions to converse
    'int' decimal to binary, octal, and hexadecimal.
'''
def int_literal():
    print(bin(10))	    # 0b1010
    print(oct(10))	    # 0o12
    print(hex(10))	    # 0xa
##int_literal()

# int(<value>) creates an int from the <value> string in decimal base.
# int(<value>, <base>) creates an int from the <value> string in <base>.
def int_base():
    print(int('007'))       ## 7    (decimal)
    print(int('100', 2))    ## 4
    print(int('100', 5))    ## 25
    print(int('a', 16))     ## 10
    # print(int('a', 10))   ## error: there is no 'a' symbols in base 10. 
##int_base()
