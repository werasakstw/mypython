'''
ภาษา Python เก็บข้อมูลที่เป็นเลขจำนวนเต็ม(integer)โดยใช้หน่วยความจำขนาดเท่ากับ
word ของหน่วยประมวลผลที่ใช้งาน ซึ่งปัจจุบันมักจะเป็น 32 หรือ 64 bits แต่ถ้าค่าของ
เลขนั้นใหญ่เกินกว่าจะเก็บในหน่วยความจำที่มี ก็จะเปลี่ยนวิธีเก็บค่าเป็นลำดับของเลขในแต่ละหลัก
ทำให้สามารถเก็บเลขจำนวนเต็มค่าใหญ่มากๆได้เท่าที่หน่วยความจำยังมีพอ
'''
# ** คือ ตัวกระทำ(operor) ยกกำลัง เช่น 2**3 คือ 2 ยกกำลัง 3 เท่ากับ 8
##print(2**3)         # 8

# Try: 
##print(123**1234)    # ผลลัพธ์เป็นเลข 2579 หลัก

## เวลา 2**64 วินาทีเท่ากับกี่พันล้าน(10**9) ปี
seconds = 2**64
minutes = seconds / 60     ## 1 minute = 60 seconds
hours = minutes / 60       ## 1 hour = 60 minutes
days = hours / 24          ## 1 day = 24 hours
years = days / 365.25      ## 365.25 day = 1 year
                           ## 1_000_000_000 years = 1 billion year

# ภาษา Python ยอมให้มี underscroe (_) ในตัวเลข โดยไม่มีค่า แต่เพื่อทำให้อ่านง่าย
billion_year = years / 1_000_000_000
##print(billion_year)   

# Using String Format:
# แสดงเป็นเลขทศนิยมหลักจุดเพียงแค่ 2 หลัก
##print('2**64 = %.2f billion years.' % billion_year)

# Using Function String:
##print(f'2**64 = {billion_year:.2f} billion years')

# นักวิทยาศาสตร์เชื่อว่าจักรวาลของเราเกิดมาแล้วประมาณ 3 พันล้านปี และจะอยู่ไปได้อีกไม่เกิน 15 พันล้านปี

#-------------------------------------------------------

''' Example:
บนกระดานหมากรุกขนาด 8x8 จะมีทั้งหมด 64 ช่อง
        หาก วางเมล็ดข้าว 1 เมล็ดลงบนช่องที่ 1
                    2 เมล็ดลงบนช่องที่ 2
                    4 เมล็ดลงบนช่องที่ 3
                    8 เมล็ดลงบนช่องที่ 4
และวางเป็นจำนวนสองเท่าของช่องก่อนหน้านั้นบนทุกๆช่องที่เหลือ จะต้องใช้ช้าวทั้งหมด 2**64 - 1 เมล็ด
   หากประเทศหนึ่งผลิตข้าวได้ 1000 ล้านตัน ต่อปี สมมติว่าข้าว 1 ตันมี 10 ล้านเมล็ด
      ประเทศนี้ต้องใช้เวลากี่ปีจึงจะผลิตข้าวจำนวนนี้ได้
'''
def rice_grains():
    grains = 2**64 - 1
    tons = grains / (10 * 1000000)
    years = tons / (1000 * 1000000)
    print('%.2f years' % (years))
##rice_grains()

''' Exercise:
1. บริษัท Google มีชื่อมาจากคำว่า googol ซึ่งมีค่าเท่ากับ 10 ยกกำลัง 100 คือ 10**100
       จงคำนวณว่าเวลา 1 googol วินาทีเท่ากับกี่พันล้าน(10**9) ปี

2. ชาวตะวันตกเชื่อว่าเลข 6 เป็นเลขอาถรรพ์ และ 666 เป็นเลขแห่งความชั่วร้าย
       จงคำนวณว่า ระหว่าง 666**666 กับ 6**(6**6) ค่าใดมากกว่ากัน

3. ในทวีปยุโรป 1 billion มีค่าเท่ากับ 1 ล้านล้าน (คือ 10**12)
   แต่ในอเมริกา 1 billion มีค่าเท่ากับ 1 พันล้าน (คือ 10**9)
กำหนดให้ หนึ่งนาทีมี 60 วินาที หนึ่งชั่วโมงมี 60 นาที หนึ่งวันมี 24 ชั่วโมง และหนึ่งปีมี 365.25 วัน
สมมติว่าคนทุกคนหายใจหนึ่งครั้งทุกวินาที ตั้งแต่เกิดและไม่หยุดหายใจจนตาย
คนยุโรปจะไม่สามารถมีอายุอยู่ถึงตอนที่หายใจครั้งที่ 1 billion
 แต่คนอเมริกันจะหายใจครั้งที่ 1 billion ตอนอายุกี่ปี

4. Alpha Centauri คือระบบกลุ่มดาวที่อยู่ห่างจากโลกประมาณ 4.37 ปีแสง(light year)
หนึ่งปีแสงคือ ระยะทางที่แสงเดินทางหนึ่งปี มีค่าประมาณ 9.4605284 × 10**12 กิโลเมตร
เครื่องบินเจ็ทที่เร็วที่สุดในโลกตอนนี้คือ MIG-25 ทำความเร็วได้ 3,089 กิโลเมตร/ชั่วโมง
จงคำนวณว่า MIG-25 ต้องใช้เวลากี่ปี จึงจะไปถึง Alpha Centauri
หากสามารถใช้ความเร็วสูงสุด และไปได้ตลอดเส้นทางโดยไม่ต้องหยุด
'''

#---------------------------------------------------------

# Python uses newline('\n'), return('\r') and semicolon(';')
#  as the statement separator. A ';' at the end of statement
#  is not necessary but not an error.


#  A document comment (to the end of the line).
## A test comment.

##print('Hello')        # Hello

# Print an empty line.
##print()

# print() evaluates its arguments then converts to string and send to standard output.
##print(1+2)            # 3

# print() always ends with newline.
##print('Hello')
##print('Bye')

# Using ';' more than one statements may be in the same line.
##print('Hello'); print('Bye')

# print() may accept more than one parameters using ',' as separator.
# All parameters are printed in the same line, with an extra space between items.
##print('Hello', 'John')

## To print without newline, define the attribute 'end' to be null.
# print('Hello', end=''); print('Bye')

## Print the format String:
# print('Hello {1} and {0}.'.format('John', 'Jack') )

## Interploration:
# print('This %s costs $%.2f.' % ('books', 12.345))


## input() always return a string.
# s = input("Enter a name.\n"); print("Hello " + s)

## To input a number we need explicit type conversion.
# n = int(input("Enter a number. ")); print(n, type(n))

