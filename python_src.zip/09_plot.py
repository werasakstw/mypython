# pip install matplotlib
import matplotlib.pyplot as pp

pp.close('all')  # There may be graphs from the previously run.

def simple_plot():
    # plot(x, y): x and y must be lists of the same size.
    x = [1, 2, 3, 4]
    y = [1, 3, 0, 5]
##    pp.plot(x, y)

    # plot(y):  default x is [0, 1, 2, ...]
##    pp.plot(x)

    # x-axis may be scaled as needed.
##    pp.plot(range(100, 500, 100), y)

    # Multiple y axises on a default x-axis.
    y1 = [0, 3, 2, 4]
    y2 = [1, 0, 1, 6]
##    pp.plot(y1)
##    pp.plot(y2)

    # Multiple graphs
    x1 = range(4, 8)
    x2 = range(0, 10, 3)
##    pp.plot(x1, y1, x2, y2)
    
    pp.show()
##simple_plot()

# A frame is defined as a figure.
def sep_frame():
    pp.figure(1)            
    pp.plot([3, 2, 5])
    pp.title('Figure 1')

    pp.figure(2)
    pp.plot([1, 3, 1, 2])
    pp.title('Figure 2')
    pp.show()
##sep_frame()

# Sub plots in a frame.
def sub_plot():
    pp.figure()     # create a new figure
    
    pp.subplot(221) # divide subplots into 2 x 2 grid and select no. 1
    pp.title('Figure 1')
    pp.plot([1, 2, 0, 4])

    pp.subplot(222) # select no. 2
    pp.title('Figure 2')
    pp.plot([6, 3, 5, 2])
    
    pp.subplot(223) # select no. 3
    pp.title('Figure 3')
    pp.plot([2, 1, 5, 2])

    #pp.tight_layout()   # Add margin between subplots.
    pp.show()
##sub_plot()
    
# Function Plot:
def fun_plot():
    #  y = 2*x - 3   for -10 <= x < 10
    pp.plot(range(-10, 10), [2*x - 3 for x in range(-10, 10)])
    
    #  y = x^2    for 0 <= x < 10
    pp.plot([x*x for x in range(10)])

    #  y = x**2 + x + 1   for -10 <= x < 10
    pp.plot(range(-10, 10), [x**2 + x + 1 for x in range(-10, 10)])

    #  y = 1 - 1 / x   for 0 <= x < 10
##    pp.plot([1 - (1/x) for x in range(10)])   # error: divide by zero
    
    pp.show()
##fun_plot()

## Using NumPy
import numpy as np
def np_test():
    # numpy's arange() creates a list of floats.
    xa = np.arange(10)
##    print(len(xa))
##    pp.plot(xa, [1 - (1/x) for x in xa])

    # numpy's linspace() creates a list of many floats for ploting.
    xr = np.linspace(0, 10)
##    print(len(xr))
##    pp.plot(xr, [1 - (1/x) for x in xr])

    # log base 2 and base 10
##    pp.plot(xr, [np.log2(x) for x in xr])
##    pp.plot(xr, [np.log10(x) for x in xr])

    # sin, cos and tan
    xa = np.linspace(0, 4*np.pi)
##    pp.plot(xa, [np.sin(x) for x in xa])
##    pp.plot(xa, [np.cos(x) for x in xa])
##    pp.plot(xa, [np.tan(x) for x in xa])
    
    # Functions can be applied to a list aggregately.
##    pp.plot(xa, np.sin(xa))
##    pp.plot(xa, np.cos(xa))
    
    pp.show()
##np_test()

#--------------------------------------------------
''' SymPy provides a more simple plot.
It was designed to work with expression of symbols,
but limited to only one symbol. '''
from sympy.plotting import plot
from sympy import Symbol
x = Symbol('x')
def parabola_plot():
    # b**2 < 4*a*c   there are no solutions.
    b, a, c = 1, 1, 1
    # plot the expression, limit x axis as [-4, 4]
    plot( a*x**2 + b*x + c, (x, -4, 4) )

    # b**2 = 4*a*c   there is one solution.
    b, a, c = 2, 1, 1
    plot( a*x**2 + b*x + c, (x, -4, 4) )

    # b**2 > 4*a*c   there are two solutions.
    b, a, c = 3, 1, 1
    plot( a*x**2 + b*x + c, (x, -4, 4) )
##parabola_plot()
# There are three plots, close one to see the other.
    
# Save the plot in a file
def save_plot():
    p = plot(x**2 - 5*x - 20, (x, -20, 20), show=False)
    p.save('plot.png')
##save_plot()

''' Solving Equations with Graphs:
Ex.     2*x+3 = 0
        3*x+1 = 0       '''
def solve_equations():
    p = plot(2*x+3, 3*x+1, (x, 0, 5), legend=True, show=False)
    p[0].line_color = 'b'
    p[1].line_color = 'r'
    p.show()
##solve_equations()
# The graphs are cross at (2, 7).

#--------------------------------------------------

# Visualizing Random Distributions
# Python Random
import random
import statistics as st

xr = range(1000)
standard = [random.random() for _ in xr]        # 0.0 -> 1.0
uniform = [random.uniform(0, 2.0) for _ in xr]  # 0.0 -> 2.0
gaussian = [random.gauss(0.5, 0.1) for _ in xr] # mean = 0.5, sd = 0.1

def dist_statistic():
    print('\t\tstandard', '\tuniform', '\tgaussian')
    print('min/max: \t(%.2f/%.2f)\t(%.2f/%.2f)\t(%.2f/%.2f)' %
          (min(standard), max(standard),
           min(uniform), max(uniform),
           min(gaussian), max(gaussian)))
    print('Mean: \t\t%.2f\t\t%.2f\t\t%.2f' %
          (st.mean(standard), st.mean(uniform), st.mean(gaussian)))
    print('Sd: \t\t%.2f\t\t%.2f\t\t%.2f' %
          (st.pstdev(standard), st.pstdev(uniform), st.pstdev(gaussian)))
##dist_statistic()

def random_scatter():
    pp.scatter(xr, standard, color='r')
    pp.scatter(xr, uniform, color='g')
    pp.scatter(xr, gaussian, color='b')
    pp.show()
##random_scatter()

def random_histogram():
    pp.subplot(131); pp.title('standard')
    pp.hist(standard)
    

    pp.subplot(132); pp.title('uniform')
    pp.hist(uniform)
    
    pp.subplot(133); pp.title('gaussian')
    pp.hist(gaussian)
    pp.show()
##random_histogram()
