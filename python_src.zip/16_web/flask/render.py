
## Add import render_template and redirect
## Create hello.html in .\templates
## Create hi.html in .\static

from flask import Flask, render_template, redirect
from flask.helpers import url_for
app = Flask(__name__)

@app.route("/raw")
def raw():  ## render raw html
    return "<html>I am raw.</html>", 200

@app.route('/hello')
def hello():  ## render html file
    return render_template('hello.html')

@app.route('/hi')
def hi():  ## redirect to html file
    return redirect(url_for('static', filename='hi.html'))

@app.route('/whatup/<name>')
def whatup(name):  ## render html file
    return render_template('whatup.html', name=name)

if __name__ == '__main__':
    app.run()

##  http://127.0.0.1:5000/raw
##  http://127.0.0.1:5000/hello
##  http://127.0.0.1:5000/hi
##  http://127.0.0.1:5000/whatup/john
