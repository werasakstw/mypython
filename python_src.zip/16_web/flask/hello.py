from flask import Flask
app = Flask(__name__)

@app.route("/")
def index():
    return "Hello! I am index."

@app.route("/hello")
def greet():
    return "Hello! I am hello."

@app.route("/hi/<name>")
def hi(name):
    return "Hi! %s." % name

if __name__ == "__main__":
    app.run()   ## default port = 5000
    #app.run(port=8080)

##  http://127.0.0.1:5000/
##  http://127.0.0.1:5000/hello
##  http://127.0.0.1:5000/hi/john

