from web3 import Web3

URL = "https://rinkeby.infura.io/v3/1c33caf701824d43882200b69d5e0849"
w3 = Web3(Web3.HTTPProvider(URL))

from web3.middleware import geth_poa_middleware
w3.middleware_onion.inject(geth_poa_middleware, layer=0)

##
##import json
##def print_json_str(st):
##   res_json = json.loads(st)
##   print(json.dumps(res_json, indent=4, sort_keys=True)) 
##
##def print_json(ad): # AttributeDict
##   st = w3o.toJSON(ad)   # str
##   js = json.loads(st)
##   print(json.dumps(js, indent=4, sort_keys=True))
##   
##def print_result(st):
##   print(json.loads(st)['result'])
##
###------------------------------------------------------
##
##def quote(w):
##   return '["%s"]' % w
##
##def quote2(w1, w2):
##   return '["%s", "%s"]' % (w1, w2)
##
##def quote3(w1, w2, w3):
##   return '["%s", "%s", "%s"]' % (w1, w2, w3)
##
##def quote4(w1, w2, w3, w4):
##   return '["%s", "%s", "%s", "%s"]' % (w1, w2, w3, w4)
##
###------------------------------------------------------
##
##import binascii
##def str_hexstr(s):
##   h = binascii.hexlify(s.encode())
##   return '0x%s' % h.decode()
####print(str_hex('Hello how do you do?'))
##
##def hexstr_str(hs):
##   return binascii.unhexlify(hs[2:]).decode()
####print(hexstr_str('0x48656c6c6f20686f7720646f20796f7520646f3f'))
##
