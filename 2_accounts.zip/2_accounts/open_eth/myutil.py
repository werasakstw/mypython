from web3 import Web3
URL = 'http://127.0.0.1:8545'
w3 = Web3(Web3.HTTPProvider(URL))

from web3.middleware import geth_poa_middleware
w3.middleware_onion.inject(geth_poa_middleware, layer=0)

#------------------------------------------------------

import json
def print_json_str(st):
   res_json = json.loads(st)
   print(json.dumps(res_json, indent=4, sort_keys=True)) 

def print_json(ad): # AttributeDict
   st = w3.toJSON(ad)   # str
   js = json.loads(st)
   print(json.dumps(js, indent=4, sort_keys=True))
##   
def print_result(st):
   print(json.loads(st)['result'])

#------------------------------------------------------

def quote(w):
   return '["%s"]' % w

def quote2(w1, w2):
   return '["%s", "%s"]' % (w1, w2)

def quote3(w1, w2, w3):
   return '["%s", "%s", "%s"]' % (w1, w2, w3)
