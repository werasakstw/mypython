''' A function is defined with a keyword 'def' follows by a <name>
 followed by possiblly <parameters> in () and a <body>.
         def <name>(<parameters>):
             <body>
Functions create new scope therefore <body> always begin with a ':'.
Statements in the body must be properly indentated.
A function must be defined before it can be invoked.
To execute the function, it must be explicitly invoked.

A function may have no parameters. '''
def hello():
    print('Hello')
# hello()

''' A function definition without a body is an error.
'pass' is a keyword to denote an empty body. '''
def empty_function():
    pass
# empty_function()

''' 'Doc String' is meta information of a function.
A doc string is defined between the head and body of the function
and bound to the __doc__ attribute. '''
def func():
    '''This is a doc string.'''
    pass    # If an empty function has a doc string, 'pass' is optional.
print(func.__doc__)
''' PEP257 defines what should be given in a docstring.
The doc string is shown when the function is passed to help(). '''
# help(func)

#------------------------------------------------------------

'''  Parameters are values passed to a function.
That allows a function can be used in different contexts.
Parameters are defined without type.
The passed value on caller side is called 'argument'.
The variables to receive values on callee side is called 'parameter'.

A function definition override the already exist name. '''
def hello(name):
    print('Hello ' + name)
# hello('John')       # Hello John
## Parameter types may vary at each executions.
# hello(123)          # Hello 123

''' A function may or may not return a value.
The returned value must be specified with 'return' keyword.
Function difinitions define no returned type. '''
def hi(name):
    return 'Hi ' + name
# print(hi('John'))

## A function may return different types.
def return_type(x):
    if x == 1:
        return 1
    return 'A'
# print(return_type(1), return_type(2))   # 1 A

## A function returns a value, but it may be a tuple.
def return_tuple():
    return 1, 2     # Tuple packing
# x, y = return_tuple(); print(x, y)      # 1 2

## 'return None', 'return' and no return are the same.
def greet(name):
    if name == 'John':
        return 'Hello'
    # return None
    # return
# print(greet('Jack'))        # None

''' 'None' is a special value that allows passing/returning nothing.
But it must be tested explicitly. '''
def greet(name):
    if name is None:
        print('Hello whoever you are.')
    else:
        print('Hello', name)
# greet()           #  error
greet(None)         #  Hello whoever you are.
# greet('John')     #  Hello John

#-----------------------------------------------------------

''' Function type annotations:
     - parameter type follows :
     - return type follows ->
They are just the hints, no effect to the codes and compilers
do not perform type checking nor enforcement. '''
def type_anno(x: int, y: float) -> str:
    return x + y
# print(type_anno(1.0, 2))
## The information are stored in the  __annotations__ attribute.
# print(type_anno.__annotations__)

''' Type annotations are mostly types(e.g. int and str), but
variable names and expressions are allowed. '''
john = 'John Rambo'
def f(x: john, y: 'int > 0' = 1):
    pass
# f('Jack', -1)

#------------------------------------------------------------------

## Python allows nested functions.
def outter(name):
    print('Start')
    def inner(n):
        return 'Hello ' + n
    print(inner(name))
# outter('John')

''' Python creates a function (as an object) dynamically.
If a function definition is not executed, the function is not created. '''
def fun_def():
    def f():
        pass
    print(dir())    #  ['f']     A list of name defined in the current scope.

    def g():
        pass
    print(dir())    #  ['f', 'g']
# fun_def()

''' Python does not allowed function overloading.
If a function with already exist name is defined, the previous
function is overrided(shadowed). '''
def function_override():
    def f(x):
        print(x)

    def f(x, y):
        print(x, y)

    # f(1)          #  error
    f(1, 2)         #  1 2
# function_override()

'''  Variable Length Arguments (Var-Arg):
A star * that applied to a parameter indicates that all
arguments are collected into a tuple and passed to
the parameter.  '''
def var_arg():
    def f(*n):      ## 'n' is a tuple.
        print(n)

    f()                  #  ()
    f('John')            #  ('John',)
    f('John', 'Jack')    #  ('John', 'Jack')
# var_arg()

#-----------------------------------------------------------
'''
There are different interpretations of 'pass by reference'.
Python parameter passing is called 'pass by sharing' which means
the argument and parameter are alias.
We need to concern only whether the arguments have side effect.
If the arguments are immutable, there will have no side effect.
If the arguments are mutable, there will be side effect.
If side effect is not desirable, the mutable arguments must be copied
and pass the other copy.
'''
def sharing():
    def f(x, y):
        x += y
        return x

    a, b = 1, 2             #  int is immutable.
    print(f(a, b), a, b)    #  3 1 2

    a, b = 'a', 'b'         #  str is immutable.
    print(f(a, b), a, b)    #  ab a b

    a, b = (1, 2), (3, 4)   #  tuple is immutable.
    print(f(a, b), a, b)    #  (1, 2, 3, 4) (1, 2) (3, 4)

    a, b = [1, 2], [3, 4]   #  list is mutable.
    print(f(a, b), a, b)    #  [1, 2, 3, 4] [1, 2, 3, 4] [3, 4]
# sharing()

#---------------------------------------------------------------

## Python supports two kinds of argument passing:
def arg_passing():
    def f(name, password):
        print(name, password)

    ##  Positional Arguments.
    f('John', 'hello')

    ##  Keyword(or Named) Arguments.
    f(password='123', name='Jack')
# arg_passing()

''' 'Default Parameters' are parameters with given default values.
If no argument passed to, the parameter assumes the default. '''
def default_param():
    def f(x, y = 0):
        print(x, y)

    f(1)            #  1 0
    f(1, 2)         #  1 2

    ## Default parameters must defined from the right most to left.
    def f(a = 1, b = 1, c = 1):
        # f(a, b = 1, c = 1):
        # f(a, b, c = 1):
        # f(a = 1, b, c = 1):      # error:
        # f(a = 1, b = 1, c):      # error:
        print(a, b, c)
# default_param()
''' So positional and keyword arguments can be mixed but the
positional ones must come first. The problem is how can we specify
which must be positional and keyword. '''
#-------------------------------------------------------------

''' Parameter Side:
A star * parameter indicates the end of positional arguments
after that must be keyword arguments. '''
def one_star_param():
    def f(x = 0, *, a = 1, b = 2):
        print(x, a, b)

    f()                  	#  0, 1, 2
    f(3)                  	#  3, 1, 2
    # f(1, 2)             	#  error
    f(1, a = 10, b = 20)        #  1 10 20
    f(a = 10, b = 20)     	#  0, 10, 20
    # f(10, b = 20)         	#  error
# one_star_param()

'''  A one star paramater is a marker and has no value.
     A var_arg, *<param> indicates that the <param> is a tuple.
A var_arg can be mixed with positional, but must be the rightmost.
That indicates parameters before the var_arg are required.  '''
def required_vararg():
    def f(a, *n):        # 'a' is required.
        print(a, n)

    # f()                #  error
    f(1)                 #  1 ()
    f(1, 2)              #  1 (2,)
    f(1, 2, 3)           #  1 (2, 3)
# required_vararg()

''' Two stars, **<param> indicates that the <param> is a dict
that is collected from keyword arguments.  '''
def two_star_param():
    def f(**d):
        print(d)

    f()              #  {}
    f(a=1)           #  {'a': 1}
    f(a=1, b=2)      #  {'a': 1, 'b': 2}
# two_star_param()

''' Positional, *<param> and **<param> can be mixed.
 *args    is tuple of positional arguments.
 **kwargs is dictionary of keyword arguments. '''
def mix_params():
    def f(a, *args, **kwargs):
        print(a, args, kwargs)

    # f()               #  error
    f(1)                #  1 () {}
    f(1, 2)             #  1 (2,) {}
    f(1, 2, b = 3)      #  1 (2,) {'b': 3}
    f(1, b = 2)         #  1 () {'b': 2}
    # f(1, a = 2, 3)    #  error: keyword parameters must be right most

    ## It is easier to strict to a pattern.
    f('hello')              # hello () {}
    f('hello', 1)           # hello (1,) {}
    f('hello', 1, 2)        # hello (1, 2) {}
    f('hello', 1, 2, x=3)   # hello (1, 2) {'x': 3}
# mix_params()

#-----------------------------------------------------------------------
''' Argument Side:
*<arg> on argument side indicates that the <arg> is unpacked and
passed to the correspond parameters.
The <arg> may be list, tuple, set or dict. '''
def arg_unpack():
    def f(x, y, z):
        print(x, y, z)

    a = [1, 2, 3]
    f(*a)                      # 1 2 3

    ## The arguments and parameters must be equal in number.
    # f(*[1, 2])              # error
    # f(*[1, 2, 3, 4])        # error

    ## If the argument is a dict, only the keys are passed.
    f(*{'a': 1, 'b': 2, 'c': 3})   # a b c

    ## *<arg> can be passed to a *<param>.
    def ff(a, *p):
        print(a, p)
    ff(*[1, 2])             # 1 (2,)
# arg_unpack()

''' **<arg> on argument side indicates that the <arg> is a dict
and passed as keyword arguments. '''
def arg_keyword():
    def f(x, y):
        print(x, y)
    ## Keyword arguments are normal acceptable.
    f(y = 1, x = 2)         # 1 2

    ## **<arg> allows passing dict as argument.
    d = {'y': 4, 'x': 3}  ## Number of elements must correspond to parameters.
    f(**d)                  # 3 4

    ## **<arg> and keyword arguments can be passed to **<param>.
    def ff(**p):
        print(p)
    ff(**{'y': 1, 'x': 2})      # {'y': 1, 'x': 2}
    ff(x = 3)                   # {'x': 3}
# arg_keyword()

''' Using * and ** at both sides indicates the argument go to tuple or dict.
And allows var-args for both positional and keyword arguments. '''
def args_kwargs():
    def f(*args, **kwargs):
        print(args, kwargs)

    a = [1, 2]
    d = {'x': 3, 'y': 4}
    f(a)          #  ([1, 2],) {}
    f(*a)         #  (1, 2) {}
    f(d)          #  ({'x': 3, 'y': 4},) {}
    f(*d)         #  ('x', 'y') {}
    f(**d)        #  () {'x': 3, 'y': 4}
    f(a, d)       #  ([1, 2], {'x': 3, 'y': 4}) {}
    f(*a, **d)    #  (1, 2) {'x': 3, 'y': 4}
# args_kwargs()
