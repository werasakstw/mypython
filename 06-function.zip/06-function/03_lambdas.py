''' Lambdas are functions with no names and defined as expressions.
          lambda <parameters> : <body>
A lambda may be invoked directly by applyed with arguments enclosed in (). '''
# (lambda name: print('Hello ' + name))('John')   #  Hello John

def lambda_obj():
    ''' A lambda is a 'function object' which may be assigned to a name
     and be executed as a function. '''
    hello = lambda name: print('Hello ' + name)
    hello('Jack')            # Hello Jack
    print(type(hello))       # <class 'function'>

    ## A lambda has a 'code object'.
    print(hello.__code__)

    ## Lambdas are callable.
    print(callable(hello))   # True

    ## Lambdas are first class objects and may be passed to/from a function.
    def test(f, name):
        f(name)
    test(hello, 'Joe')       # Hello Joe
# lambda_obj()

def lambda_syntax():
    ## A lambda may have no parameters.
    print((lambda : 'Hello')())            # Hello

    ## Lambda body must be an expression and result is automatically returned.
    print((lambda x : x+1)(1))              # 2

    ## Parenthesis () arounds lambda parameters is not allowed.
    # print((lambda (n): 'Hello' + n)())   # error

    ## Lambda parameters are separated by ','.
    print((lambda a, b : a+b)(1,2))        # 3

    ## Lambda body must be a single expression.
    # print((lambda a, b : a + b, a * b)(1,2))    # error

    ''' Lambda body expressions may result:
            - a tuple if enclosed with ().
            - a list if enclosed with [].
            - a set or dict if enclosed with {}.
    So enclosing a body with {} does not make it a block. '''
    print((lambda x : { 'x': x, 'x+1': x+1 })(1))    # {'x': 1, 'x+1': 2}

    ## print() is a function that returns a None, not a statement.
    print((lambda: { print('Hello'), print('Hi') })())  # Hello
                                                        # Hi
            # Resulting a None because it is a set.     # {None}
# lambda_syntax()

''' Lambda VS Normal Function:
- Lambdas are designed for small(a single expression) while Normal
 functions can be as big as required.
- Unlike normal functions, lambdas do not require adding/removing
 names to/from namespaces
- Lambdas are good for short-life, use-and-forget and passing
 around functions. Normal functions are for long-term and heavy usages.
 '''
def func_namespaces():
    ## Function definition adds the function name to working namespace.
    def hello(name):
        print('Hello', name)
    hello('John')               # Hello John
    print(dir())                # ['hello']

    ## Lambda do not add name to working namespace.
    (lambda name: print('Hi', name))('Jack')  # Hi Jack
    print(dir())                # ['hello']
# func_namespaces()

''' Lambdas are function that expressed as expressions.
'function str' is a function that expressed as string and results a str.
It allows embedded expressions inside str literals.
An expression in 'function str' is enclosed with {}. '''
def func_str():
    ''' Expressions in 'function str' are evalulated then results
    are inserted at the positions. '''
    print(f'a{1+2}b')           # a3b

    ## The expression may contain function calls.
    print(f'{len("John")}')     # 4

    ## Collections projections.
    l = ['John', 'Jack', 'Joe']
    print(f'Hi {l[1]}')         # Hi Jack
    d = { 'first-name': 'Joe', 'last-name': 'Green'}
    print(f'What up? {d["first-name"]}')    # What up? Joe

    ## Format characters are supported.
    x = 1.23456
    print(f'x = {x:.2f}')       # x = 1.23
# func_str()

''' Python supports evaluating expressions that represented as str:
              eval(<expression str>[, globals[, locals]])
The result type is the returned value type.  '''
def eval_test():
    print(eval('1+2'))              # 3

    # The <expression str> may contain function calls.
    print(eval("len('John')"))      # 4
# eval_test()

#------------------------------------------------

''' An alternative approach for meta-programming:
A function can be created from a string.
              exec(<func_def str>, <context>)
<func_def str> is a str that contains function definition.
<context> is a dict.
The result is a <name>:<function> element in the <context>. '''
def exec_test():
    hello_str = '''
def hello(name):
   print('Hello ' + name)
'''
    ctx = {}
    exec(hello_str, ctx)
    ctx['hello']('John')        # Hello John
# exec_test()

''' A code object of a function is an object that wraps code of the function.
Code objects are not callable, but can be executed by eval(). '''
def greet():
    print('Greeting ' + name)
# eval(greet.__code__, {'name': 'john'})      # Greeting john

''' A code object can be created from a string that contains
  statement or expression.
      compile(<expr str>, <file name>, <mode>)  '''
# co = compile("print('How do you do?')", 'hello.py', 'eval')
# eval(co)            # How do you do?
