''' Functions are easier to be understood and used than objects.

A python functions is an objects of <class 'function'>. '''
def function_object():
    def f():
        '''function doc string'''
        print('Hello')
    print(type(f))      # <class 'function'>
    ## A function is represented as a 'function object' of <class 'function'>.

    ## A 'function object' has a namespace which contains:
    print(f.__dict__)   # {}

    ## A python function is stateful, that means it may have state.
    f.x = 1
    print(f.__dict__)   # {'x': 1}

    ## A 'function object' has the following special attributes:
    print(f.__name__)   # f
    print(f.__doc__)    # function doc string
    print(f.__class__)  # <class 'function'>    same as type(<func>)
    print(f.__code__)   # 'code object' that represents program of the function.
# function_object()

''' A function local variable holds its state during the function activation.
A 'function object' holds its state during the object lifetime, that means
  its state is persist between successive calls.  '''
def stateful_func():
    def inc():
        if 'c' not in inc.__dict__:
            inc.c = 0
        inc.c += 1            # inc.c is remembered as a state of inc().
        return inc.c

    print([inc() for _ in range(3)])       # [1, 2, 3]
# stateful_func()

''' An object of any classes is 'callable' if it has __call__().
That allows callng an object like a function. '''
def callable_obj():
    class A:
        def __call__(self, name):
            print('Hello', name)

    ''' () is the 'call' operator.
    If () is applied to a class, the meta-class's __call__() is invoked
      and the created object of the class is returned. '''
    a = A()

    ## If () is applied to a callable object, its __call__() is invoked.
    a('John')                           # Hello John

    # callable(<arg>) is built-in function for testing if <arg> is callable.
    print(callable(A), callable(a))     # True True
# callable_obj()

''' All classes are callable since <class 'object'> has a __call__().
If a class does not implement __call__() it's objects are not callable. '''
class X:
    pass
# print(callable(X), callable(X()))       # True False

''' Function VS Method:
Methods need object reference as the first parameter, functions do not.
Methods are functions wrapped in 'method objects'.
A 'method object' has:
    __func__() that calls to the function's 'code object'.
    __call__() that calls to __func__() by inserting the first argument as 'self'.
When a method name applied with () its __call__() is executed.  '''
def met_call():
    class A:
        def m(self, name):
            print('Hello', name)

        def c(name):
            print('Hi', name)
    a = A()
    a.m('John')                # Hello John
    a.m.__call__('Jack')       # Hello Jack
    a.m.__func__(a, 'Joe')     # Hello Joe

    ## A 'class method' is a function.
    A.c('Jim')                 # Hi Jim
    A.c.__call__('Jame')       # Hi Jame
    a.c.__func__('Jody')       # Hi Jody
# met_call()
