''' Functional Programming is a programming paradigm that everything
 are functions, no statements, no side effect, nor iterations.

Aggregation is a mechanism to apply a function to every elements
 in a sequence one by one resulting a stream of results.
That allows programming without explicit loopings.

Python supports aggregarion by a built-in function:
          map(<function>, <sequence>)
<sequence> may be collections, generator, iterable or a range().
<function> is a callable which may be function or lambda.
map() returns a generator for the results stream. '''
sq = lambda n : n*n
# print(list(map(sq, range(5))))        # [0, 1, 4, 9, 16]
''' Since map() generates results one at a time, we need list()
to collect the stream. '''

''' Decision Aggregation: Python provides a built-in function:
            filter(<boolean function>, <sequence>)
<boolean function> is applied to elements in <sequence>,
 if a result is True the element is passed to the result. '''
import math
is_sq_number = lambda n: n == math.sqrt(n) * math.sqrt(n)
# print(list(filter(is_sq_number, range(10))))       # [0, 1, 4, 9]

## Comprehension can do the job with more efficient and readable.
# print([ x for x in range(5) if is_sq_number(x) ])   # [0, 2, 4, 6, 8]

''' 'Reduce' reduces a stream of results into a value.
    'functools' lib has:
             reduce(<function>, <sequence>)
<function> is applied to two successive elements in the <sequence>,
 the result is accumulated to a value. '''
import functools, operator
def reduce_test(n):
    r = range(1, n+1)           # 1 -> n

    ## Sumation
    print(functools.reduce(operator.add, r))       # 55

    ## Factorial
    print(functools.reduce(operator.mul, r))       # 3628800
# reduce_test(10)

''' Map-Reduce Programming Paradigm:
Ex. To compute summation of even numbers less than 10. '''
def paradigms():
    is_even = lambda x: x % 2 == 0

    ## Procedural (Imperative)
    r1 = []
    for x in range(10):
        if is_even(x):
            r1.append(sq(x))
    r2 = 0
    for x in r1:
       r2 += x
    print(r2)                           # 120

    ## Map-Reduce (Functional)
    print(functools.reduce(operator.add,
          map(sq,
          filter(is_even, range(10)))))  # 120

    ## Comprehension Style
    print(sum([sq(x) for x in range(10) if is_even(x)]))  # 120
# paradigms()
