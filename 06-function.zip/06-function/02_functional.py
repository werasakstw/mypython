''' A function is 'first class' object if:
  1. Created dynatically at runtime.
  2. Assignable to variable names.
  3. Passed to/from functions. '''
def functional():
    ## Function definitions creates function dynamically.
    print(dir())        # []
    def sq(n):
        return n*n
    print(dir())        # ['sq']

    ## Functions can be saved to a variable or collection.
    f = sq          ## just the name without ().
    print(f(2))         # 4

    ## Functionals may accept function as parameters.
    def meta_fun(f, a):
        return f(a)
    print(meta_fun(sq, 3))   # 9

    def get_sq():
        return sq
    print(get_sq()(4))      # 16
# functional()

''' A functional may return an inner function to be used outside its scope
If a returned function refers to objects in outer its scope, the object
 must be copied to go with the function, this is called 'capturing'.
A function with its captured objects is called closure. '''
def get_hello(name):
    msg = 'Hello '
    def hello():
        return msg + name
    return hello
# print(get_hello('John')())              # Hello John

''' In Java, closures hold an immutable of captured objects, since they may
  returned to many callers.
Python closures hold mutable captured objects. '''
def get_inc():
    x = 0
    def inc():
        nonlocal x
        x += 1
        return x
    return inc

def inc_test():
    f1 = get_inc()
    f2 = get_inc()
    print(f1(), f2())      # 1 1
# inc_test()

#----------------------------------------------------------------------

''' 'Partial functions' are functions for an action that some parameters
 are fixed as default. That allows greater flexibility of calling the function.
Python does not support overloading, but callable objects can be created with
 different name for some fixed parameters. '''
def callable_objects():
    class Greet:
        def __init__(self, msg):
            self.msg = msg

        def greet(self, name):
            return self.msg + ' ' + name

        def __call__(self, name):
            return self.greet(name)  ## Returns a callable greet with fix 'msg'.

    hello_greet = Greet('Hello')
    print(hello_greet('John'))          # Hello John

    hi_greet = Greet('Hi')
    print(hi_greet('Jack'))             # Hi Jack
# callable_objects()

''' 'functools' lib has partial() for creating a partial function from
 an already defined function. '''
import functools
def partial_func():
    def add(a, b):
        return a + b

    ## Only the right most parameters may have default values.
    add_one = functools.partial(add, b=1)   ## 'b' parameter is fixed.
    add_two = functools.partial(add, b=2)
    print(add_one(1), add_two(1))           # 2 3
# partial_func()

import operator     ## A standard lib with a lot of operators defined.
# print(dir(operator))

def partial_op():
    ## 'mul' for multiplication
    print(operator.mul(2, 3))   # 6

    ## Create a function from an already exist one.
    triple = functools.partial(operator.mul, 3)
    print(triple(2))            # 6
# partial_op()

#----------------------------------------------------------------

''' A 'decorator' is a functional that accepts a function as parameter
 and returns the modified function as result.  '''
def decorator_test():
    ## To add an extra line to the doc string of a function.
    def written_by_john(f):
        f.__doc__ += '\nWritten by: John.'
        return f

    ## 1. Manually implemented decorator, (performed at runtime).
    def hello():
        '''Return: Hello'''
        print('Hello')
    hello = written_by_john(hello)
    print(hello.__doc__)        # Return: Hello
                                # Written by: John.

    ''' 2.@<decorator> adds the <decorator> to the function below.
    It is performed when the function is created.
    There can be multiple decorators applied, the lowest is the first. '''
    @written_by_john
    def hi():
       '''Return: Hi'''
       return 'Hi!'
    print(hi.__doc__)           # Return: Hi
                                # Written by: John.
# decorator_test()

## A decorator may add parameters to the function, using function wrapper.
def func_wrap():
    def add_param(func):
        def _f(name):
            return func() + ' ' + name
        return _f

    @add_param
    def hello():
        return 'Hello'

    print(hello('John'))       # Hello John
# func_wrap()

# A decorator may has parameters by using function wrapper wrapper.
def wrapper_wrapper():
    def add(msg):
        def __f(func):
            def _f(name):
                return func() + ' ' + name + ', ' + msg
            return _f
        return __f

    @add('how do you do?')
    def hello():
        return 'Hello'

    print(hello('John'))            # Hello John, how do you do?
# wrapper_wrapper()
