from myutil import *

# Before signing the message must be prepared as
#  signable message defined by EIP-191.
from eth_account.messages import encode_defunct
from eth_utils.curried import to_hex, to_bytes
def signable_msg():
    msg = "hello"
    sm = encode_defunct(text=msg)
    print(sm.body)              # bytes (array of bytes).
    print(to_hex(sm.body))
    print(sm.body.decode())     # bytes to str.
##signable_msg()

# Sign and verify a message: (using 'Account')
from eth_account import Account
def sign_verify():
    # Create an account of the signer.
    a = Account.create('john')
    print(a.address)

    # Message to be signed.
    msg = 'Hello how do you do?'
    signable_msg = encode_defunct(text=msg)

    # Sign message with the signer's private key    
    signed_msg = Account.sign_message(signable_msg, a.key)
##    print(signed_msg)

    # A signed message contains its signature.
    sig = signed_msg.signature
    print(to_hex(sig))

    # Recover the signer address from msg and sig.
    ac = Account.recover_message(encode_defunct(text=msg), signature=sig)
    print(ac)

    # A signed message also contains its message hash
    #  which is using less space than the message.
    msg_hash = signed_msg.messageHash
    print(to_hex(msg_hash))

    # Alternatively we can recover the signer address
    #  from its message hash instead of the message.
    ac = Account.recoverHash(msg_hash, signature=sig)
    print(ac)   
##sign_verify()

def fail_verify():
    a = Account.create('john')
    msg = 'Hello how do you do?'
    signable_msg = encode_defunct(text=msg)
    signed_msg = Account.sign_message(signable_msg, a.key)
    addr = Account.recover_message(encode_defunct(text=msg), \
                     signature=signed_msg.signature)
    
    # 1. The message was tampered.
##    msg = 'Hello how do you do.'
##    addr = Account.recover_message(encode_defunct(text=msg), \
##                     signature=signed_msg.signature)
    
    # 2. The message was signed with different private key.
##    signed_msg = Account.sign_message(signable_msg,
##                     Account.create('jack').key)
##    addr = Account.recover_message(signable_msg, \
##                     signature=signed_msg.signature)
    
    print(a.address == addr)
##fail_verify()
