from myutil import *
from eth_utils.curried import to_hex

def infura_info():
    print(w3.clientVersion) # Geth ....
    print(w3.eth.chainId)   # 4
    print(w3.eth.mining)    # False
    print(w3.eth.get_block('latest').number)
##infura_info()

# Infura is not a wallet.
##print(w3.eth.accounts)  # []    

# Infura allows creating owa but not iwa.
def create_account():
    a1 = w3.eth.account.create('This is a seed.')
    print(to_hex(a1._private_key))
    print(a1._address)
    
    # 'personal' package is not supported.
##    a2 = w3.geth.personal.new_account('john') # error
##create_account()    # Try: list accounts again.

def get_me_balance():  # 'me' account from metamask.
    me_addr = '0x16c25A4cb42906a367Cce89043f3e39F9f892eb0'
    print(w3.eth.get_balance(me_addr))
##get_me_balance()
