from web3 import Web3

URL = "https://rinkeby.infura.io/v3/1c33caf701824d43882200b69d5e0849"
w3 = Web3(Web3.HTTPProvider(URL))

from web3.middleware import geth_poa_middleware
w3.middleware_onion.inject(geth_poa_middleware, layer=0)

import json
def print_json(ad): # AttributeDict
   st = w3.toJSON(ad)   # str
   js = json.loads(st)
   print(json.dumps(js, indent=4, sort_keys=True))
   
