from myutil import *
from eth_utils.curried import to_hex

def oeth_info():
    print(w3.clientVersion) # OpenEthereum
    print(w3.eth.chainId)   # 4
    print(w3.eth.mining)    # True
    print(w3.eth.get_block('latest').number)
##oeth_info()

# Openethereum can perform a wallet, which stores and manage user accounts.
# List accounts:
##print(w3.eth.accounts)

# Off Wallet Account(owa): not managed by the wallets.
# An account contains private key and address.
def create_owa(): # Always return a new account.
    a = w3.eth.account.create('This is a seed, not password.')
    print(to_hex(a._private_key))
    print(a._address)
##create_owa()          # Try: list accounts again.

# Alternatively an owa can be created using Account.
from eth_account import Account
def alt_create_owa(): # Not needs to request the provider.
    a = Account.create('john')  # 'john' is the account password.
    print(to_hex(a.privateKey)) # Or just 'key'
    print(a.address)
##alt_create_owa()       # Try: list accounts again.

# In Wallet Account(iwa): with the account password.
def create_iwa(pwd):
    print(w3.geth.personal.new_account(pwd))
##create_iwa('jack')
# The address is returned, the private key is stored in the wallet.
# A key file is created at:
# ....\AppData\Roaming\OpenEthereum\keys\rinkeby

# A private key can be retrieved from a key file,
#  if the password is known.
def retrieve_privatekey():
    key_dir = 'C:/Users/THAIMART/AppData/Roaming/OpenEthereum/keys/rinkeby'
    key_file = '/UTC--2022-04-04T05-10-38Z--6b7934c6-f70a-ac52-1095-65f06d54e16f'
    with open(key_dir+key_file) as f:
##        prikey = w3.eth.account.decrypt(f.read(), 'jack')
        prikey = Account.decrypt(f.read(), 'jack')
        print(to_hex(prikey))
##retrieve_privatekey()
# For accounts created in Metamask, their private keys can be exported.

# Addresses are used for balance checking.
def get_balance():  # 'me' account in Metamask.
    me_addr = '0x16c25A4cb42906a367Cce89043f3e39F9f892eb0'
    print(w3.eth.get_balance(me_addr)) # Openethereum must complete syncing.
    owa_addr = '0x892Fc50B1D07EA82C978f40BC0e66039F4292357'
    print(w3.eth.get_balance(owa_addr))
    jack_addr = '0x83eFF7607721E777b9fbb337E25ddE28415DaC8d'
    print(w3.eth.get_balance(jack_addr))
##get_balance()
