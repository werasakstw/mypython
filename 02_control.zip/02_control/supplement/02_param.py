''' Type Annotations:
Since the first release of Python 3 there type meta information for:
        - parameter type which follows :
        - return type    which follows ->
They are just the hints, no effect to the codes.
Compilers do not perform any type checking nor enforcement. '''
def type_anno(x: int, y: float) -> str:
    return x + y
# print(type_anno(1.0, 2))        ## 3.0

''' Type annotations are mostly types(e.g. int and str)
  but variable names and expressions are allowed. '''
john = 'John Rambo'
def f(x: john, y: 'int > 0' = 1):
    pass
# f('Jack', -1)

''' Parameter Passing Mechanism
There are different interpretations of 'pass by reference'.
Python parameter passing is called 'pass by sharing' which means
  the argument and parameter are alias.
We need to concern only whether the arguments have side effect.
If the arguments are immutable, there will have no side effect.
If the arguments are mutable, there can be side effect.
If side effect is not desirable, the mutable arguments must be copied
  and pass the other copy.     '''
def sharing_pass():
    def f(x, y):
        x += y
        return x

    a, b = 1, 2           ##  int is immutable.
    print(f(a, b), a, b)    ##  3 1 2

    a, b = 'a', 'b'       ##  str is immutable.
    print(f(a, b), a, b)    ##  ab a b

    a, b = (1, 2), (3, 4) ##  tuple is immutable.
    print(f(a, b), a, b)    #  (1, 2, 3, 4) (1, 2) (3, 4)

    a, b = [1, 2], [3, 4] ##  list is mutable.
    print(f(a, b), a, b)    #  [1, 2, 3, 4] [1, 2, 3, 4] [3, 4]
# sharing_pass()

''' Python supports two kinds of argument passing.   '''
def arg_passing():
    def f(name, password):
        print(name, password)

    '''  Positional Arguments.  '''
    f('John', 'hello')

    '''  Keyword(or Named) Arguments.  '''
    f(password='123', name='Jack')
# arg_passing()

''' 'Default Parameters' are parameters with default values.
If no argument passed to, the parameter assumes the default. '''
def default_param():
    def f(x, y = 0):
        print(x, y)

    f(1)            #  1 0
    f(1, 2)         #  1 2

    ## Default parameters must defined from the right most to left.
    def f1(a = 1, b = 1, c = 1): pass
    def f2(a, b = 1, c = 1): pass
    def f3(a, b, c = 1): pass
    # def f4(a = 1, b, c = 1): pass     ## error:
    # def f5(a = 1, b = 1, c): pass     ## error:
# default_param()

''' Positional and keyword arguments can be mixed but the
  positional ones must come first.
And we need a way to specify which one will be positional or keyword. '''

''' Parameter Side:
A * parameter indicates the end of positional arguments
  after that will be keyword arguments.
A * paramater is a marker and has no value. '''
def one_star_param():
    def f(x = 0, *, a = 1, b = 2):
        print(x, a, b)

    f()                  	##  0, 1, 2
    f(3)                  	##  3, 1, 2
    # f(1, 2)             	##  error
    f(1, a = 10, b = 20)    ##  1 10 20
    f(a = 10, b = 20)     	##  0, 10, 20
    # f(10, b = 20)         ##  error
# one_star_param()

''' Variable Length Arguments (Var-Arg): is a mechanism that allows
  passing any number of arguments to a function.
A *<param> that indicates that arguments are collected into a tuple
  and passed to the <param>.
A var_arg can be mixed with positional, but must be the rightmost.
Parameters before the var_arg are required.  '''
def vararg():
    def f(a, *n):   ## 'a' is required, n is a tuple.
        print(a, n)

    # f()                ##  error
    f(1)                 ##  1 ()
    f(1, 2)              ##  1 (2,)
    f(1, 2, 3)           ##  1 (2, 3)
# vararg()

''' Two stars, **<param> indicates that the <param> is a dict
  that is collected from keyword arguments.  '''
def two_star_param():
    def f(**d):
        print(d)

    f()              ##  {}
    f(a=1)           ##  {'a': 1}
    f(a=1, b=2)      ##  {'a': 1, 'b': 2}
# two_star_param()

''' Positional, *<param> and **<param> can be mixed, by convention:
         *args    is tuple of positional arguments.
         **kwargs is dictionary of keyword arguments. '''
def mix_params():
    def f(a, *args, **kwargs):
        print(a, args, kwargs)

    # f()               ##  error
    f(1)                ##  1 () {}
    f(1, 2)             ##  1 (2,) {}
    f(1, 2, b = 3)      ##  1 (2,) {'b': 3}
    f(1, b = 2)         ##  1 () {'b': 2}
    # f(1, a = 2, 3)    ##  error: keyword parameters must be right most

    ''' It is easier to strict to a pattern. '''
    f('hello')              ## hello () {}
    f('hello', 1)           ## hello (1,) {}
    f('hello', 1, 2)        ## hello (1, 2) {}
    f('hello', 1, 2, x=3)   ## hello (1, 2) {'x': 3}
# mix_params()

#-----------------------------------------------------------------------

''' Argument Side:
*<arg> indicates that the <arg> is unpacked and passed to the correspond parameters.
The <arg> may be list, tuple, set or dict. '''
def arg_unpack():
    def f(x, y, z):
        print(x, y, z)

    a = [1, 2, 3]
    f(*a)                      ## 1 2 3

    ''' The arguments and parameters must be equal in number.  '''
    # f(*[1, 2])              ## error
    # f(*[1, 2, 3, 4])        ## error

    ''' If the argument is a dict, only the keys are passed. '''
    f(*{'a': 1, 'b': 2, 'c': 3})   # a b c

    '''  *<arg> can be passed to a *<param>.  '''
    def ff(a, *p):
        print(a, p)
    ff(*[1, 2])             # 1 (2,)
# arg_unpack()

''' **<arg> indicates that the <arg> is a dict and passed as keyword arguments. '''
def arg_keyword():
    def f(x, y):
        print(x, y)

    ''' Keyword arguments are acceptable.  '''
    f(y = 1, x = 2)         # 1 2

    ''' **<arg> allows passing dict as argument. '''
    d = {'y': 4, 'x': 3}  ## Number of elements must correspond to parameters.
    f(**d)                  # 3 4

    '''  **<arg> and keyword arguments can be passed to **<param>. '''
    def ff(**p):
        print(p)
    ff(**{'y': 1, 'x': 2})      # {'y': 1, 'x': 2}
    ff(x = 3)                   # {'x': 3}
arg_keyword()

''' Using * and ** at both sides indicates the argument go to tuple or dict.
And allows var-args for both positional and keyword arguments. '''
def args_kwargs():
    ''' This is a very popular paramater pattern. '''
    def f(*args, **kwargs):
        print(args, kwargs)

    a = [1, 2]
    d = {'x': 3, 'y': 4}
    f(a)          #  ([1, 2],) {}
    f(*a)         #  (1, 2) {}
    f(d)          #  ({'x': 3, 'y': 4},) {}
    f(*d)         #  ('x', 'y') {}
    f(**d)        #  () {'x': 3, 'y': 4}
    f(a, d)       #  ([1, 2], {'x': 3, 'y': 4}) {}
    f(*a, **d)    #  (1, 2) {'x': 3, 'y': 4}
# args_kwargs()
