''' Python implements a scope using a dict which is a very efficient approach.
The collection of names defined in a scope is called a 'namespace'.
Python creates scopes dynamically(at runtime) when the scope is entered.
Python provides two built-in functions to access namespace:
   globals() returns the dict of global namespace.
   locals() returns the dict of local namespace.     '''
def np_dict():  ## There is an 'x' bound to global namespace.
    x = 2       ##  bound to local namespace
    print(list(locals().keys()))
    print(list(globals().keys()))
# np_dict()

''' Python supports expression evaluation with provided global and local namespace.
             eval(expression, globals=None, locals=None)     '''
def eval_test():
    y = 2
    print(eval('x+y', globals(), locals()))     #  3
# eval_test()

''' dir() and vars() show names in the current namespace.
dir(<namespace>) and vars(<namespace>) show names inherited to the <namespace>.
dir() shows as a list. vars() shows as a dict.    '''
def dir_vars():
    x = 1
    def f():
        y = 2
        print(dir())    ##  ['y']
        # print(dir(f))

    class C:
        pass

    print(dir())        ##  ['C', 'f', 'x']
    print(vars())
    f()

    print(dir(dir_vars))
# dir_vars()
#----------------------------------------------------------------

''' '__builtins__' object contains all built-in names, that
       can be used without importing. '''
# print(dir(__builtins__))

''' In any programs, the following namespaces are always available.
    - builtin namespace, created when the compiler starts.
    - global namespace, created when the module(file) is loaded.
    - outer scope namespaces (if any).
    - local namespace, created when the local scope is entered.

The compiler searches the name in the order:
                local, outer, global and builtin.
    If not found, an exception is raised.  '''
g = 1
def name_search():
    o = 2
    def f():
        l = 3
        print(l, o, g, len([]))
    f()
# name_search()

''' Accessing global names take longer time than accessing local names. '''
x = 1
def sum_x():
    global x
    for i in range(100000):
        x += i
    return x
def sum_y():
    y = 1
    for i in range(100000):
        y += i
    return y
def time_test():
    import time
    start = time.perf_counter()
    print(sum_x())
    stop = time.perf_counter()
    print(stop - start)

    start = time.perf_counter()
    print(sum_y())
    stop = time.perf_counter()
    print(stop - start)
# time_test()
