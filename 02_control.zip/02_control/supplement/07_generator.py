﻿'''
'for' loop is 'lazy' in the sense that elements are retrieved and
  processed one at a time then the the results are collected or as effect.
  Ex. A line in a file may be read and processed one at a time.

'comprehension' is 'eager', that means all elements are retrieved, processed
 and collected as a 'whole' then the result is returned.
There are many cases that 'as a whole' is more efficent.
   Ex. Processing all elements in an array as a whole is better than one at a time.

But processing a large file as a whole requires a lot of memory so there are
  cases that 'one at a time' is a better choice.

A 'generator' is an object/function that returns elements one at a time,
 that allows 'lazy' processing.

When a function 'return' a value, its execution terminates.
If a function 'yield' a value, it does not terminate.
The function will resumes if the caller calls next().
The pause/resume may repeated as many times as there is a statement
 to continue, unless the functon terminates.
If there is no next value to be yielded, a 'StopIteration' error is
 raised. There is no ways to check before hand.

Ex. range() is an iterable (not a generator),
    iter(<iterable>) returns an iterator which can be used as a generator. '''
def iter_test():
    r = range(3)        ## range
    g = iter(r)         ## generator
    try:
        while True:
            print(next(g), end=', ')
    except StopIteration:
        print('Stop')           ## 0, 1, 2, Stop

    ''' Processing a generator needs a lot of work, Python simplifies the tasks
          with 'for' and 'comprehension'. '''
    for i in iter(r):
        print(i, end=', ')       ## 0, 1, 2,
    print()
    print([i for i in iter(r)])  ## [0, 1, 2]
# iter_test()

''' A functions that 'yield' is called 'function generator'.
A function generator creates and yields one element at a time without
  destroy and recreate its namespace, but just suspend and resume.  '''
def my_generator(start, stop, step=1):
    i = start
    while i < stop:
        yield i
        i += step

def my_generator_test():
    g = my_generator(0, 3)
    try:
        while True:
            print(next(g), end=', ')
    except StopIteration:
        print('Stop')           ## 0, 1, 2, Stop

    ''' After a generator had been iterated, it is run out of elements. '''
    print([i for i in g])       ## [ ]

    ''' Calling a function generator returns a new generator object. '''
    print([i for i in my_generator(0, 3)])  # [0, 1, 2]
# my_generator_test()

''' Instead of creating a 'generator' with function that 'yield', Python provides
  an alternative for creating a 'generator' with comprehension.
Comprehension that surrounded with [ ] returns a list.
                       surrounded with { } returns a set or dict.
                   but surrounded with ( ) returns a generator. '''
def comprehension_generator():
    g = (x for x in range(3))
    print(type(g))          ##  <class 'generator'>
    print([x for x in g])   ##  [0, 1, 2]
# comprehension_generator()

''' Function Generator VS Comprehension Generator
  Comprehension generators are more compact but the run-out cannot be reused.
  Function generators create new a generator for each calls. '''
def nest_iteration():
    ''' Function generators are more convenient in nested iteration. '''
    print([(x, y) for x in my_generator(0, 2)
                  for y in my_generator(0, 2)])
                            ##  [(0, 0), (0, 1), (1, 0), (1, 1)]

    ''' Reusing comprehension generator in nested iteration is an error. '''
    g = (i for i in [0, 1])
    print([(x, y) for x in g
                  for y in g])	   # #  [(0, 1)]
# nest_iteration()

''' Lazy VS Eager '''
def lazy_eager():
    def gen():
        print('one', end=',')
        yield 1
        print('two', end=',')
        yield 2

    ''' 'for' loops lazyly request an item and process one at a time. '''
    for i in gen():
        print(i, end=',')       ##  one,1,two,2,
    print()

    ''' Comprehension eagerly creates all elements and returns as a whole. '''
    c = [i for i in gen()]      ##  one,two
    print(c)                    ##  [1, 2]
# lazy_eager()

''' yield from <generator|iterator>
        is the same as:
    for x in <generator|iterator>:
        yield x         '''
def yield_from():
    def gen1():
        yield 0
        yield 1
        yield 2

    print([x for x in gen1()])      ## [0, 1, 2]

    ''' 'yield from' simplifies creating generator from
           range(), collection or generator. '''
    def gen2():
        yield from range(3)     ## 'yield' must be in a function.
        # yield from [0,1,2]
        # # yield from (0,1,2)
        # # yield from (x for x in range(3))
    print([x for x in gen2()])      ## [0, 1, 2]
# yield_from()

''' Lazy is more memory effective.
But eager is more efficent if a lot of elements are created at once.

Ex.Factorial:
           fac(n) = 1*2*3*...(n-1)*n
To create a list of 10 factorials.  '''
def facorial():
    '''  This factorial function starts over from 1 every time. '''
    def fac(n):
        r = 1
        for i in range(2, n+1):
            r *= i
        return r

    print([fac(n) for n in range(10)])
        ## [1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880]

    ''' Factorial Generator can compute a result from the previous calls. '''
    def fac_gen(max):   ## 'max' is the maximum number of factorials to be created.
        r, i = 1, 0
        while i < max:
            i += 1
            yield r
            r *= i
    print([f for f in fac_gen(10)])
        ## [1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880]
# facorial()

''' Function Generators may be stateful, which means the function
      may remember its state between calls.
Python functions are stateful.

Ex. To generate a sequence of 10 non repeated random numbers.
The generator may keep a set of already generated numbers. '''
import random
def random_generator():
    def ran_gen(n):
        s = set()
        while len(s) < n:
            r = random.randint(1, n)
            if r not in s:
                s.add(r)
                yield r

    print([n for n in ran_gen(10)])
# random_generator()

#---------------------------------------------------------------

''' 'Coroutine' is a function with
               <variable> = yield <expression>
When a coroutine function is called, it suspends the execution.
Until when the caller call next(<coroutine function>), the coroutine
  function resumes and proceeds to the first 'yield', this is called
  'priming', and returns the value of <expression> then waits.
The caller receives the yielded value and process.
Then when the caller calls <coroutine function>.send(<value>), the
  coroutine function resumes and the sent <value> is assigned to the
  waiting <variable> then processes.
Calling send() when there is no next 'yield' will raise a StopIteration. '''
def my_coroutine():
    print('start')
    x = yield 1
    print('x = ', x)
    y = yield 2
    print('y = ', y)

def my_coroutine_test():
    try:
        c = my_coroutine()         ## No execution yet.
        print(next(c))             ## 'start'    proceeds to the first 'yield'
                                   ## 1
        print(c.send('hello'))     ## x =  hello
                                   ## 2
        print(c.send('hi'))        ## y =  hi
    except StopIteration as e:
        print('Stop')              ## 'Stop'
# my_coroutine_test()

''' A coroutine may be stopped before elements run-out,
  when the caller calls close() on its object. '''
def close_test():
    c = my_coroutine()
    print(next(c))              #  start
                                #  1
    print(c.send('hello'))      #  x =  hello
                                #  2
    c.close()
# close_test()

''' Generators can send data to the caller only.
    Coroutines may send data both ways.  '''
def both_ways():
    ''' An infinite coroutine is implemented by yielding in a 'while' True loop.
    A coroutine may stop itself by yielding as the last statement.
    Ex. An infinite sequence coroutine. '''
    def inc(first=0):
        n = first
        while True:
            cmd = yield n
            if cmd == 'stop':
                break
            n += 1
        yield None

    ''' Caller '''
    s = inc()
    i = next(s)             ##  Priming.
    while True:
        if i >= 10:
            s.send('stop')
            break
        print(i, end=',')
        i = s.send('more')  ## 0,1,2,3,4,5,6,7,8,9
# both_ways()
