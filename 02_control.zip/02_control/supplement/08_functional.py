''' A python functions is an objects of <class 'function'>. '''
def function_object():
    def f():
        '''function doc string'''
        print('Hello')
    print(type(f))      ## <class 'function'>
    ''' A function is represented as a 'function object' of <class 'function'>. '''

    ''' A 'function object' has a dict for its namespace. '''
    print(f.__dict__)   ## {}

    ''' A python function is stateful, that means it may contain state between calls. '''
    f.x = 1
    print(f.__dict__)   ## {'x': 1}

    ''' A 'function object' has the following special attributes. '''
    print(f.__name__)   ## f
    print(f.__doc__)    ## function doc string
    print(f.__class__)  ## <class 'function'>    same as type(<func>)
    print(f.__code__)   ## 'code object' that represents program of the function.
# function_object()

''' A function local variable holds its state during the function activation.
A 'function object' holds its state during the object lifetime, that means
  its state is persist between successive calls.  '''
def stateful_func():
    def inc():
        if 'c' not in inc.__dict__:
            inc.c = 0
        inc.c += 1            ## inc.c is a state of inc().
        return inc.c

    print([inc() for _ in range(3)])       # [1, 2, 3]
# stateful_func()

''' An object of any classes is 'callable' if it has __call__().
That allows callng an object like a function. '''
def callable_obj():
    class A:
        def __call__(self, name):
            print('Hello', name)

    ''' () is the 'call' operator.
    If () is applied to a class, the meta-class's __call__() is invoked
      and the created object of the class is returned. '''
    a = A()

    ''' If () is applied to a callable object, its __call__() is invoked. '''
    a('John')                           ## Hello John

    ''' callable(<obj>) is built-in function for testing if <obj> is callable. '''
    print(callable(A), callable(a))     ## True True
# callable_obj()

#-----------------------------------------------------------------

''' A function is 'first class' object if:
      1. Created dynamically at runtime.
      2. Assignable to variable or storage.
      3. Passed to/from functions.
Languages that support 'first class' object is called 'functional' languages.
Ex. Assign a function to a variable.     '''
def assign_func():
    def hello():
        print('Hello')
    greet = hello
    greet()
# assign_func()         ## Hello

''' Ex. A function that returns a function. '''
def get_hello():
    def hello():
        print('Hello')
    return hello
# get_hello()()         ## Hello

''' A functional may return an inner function to be used outside.
If a returned function refers to objects in outer scope, the object
 must be copied to go with the function, this is called 'capturing'.
A function with its captured objects is called 'closure'. '''
def get_closure(name):
    msg = 'Hello '
    def hello():
        return msg + name
    return hello
# print(get_closure('John')())

''' Since a closure may be returned to many callers.
Most languages e.g. Java have restriction that closure state must be immutable.
But Python allows mutable closure states. '''
def get_counter():
    x = 0
    def counter():
        nonlocal x
        x += 1
        return x

    return counter
c = get_counter()
# print(c(), c())                           ## 1 2
''' Each calls to the function returns a new closure. '''
# print(get_counter()(), get_counter()())   ## 1 1

#---------------------------------------------------------------------

''' Callable objects can be created with fixed state to simplify using the objects. '''
def callable_obj():
    class Greet:
        def __init__(self, msg):
            self.msg = msg

        def __call__(self, name):
            return self.msg + ' ' + name
            ## Returns a callable greet with fix 'msg'.

    hello = Greet('Hello')
    print(hello('John'))          ## Hello John

    hi = Greet('Hi')
    print(hi('Jack'))             ## Hi Jack
# callable_obj()

''' 'Partial functions' are created from another function with some
  parameters/states are fixed as default.
That allows calling to the function without the fixed parameters.
'functools' lib has partial() for creating a partial function from
  an already defined function. '''
import functools
def partial_func():
    def add(a, b):
        return a + b

    ''' Only the right most parameters may have default values. '''
    add_one = functools.partial(add, b=1)   ## 'b' parameter is fixed.
    add_two = functools.partial(add, b=2)
    print(add_one(1), add_two(1))           ## 2 3
# partial_func()

''' 'operator' lib defines a lot of ready to use operators. '''
import operator
# print(dir(operator))

''' Ex. 'mul' is for multiplication. '''
# print(operator.mul(2, 3))       ## 6

''' Ex. A partial function for multiply by 3.  '''
triple = functools.partial(operator.mul, 3)
# print(triple(2))                ## 6

#----------------------------------------------------------------

''' A 'decorator' is a functional that accepts a function as parameter
     and returns a modified function as result.  '''
def decorator_test():
    ''' Ex. To add an extra line to the doc string of a function. '''
    def written_by_john(f):
        f.__doc__ += '\nWritten by: John.'
        return f

    ## 1. Manually implemented decorator, (performed at runtime).
    def hello():
        '''Return: Hello'''
        print('Hello')
    hello = written_by_john(hello)
    print(hello.__doc__)        ## Return: Hello
                                ## Written by: John.

    ''' 2.@<decorator> adds the <decorator> to the function below.
    It is performed when the function is created.
    There can be multiple decorators applied, the lowest is the first. '''
    @written_by_john
    def hi():
       '''Return: Hi'''
       return 'Hi!'
    print(hi.__doc__)           ## Return: Hi
                                ## Written by: John.
# decorator_test()

''' A decorator may add parameters to the function, using function wrapper. '''
def func_wrap():
    def add_param(func):
        def _f(name):
            return func() + ' ' + name
        return _f

    @add_param
    def hello():
        return 'Hello'

    print(hello('John'))       # Hello John
# func_wrap()

''' A decorator may has parameters by using function wrapper wrapper. '''
def wrapper_wrapper():
    def add(msg):
        def __f(func):
            def _f(name):
                return func() + ' ' + name + ', ' + msg
            return _f
        return __f

    @add('how do you do?')
    def hello():
        return 'Hello'

    print(hello('John'))            # Hello John, how do you do?
# wrapper_wrapper()
