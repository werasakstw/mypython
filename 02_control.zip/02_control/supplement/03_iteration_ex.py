''' Beautiful Math:
Working with math would be pleasurable if we do not need to do math.

Ex. Multiply some specific numbers with 1 to 9.   '''
def mul(n):
    for i in range(1, 10):
        print('%6d' % (n * i))
# mul(1099)
''' Try: 89, 99, 108, 109, 898, 899, 1089, 1099, 10889, 10899, 108899, ....  '''

''' Ex. Mutiply 37 with numbers that are multiple of 3 for all below 100. '''
def mul_of3():
    for i in range(3, 100, 3):
        print('37 x %2d = %10d' % (i, 37 * i))
# mul_of3()

''' Exercises:
Write a program to multiple 142857 with numbers that are multiple of 7, below 100. '''

#------------------------------------------------------------------

''' Optimization: is the process of finding the best value for some situation.

Ex. Archimedes introduced 22/7 as a Pi approximation which is only 2 digits
  correct, but why this approximation is the most popular?  '''
# print(22/7)                 ## 3.142857142857143

''' 'math' lib provides Pi constant which is correct to 15 digits.  '''
# print(math.pi)              ## 3.141592653589793

''' Ex. Find the best Pi approximation using fraction of two integers under 100. '''
def pi_approx(m):
    x, y, c = 0, 0, 1
    for a in range(1, m):
        for b in range(1, m):
            d = a/b - math.pi
            d = d if d > 0 else -d
            if d < c:
                x, y, c = a, b, d
    print("%d / %d" % (x , y))
# pi_approx(100)                  ## 22 / 7

''' Exercise:
Find the best Pi approximation using a fraction of two integers under 1000 and 10000.
The result was found by Tsu-ching Chih(480 AD).   '''

#-------------------------------------------------------------------------------

''' Non-deterministic Loop Example:
Ex. Printing an integer in reverse digit order.
We use 'while' loop since the integer may be any digits number.  '''
def rev_digits(n):
    while n > 0:
        print(n % 10, end=',')
        n //= 10
    print()
# rev_digits(1234)          ##  4,3,2,1,

''' Ex. Digit Sum: Let dsum(n) be the sum of all digits in n, where n > 0.
Suppose n is an n digits integer.
                dsum(n) = a + b + c + ... + n.   '''
def dsum(n):
    s = 0
    while n > 0:
        s += n % 10
        n //= 10
    return s
# print(dsum(1234567890))     ## 45

''' Recursion is a approach of doing something repeatedly by a function calls
      to itself with different parameters.
Ex. Recursive Digit Sum '''
def dsumR(n):
    if n < 10:
        return n
    return (n % 10) + dsumR(n // 10)
# print(dsumR(1234567890))    ## 45

''' Ex. Digital Root: of a number is computed by applying dsum() repeatedly
  until the result is one digit.   '''
def droot(n):
    while True:
        n = dsum(n)
        if n < 10:
            return n
# print(droot(1234567890))    # 9

''' Exercises: Write a program to verify that for all numbers below 1_000_000
   that are multiple of 9 have digital root equal to 9. '''

''' Ex. Integer Reversal: is the reversed sequence of digits in a number.
        e.g    rev(123) = 321       '''
def rev(n):
    x, m = 0, n
    while m > 0:
        x *= 10
        x += m % 10
        m //= 10
    return x
# print(rev(123))     # 321

''' Ex. Palindrom: A positive interger n is a palindrom if n == rev(n).
Excluded single digit numbers e.g. 1, 2, 3, ..., 9 and
  numbers that contain only one digit e.g. 11, 111, 222....    '''
def is_one_digit(n):
    d = set()    # Sets do not allow duplicate members.
    while n > 0:
        d.add(n % 10)
        n //= 10
    return len(d) == 1
# print(is_one_digit(2))          # True
# print(is_one_digit(11))         # True
# print(is_one_digit(12))         # False

def is_palindrom(n):
    if n < 10 or is_one_digit(n):
        return False
    return n == rev(n)
''' Find palindroms less than 1000. '''
# print([ n for n in range(1000) if is_palindrom(n)])

''' Exercises: Find a, b, and c that are palindroms below 10_000
  where a != b != c such that
      1. a * b = c
      2. a**2 * b**2 = c      '''

''' Ex. Greatest Common Divisor (gcd):
          gcd(m, n) = g
If g is the largest integer such that m % g == 0   and n % g == 0   '''
def gcd(m, n):
    g = m if m < n else n    ## g is the smaller of m and n.
    while g > 1 and not((m % g == 0) and (n % g == 0)):
        g -= 1
    return g
# print(gcd(34, 425))         ## 17

''' Ex. Euclid propsed an algorithm for finding gcd.
Probably the oldest algorithm ever recorded.  '''
def euclid_gcd(m, n):
    r = m % n
    while r > 0:
        m = n
        n = r
        r = m % n
    return n
# print(euclid_gcd(34, 425))        ## 17

#---------------------------------------------------------------------------

''' Approximation:
There are mathematical methods that the more rounds we compute,
   the result will be more accurate.
These methods are good to compute something that hard to do directly.
The results will not be exact but it is simpler to compute and
  we can stop when it is good enough.

Ex. The Newton's Square Root method:
                        sqrt(n) ~ (n/g + g)/2
        where g is a good guess.
If the result is not good enough, use the result as g in the next iteration.
Suppose n is 10.
1. The guess may be anything less than n, a blind guess is the halve of n.
                g = 10/2 = 5
2. Compute next g = (10/5 + 5)/2 = 3.5
3. g is not good enough then repeat
                g = (10/3.5 + 3.5)/2  =  3.178571428571429
                .....
          Stop when satisfied.        '''
import math
def newton_sqrt(n):
    def _sqrt(n, r):
        g = n / 2
        for i in range(r):    ## Performs r rounds.
            g = (n/g + g)/2;
        return g

    def is_good_enough(s):  ## Compare to math.sqrt()
        return math.fabs(sq-s) < 0.0001

    r = 1
    sq = math.sqrt(n)
    while True:
        s = _sqrt(n, r)
        print('%d, %r:\t%.3f' % (n, r, s))
        if is_good_enough(s):
            break
        r += 1
# newton_sqrt(21)

''' Exercises:
1. Compare the Newton square root with Python's math.sqrt() for n < 100.
2. For n up to 1000, how many rounds the newton_sqrt() have to perform
   to get results that good to the fourth decimal position.   '''

#-------------------------------------------------------------------------

''' Convolution:
There are mathematical series that if we compute to infinity terms
   the result will go toward a value, that is 'convolution'.
A program cannot compute to infinity, but we can stop when it is
  good enough or we notice the result is going to some value.

Ex. Let show that   1/2 + 1/4 + 1/8 + 1/16 + ..... = 1       '''
def convolution():
    def _sum(n):     ## Summation of 1 / (2**x) to the n term.
        s = 0
        for x in range(1, n):
            s += 1 / (2**x)
        return s

    def is_good_enough(s):  ## Close to 1.
        return math.fabs(s-1.0) < 0.00001

    n = 1
    while True:
        s = _sum(n)
        print('%2d: %.7f' % (n, s))
        if is_good_enough(s):
            break
        n += 1
# convolution()         ## 45: 0.999999999999943

''' Ex. Francois Viete(1592) introduced an infinite serie for Pi.
  Pi = 2 * (2/sqrt(2)) * (2/sqrt(2+sqrt(2))) * (2/sqrt(2+sqrt(2+sqrt(2)))) * ...   '''
def viete_pi(n):
    s, t = 2.0, 0.0
    for i in range(2, n+2):
        t = math.sqrt(2+t)
        s *= 2/t
    return s
# print(viete_pi(10))     ## 3.1415914215112
''' In 10 rounds(n = 10) the result is correct to 5 digits, but needs sqrt(). '''

''' Ex. John Wallis(1616): simplified the serie to:
     Pi/2 = (2*2)/(1*3) * (4*4)/(3*5) * (6*6)/(5*7) * ....       '''
def wallis_pi(n):
    s = 1.0
    for i in range(1, n+1):
        s *= ((2.0*i)*(2.0*i))/((2.0*i-1)*(2.0*i+1))
    return 2*s
# print(wallis_pi(1000))    ## 3.140807746030402
''' The serie is simpler but 1000 rounds just give 2 digits correct. '''

''' Exercise:  Write programs for the following Pi series:
1. Leibniz(1646) proposed a surprisingly beautiful serie.
        Pi = 4(1 - 1/3 + 1/5 - 1/7 ....)
2. Euler(1707) proposed probably the most beautiful Pi serie ever.
        Pi**2 = 6(1 + 1/2**2 + 1/3**2 + 1/4**2 +...)   '''

''' Since the computer era there are a lot of algorithms for computing Pi.
Quick Pi: an algorithm that produces a good Pi with less iterations. '''
def quick_pi(n):
    a = 1
    b = 1 / math.sqrt(2)
    c = 1 / 4
    x = 1
    for i in range(n):      ## 'n' is the number of rounds.
        y = a
        a = (a + b) / 2
        b = math.sqrt(b*y)
        c -= x * ((a-y) ** 2)
        x *= 2
    return ((a+b)**2) / (4*c)
# print(quick_pi(3))              ## 3.141592653589794
''' Just 3 rounds the result is 14 digits correct. '''

''' David Bailey, Peter Borwein and Simon Plouffe:
   Pi = sum(n=0,inf)( 4/(8*n+1) - 2/(8*n+4) - 1/(8*n+5) - 1/(8*n+6) ) / 16**n
Python represents a float using 8 bytes so the decimal points is valid up
  to approximately 15 position.  '''
def dps_pi(n):
    s = 0.0
    for i in range(n):  ## Increasing n would increase the precision.
        i8 = 8*i
        s += (4.0/(i8+1) - 2.0/(i8 +4) - 1.0/(i8+5) - 1.0/(i8+6)) / 16**i
    return s
# print(dps_pi(11))           ## 3.141592653589793 (15 digits correct)

''' Python has the 'Decimal' type for representing high precision floating points. '''
from decimal import Decimal, getcontext
def dps_pi1000():
    getcontext().prec = 1000  ## Set the precision to 1000 digits.
    s = Decimal(0.0)
    for i in range(1000):
        i8 = Decimal(8*i)
        s += (Decimal(4.0)/(i8+1) - Decimal(2.0)/(i8 +4) - Decimal(1.0)/(i8+5) - Decimal(1.0)/(i8+6)) / 16**i
    return s
# print(dps_pi1000())   ## The 1000 digits Pi.
