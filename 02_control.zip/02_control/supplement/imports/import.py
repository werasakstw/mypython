''' A Python module is a file.
The file name is the name of the module(and also its namespace).
A module may contain constants, variables(objects), functions
  and classes that are all defined as objects.

'import' statements allow using objects defined in modules.
Module in working directory are in the 'search path' which are importable.

Python has several import options.
   1.  import <module>
One or more <module> can be imported using , as seperater. '''
def import_mod():
    import my_mod      ## Allows locally import
    ''' The module name must be used to quantify referring to the objects. '''
    print(my_mod.x, my_mod.names)
    my_mod.hello()
    my_mod._hi()
    my_mod.A()
# import_mod()

''' 2.  import <module> as <other>
Allows referring <module> as <other>, which is usually shorter or more meaningful. '''
def import_as():
    import my_mod as m     ## Allows locally import
    print(m.x, m.names)
    m.hello()
    m._hi()
    m.A()
# import_as()

''' 3.  from <module> import <objects>
Allows referring to <object> without quantifing, that is called 'static import'.
One or more <object> can be imported using , as seperater. '''
def from_import():
    from my_mod import x, hello, _hi   ## Allows locally import
    print(x)
    hello()
    _hi()       ## Names that begin with _ can be imported.
# from_import()

''' 4.  from <module> import <object> as <other>
Allows directly referring as <other>.   '''
def from_import_as():
    from my_mod import hello as greet
    from my_mod import _hi as hi
    greet()
    hi()
# from_import_as()

''' 5. from <module> import *
Allows 'static import' all importable objects
Names that begin with _ are not importable in this form.
It is allowed only at the module level(not locally import).  '''
from my_mod import *
def from_import_star():
    print(x, names)
    hello()
    # _hi()         ## error
    A()
# from_import_star()

''' A name that begins with an _ is not local(or private to
  the module) since it can be imported normally as in from_import(). '''

''' For using with static import star, a module may define a tuple __all__
  to specify the names that can be referred to. e.g. mod_all.py '''
from my_mod_all import *
def all_test():
    print(john)
    # print(jack)     # error
    hello()
    # hi()            # error

    ''' __all__ does not make the unlisted names un-importable. '''
    import my_mod_all
    print(my_mod_all.jack)
    my_mod_all.hi()
# all_test()

#-----------------------------------------------------------

''' A Python 'package' is a directory, which is a collection of modules.
Packages allow organizing a lot of modules as directory.
Packages has different meaning in different languages, a more meaningful
  name is called 'lib' for library.

Importing a module in a package needs the path to the module
  starting from the search path.
Before Python 3.3, a package directory must have a file '__init__.py'
  to mark that it is a package but not for now. '''
def pack_import():
    ''' 1.  import <module path>            '''
    import my_lib.one.greet
    my_lib.one.greet.hello()
    my_lib.one.greet.hi()

    ''' 2. from <module path> import <name>   '''
    from my_lib.one.greet import hello
    hello()

    ''' 3.  from <module path> import <name> as <other>   '''
    from my_lib.one.greet import hi as h
    h()

    '''  4. from <package path> import <module>   '''
    from my_lib.one import greet
    greet.hello()
    greet.hi()
# pack_import()

''' 5. from <module path> import *
Allowed only at the module level.  '''
from my_lib.one.greet import *
def import_pack_star():
    hello()
    hi()
# import_pack_star()

#---------------------------------------------------------------

''' What happen when an 'import <module>' is executed:
    1. The module is loaded.
    2. The module's namespace is created as a dict and can be referred by __dict__.
    3. The module code is executed.
    4. Objects defined in the module are created and added to the dict.
So two modules may contain the same names, since created in different namespaces. '''
def np_dict():
    import my_mod  ## The namespace 'my_mod' is created and added to current namespace.
    print(dir())                ## ['my_mod']

    print(my_mod.__name__)      ## my_mod

    ''' A namespace is created as a __dict__ for storing names in the namespace. '''
    print(my_mod.__dict__.keys())
    # print(dir(my_mod))
# np_dict()

''' The module namespace is created once at the first import.
Reimporting an imported module does not create a new namespace. '''
def reimport():
    import my_mod
    print(my_mod.x)        #  1
    my_mod.x = 3

    import my_mod      ##  Reimport the same module.
    print(my_mod.x)        #  3

    ''' importlib.reload() allows reimporting to recreate new namespace. '''
    import importlib
    importlib.reload(my_mod)
    print(my_mod.x)
# reimport()

''' 'sys.path' is a list for searching imported module paths.
By default the sys.path is initialized as:
      - Working directory.
      - PYTHONPATH environment variable.
      - The installation dependent default.  '''
import sys
def search_path():
    for p in sys.path:
        print(p)
# search_path()

''' 'sys.path' is a mutable list.
That allows adding extra modules to be imported.
Suppose we want to import \my_lib\greet.  '''
def mod_path():
    ''' Get the current directory path. '''
    print(__file__)
    p = __file__.replace('\import.py', '')
    print(p)

    ''' Add to the search path '''
    sys.path.append(p + '\my_lib')
    import greet
    greet.hello()
# mod_path()

''' Modifying sys.path is not encouraged.
Since that makes search path vary from program to program and
  longer search path would make searching slow.
If 'my_lib' is in the search path, we should just import it. '''
def imp_my_lib():
    from my_lib import greet
    greet.hello()
# imp_my_lib()
