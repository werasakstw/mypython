''' 'Lambda' is a function with no names and defined as expressions.
            lambda <parameters> : <body>
A lambda may be invoked directly by applyed with arguments enclosed in ().
But to call the function again the lambda expression must be redefined.  '''
# (lambda name: print('Hello ' + name))('John')   ##  Hello John

''' Lambdas are primary used to avoid creating function names in the
  namespace e.g. passing lambdas as arguments to functions.
But lambda is a 'function object' which may be assigned to a name
   and be executed as many time as a function. '''
hello = lambda name: print('Hello ' + name) ## Lambda expression results a lambda.
# hello('Jack')            ## Hello Jack

''' A lambda may have no parameters.  '''
# print((lambda : 'Hello')())            ## Hello

''' <body> is an expression and result is automatically returned.  '''
# print((lambda x : x+1)(1))              ## 2

''' () arounds lambda parameters is not allowed. '''
# print((lambda (n): 'Hello' + n)())     ## error

''' Lambda parameters are separated by , . '''
# print((lambda a, b : a+b)(1,2))        ## 3

''' Lambda body must be a single expression.  '''
# print((lambda a, b : a + b, a * b)(1,2))    ## error

''' Lambda body expressions may result:
        - a tuple if enclosed with ().
        - a list if enclosed with [].
        - a set or dict if enclosed with {}.
So enclosing a body with {} does not make it a block. '''
# print((lambda x : { 'x': x, 'x+1': x+1 })(1))    # {'x': 1, 'x+1': 2}

''' print() is not a statement, it is an expression(function) that returns a None. '''
# print((lambda: { print('Hello'), print('Hi') })())  ## Hello
                                                      ## Hi
        ## Resulting a None because it is a set.      ## {None}

#--------------------------------------------------------------------

''' Lambda VS Function:
- Lambdas are designed for small(a single expression) while Normal
 functions can be as big as required.
- Unlike normal functions, lambdas do not require adding/removing
 names to/from namespaces
- Lambdas are good for short-life, use-and-forget and passing
 around functions. Normal functions are for long-term and heavy usages.
 '''
def func_namespaces():
    ''' Function definition adds the function name to working namespace. '''
    def hello(name):
        print('Hello', name)
    hello('John')               ## Hello John
    print(dir())                ## ['hello']

    ''' Lambda do not add name to working namespace. '''
    (lambda name: print('Hi', name))('Jack')  ## Hi Jack
    print(dir())                              ## ['hello']
# func_namespaces()

''' Lambdas are function that expressed as expressions.
'function str' is a function that expressed as string and results a str.
It allows embedded expressions inside str literals.
An expression in 'function str' is enclosed with {}. '''
def func_str():
    ''' Expressions in 'function str' are evalulated then results
    are inserted at the positions. '''
    print(f'a{1+2}b')           ## a3b

    ''' The expression may contain function calls. '''
    print(f'{len("John")}')                 ## 4

    ''' Collections projections '''
    l = ['John', 'Jack', 'Joe']
    print(f'Hi {l[1]}')                     ## Hi Jack
    d = { 'first-name': 'Joe', 'last-name': 'Green'}
    print(f'What up? {d["first-name"]}')    ## What up? Joe

    ''' Format characters are supported. '''
    x = 1.23456
    print(f'x = {x:.2f}')       # x = 1.23
# func_str()

#--------------------------------------------------------------------------

''' Functional Programming is a programming paradigm that everything
      are functions, no statements, no side effect, nor iterations.

Aggregation is a mechanism to apply a function to every elements
  in a sequence one by one resulting a stream of results.
That allows programming without explicit loopings.

Python supports aggregarion by a built-in function:
            map(<function>, <sequence>)
<sequence> may be collections, generator, iterable or a range().
<function> may be function, lambda or callable object.

map() returns a generator which generates a result one at a time,
  to get all resultswe must iterate or collect into a collection. '''
sq = lambda n : n*n
# print(list(map(sq, range(5))))        # [0, 1, 4, 9, 16]

''' Decision Aggregation: Python provides a built-in function:
            filter(<predicate>, <sequence>)
<predicate> is applied to elements in <sequence>, if True the element is passed to the result. '''
import math
is_sq_number = lambda n: n == math.sqrt(n) * math.sqrt(n)
# print(list(filter(is_sq_number, range(10))))         ## [0, 1, 4, 9]

''' But comprehension can do the job. '''
# print([ x for x in range(10) if is_sq_number(x) ])   ## [0, 1, 4, 9]

''' 'Reduce' reduces a stream of results into a value.
    'functools' lib has:
             reduce(<function>, <sequence>)
<function> is applied to two successive elements in the <sequence>,
   the result is accumulated to a value. '''
import functools, operator
def reduce_test():
    r = range(1, 11)      ## 1 -> 10

    ''' Sumation '''
    print(functools.reduce(operator.add, r))       ## 55

    ''' Factorial '''
    print(functools.reduce(operator.mul, r))       ## 3628800
# reduce_test()

''' Map-Reduce Programming
    1. Start with a source to provide a stream of input values.
    2. Map or Filter the stream with functions as many as you need.
    3. Reduce or Collect the result stream to a value or a collection.

Ex. To compute summation of even numbers less than 10. '''
def paradigms():
    ''' A filter predicate'''
    is_even = lambda x: x % 2 == 0

    ''' Procedural (Imperative) '''
    r1 = []
    for x in range(10):
        if is_even(x):
            r1.append(sq(x))
    r2 = 0
    for x in r1:
       r2 += x
    print(r2)                           ## 120

    ''' Map-Reduce (Functional) '''
    print(functools.reduce(operator.add,
          map(sq,
          filter(is_even, range(10)))))  ## 120

    ''' Comprehension '''
    print(sum([sq(x) for x in range(10) if is_even(x)]))  ## 120
# paradigms()
