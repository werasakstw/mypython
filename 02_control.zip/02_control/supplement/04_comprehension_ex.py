''' Ex. A farmer say 'My farm has 36 heads and 100 feet altogether,
      but they are just chickens and pigs".
How many chickens and pigs does he have?        '''
def farmer():
    for c in range(36):
        for p in range(36-c, 36):
            if (c+p == 36) and (c*2 + p*4 == 100):
                print(c, p)
# farmer()
''' Using comprehension
[ print(c, p)
    for c in range(36)
    for p in range(36-c, 36) if (c+p == 36) and (c*2 + p*4 == 100) ]
'''

''' Ex. A monkey ate 100 coconuts in 5 dates, each day ate 6 more than
 the previous day. How many coconuts did he eat on each days? '''
def monkey():
    for a in range(100):      ## The range may be optimized.
        for b in range(100):
            if (6+a == b):
                for c in range(100):
                    if (6+b == c):
                        for d in range(100):
                            if (6+c == d):
                                for e in range(100):
                                    if (6+d == e) and (a+b+c+d+e == 100):
                                        print(a, b, c, d, e)
# monkey()
''' Using comprehension
[ print(a, b, c, d, e)
    for a in range(100)
    for b in range(100) if (6+a == b)
    for c in range(100) if (6+b == c)
    for d in range(100) if (6+c == d)
    for e in range(100) if (6+d == e) and (a+b+c+d+e == 100) ]
'''

''' Ex. There is a flock of birds and herd of cows.
  If a brid rest on back of a cow there will be a bird left.
  If two brids rest on a cow there will be a cow left.
Find the smallest numbers of birds and cows. '''
def brids_cows():
    for b in range(100):
        for c in range(100):
            if (b - c == 1) and (c - b/2 == 1):
                print(b, c)
                break
# brids_cows()
''' Comprehension cannot 'break' the iteration,
But the <item> to be processed can be filtered.
[ print(b, c)
    for b in range(10)
    for c in range(10) if (b - c == 1) and (c - b/2 == 1) ]
'''

#-------------------------------------------------------------------

''' Solving equations with 'generate and test':
In schools, we needed n equations to find solutions for n variables.
Generate and Test can generate any number of variables to satisfy
  any number of equations, but the ranges must be specified.
Ex. Find solutions for the equation:
         x(x+1) = y(y+1)(y+2)
For all 0 < x, y < 100.             '''
def solv_eq():
    print([ (x, y) for x in range(1, 100)
                   for y in range(1, 100)
                        if x*(x+1) == y*(y+1)*(y+2) ])
# solv_eq()

''' Exercises:
1. Find four consecutive odd numbers which their sum is exactly 80.
 Hint:    x + (x+1) + (x+2) + (x+3) == 80
                             x % 2  == 1
     Guess the optimum range to search for x.

2. For 0 < x < y < z < 10, find solutions for the following equations:
      2.1.    x + y + z = x * y * z
      2.2.    x**3 + y**3 + z**3 == 6**2
      2.3.    x**3 + y**3 + z**3 == 6*x*y*z        '''

''' Logic Puzzle:
Ex. Pork and Chicken.
A, B, and C always have lunch together.
    (1). If A order chicken, then B order pork.
    (2). Either A or C order chicken.
    (3). At least one of B and C order chicken.
Who do not eat pork?
'''
def pork_chicken():
    def test1(a, b):
        # if a == 'chicken' and not (b == 'pork'):
        #     return False
        # return True
        return False if a == 'chicken' and not (b == 'pork') else True

    def test2(a, c):
        return True if (a == 'chicken' and c == 'pork') or \
                        (a == 'pork' and c == 'chicken') else False

    def test3(b, c):
        return True if b == 'chicken' or c == 'chicken'else False

    order = ['pork', 'chicken']
    [print('A = %s     B = %s     C = %s' % (a, b, c))
        for a in order for b in order for c in order
            if test1(a, b) and test2(a, c) and test3(b, c)
    ]
# pork_chicken()

#---------------------------------------------------------------------

''' Ex. Leap year problems using comprehension.
Import is_leap_year() to be used here.

1. All Leap years from 2020 to 2112. '''
# print([y for y in range(2020, 2100) if is_leap_year(y)])

''' 2. All years from 2020 to 2112 that divisible by 4 but not a leap year. '''
# print([y for y in range(2020, 2112) if y % 4 == 0 and not is_leap_year(y)])

''' 3. All years from 2020 to 3000 that divisible by 100 but is a leap year. '''
# print([y for y in range(2020, 3000) if y % 100 == 0 and is_leap_year(y)])
