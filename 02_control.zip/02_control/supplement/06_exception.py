''' When an illegal operation is encountered, Python runtime creates and
  raises an execption. Exceptions are objects that carry error information.
Programs may detect an exception with 'try-except' construct.
If an exception is catched and handled, the program execution may go on.
That allows programs to recover from errors.
If an exception is not catched, it will be propagated to next level scope.
If the exception is not handled it will reach the Python runtime and
  be handled by default:
       - print the stack trace and the exception info.
       - stops the program.

Exceptions may be raised by:
    - The Python runtime.
    - A running program.            '''
def excep_ex():
    a = [0, 1, 2]
    # print(a[3])       ## IndexError (out-of-bound)

    x = 0
    # print(1/x)        ## ZeroDivisionError

    # print(1 + '1')    ## TypeError

    d = { 'john': 1 }
    # print(d['jack'])  ## KeyError
# excep_ex()

''' 'try-except' is a statement of the form:
               try:
                   <try block>
               except:
                   <except block>
               [finally:
                   <finally block>]
<try block> is executed unconditionally.
While <try block> is executed, if an exception is raised
 the rest statements are ignored, the exception object is created
 and passed to the <except block> and be executed.
Otherwise the execution continues at the next statement.
After the error is handled in <except block> execution proceed
  the next statement. '''
a = [0, 1, 2]
def index_acc(n):
    try:
        print(a[n])
    except:           ## catch all exception types
        print('Index out of bound.')
# index_acc(1)        ## 1
# index_acc(3)        ## Index out of bound.

''' 'Exception' class is the super class of all exception.
Ex. 'IndexError' is a descendant class of 'Exception'. '''
# print(isinstance(IndexError(), Exception))  # True

''' Exceptions may be catched by matching with type.
         except <exception type> as <object>
<object> is an exception object that contains information about the error.
<exception type> is an exception class.

A 'try' block may raise exceptions of many types.
But there can be only the first one that is actually raised.
A 'try' block may be followed by multiple 'execpt' blocks for catching each types. '''
def mul_catch(n):
    try:
        print(a[n])
    except IndexError as err:
        print(err)
    except Exception as err:
        print(err)
# mul_catch(1)        ## 1
# mul_catch(3)        ## list index out of range
# mul_catch(None)     ## list indices must be integers or slices, not NoneType

''' The order of catching child/parent classes is no matter. '''
def catch_order(n):
    try:
        print(a[n])
    except Exception as err:
        print(n, err)
    except IndexError as err:
        print(n, err)
# catch_order(3)
# catch_order(None)

''' A 'finally' block is optional, if there is the finally block will alway
     be executed, even there is a 'return' statement is executed or another
     exception is raised. '''
def try_finally(n):
    try:
        print(1/n, end=', ')
        if n == 2:
            return          # abnormal abort
    except ArithmeticError as err:
        print(err, end=', ')
        raise Exception()
    finally:
        print('finally')

def try_finally_test():
    try:
        try_finally(0)      ## division by zero, finally
    except:
        print('exception')  ## exception
    try_finally(1)          ## 1.0, finally
    try_finally(2)          ## 0.5, finally
# try_finally_test()

''' Finally in loop '''
def fin_loop():
    for i in range(5):
        print(i, end=', ')
        try:
            print(1/i, end=', ')
            if i == 2:
                continue
            elif i == 3:
                break
        except ArithmeticError as err:
            print(err, end=', ')
        else:
            print('else', end=', ')
        finally:
            print('finally')
# fin_loop()        ## 0, division by zero, finally
                    ## 1, 1.0, else, finally
                    ## 2, 0.5, finally
                    ## 3, 0.3333333333333333, finally

#---------------------------------------------------------------

''' We can create our Exception class, to provide a proper name and
      and carry error information.
There is the 'Exception' class already defined to be parent of exception classes. '''
# raise Exception()

''' Ex. To create our Exception class by sub-classing 'Exception'.  '''
class MyException(Exception):
    pass    ## We can define members for error information here.
# raise MyException()

''' Do not use 'try' as decision. Since a simple if-else is more effective. '''
def bad_except():
    def greet(name):
        try:
            if name == 'John':
                raise MyException()
            print('Hello ', name)
        except MyException:
            print('Hi ', name)

    greet('John')       #  Hi  John
    greet('Jack')       #  Hello  Jack
# bad_except()

''' The places that raise and catch exception should be in the different scope. '''
def good_except():
    def greet(name):
        if name == 'John':
            raise MyException()
        print('Hello ', name)

    def caller(name):
        try:
            greet(name)
        except MyException:
            print('Hi ', name)

    caller('John')      ##  Hi  John
    caller('Jack')      ##  Hello  Jack
# good_except()

''' A valid use case of 'try' is 'transaction' which is a sequence of
      operations that must be completed as a whole, unless roolback.
Ex. A normal database transaction:
          turn auto-commit off
          try:
              operation1()
              operation2()
              ....
              commit()
          except:
              roolback                   '''
def transaction():
    class Exception1(Exception):
        pass
    class Exception2(Exception):
        pass

    def op1():
        raise Exception1()
    def op2():
        raise Exception2()

    ''' Independence Operations '''
    try:
        op1()
    except Exception1:
        print('S1')         #  S1
    try:
        op2()
    except Exception2:
        print('S2')         #  S2

    ''' Transaction '''
    try:
        op1()
        op2()
    except Exception1:
        print('S1')         #  S1
    except Exception2:
        print('S2')
# transaction()

#-------------------------------------------------------------------

''' Assertion: is a debug mechanism that used for detecting errors
       during development time.
If a program violates an assert expression, an exception is
  raised forcing the program to exit with no recovering.
           assert <expression>
           assert <expression>, <error message>
It is equivalent to:
       if __debug__:     ## The program is running in debug mode.
           if not <expression>:
               raise AssertionError(<error message>)       '''
def assertion(x):
    print(__debug__)
    assert x == 0
    # assert x == 0, 'x must be zero.'
# assertion(0)
# assertion(1)

''' Assertions should be used in development, not in production.
Assertions should never be used for validation/authentication.
Since it can be turn off by setting __debug__.

Assertion will be disabled if Python performs optimization.
python -O exception.py

Alternatively.
set PYTHONOPTIMIZE=1
python exception.py

Beware: Do not wrap <expression>, <error message> in ( ) that
makes it a tuple and always True.  '''
x = 1
# assert (x == 0, 'x must be zero.')
