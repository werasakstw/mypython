''' Functions abstract complexity of computation.
Functions allow us to compute something without knowing exactly how to do.

 Ex. Converting between Celsius(C) and Fahrenheit(F):
                F = C * (9/5) + 32           '''
def to_fahrenheit(c):
     return c*(9/5) + 32
 # print(to_fahrenheit(0))

''' Ex. Wind Chill Index:
In winter, strong wind make we feel cooler than real temperatures.
In 2001, Canada, United Kingdom and United States defined the formula:
  wind_chill_index = 13.12 + 0.6215*T - 11.37*V**0.16 + 0.3965*T*V**0.16
T is the real temperature in Celsius which must be lower than 10 Celsius
V is the wind speed in kilometers/hour which must be greater than 4.8 kilometers/hour. '''
def wind_chill_index(t, v):
    wci = 13.12 + (0.6215*t) - (11.37*v**0.16) + (0.3965*t*v**0.16)
    return '%.2f' % wci
# print(wind_chill_index(0, 60))

''' Python provides 'math'lib  as a standard package that needed to be import'.
 Using library or someone else allow us to work with the functions without
   knowing how the results are computed.     '''
import math

 ''' Ex. Droppin an object with initial speed 'u' meters/sec from the
   height 'h' meters, assume the earth gravity is 9.8 meters/(sec**2)
 The object will hit the ground at speed v = sqrt(u**2 + 2*g*h).
 'math' lib provides sqrt(<number>) for computing the square root of <number>. '''
 def speed(u, h):
     return math.sqrt(u**2 + 2 * 9.8 * h)
 # print('%.2f' % speed(0, 100))               ## 44.27

 ''' 'math' lib also provides some wellknown constants.
 Ex. Compute circle area: pi*(r**2) where r is the radius length. '''
 def circle_area(r):
     return math.pi*(r**2)
 # print('%.2f' % circle_area(123))           ## 47529.16

 ''' Exercises: Computing distances on earth.
 The Earth is sphere, two long distance points are not on a stright line.
    Given (t1, g1) and (t2, g2) are (latitude, longitude) of two points.
    The distance between two points is computed by:
       distance = 6371.01*arccos(sin(t1)*sin(t2) +
                   cos(t1)*cos(t2)*cos(g1 - g2))
       where latitudes and longitude are in degrees
             6371.01 is the earth radius in kilometers.
    Write a function distance(t1, g1, t2, g2) to compute the distance.
 Hint: 'math' lib provides sin(<radian>), cos(<radian>), arccos(<radian>).
      math.radians(<degree>) return <radian>.    '''
