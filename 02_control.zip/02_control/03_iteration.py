''' Loops are controls for execute a block repeatedly.
Iterations are loops to perform some task on every elements of a range or collection.
There are two kinds of loops:
1. 'for' loop is a statement. It is deterministic which the number of
     iteration (round) can be perdetermined.
            for <variable> in <iterable>:
                <block>
<block> must begin with a : even there is only statement.
Each 'for' loop has its own scope and <variable> is local to the scope.
<iterable> is an object that produces item one at a time.
    e.g. string, range, sequence(list, tuple, set, dict).  '''
def for_loop():
    ''' Iterate sequences or range '''
    a = [1, 2, 3]
    # a = range(3)
    for x in a:
        print(x, end=', ')
    print()

    ''' 'for' uses iterator to access elements, indexing is not encouraged. '''
    for i in range(len(a)):
        print(a[i], end=', ')      ## 1,2,3,
    print()
# for_loop()

'''   2. 'while' loop is a statement, it is non-deterministic which means
  termination cannot be predetermined.
               while <condition>:
                   <body>
 'while' loop executs the <body> as long as the <condition> is true.
<condition> is an expression that results a boolean which may contain:
     Logical operations:   and, or, not
     Comparison operations: <, ==, !=, >, <=, >=
'while' loop has more general terminate conditions then 'for' loop. '''
def while_loop():
    n = 0
    while n < 3:
        print(n, end=', ')
        n += 1
    print()
# while_loop()

#--------------------------------------------------------------------

''' Disrupting Loop: applyable to both 'for' and 'while'.
        'break' skips the rest loop.  '''
def for_break():
    for i in range(5):
        if i == 2:
            break
        print(i, end=',')           ## 0,1,
    print()
# for_break()

''' 'continue' skips the round.  '''
def for_continue():
    for i in range(5):
        if i == 2:
            continue
        print(i, end=',')           ## 0,1,3,4,
    print()
# for_continue()

#---------------------------------------------------------------

''' Python does not allow assignments be coerced(auto conversed
  to boolean) for conditions. '''
# while s = input('Enter: '):   ## error
#    print(s)

''' That mades looping input so clumsy. '''
def clumsy():
    s = input('Enter: ')
    while s != '':
        print(s)
        s = input('Enter: ')
# clumsy()

''' Python 3.8 introduced Assignment Expression (:=). '''
def assign_exp():
    while s := input('Enter: '):
        print(s)
        if s == '':
            break
# assign_exp()
