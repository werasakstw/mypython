''' Default execution is sequential flow.
'Controls' are machanisms that change execution flows.

'if' statement is a control for making decision.
                if <condition>:
                    <if block>
                [ elif <condition>:
                    <elif block> ]*
                [ else:
                    <else block> ]
<condition> must be boolean and no needs to be surrounded by ().
<if block>, <elif block> and <else block> have their own block,
  that must begin with : even there is only one statement.    '''
def simp_if(x):
    if x == 1:
        print('One')
    print('End')
# simp_if(1)
# simp_if(2)

''' else: is optional and needs : to open its block. '''
def if_else(x):
    if x == 1:
        print('One')
    else:
        print('Else')
    print('End')
# simp_if(1)
# simp_if(2)

''' Python allows 'nested if' and uses indentation to determines
  how 'if' and 'else' are paired.  '''
def nest_if(x, y):
    if x == 1:
        if y == 2:
            print('One, Two')
    #	else:
    #	    print('Other 1')
    else:
        print('Other 2')
# nest_if(1, 3)
# nest_if(2, 3)

''' 'elif' is used to avoid nested layers of mutilple cases. '''
def if_elif(x):
    if x == 1:
        print('One')
    elif x == 2:
        print('Two')
    elif x == 3:
        print('Three')
    else:
        print('Else')
# if_elif(0)
# if_elif(1)

''' 'Conditional' is an expression that returns a result.
        <true return> if <condition> else <false return>    '''
x = 2
# print('Few' if x <= 3 else 'Many')

################################################################

''' Ex. Leap Years.
The Earth takes 365(1/4) days and a little bit to orbit the Sun.
So February 29, is included in some years to correct the extra times.
Such the years are called 'leap years'.

To determine whether a year is a leap year:
   If the year is divisible by 400 it is a leap year.
   Else if it is divisible by 100 it is not a leap year.
   Else if it is divisible by 4 it is a leap year.
   All the remains are not leap years.
'''
def is_leap_year(year):
    if year % 400 == 0:
        return True
    elif year % 100 == 0:
        return False
    elif year % 4 == 0:
        return True
    return False
''' 2000 is a leap year but 1000 is not.  '''
# print(is_leap_year(2000), is_leap_year(1000))

''' To check that a date (day, month, year) is valid, for years 1754 to 2200. '''
def is_valid_date(d, m, y):
    if d < 1 or d > 31 or m < 1 or m > 12 or y < 1753 or y > 2199:
        return False
    if m == 2:      ## February
        if is_leap_year(y) and d <= 29:
            return True
        if d > 28:
            return False
    if (m == 4 or m == 6 or m == 9 or m == 11) and d == 31:
        return False
    return True
# print(is_valid_date(29, 2, 2020), is_valid_date(29, 2, 2023))

#----------------------------------------------------------------

''' Diagnostic:
Ex. Body Mass Index(BMI): a simple health indicator.
             bmi = weight / (height**2)
  where weight is in kilograms and  height in meters.
An interpretation:
                 bmi             status
             < 18.5              Underweight
         18.5 - 24.9             Normal
         25.0 - 29.9             Overweight
         30.0 - 34.9             Obesity class I
         35.0 - 39.9             Obesity class II
              > 40               Obesity class III                  '''
def bmi(w, h):
    b = w / (h**2)
    if b < 18.5:
        return 'Underweight'
    if 18.5 < b < 24.9:
        return 'Normal'
    if 25.0 < b < 29.9:
        return 'Overweight'
    if 30.0 < b < 34.9:
        return 'Obesity class I'
    if 35.0 < b < 39.9:
        return 'Obesity class II'
    return 'Obesity class III'
# print(bmi(75, 1.65))

#-----------------------------------------------------------

''' Classification:
Ex. Student Grades.
Suppose a student grades is determined by total scores(scaled to 100):
                 90 <= total      A
                 80 <= total      B
                 65 <= total      C
                 50 <= total      D
                  otherwise       F     '''
def to_grade(total):
    if 90 <= total:
        return 'A'
    elif 80 <= total:
        return 'B'
    elif 65 <= total:
        return 'C'
    elif 50 <= total:
        return 'D'
    return 'F'
# print(to_grade(84), to_grade(44))

''' Alternatively: Student Grades with conditional.  '''
def to_grade_(t):
    return 'A' if 90 <= t else 'B' if 80 <= t else 'C' \
            if 65 <= t else 'D' if 50 <= t else 'F'
# print(to_grade_(84), to_grade_(44))
