''' 'Expression' may be
        - literal
        - variable
        - term of operations e.g.  x+1
        - function call      e.g.  hello('John')
   which return a value as a result.
Expressions appear in positions that need values.
  e.g. arguments to functions and right hand side of assignments.
But Python allows expression at statement levels which do not
  need value and the values are ignored. '''

0                  ## A literal.
1 + 2              ## An expression.

x = 1               ## A variable definition creates a variable.
x
x + 1

#------------------------------------------------------------

''' 'Statement' is a unit of execution, it appears where a
  value is not needed.
A statement does not return values, not even a None.
Definition and Assignment are statements.
                    <variable> = <expression>

'Definition' is the first time that a variable is assigned with a value.
The variable is created and assigned with the value. '''
x = 1 + 2

''' Assignments is an already created variable is assigned with a value. '''
x = 0

''' Assignments are not allowed in place of arguments and in conditions of 'if' nor 'while'. '''
# print(x = 1)                  ## error
# if x = 1:                     ## error
#     x +=1

''' Assignment chains are allowed but not with (). '''
y = x = 1
# y = (x = 1)                   ## error

''' Function definitions are statements, no values returned.
A function definition cannot be assigned to a name. '''
# f = def func(): pass          ## error

''' Controls are statements. Chjeck with: 'if', 'for', and 'while'.

#------------------------------------------------------------------

'Block' is a sequence of statements.
Python uses indentation to define blocks.
Statements in the same block must be equally indented.
The top level of the file scope is the 'global block'.    '''
# print('Hello')
# print('Hi')
##   print('Error')     # error

''' Functions and controls have their own blocks that created as
  a nested block in the current block.
 A : is needed to specify that a new block is created here
   and all statements in the new block must be indented to a next level. '''
def greet():
    print('Hello')
    print('Hi')
    # print('Error')     # error
# greet()
