''' A namespace is a collection of named objects.
A scope is an area(in source code) where a namespace is defined.
A scopes is defined by a block (of control, function, class) or file.
Scopes can be nested.
'Scope Rules' are rules that define how to determine which name refers
   to which objects. '''
def scope_rules():
    ''' 1. A name must be defined in a scope before it can be referred. '''
    # print(x)      ## error
    x = 0
    print(x)        ## 0

    ''' 2. A name can be shadowed(redfined) in the same scope. '''
    x = 1
    print(x)        ## 1
    ''' Funcation names may be shadowed in the same scope.
    Python does not allow function overloading(in the sense as Java). '''
    def greet():
        print('Hello')
    def greet(name):
        print('Hi', name)
    # greet()         ## error
    greet('John')     ## Hi John

    ''' 3. An inner scope may refer to names in outer scopes. '''
    def f():
        print(x)
    f()             ## 1

    ''' 4. An inner scope may shadow names in outer scopes. '''
    def f():
        x = 2
        print(x)    ## 2
    f()
    print(x)        ## 1

    ''' 5. In an inner scope, after the name is referred to it cannot be
      shadowed with name in the outer scope. '''
    def f():
        print(x)
        x = 2       ## error
    # f()

    ''' 6. An inner scope cannot modify the outer scope variables. '''
    def f():
        x += 1      ## error
    # f()

    ''' Python applies static(lexical) scope rules, that means names
     are bound by lexical scope, not by calling stack scope. '''
    def f():
        print(x)    ## 1
        ## x bound to x in the outer scope, not to scope where calling from.
    def ff():
        x = 2
        f()
    ff()
# scope_rules()

''' In inner scopes cannot directly modify variables of outer scope.
'global' binds local name to global name and allows modification. '''
x = 1
def global_test():
    global x
    x += 1
    print(x)                ## 2
# global_test()
# print(x)                  ## 2

''' 'nonlocal' binds local name the outer scope names, that is not global. '''
y = 1
def nonlocal_test():
    y = 2
    def f():
        # global y          ## Try:
        nonlocal y
        print(y)            ## 2
    f()
# nonlocal_test()
#-------------------------------------------------------------------

''' Python control blocks do not create namespaces.
dir() returns a list of names in current scope.  '''
def control_blocks():
    a = 1
    if a < 0:
        m = 2    ##  'm' is not created.
    else:
        n = 3    ##  'n' is created and added to the function's namespace.
    print(dir())    # ['a', 'n']
    ''' Whether 'm' or 'n' is created depends on the flow of program. '''

    for i in range(2):
        d = 2    ##  'i' and 'd' are created and added to the function's namespace.
    print(dir())    # ['a', 'd', 'i', 'n']
    ''' So 'i' is not local to the 'for' block. '''
# control_blocks()

''' Scopes are created at the start of the function execution and
      destroyed when the function exits. '''
def dynamic_scope():
    a = 1
    print(dir())            ##  ['a']

    def f():
        print(dir())        ##  []
        b = 2
        print(dir())        ##  ['b']

        ''' If an outer name is referred to, it is added to the current namespace. '''
        # print(a)          ## Try: uncomment this line
    f()

    print(dir())            #  ['a', 'f']
# dynamic_scope()

''' All names created in a scope are added to the namespace.
To prevent adding unnecessary names, uses _ for "don’t care".
However all "don’t care" names are added as '_'.     '''
def single_():
    ''' Tuple unpacking '''
    x, y, _ = (1, 2, 3)
    print(dir())        #  ['_', 'x', 'y']

    ''' Unindex loop '''
    for _ in range(3):
        print('Hello', end=',')
    print()

    print(dir())        #  ['_', 'x', 'y']
# single_()
