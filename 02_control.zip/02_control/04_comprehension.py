''' 'for' loops are statements.
    'comprehension' is an expression that returns a result.
The results may be list, set, dict, but not tuple.   Check with: generator
Comprehension is defined as:
        <expression> for <item> in <iterable> if <condition>
<item> is taked from <iterable> one at time if the <condition> is true.
<expression> is applied to <item> then collected in the result of the conprehension.

 A comprehension is an expression. '''
 # print([n for n in range(3)])        ## [0, 1, 2]

''' <expression> is applied to <item>, results are collected and returned. '''
 # print([n**2 for n in range(5)])     ## [0, 1, 4, 9, 16]

''' <condition> is a boolean filter to allow <item> to be in the result.
 <condition> is optional if not present all elements will be processed.
 Ex. To compute a list of n**2 where n is even in range(10).  '''
 # print([n**2 for n in range(5) if n % 2 == 0])   ## [0, 4, 16]

''' Comprehension is more concise and efficient than 'for' loop. '''
def for_even_sq():
    a = []
    for n in range(5):
        if n % 2 == 0:
            a.append(n**2)
    print(a)                        # [0, 4, 16]
# for_even_sq()

''' The result of comprehension may be collected as:
A list if enclosed with [].
A set if enclosed with {}.
A dict if enclosed with {} and <expression> is <key>:<value>.
Enclosing comprehension with () results a 'generator', not a tuple. '''
# print([x for x in 'Hello'])             ##  ['H', 'e', 'l', 'l', 'o']
# print({x for x in 'Hello'})             ##  {'o', 'H', 'l', 'e'}
# print({x:x.isupper() for x in 'John'})  ##  {'J': True, 'o': False, 'h': False, 'n': False}

''' <expression> may be <key>:<value> to define elements of dict as the result. '''
grades = ['D', 'A', 'C', 'B', 'F', 'C', 'C', 'B']
# print({g:grades.count(g) for g in grades})
                     ## {'D': 1, 'A': 1, 'C': 3, 'B': 2, 'F': 1}

''' <item> defines how to match elements in the <iterable>. '''
# print([a+b for (a, b) in [(1,2),(3,4),(5,6)]])      ## [3, 7, 11]
# print({x:v for (x, v) in zip([1, 2, 3], ['a', 'b', 'c'])})
                         ## {1: 'a', 2: 'b', 3: 'c'}

''' Multiple comprehensions are more concise and faster than multiple 'for' loops.
Comprehension does not create a new block.
Comprehension can be nested and does not need indentations.
But line saparation improves readability. '''
# print([(x, y) for x in [1, 2]
 #              for y in ['a', 'b']])
         ## [(1, 'a'), (1, 'b'), (2, 'a'), (2, 'b')]

''' Performance comparison  between 'for' loop and comprehension.
Ex. To create a large list filled with numbers. '''
from time import perf_counter as pc
def performance_test():
    r = range(10**7)

    ''' Using 'for' loop '''
    start = pc()
    a = []
    for i in r:
        a.append(i)
    stop = pc()
    print(stop - start)

    ''' Using comprehension '''
    start = pc()
    b = [i for i in r]
    stop = pc()
    print( stop - start)
# performance_test()
