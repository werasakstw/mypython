''' Function definition is a statement that creates a function.
            def <function name>(<parameters>):
                <block>
Functions have thier own block that begins with colon(:).
A function can only be called(invoked) after its definition.
A function may return or not return a value.       '''
def hello():
    print('Hello')
# hello()

''' 'Arguments' are values that passed from the caller side.
    'Parameters' are values that passed to the function side.
That allows a function to be used in different contexts.
Parameters are defined without type. '''
def hi(name):
    print('Hi', name)
# hi('John')

''' 'Return Values' are value returned as the result of a function.
A function may return a value, if it is the value must be explicitly
  returned with 'return'.
Return types are not defined.       '''
def whatup(name):
    return 'What up %s?' % name
# print(whatup('Jack'))

''' Python allows nested function definitions.  '''
def outter(name):
    print('Start')
    def inner(n):
        return 'Hello ' + n
    print(inner(name))
# outter('John')

''' A function definition without its block is an error.
'pass' is a keyword to denote an empty body block. '''
def empty_function():
    pass

''' 'Doc String' is meta information of a function.
A doc string is defined between the head and body of the function.
It is bound to the __doc__ attribute.
If a function has a doc string, 'pass' is optional.
PEP257 defines what should be a docstring.
The doc string is shown when the function is passed to help(). '''
def func():
    '''This is a doc string.'''
    pass
# print(func.__doc__)
# help(func)

''' A function definition with the same name as an already exist
  is not an error, but it overrides the existing one.
So Python has no function overloading (in the sense as Java). '''
def hello(name):
    print('Hello ' + name)
# hello('John')       ## Hello John
# hello()             ## error

''' Parameter types are not defined so argument types may be vary
  as long as operations on parameters are valid. '''
def add(a, b):
    return a + b
# print(add('Hello ', 'John'))    ## Hello John
# print(add(1, 2))                ## 3
# print(add('1', 2))              ## error

'''  Return types are not defined so a function may return different types. '''
def return_type(x):
    if x == 1:
        return 1
    return 'A'
# print(return_type(1), return_type(2))   # 1 A

''' A function returns a value, but it may be a tuple which has more than one values.  '''
def return_tuple():
    return 1, 2     ## Check with: Tuple packing
# x, y = return_tuple()
# print(x, y)      ## 1 2
