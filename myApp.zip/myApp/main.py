
from flask import Flask, render_template, request
from myutil import *

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

import csv
@app.route('/prepare', methods=['POST'])
def perpare():
   # verify admin password
   adminpwd = request.form['pwd']
   if not is_valid_pwd(adminpwd):
      return 'Invalid password'
   
   # create 'nameaddr' stream
   r = api.create('stream', 'nameaddr', True)
   try:
      if r['error']:
         return str(r['error']['message'])
   except:
      api.subscribe('nameaddr')

   # publish admin address to 'nameaddr'
   adminaddr = get_admin_addr() 
   api.publish('nameaddr', 'admin', str_hex(encode(adminaddr, adminpwd)))

   # create 'names' stream 
   r = api.create('stream', 'names', True)
   try:
      if r['error']:
         return str(r['error']['message'])
   except:
      api.subscribe('names')

   # read users list and publish to 'names' and 'nameaddr'.
   try:
      c = 0
      with open('data/users.csv') as f:
         for r in csv.DictReader(f):
            api.publish('names', 'name', str_hex(r['name']))
            c += 1
            print(r['name'])
      return 'There are %d users.' % c
   except:
      return 'Error reading users, please reset the Blockchain'

#####################################################

@app.route('/registeruser', methods=['POST'])
def register_user():
   name = request.form['name']
   if not is_valid_name(name):
      return 'Invalid user'

   if is_registered(name):
      return 'The voter is already registered'

   api.publish('names', 'registered', str_hex(name))
   addr = api.getnewaddress()
   api.grant(addr, 'send,receive')
   pwd = gen_pwd()
   api.publish('nameaddr', name, str_hex(encode(addr, pwd)))
   return '{"name": %s, "pwd": %s, "addr": %s}' % (name, pwd, addr)

##------------------------------------------------------

if __name__ == '__main__':
    app.run(port=8080, debug=True)


