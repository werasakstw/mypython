from myutil import *

def gen_pwd_test():
    for _ in range(10):
        pwd = gen_pwd()
        print(gen_pwd(), is_valid_pwd(pwd))
##gen_pwd_test()

def list_streams():
    for s in api.liststreams():
        print(s['name'])
##list_streams()

def print_stream_items(stream):
    for i in get_stream_items(stream):
        print(i)
print_stream_items('names')
##print_stream_items('nameaddr')

##print(is_valid_name('john'))
##print(is_registered('john'))        
##print(is_valid_name_addr('john','1G3boruhc22xK3AW5maYHTqoMifNzbxzizBHC'))

##print(count_items('names'))
##print(count_items('nameaddr'))

##print(get_admin_addr())

##print(get_user_addr('jack'))

